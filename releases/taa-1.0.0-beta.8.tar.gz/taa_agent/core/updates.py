"""Local TAA update checker / downloader / detached installer.

Design defaults:
  mode=download
  check_at=10:07,20:07 local time
  no more than 2 automatic checks/day and 1 automatic apply/day

The updater never copies data itself; it invokes ``taa_upgrade.py`` which owns
the protected-data/atomic-swap/rollback contract.
"""
from __future__ import annotations

import hashlib
import json
import os
import random
import re
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
HOME = Path(os.environ.get("TAA_HOME") or (Path.home() / ".taa")).expanduser()
STATE = HOME / "update.json"
UPDATES = HOME / "updates"
DEFAULT_URL = os.environ.get(
    "TAA_UPDATE_URL",
    "https://raw.githubusercontent.com/jiyanjiang/team_ai_alice/main/releases/latest.json",
)
LOCK = threading.Lock()
_scheduler_started = False

DEFAULT = {
    "enabled": True,
    "mode": "download",          # notify | download | auto
    "channel": "beta",
    "check_at": ["10:07", "20:07"],
    "jitter_seconds": 600,
    "last_check_at": "",
    "last_check_day": "",
    "checks_today": 0,
    "checked_slots": [],
    "last_apply_at": "",
    "last_apply_day": "",
    "applies_today": 0,
    "latest": None,
    "downloaded": None,
    "last_error": "",
    "last_result": "",
}


def _load() -> dict:
    data = dict(DEFAULT)
    try:
        raw = json.loads(STATE.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            data.update(raw)
    except Exception:
        pass
    today = date.today().isoformat()
    if data.get("last_check_day") != today:
        data["last_check_day"] = today
        data["checks_today"] = 0
        data["checked_slots"] = []
    if data.get("last_apply_day") != today:
        data["last_apply_day"] = today
        data["applies_today"] = 0
    return data


def _save(data: dict) -> None:
    HOME.mkdir(parents=True, exist_ok=True)
    tmp = STATE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    try:
        tmp.chmod(0o600)
    except OSError:
        pass
    os.replace(tmp, STATE)


def current_version() -> str:
    for p in (ROOT / "VERSION", ROOT / "dist" / "VERSION"):
        try:
            v = p.read_text(encoding="utf-8").strip()
            if v:
                return v
        except OSError:
            continue
    return "0.0.0"


def _ver(v: str) -> tuple:
    m = re.match(r"^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?", str(v or ""))
    if not m:
        return (0, 0, 0, 0, ())
    pre = tuple(int(x) if x.isdigit() else x for x in (m.group(4) or "").split(".") if x)
    return (int(m.group(1)), int(m.group(2)), int(m.group(3)),
            0 if pre else 1, pre)


def version_gt(a: str, b: str) -> bool:
    return _ver(a) > _ver(b)


def _fetch(url: str, timeout: int = 15) -> dict:
    req = urllib.request.Request(url, headers={"user-agent": "TAA-Updater/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read(2_000_000)
    data = json.loads(raw.decode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError("latest.json is not an object")
    return data


def _safe_download(url: str, dest: Path, sha: str, size: int = 0) -> None:
    UPDATES.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(dest.suffix + ".part")
    h = hashlib.sha256()
    total = 0
    req = urllib.request.Request(url, headers={"user-agent": "TAA-Updater/1.0"})
    with urllib.request.urlopen(req, timeout=60) as resp, part.open("wb") as out:
        while True:
            chunk = resp.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if size and total > size:
                raise ValueError("package larger than manifest")
            h.update(chunk)
            out.write(chunk)
    if sha and h.hexdigest() != sha:
        part.unlink(missing_ok=True)
        raise ValueError("package sha256 mismatch")
    if size and total != size:
        part.unlink(missing_ok=True)
        raise ValueError("package size mismatch")
    os.replace(part, dest)


def status() -> dict:
    s = _load()
    latest = s.get("latest") or {}
    downloaded = s.get("downloaded") or {}
    return {
        "current": current_version(),
        "latest": latest.get("version", ""),
        "available": bool(latest.get("version") and version_gt(str(latest["version"]), current_version())),
        "mode": s.get("mode", "download"),
        "check_at": s.get("check_at", []),
        "last_check_at": s.get("last_check_at", ""),
        "last_error": s.get("last_error", ""),
        "downloaded": downloaded.get("path", ""),
        "downloaded_version": downloaded.get("version", ""),
        "last_result": s.get("last_result", ""),
        "notes_url": latest.get("notes_url", ""),
        "bytes": latest.get("bytes", 0),
    }


def check(force: bool = False) -> dict:
    with LOCK:
        s = _load()
        if not s.get("enabled", True) and not force:
            return {"ok": False, "error": "updates disabled", **status()}
        try:
            latest = _fetch(DEFAULT_URL)
            if str(latest.get("product") or "TAA") != "TAA":
                raise ValueError("not a TAA manifest")
            s["latest"] = latest
            s["last_error"] = ""
            s["last_result"] = "checked"
            s["last_check_at"] = datetime.now().isoformat(timespec="seconds")
            s["last_check_day"] = date.today().isoformat()
            s["checks_today"] = int(s.get("checks_today") or 0) + 1
            slot = f"{date.today().isoformat()}T{datetime.now().strftime('%H:%M')}"
            slots = list(s.get("checked_slots") or [])
            if slot not in slots:
                slots.append(slot)
            s["checked_slots"] = slots[-6:]
            _save(s)
            available = bool(latest.get("version") and version_gt(str(latest["version"]), current_version()))
            if available and s.get("mode") in ("download", "auto"):
                try:
                    download()
                except Exception as exc:  # noqa: BLE001
                    s = _load()
                    s["last_error"] = str(exc)
                    _save(s)
            return {"ok": True, **status()}
        except Exception as exc:  # noqa: BLE001
            s = _load()
            s["last_error"] = str(exc)
            s["last_check_at"] = datetime.now().isoformat(timespec="seconds")
            _save(s)
            return {"ok": False, "error": str(exc), **status()}


def download(force: bool = False) -> dict:
    s = _load()
    latest = s.get("latest") or {}
    ver = str(latest.get("version") or "")
    if not ver:
        return {"ok": False, "error": "no latest version"}
    if not version_gt(ver, current_version()):
        return {"ok": False, "error": "not newer"}
    url = str(latest.get("url") or "")
    if not url.startswith("https://"):
        return {"ok": False, "error": "unsafe update URL"}
    UPDATES.mkdir(parents=True, exist_ok=True)
    dest = UPDATES / f"taa-{ver}.tar.gz"
    try:
        _safe_download(url, dest, str(latest.get("sha256") or ""), int(latest.get("bytes") or 0))
        s["downloaded"] = {"version": ver, "path": str(dest),
                           "sha256": hashlib.sha256(dest.read_bytes()).hexdigest()}
        s["last_error"] = ""
        s["last_result"] = "downloaded"
        _save(s)
        _notify(
            "TAA update downloaded",
            f"v{ver} 已下载，可在版本页安装并重启。",
            f"p-{ver}",
        )
        return {"ok": True, **status()}
    except Exception as exc:  # noqa: BLE001
        s["last_error"] = str(exc)
        _save(s)
        return {"ok": False, "error": str(exc), **status()}


def _notify(title: str, body: str, ref: str) -> None:
    """Best-effort local inbox notification for every local AI agent."""
    try:
        from core import db, community
        conn = db.connect()
        try:
            for row in conn.execute("SELECT id FROM agents WHERE kind='ai'"):
                try:
                    community.add_notification(conn, row["id"], "update", ref, f"{title}：{body}")
                except Exception:
                    pass
            conn.commit()
        finally:
            conn.close()
    except Exception:
        pass


def _is_idle() -> bool:
    try:
        from core import db
        conn = db.connect()
        try:
            busy = conn.execute(
                "SELECT 1 FROM tasks WHERE status IN ('claimed','in_progress','review') LIMIT 1"
            ).fetchone()
            room = conn.execute("SELECT 1 FROM rooms WHERE status='running' LIMIT 1").fetchone()
            return not busy and not room
        finally:
            conn.close()
    except Exception:
        return False


def apply() -> dict:
    s = _load()
    if s.get("mode") == "auto" and int(s.get("applies_today") or 0) >= 1:
        return {"ok": True, "deferred": True, "reason": "daily auto-apply limit", **status()}
    d = s.get("downloaded") or {}
    ver = str(d.get("version") or "")
    pkg = Path(str(d.get("path") or ""))
    if not ver or not pkg.exists():
        return {"ok": False, "error": "no downloaded package"}
    if not version_gt(ver, current_version()):
        return {"ok": False, "error": "not newer"}
    if s.get("mode") == "auto" and not _is_idle():
        s["last_result"] = "deferred_busy"
        _save(s)
        return {"ok": True, "deferred": True, **status()}
    extract = UPDATES / f"extract-{ver}"
    try:
        if extract.exists():
            import shutil
            shutil.rmtree(extract)
        extract.mkdir(parents=True)
        with tarfile.open(pkg, "r:gz") as tf:
            try:
                tf.extractall(extract, filter="data")  # Python 3.12+
            except TypeError:
                tf.extractall(extract)
        src = extract / "taa_agent"
        updater = ROOT / "taa_upgrade.py"
        if not updater.exists():
            updater = ROOT / "scripts" / "taa_upgrade.py"
        if not updater.exists():
            return {"ok": False, "error": "taa_upgrade.py missing"}
        env = dict(os.environ, TAA_HOME=str(HOME), TAA_HTTP_PORT=os.environ.get("TAA_HTTP_PORT", "6080"))
        subprocess.Popen(
            [sys.executable, str(updater), "--source", str(src), "--home", str(HOME),
             "--port", os.environ.get("TAA_HTTP_PORT", "6080"),
             "--python", sys.executable, "--no-open"],
            env=env, cwd=str(HOME / "app"), stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True,
        )
        s["last_apply_at"] = datetime.now().isoformat(timespec="seconds")
        s["last_apply_day"] = date.today().isoformat()
        s["applies_today"] = int(s.get("applies_today") or 0) + 1
        s["last_result"] = "applying"
        _save(s)
        return {"ok": True, "started": True, **status()}
    except Exception as exc:  # noqa: BLE001
        s["last_error"] = str(exc)
        _save(s)
        return {"ok": False, "error": str(exc), **status()}


def _due() -> bool:
    s = _load()
    if not s.get("enabled", True):
        return False
    if int(s.get("checks_today") or 0) >= 2:
        return False
    now = datetime.now()
    today = date.today().isoformat()
    try:
        last = datetime.fromisoformat(str(s.get("last_check_at") or ""))
        if last.date() == now.date() and abs((now - last).total_seconds()) < 30 * 60:
            return False
    except Exception:
        pass
    slots = set(s.get("checked_slots") or [])
    for hm in s.get("check_at") or []:
        try:
            h, m = [int(x) for x in str(hm).split(":")]
        except Exception:
            continue
        slot = f"{today}T{hm}"
        if slot in slots:
            continue
        target = now.replace(hour=h, minute=m, second=0, microsecond=0)
        due = target + timedelta(seconds=min(600, int(s.get("jitter_seconds") or 0)))
        if due <= now < due + timedelta(minutes=30):
            return True
    return False


def _loop() -> None:
    while True:
        try:
            if _due():
                check()
                s = _load()
                if s.get("mode") == "auto" and s.get("downloaded"):
                    apply()
        except Exception:
            pass
        time.sleep(45)


def start_scheduler() -> None:
    global _scheduler_started
    if _scheduler_started or os.environ.get("TAA_UPDATE_DISABLE") == "1":
        return
    _scheduler_started = True
    threading.Thread(target=_loop, name="taa-update-check", daemon=True).start()
