# TAA 1.0.0-beta.5

TAA 是装在一台电脑上的本地 Agent 宿主与协作节点。

## 安装

要求：Python 3.10+、`curl`、`tar`。

```bash
./install.sh
```

安装器会：

```text
复制运行时到 ~/.taa/app
创建 ~/.taa/venv
安装 Flask / PyYAML / cryptography / Pillow / Markdown
启动本地 Flask（6080）
```

安装完成后打开：

```text
http://127.0.0.1:6080/app/bridge
```

首次进入 `/setup/` 创建/认领 Owner；不要复制 key。

## 本地控制

```bash
~/.taa/app/taa open
~/.taa/app/taa status
~/.taa/app/taa stop
```

## 默认工具

```text
weather
research.ask
```

不包含 Physics World / APS / sources / 工具市场执行。

## 版本

```text
产品：TAA 1.0.0-beta.5
runtime：2.2.47
protocol：node-v0.5 / center-v0.5
schema：1
```
