"""Gate 3: connect local node identity to the center claim flow."""
from __future__ import annotations

import pathlib
from typing import Any

from .center import CenterClient, CenterError
from .identity import IdentityState, load_state, now_iso, save_state, set_owner_password


def _summary(state: IdentityState) -> dict[str, Any]:
    return {
        "owner_id": state.owner.owner_id,
        "owner_username": state.owner.username,
        "node_id": state.node.node_id,
        "node_alias": state.node.alias,
        "node_status": state.node.status,
        "center": {
            "base": state.center.base,
            "owner_id": state.center.owner_id,
            "claimed_at": state.center.claimed_at,
        },
        "agents": [
            {"agent_id": agent.agent_id, "name": agent.display_name, "status": agent.status}
            for agent in state.agents
        ],
    }


def connect(
    home: pathlib.Path,
    *,
    base: str,
    username: str,
    password: str,
    create_owner: bool = False,
    email: str = "",
    register_agents: bool = True,
) -> dict[str, Any]:
    home = pathlib.Path(home).expanduser()
    state = load_state(home)
    client = CenterClient(base)

    claim_token: str | None = None
    node_owner_id: str | None = None
    try:
        registered = client.register_node(
            node_id=state.node.node_id,
            node_key=state.node.node_key,
            alias=state.node.alias,
            fingerprint_hash=state.node.fingerprint_hash,
            version="0.5.0",
            enc_pubkey=state.node.enc_pubkey,
        )
        claim_token = registered.get("claim_token")
    except CenterError as exc:
        if exc.status != 409:
            raise
        current = client.node_me(node_key=state.node.node_key)
        node = current.get("node") or {}
        node_owner_id = node.get("owner_id") or None
        if node.get("status") == "pending_owner":
            refreshed = client.refresh_claim(node_key=state.node.node_key)
            claim_token = refreshed.get("claim_token")
            node_owner_id = None
        elif node.get("status") != "active":
            raise

    if create_owner:
        owner = client.owner_register(username=username, password=password, email=email)
    else:
        owner = client.owner_login(username=username, password=password)
    owner_token = owner.get("owner_token") or ""
    center_owner = owner.get("owner") or {}
    center_owner_id = str(center_owner.get("owner_id") or "")
    if not owner_token or not center_owner_id:
        raise RuntimeError("center did not return owner session")

    if node_owner_id and node_owner_id != center_owner_id:
        raise RuntimeError("node belongs to a different owner")
    if claim_token:
        client.claim_node(owner_token=owner_token, claim_token=claim_token)
    else:
        # Already active; verify owner identity from center.
        current = client.node_me(node_key=state.node.node_key)
        node = current.get("node") or {}
        if node.get("status") != "active" or node.get("owner_id") != center_owner_id:
            raise RuntimeError("node is not active for this owner")

    if register_agents:
        for agent in state.agents:
            try:
                client.register_agent(
                    node_key=state.node.node_key,
                    agent_id=agent.agent_id,
                    agent_key=agent.agent_key,
                    display_name=agent.display_name,
                )
            except CenterError as exc:
                # A retry after a partial registration is safe only for 409;
                # other failures remain visible to the caller.
                if exc.status != 409:
                    raise

    state.node.status = "active"
    state.center.base = base.rstrip("/")
    state.center.owner_id = center_owner_id
    state.center.claimed_at = state.center.claimed_at or now_iso()
    save_state(home, state)
    return {"ok": True, **_summary(state)}


def reset_owner_password(home: pathlib.Path, *, base: str, password: str) -> dict[str, Any]:
    state = load_state(home)
    client = CenterClient(base)
    result = client.reset_owner_password(
        node_id=state.node.node_id,
        node_key=state.node.node_key,
        password=password,
    )
    set_owner_password(home, password)
    return {"ok": True, **result, "local_password_updated": True}
