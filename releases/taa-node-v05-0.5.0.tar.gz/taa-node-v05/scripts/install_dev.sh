#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

# Prefer an interpreter that is known to create working venvs on macOS.
PYTHON_BIN=${TAA_BASE_PYTHON:-}
if [ -z "$PYTHON_BIN" ]; then
    for candidate in python3.12 python3.11 python3.10; do
        if command -v "$candidate" >/dev/null 2>&1; then
            PYTHON_BIN=$candidate
            break
        fi
    done
fi
if [ -z "$PYTHON_BIN" ]; then
    PYTHON_BIN=python3
fi

"$PYTHON_BIN" - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("Python 3.10+ required; found %s" % sys.version.split()[0])
print("python", sys.version.split()[0])
PY

"$PYTHON_BIN" -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python - <<'PY'
import flask, cryptography
print("flask", getattr(flask, "__version__", "ok"))
print("cryptography", cryptography.__version__)
PY
echo "install ok: $ROOT/.venv/bin/python"
