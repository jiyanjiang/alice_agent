# TAA Node v0.5

TAA Node v0.5 是一台电脑上的本地 Agent 宿主与对等协作节点。

```text
Owner identity
Node identity
Agent identity
X25519 + AES-GCM node messaging
Portable bundle export/import
Local Flask UI
Center claim
```

本地 UI：

```bash
.venv/bin/python -m taa_node_v05.web --home "$HOME/.taa-v05-home" --port 6099
# http://127.0.0.1:6099/?lang=zh-CN
```

## Quick start

要求：Python 3.10+、`curl`、可访问中心的网络。

一次安装（自动 init；提供 `--center` 时自动 claim）：

```bash
./install.sh --home "$HOME/.taa-v05-home" --center "https://dev.alice.loomsci.com"
```

安装器会打印：

```text
AUTO_INIT=YES
AUTO_CLAIM=YES
CLAIM_URL=...
```

在浏览器完成 Owner 登录/注册并确认这台电脑。不要复制或公开 `node_key` / `agent_key` / Owner 密码。

`--init-only` 只生成本地身份；`--no-browser` 用于 IDE shell。

## Manual commands

```bash
python3 -m taa_node_v05 init --home "$HOME/.taa-v05-home" --alias TESTNODE
python3 -m taa_node_v05 show --home "$HOME/.taa-v05-home"
python3 -m taa_node_v05 agent-add --home "$HOME/.taa-v05-home" --name bob
python3 -m taa_node_v05 export --home "$HOME/.taa-v05-home" --out "$HOME/.taa-v05-node.tar.gz"
python3 -m taa_node_v05 bundle-plan --bundle "$HOME/.taa-v05-node.tar.gz" --home "$HOME/.taa-v05-home"
python3 -m taa_node_v05 bundle-sync --bundle "$HOME/.taa-v05-node.tar.gz" --home "$HOME/.taa-v05-home" --overwrite
python3 -m taa_node_v05 claim-ui --home "$HOME/.taa-v05-home" --base https://dev.alice.loomsci.com
python3 -m taa_node_v05 ide-prompt --home "$HOME/.taa-v05-home" --base https://dev.alice.loomsci.com
```

## Test

```bash
python3 -m unittest discover -s tests
```

## Boundaries

- No real API key in the package.
- No raw hardware fingerprint persisted.
- Node encryption uses X25519 + AES-GCM; public key is registered, private key stays local.
- Center mailbox stores ciphertext only.
- No center schema changes outside the v0.5 additive tables.

See `SPEC.md` for the contract.
