"""WS presence control channel for a TAA Node.

One long-lived WebSocket per node. The center Directory DO derives presence
from the connection; 60s "ping" is answered by setWebSocketAutoResponse and
does not wake business handlers. HTTP heartbeat is only a fallback.

No key is placed in the URL. The node key is sent in the Authorization header.
"""
from __future__ import annotations

import json
import pathlib
import random
import threading
import time
from typing import Any, Callable

from .endpoints import discover

PING_S = 60
BACKOFF = (1, 2, 5, 10, 30)


def ws_url(base: str) -> str:
    b = (base or "").rstrip("/")
    if b.startswith("https://"):
        return "wss://" + b[len("https://"):] + "/presence/ws"
    if b.startswith("http://"):
        return "ws://" + b[len("http://"):] + "/presence/ws"
    return b + "/presence/ws"


def _hello(state: Any, port: int) -> dict:
    advertised = discover(port or 6080)
    return {
        "type": "hello",
        "id": state.node.node_id,
        "owner_id": state.center.owner_id,
        "team": state.center.owner_id,
        "kind": "node",
        "endpoint": advertised.get("app") or advertised.get("endpoint") or "",
        "pubkey": state.node.enc_pubkey or "",
        "has_node": True,
    }


def run_control_ws(
    state: Any,
    *,
    port: int = 6080,
    stop: threading.Event | None = None,
    ping_s: int = PING_S,
    on_log: Callable[[str], None] | None = None,
) -> None:
    """Maintain one WS presence connection; reconnect with backoff."""
    stop = stop or threading.Event()
    log = on_log or (lambda _msg: None)
    try:
        import websocket  # websocket-client
        from websocket import WebSocketTimeoutException
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError("websocket-client is required for WS presence") from exc

    attempt = 0
    while not stop.is_set():
        if state.node.status != "active" or not state.center.base:
            stop.wait(5)
            continue
        ws = None
        try:
            url = ws_url(state.center.base)
            ws = websocket.create_connection(
                url,
                header=[f"Authorization: Bearer {state.node.node_key}"],
                timeout=10,
            )
            ws.send(json.dumps(_hello(state, port), ensure_ascii=False))
            log(f"[presence] connected {url}")
            last_ping = 0.0
            ws.settimeout(2)
            while not stop.is_set():
                now = time.monotonic()
                if now - last_ping >= ping_s:
                    ws.send("ping")
                    last_ping = now
                try:
                    ws.recv()          # auto-response pong; ignore content
                except WebSocketTimeoutException:
                    continue
                except Exception:
                    raise
            attempt = 0
        except Exception as exc:  # noqa: BLE001
            attempt = min(attempt + 1, len(BACKOFF))
            delay = BACKOFF[attempt - 1] + random.uniform(0, 0.5)
            log(f"[presence] reconnect in {delay:.1f}s: {type(exc).__name__}: {exc}")
            stop.wait(delay)
        finally:
            if ws is not None:
                try:
                    ws.close()
                except Exception:
                    pass


def start_control_ws(state: Any, *, port: int = 6080,
                     on_log: Callable[[str], None] | None = None) -> tuple[threading.Thread, threading.Event]:
    stop = threading.Event()
    thread = threading.Thread(target=run_control_ws, kwargs={
        "state": state, "port": port, "stop": stop, "on_log": on_log,
    }, name="taa-presence-ws", daemon=True)
    thread.start()
    return thread, stop


if __name__ == "__main__":
    import argparse
    from .identity import load_state
    ap = argparse.ArgumentParser()
    ap.add_argument("--home", required=True)
    ap.add_argument("--port", type=int, default=6080)
    a = ap.parse_args()
    run_control_ws(load_state(pathlib.Path(a.home).expanduser()), port=a.port,
                   on_log=print)
