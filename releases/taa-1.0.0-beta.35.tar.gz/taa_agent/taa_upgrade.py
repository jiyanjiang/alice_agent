#!/usr/bin/env python3
"""TAA upgrade: staging + protected data + atomic swap + rollback.

This script is intentionally self-contained (stdlib only). It is called by the
package install.sh only when an existing install is detected. A fresh install
continues to use the normal install path.

Phases:
  preflight -> backup -> stop -> migrate-events -> stage -> swap -> start
  -> verify -> commit
Any failure after stop restores the previous app and database backups.
"""
from __future__ import annotations

import argparse
import contextlib
import fcntl
import hashlib
import json
import os
import shutil
import socket
import sqlite3
import subprocess
import sys
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


def now_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def copy_file(src: Path, dst: Path) -> None:
    if not src.exists():
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def copy_tree(src: Path, dst: Path) -> None:
    if not src.exists():
        return
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst, symlinks=True)


def sqlite_backup(src: Path, dst: Path) -> None:
    """Consistent SQLite copy (includes WAL). Caller must stop writers."""
    if not src.exists():
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    with contextlib.closing(sqlite3.connect(str(src))) as s:
        with contextlib.closing(sqlite3.connect(str(dst))) as d:
            s.backup(d)


def sqlite_integrity(path: Path) -> str:
    if not path.exists():
        return "missing"
    with contextlib.closing(sqlite3.connect(str(path))) as c:
        row = c.execute("PRAGMA integrity_check").fetchone()
        return str(row[0] if row else "unknown")


def port_open(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.4)
        return s.connect_ex(("127.0.0.1", port)) == 0


def wait_port_free(port: int, timeout: float = 20.0) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        if not port_open(port):
            return True
        time.sleep(0.25)
    return False


def health(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/v1/health", timeout=2) as r:
            return r.status == 200
    except Exception:
        return False


def run(cmd: list[str], *, env: dict[str, str], timeout: int = 60) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, env=env, text=True, capture_output=True, timeout=timeout)


class UpgradeError(RuntimeError):
    pass


class Upgrade:
    def __init__(self, source: Path, home: Path, port: int, python: str,
                 no_open: bool = True):
        self.source = source.resolve()
        self.home = home.expanduser().resolve()
        self.port = int(port)
        self.python = python
        self.no_open = no_open
        self.app = self.home / "app"
        self.stamp = now_stamp()
        self.new_app = self.home / f"app.new.{self.stamp}"
        self.prev_app = self.home / f"app.prev.{self.stamp}"
        self.failed_app = self.home / f"app.failed.{self.stamp}"
        self.backup = self.home / "backups" / f"upgrade-{self.stamp}"
        self.journal = self.home / "upgrade.state.json"
        self.swapped = False
        self.stopped = False
        self.old_events = self.app / "events.db"
        self.home_events = self.home / "events.db"

    # ---------- journal ----------
    def set_phase(self, phase: str, **extra) -> None:
        data = {
            "phase": phase,
            "source": str(self.source),
            "home": str(self.home),
            "app": str(self.app),
            "prev_app": str(self.prev_app),
            "backup": str(self.backup),
            "timestamp": now_stamp(),
            **extra,
        }
        tmp = self.journal.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, self.journal)
        print(f"[upgrade] phase={phase}")

    # ---------- service ----------
    def stop(self) -> None:
        self.stopped = True
        env = dict(os.environ, TAA_HOME=str(self.home), TAA_HTTP_PORT=str(self.port),
                   TAA_PYTHON=self.python)
        launcher = self.app / "taa"
        if launcher.exists():
            try:
                run([str(launcher), "stop"], env=env, timeout=20)
            except Exception as exc:
                print(f"[upgrade] stop command warning: {exc}")
        if not wait_port_free(self.port):
            raise UpgradeError(f"port {self.port} still in use after stop")
        print("[upgrade] old service stopped")

    def start(self, app: Path) -> bool:
        env = dict(os.environ, TAA_HOME=str(self.home), TAA_HTTP_PORT=str(self.port),
                   TAA_PYTHON=self.python)
        launcher = app / "taa"
        cmd = [str(launcher), "start", "--no-open"] if self.no_open else [str(launcher), "start"]
        try:
            proc = subprocess.run(cmd, env=env, cwd=str(app), text=True,
                                  capture_output=True, timeout=30)
            if proc.returncode != 0:
                print(proc.stdout[-3000:])
                print(proc.stderr[-3000:], file=sys.stderr)
        except Exception as exc:
            print(f"[upgrade] start warning: {exc}", file=sys.stderr)
        end = time.time() + 30
        while time.time() < end:
            if health(self.port):
                print("[upgrade] health OK")
                return True
            time.sleep(0.35)
        return False

    def stop_new(self) -> None:
        env = dict(os.environ, TAA_HOME=str(self.home), TAA_HTTP_PORT=str(self.port),
                   TAA_PYTHON=self.python)
        launcher = self.app / "taa"
        if launcher.exists():
            try:
                run([str(launcher), "stop"], env=env, timeout=20)
            except Exception:
                pass
        wait_port_free(self.port, timeout=10)

    # ---------- backup ----------
    def make_backup(self) -> None:
        self.backup.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self.backup, 0o700)
        except OSError:
            pass
        copy_file(self.home / "identity.json", self.backup / "identity.json")
        copy_tree(self.home / "agents", self.backup / "agents")
        copy_tree(self.home / "bootstrap", self.backup / "bootstrap")
        copy_file(self.home / "config.toml", self.backup / "config.toml")
        sqlite_backup(self.home / "data.db", self.backup / "data.db")
        sqlite_backup(self.old_events, self.backup / "events.db")
        if self.home_events.exists():
            sqlite_backup(self.home_events, self.backup / "events.home.db")
        copy_tree(self.app / "data", self.backup / "app-data")
        # uploads can be large; record them, but allow a full copy via env.
        uploads = self.home / "static" / "uploads"
        if os.environ.get("TAA_UPGRADE_SKIP_UPLOADS") != "1":
            copy_tree(uploads, self.backup / "uploads")
        entries = {}
        for p in self.backup.rglob("*"):
            if p.is_file():
                entries[p.relative_to(self.backup).as_posix()] = sha256_file(p)
        (self.backup / "checksums.json").write_text(
            json.dumps(entries, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"[upgrade] backup -> {self.backup}")

    # ---------- staging ----------
    def stage(self) -> None:
        if self.new_app.exists():
            shutil.rmtree(self.new_app)
        shutil.copytree(self.source, self.new_app, symlinks=True)
        # Preserve runtime state that lived under old app.
        if self.old_events.exists():
            sqlite_backup(self.old_events, self.new_app / "events.db")
        copy_tree(self.app / "data", self.new_app / "data")
        # Data symlinks are the only live links in the app tree.
        for rel, target in (("agents", self.home / "agents"),
                            ("bootstrap", self.home / "bootstrap"),
                            ("static/uploads", self.home / "static" / "uploads")):
            target.mkdir(parents=True, exist_ok=True)
            link = self.new_app / rel
            if link.is_symlink() or link.exists():
                if link.is_dir() and not link.is_symlink():
                    shutil.rmtree(link)
                else:
                    link.unlink()
            link.parent.mkdir(parents=True, exist_ok=True)
            link.symlink_to(target)
        # Move the event log to the stable home path for new launchers.
        if not self.home_events.exists():
            sqlite_backup(self.old_events, self.home_events)
        print("[upgrade] staged app.new")

    # ---------- verify ----------
    def verify(self) -> None:
        if not health(self.port):
            raise UpgradeError("new service unhealthy")
        if not (self.home / "identity.json").exists():
            raise UpgradeError("identity.json missing after upgrade")
        if not (self.home / "data.db").exists():
            raise UpgradeError("data.db missing after upgrade")
        if not (self.home_events.exists() or (self.app / "events.db").exists()):
            raise UpgradeError("events.db missing after upgrade")
        ver = (self.app / "VERSION").read_text(encoding="utf-8").strip() if (self.app / "VERSION").exists() else ""
        if not ver:
            raise UpgradeError("new app VERSION missing")
        dbi = sqlite_integrity(self.home / "data.db")
        if dbi != "ok":
            raise UpgradeError(f"data.db integrity={dbi}")
        ev = self.home_events if self.home_events.exists() else (self.app / "events.db")
        evi = sqlite_integrity(ev)
        if evi != "ok":
            raise UpgradeError(f"events.db integrity={evi}")
        # Never print keys; only counts.
        with contextlib.closing(sqlite3.connect(str(self.home / "data.db"))) as c:
            agents = c.execute("SELECT COUNT(*) FROM agents").fetchone()[0]
        print(f"[upgrade] verified version={ver} agents={agents}")

    # ---------- rollback ----------
    def rollback(self) -> None:
        print("[upgrade] ROLLBACK")
        self.stop_new()
        if self.swapped and self.prev_app.exists():
            if self.app.exists():
                os.replace(self.app, self.failed_app)
            os.replace(self.prev_app, self.app)
        # Restore only DB/event data that may have been migrated.
        if (self.backup / "data.db").exists():
            sqlite_backup(self.backup / "data.db", self.home / "data.db")
        if (self.backup / "events.db").exists():
            sqlite_backup(self.backup / "events.db", self.app / "events.db")
        if (self.backup / "events.home.db").exists():
            sqlite_backup(self.backup / "events.home.db", self.home / "events.db")
        elif self.home_events.exists() and not (self.backup / "events.home.db").exists():
            # Old app may not understand home events; leave it, old app uses app/events.db.
            pass
        try:
            self.start(self.app)
        except Exception as exc:
            print(f"[upgrade] old restart failed: {exc}", file=sys.stderr)
        self.set_phase("ROLLED_BACK", failed_app=str(self.failed_app))

    def run(self) -> int:
        self.home.mkdir(parents=True, exist_ok=True)
        lock_path = self.home / ".upgrade.lock"
        with lock_path.open("w") as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                print("upgrade already running", file=sys.stderr)
                return 3
            try:
                self.set_phase("PREFLIGHT")
                if not (self.home / "identity.json").exists():
                    print("no existing identity; use fresh installer", file=sys.stderr)
                    return 2
                if not (self.source / "VERSION").exists():
                    raise UpgradeError("package VERSION missing")
                if not self.app.exists():
                    raise UpgradeError("existing app missing")
                self.set_phase("STOP")
                self.stop()
                self.set_phase("BACKUP")
                self.make_backup()
                self.set_phase("STAGE")
                self.stage()
                self.set_phase("SWAP")
                os.replace(self.app, self.prev_app)
                os.replace(self.new_app, self.app)
                self.swapped = True
                self.set_phase("START")
                if not self.start(self.app):
                    raise UpgradeError("new service did not become healthy")
                if os.environ.get("TAA_UPGRADE_FORCE_FAIL") == "verify":
                    raise UpgradeError("forced verify failure for rollback test")
                self.verify()
                self.set_phase("COMMITTED")
                print(f"[upgrade] committed; previous={self.prev_app}")
                return 0
            except Exception as exc:
                print(f"[upgrade] FAILED: {exc}", file=sys.stderr)
                try:
                    self.rollback()
                except Exception as rb:
                    print(f"[upgrade] rollback error: {rb}", file=sys.stderr)
                return 1


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True)
    ap.add_argument("--home", required=True)
    ap.add_argument("--port", type=int, default=6080)
    ap.add_argument("--python", default=sys.executable)
    ap.add_argument("--no-open", action="store_true")
    a = ap.parse_args()
    return Upgrade(Path(a.source), Path(a.home), a.port, a.python, a.no_open).run()


if __name__ == "__main__":
    raise SystemExit(main())
