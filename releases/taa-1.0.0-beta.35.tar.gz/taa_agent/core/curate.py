"""精选与推荐（docs/33）：LLM 判断哪些产出**值得推荐给人看**，由协调者整理发到群里。

- 判断权归 LLM（成篇长文/图/数据、单一主题、可回溯、有品味）；规则只做结构过滤与状态去重。
- 只发**帖号**到群（群里渲染成引用卡片 → 右栏读全文）；精选帖指向原帖，不复制正文（避免重复）。
- 已推荐过的记 `agents/<agent>/.curated.json`，不重复推荐。
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

from .harvest import extract_json

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_MODEL = os.environ.get("TEAMAI_CURATE_MODEL", "deepseek/deepseek-flash")
DEFAULT_CHANNELS = ("#reading", "#projects/team-ai")


def _state_path(agent: str) -> Path:
    d = ROOT / "agents" / agent
    d.mkdir(parents=True, exist_ok=True)
    return d / ".curated.json"


def _load_state(agent: str) -> list[str]:
    try:
        return json.loads(_state_path(agent).read_text(encoding="utf-8")).get("ids", [])
    except Exception:
        return []


def _save_state(agent: str, ids: list[str]) -> None:
    try:
        _state_path(agent).write_text(json.dumps({"ids": ids[-200:]}, ensure_ascii=False), encoding="utf-8")
    except Exception as e:  # noqa: BLE001
        print("[curate] save state err:", e)


def build_prompt(posts: list[dict], already: set[str]) -> str:
    lines = []
    for p in posts:
        if p.get("id") in already:
            continue
        body = (p.get("body") or "").strip().replace("\n", " ")[:180]
        att = len(p.get("attachments") or [])
        lines.append(f"{p.get('id')} | {p.get('channel') or p.get('channel_id')} | "
                     f"{p.get('author') or p.get('author_id')} | 附件{att} | "
                     f"{p.get('title') or ''} | {body}")
    return (
        "你是团队的『精选编辑』。下面是近期产出帖。请判断**哪些值得推荐给人看**——"
        "判据：成篇长文/图/数据；单一主题、有叙事；事实可回溯（有附件/事实库）；有品味、有新信息。"
        "宁少勿滥（最多 3 条）；已推荐过的不要选；standup/一句话凑数/重复帖不选。\n"
        "只输出一个 JSON：{\"picks\":[{\"post_id\":\"p-…\",\"headline\":\"一句标题\",\"reason\":\"为什么值得看（一两句）\"}]}\n\n"
        "近期产出：\n" + "\n".join(lines[:40])
    )


def pick(posts: list[dict], already: set[str], *, llm=None,
         model: str = DEFAULT_MODEL, backend: str = "opencode") -> list[dict]:
    prompt = build_prompt(posts, already)
    if llm is None:
        from core.llm import get as llm_get
        res = llm_get(backend).run(prompt, model=model, cwd=str(ROOT), title="curate", timeout=180)
        text = res.text if res.ok else ""
        if not res.ok:
            return []
    else:
        text = llm(prompt)
    d = extract_json(text) or {}
    out = []
    for x in (d.get("picks") or []):
        if not isinstance(x, dict):
            continue
        pid = str(x.get("post_id") or "").strip()
        if re.match(r"^p-[0-9a-f]{8}$", pid) and pid not in already:
            out.append({"post_id": pid, "headline": str(x.get("headline") or "").strip(),
                        "reason": str(x.get("reason") or "").strip()})
    return out[:3]


def run(call, agent: str, *, channels=DEFAULT_CHANNELS, limit: int = 40,
        llm=None, dry_run: bool = False) -> dict:
    """call(method, path, body=None)->dict（CLI 或 loop 注入）。返回 {picks, published, room}。"""
    posts, seen = [], set()
    for ch in channels:
        try:
            got = call("GET", "/v1/posts?channel=" + ch.replace("#", "%23") + f"&limit={limit}").get("posts", [])
        except Exception:
            got = []
        for p in got:
            if p.get("id") in seen:
                continue
            seen.add(p.get("id"))
            posts.append(p)
    already = set(_load_state(agent))
    picks = pick(posts, already, llm=llm)
    if dry_run or not picks:
        return {"picks": picks, "published": [], "room": None}
    rooms = []
    try:
        rooms = call("GET", "/v1/rooms").get("rooms", [])
    except Exception:
        pass
    rid = None
    for r in rooms:
        if r.get("status") != "running":
            continue
        try:
            d = call("GET", "/v1/rooms/" + r["id"])
        except Exception:
            continue
        if agent in [m.get("agent_id") for m in (d.get("room", {}).get("members") or [])]:
            rid = r["id"]
            break
    published = []
    for pp in picks:
        pid, head = pp["post_id"], (pp["headline"] or pp["post_id"])
        reason = pp["reason"] or "值得一读。"
        try:
            call("POST", "/v1/posts", {"channel_id": "#reading", "type": "note",
                                       "title": "精选｜" + head,
                                       "body": f"推荐理由：{reason}\n\n原文见：**{pid}**",
                                       "tags": ["精选", "推荐"]})
        except Exception:
            pass
        if rid:
            try:
                call("POST", f"/v1/rooms/{rid}/report",
                     {"text": f"【精选推荐】{head} —— {reason} 点帖号看全文：{pid}"})
            except Exception:
                pass
        published.append(pid)
    _save_state(agent, list(already) + published)
    return {"picks": picks, "published": published, "room": rid}
