"""项目分享区 · 安全交换（S1–S6 最小实现）。依据 `docs/71 §3`。

| # | 机制 | 本模块落地 |
|---|---|---|
| S1 | 来源可溯/防篡改 | 条目必带 `sha256 + signed_by + signature`（**Ed25519**，签名覆盖条目元数据+内容哈希）；读/导出时复算哈希+验签，**失败即拒收** |
| S2 | 默认不自动执行 | 加条目只入库不动；执行需**本机显式同意**（复用 `core.remote_wake` 的 4 位码 + 限速/锁定/审计）+ **一次性 nonce**（防重放） |
| S3 | 沙箱与最小权限 | 隔离目录 `.sandbox/item-*`；macOS 用 `sandbox-exec` 强制 **默认拒绝**（无网络、隔离目录外不可写）；非 macOS 退回 Python 预置守卫；进程组可杀 |
| S4 | 全程审计 | `import/export/execute/revoke/rollback` 各留一条 `exchanges` + `audit_log`，`replay()` 可回放「谁/何时/什么哈希/结果」 |
| S5 | 分级与越权 | `level=project|friends|private`；非成员取数 **403** |
| S6 | 一键回滚 | 复用 `core.apply.snapshot()/rollback()`；误应用后一键回滚且留痕 |

设计红线：**不自动执行他方代码**（`docs/71 §8`）——`add_item` 永不执行；执行是**独立、需同意、在沙箱内**的动作。
本模块不依赖 Flask，可单测；HTTP 层在 `core/server.py` 的 `/v1/projects/<id>/…` 路由。
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import secrets
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

from . import apply as apply_mod
from . import remote_wake

ROOT = Path(__file__).resolve().parent.parent
UPLOADS = ROOT / "static" / "uploads"
SANDBOX_ROOT = ROOT / ".sandbox"
# 可经 TEAMAI_AGENTS_DIR 指向临时目录（自检/测试**隔离**，避免在真实 agents/ 下生成签名密钥）
AGENTS_DIR = Path(os.environ.get("TEAMAI_AGENTS_DIR") or (ROOT / "agents"))

LEVELS = ("project", "friends", "private")
# 审计动作（在 docs/71 的 import|export|execute|revoke 基础上补 rollback）
ACTIONS = ("import", "export", "execute", "revoke", "rollback")
MAX_EXPORT_BYTES = 2 * 1024 * 1024


class ShareError(Exception):
    """业务错误 → HTTP 状态码（403=越权/未同意，409=验签拒收/状态冲突）。"""

    def __init__(self, msg: str, code: int = 400):
        super().__init__(msg)
        self.msg = msg
        self.code = code


# ----------------------------------------------------------------- Ed25519 签名（S1）
def _b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode()


def _unb64(s: str) -> bytes:
    return base64.urlsafe_b64decode(s)


def _key_path(agent: str) -> Path:
    return AGENTS_DIR / agent / "share_ed25519.key"


def _pub_path(agent: str) -> Path:
    return AGENTS_DIR / agent / "share_ed25519.pub"


def signing_key(agent: str) -> Ed25519PrivateKey:
    """每 agent 独立的 Ed25519 私钥（首用生成，0600）。signed_by 才有实义。"""
    p = _key_path(agent)
    if p.exists():
        return Ed25519PrivateKey.from_private_bytes(_unb64(p.read_text(encoding="utf-8").strip()))
    sk = Ed25519PrivateKey.generate()
    p.parent.mkdir(parents=True, exist_ok=True)
    seed = sk.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                            serialization.NoEncryption())
    p.write_text(_b64(seed), encoding="utf-8")
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass
    pub = sk.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    _pub_path(agent).write_text(_b64(pub), encoding="utf-8")
    return sk


def public_key_b64(agent: str) -> str | None:
    p = _pub_path(agent)
    if not p.exists():
        if not _key_path(agent).exists():
            return None
        return _b64(signing_key(agent).public_key().public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw))
    return p.read_text(encoding="utf-8").strip()


def key_fingerprint(agent: str) -> str:
    pub = public_key_b64(agent)
    if not pub:
        return ""
    return hashlib.sha256(_unb64(pub)).hexdigest()[:16]


def canonical(meta: dict) -> bytes:
    return json.dumps(meta, sort_keys=True, ensure_ascii=False,
                      separators=(",", ":")).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _item_meta(project_id: str, kind: str, ref: str, level: str, nbytes: int,
               sha256: str) -> dict:
    return {"v": 1, "project_id": project_id, "kind": kind, "ref": ref,
            "level": level, "bytes": nbytes, "sha256": sha256}


def seal(agent: str, project_id: str, kind: str, ref: str, level: str,
         content: bytes) -> dict:
    """对条目内容+元数据签名（S1）。返回 {sha256, signed_by, signature}。"""
    sha = sha256_bytes(content)
    meta = _item_meta(project_id, kind, ref, level, len(content), sha)
    sig = _b64(signing_key(agent).sign(canonical(meta)))
    return {"sha256": sha, "signed_by": agent, "signature": sig}


def verify(signed_by: str, project_id: str, kind: str, ref: str, level: str,
           signed_sha256: str, signature: str, content: bytes | None) -> tuple[bool, str]:
    """复算哈希 + 用 signed_by 公钥验签。返回 (通过?, 原因)。"""
    if content is None:
        return False, "content_unavailable"
    sha = sha256_bytes(content)
    if signed_sha256 and sha != signed_sha256:
        return False, "sha256_mismatch(tampered)"
    pub = public_key_b64(signed_by)
    if not pub:
        return False, "unknown_signer"
    meta = _item_meta(project_id, kind, ref, level, len(content), sha)
    try:
        Ed25519PublicKey.from_public_bytes(_unb64(pub)).verify(_unb64(signature), canonical(meta))
    except Exception:  # noqa: BLE001
        return False, "bad_signature"
    return True, "ok"


# ----------------------------------------------------------------- 内容解析
def resolve_content(kind: str, ref: str) -> bytes | None:
    """把 kind/ref 解析成签名字节。最小实现：file（uploads）与 inline/text/code。"""
    if kind == "file":
        name = os.path.basename((ref or "").split("?")[0].rstrip("/"))
        if not name or name in (".", ".."):
            return None
        p = UPLOADS / name
        return p.read_bytes() if p.exists() else None
    if kind in ("inline", "text", "code", "dataset"):
        return (ref or "").encode("utf-8")
    return None


# ----------------------------------------------------------------- 成员/分级（S5）
def member_row(conn, project_id: str, agent_id: str):
    return conn.execute(
        "SELECT * FROM project_members WHERE project_id=? AND member_id=?",
        (project_id, agent_id)).fetchone()


def is_member(conn, project_id: str, agent_id: str) -> bool:
    return member_row(conn, project_id, agent_id) is not None


def can_write(m) -> bool:
    return bool(m) and int(m["share_write"] or 0) == 1


def can_read(item, m) -> bool:
    """分级读权限：project=任意成员；friends=非 viewer 成员；private=owner 或本人添加。"""
    if not m:
        return False
    level = (item["level"] if not isinstance(item, dict) else item.get("level")) or "project"
    if level == "project":
        return True
    if level == "friends":
        return m["role"] in ("owner", "member")
    if level == "private":
        added_by = item["added_by"] if not isinstance(item, dict) else item.get("added_by")
        return m["role"] == "owner" or added_by == m["member_id"]
    return False


def add_member(conn, project_id: str, actor: str, member_id: str, kind: str = "ai",
               role: str = "member", share_write: int = 1) -> dict:
    a = member_row(conn, project_id, actor)
    if not a:
        raise ShareError("非项目成员，禁止操作", 403)
    if a["role"] != "owner":
        raise ShareError("仅 owner 可管理成员", 403)
    conn.execute(
        "INSERT OR REPLACE INTO project_members(project_id, member_id, kind, role, share_write)"
        " VALUES (?,?,?,?,?)", (project_id, member_id, kind, role, int(share_write)))
    conn.commit()
    return {"project_id": project_id, "member_id": member_id, "kind": kind, "role": role}


# ----------------------------------------------------------------- 审计（S4）
def _audit_log(conn, actor: str, action: str, target: str, detail: dict) -> None:
    conn.execute("INSERT INTO audit_log(actor, action, target, detail) VALUES (?,?,?,?)",
                 (actor, action, target, json.dumps(detail, ensure_ascii=False)))


def record(conn, project_id: str, actor: str, item_id, action: str, *,
           sha256: str | None = None, signature_ok=None, consent: str | None = None,
           result: str | None = None, commit: bool = True) -> int:
    cur = conn.execute(
        "INSERT INTO exchanges(project_id, actor, item_id, action, sha256, signature_ok,"
        " consent, result) VALUES (?,?,?,?,?,?,?,?)",
        (project_id, actor, item_id, action, sha256,
         None if signature_ok is None else int(signature_ok), consent, result))
    _audit_log(conn, actor, f"share.{action}",
               f"{project_id}:{item_id}", {"sha256": sha256, "signature_ok": signature_ok,
                                           "consent": consent, "result": result})
    if commit:
        conn.commit()
    return int(cur.lastrowid or 0)


def replay(conn, project_id: str, item_id: int | None = None, limit: int = 200) -> list[dict]:
    """按时间回放「谁/何时/什么哈希/结果」（S4）。"""
    sql = ("SELECT id, actor, item_id, action, sha256, signature_ok, consent, result, created_at"
           " FROM exchanges WHERE project_id=?")
    args: list = [project_id]
    if item_id is not None:
        sql += " AND item_id=?"
        args.append(item_id)
    sql += " ORDER BY id LIMIT ?"
    args.append(limit)
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def get_item(conn, item_id: int):
    return conn.execute("SELECT * FROM share_items WHERE id=?", (item_id,)).fetchone()


# ----------------------------------------------------------------- 分享条目（S1/S4）
def add_item(conn, project_id: str, actor: str, kind: str, ref: str, *,
             level: str = "project", content: bytes | None = None,
             mime: str | None = None) -> dict:
    """加条目：**只入库不动**（S2）。上传即签名（S1）。"""
    m = member_row(conn, project_id, actor)
    if not m:
        raise ShareError("非项目成员，禁止写入分享区", 403)
    if not can_write(m):
        raise ShareError("无写入权限（viewer / share_write=0）", 403)
    if level not in LEVELS:
        raise ShareError(f"level 必须为 {LEVELS}", 400)
    if content is None:
        content = resolve_content(kind, ref)
    if content is None:
        raise ShareError("内容不可读取，无法签名（S1 要求必带 sha256）", 422)
    s = seal(actor, project_id, kind, ref, level, content)
    cur = conn.execute(
        "INSERT INTO share_items(project_id, kind, ref, sha256, bytes, mime, signed_by,"
        " signature, level, added_by) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (project_id, kind, ref, s["sha256"], len(content), mime, s["signed_by"],
         s["signature"], level, actor))
    iid = int(cur.lastrowid or 0)
    record(conn, project_id, actor, iid, "import", sha256=s["sha256"], signature_ok=1,
           result=f"level={level};bytes={len(content)}")
    return {"item_id": iid, "sha256": s["sha256"], "signed_by": s["signed_by"],
            "signature": s["signature"], "level": level, "bytes": len(content),
            "key_fingerprint": key_fingerprint(actor)}


def list_items(conn, project_id: str, actor: str, include_revoked: bool = False) -> list[dict]:
    """按权限过滤列出（S5）。非成员 → 403。

    默认**不返回已撤下条目**（撤下=从分享区移除）；`include_revoked=True` 供审计/UI 显示历史。
    """
    m = member_row(conn, project_id, actor)
    if not m:
        raise ShareError("非项目成员，禁止取数", 403)
    rows = conn.execute(
        "SELECT id, project_id, kind, ref, sha256, bytes, mime, signed_by, level, added_by,"
        " added_at, revoked_at FROM share_items WHERE project_id=? ORDER BY id",
        (project_id,)).fetchall()
    out = [dict(r) for r in rows if can_read(r, m)]
    if not include_revoked:
        out = [r for r in out if not r["revoked_at"]]
    return out


def verify_stored(conn, item, content: bytes | None = None) -> tuple[bool, str]:
    if content is None:
        content = resolve_content(item["kind"], item["ref"])
    return verify(item["signed_by"], item["project_id"], item["kind"], item["ref"],
                  item["level"], item["sha256"], item["signature"], content)


def export_item(conn, project_id: str, item_id: int, actor: str) -> dict:
    """取数（export）：先验签，**失败即拒收**（S1），并留审计（S4）。"""
    item = get_item(conn, item_id)
    if not item or item["project_id"] != project_id:
        raise ShareError("条目不存在", 404)
    m = member_row(conn, project_id, actor)
    if not m:
        record(conn, project_id, actor, item_id, "export", sha256=item["sha256"],
               signature_ok=0, result="403_not_member")
        raise ShareError("非项目成员，禁止取数", 403)
    if not can_read(item, m):
        record(conn, project_id, actor, item_id, "export", sha256=item["sha256"],
               signature_ok=0, result="403_level_denied")
        raise ShareError("级别不足，禁止取数", 403)
    if item["revoked_at"]:
        record(conn, project_id, actor, item_id, "export", sha256=item["sha256"],
               signature_ok=0, result="409_revoked")
        raise ShareError("条目已撤下，禁止取数", 409)
    content = resolve_content(item["kind"], item["ref"])
    ok, reason = verify_stored(conn, item, content)
    if not ok:
        record(conn, project_id, actor, item_id, "export", sha256=item["sha256"],
               signature_ok=0, result=f"REJECT:{reason}")
        raise ShareError(f"验签失败，拒收：{reason}", 409)
    record(conn, project_id, actor, item_id, "export", sha256=item["sha256"],
           signature_ok=1, result="ok")
    out = {"ok": True, "item_id": item_id, "sha256": item["sha256"], "bytes": len(content),
           "verify": reason, "signed_by": item["signed_by"]}
    if len(content) <= MAX_EXPORT_BYTES:
        out["content_b64"] = _b64(content)
    return out


def revoke_item(conn, project_id: str, item_id: int, actor: str) -> dict:
    item = get_item(conn, item_id)
    if not item or item["project_id"] != project_id:
        raise ShareError("条目不存在", 404)
    m = member_row(conn, project_id, actor)
    if not m:
        raise ShareError("非项目成员，禁止操作", 403)
    if not (can_write(m) and (m["role"] == "owner" or item["added_by"] == actor)):
        raise ShareError("仅 owner 或条目添加者可撤下", 403)
    if item["revoked_at"]:
        raise ShareError("条目已撤下", 409)
    conn.execute("UPDATE share_items SET revoked_at=datetime('now','localtime') WHERE id=?",
                 (item_id,))
    record(conn, project_id, actor, item_id, "revoke", sha256=item["sha256"],
           signature_ok=1, result="revoked")
    return {"ok": True, "item_id": item_id, "revoked": True}


# ----------------------------------------------------------------- 沙箱（S3）
_SB_PROFILE = """(version 1)
(deny default)
(allow process*)
(allow file-read*)
(allow file-write* (subpath "{jail}"))
(allow file-write-data (literal "/dev/null") (literal "/dev/stdout") (literal "/dev/stderr"))
(allow sysctl-read)
"""

_PRELUDE = r'''
import builtins, os, socket, sys
_JAIL = {jail!r}
def _ok(p):
    try:
        return os.path.realpath(str(p)).startswith(_JAIL)
    except Exception:
        return False
_o, _oo = builtins.open, os.open
def _guarded(path, mode="r", *a, **k):
    if any(c in str(mode) for c in "wax+"):
        if not _ok(path):
            raise PermissionError("sandbox: write outside jail blocked: %s" % path)
    return _o(path, mode, *a, **k)
builtins.open = _guarded
def _gopen(path, flags, *a, **k):
    if flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT):
        if not _ok(path):
            raise PermissionError("sandbox: write outside jail blocked: %s" % path)
    return _oo(path, flags, *a, **k)
os.open = _gopen
class _NoNet(socket.socket):
    def connect(self, *a, **k):
        raise PermissionError("sandbox: network denied")
    def connect_ex(self, *a, **k):
        raise PermissionError("sandbox: network denied")
socket.socket = _NoNet
socket.create_connection = lambda *a, **k: (_ for _ in ()).throw(PermissionError("sandbox: network denied"))
'''


def _sandbox_cmd(jail_real: str) -> tuple[list[str], str]:
    exe = "/usr/bin/sandbox-exec"
    if sys.platform == "darwin" and os.path.exists(exe) and '"' not in jail_real:
        return [exe, "-p", _SB_PROFILE.format(jail=jail_real), sys.executable, "main.py"], "sandbox-exec"
    prelude = _PRELUDE.format(jail=jail_real)
    return [sys.executable, "-c", prelude + "\nexec(compile(open('main.py').read(), 'main.py', 'exec'),"
            " {'__name__': '__main__', '__file__': 'main.py'})"], "py-guard"


def _kill_group(p: subprocess.Popen) -> None:
    try:
        os.killpg(os.getpgid(p.pid), signal.SIGKILL)
    except Exception:  # noqa: BLE001
        try:
            p.kill()
        except Exception:  # noqa: BLE001
            pass


def sandbox_run(payload: bytes, tag: str, timeout: int = 20) -> dict:
    """在隔离目录执行 payload；默认无网络、隔离目录外不可写、超时可杀进程组。"""
    SANDBOX_ROOT.mkdir(parents=True, exist_ok=True)
    jail = SANDBOX_ROOT / f"{re.sub(r'[^A-Za-z0-9_.-]', '_', str(tag))}-{int(time.time())}"
    if jail.exists():
        shutil.rmtree(jail)
    jail.mkdir(parents=True, exist_ok=True)
    (jail / "main.py").write_bytes(payload)
    jail_real = str(jail.resolve())
    cmd, mode = _sandbox_cmd(jail_real)
    env = {"PATH": "/usr/bin:/bin", "HOME": jail_real, "TMPDIR": jail_real,
           "REAL_HOME": str(Path.home()), "LANG": "C", "PYTHONDONTWRITEBYTECODE": "1"}
    p = subprocess.Popen(cmd, cwd=jail_real, env=env, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, text=True, start_new_session=True)
    killed = False
    try:
        out, err = p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        killed = True
        _kill_group(p)
        out, err = p.communicate()
    return {"exit_code": p.returncode, "killed": killed, "mode": mode,
            "stdout": (out or "")[-4000:], "stderr": (err or "")[-4000:],
            "jail": str(jail.relative_to(ROOT))}


# ----------------------------------------------------------------- 执行（S2+S3+S4）
def execute_item(conn, project_id: str, item_id: int, actor: str, *,
                 consent_code: str | None = None, nonce: str | None = None,
                 timeout: int = 20) -> dict:
    """执行：需求 S2 本机显式同意 + S1 验签 + S3 沙箱 + S4 审计。**默认绝不自动执行**。"""
    item = get_item(conn, item_id)
    if not item or item["project_id"] != project_id:
        raise ShareError("条目不存在", 404)
    m = member_row(conn, project_id, actor)
    if not m:
        raise ShareError("非项目成员，禁止执行", 403)
    if not can_read(item, m):
        raise ShareError("级别不足，禁止执行", 403)
    if item["revoked_at"]:
        raise ShareError("条目已撤下，禁止执行", 409)

    # --- S2：本机显式同意（复用 remote_wake：4 位码 + 限速/锁定/审计） ---
    if not consent_code:
        record(conn, project_id, actor, item_id, "execute", sha256=item["sha256"],
               consent="missing", result="403_consent_required")
        raise ShareError("需本机显式同意：缺少 consent_code", 403)
    ok, reason = remote_wake.verify(actor, consent_code, src=f"share-execute:{item_id}")
    if reason == "not_enabled":
        record(conn, project_id, actor, item_id, "execute", sha256=item["sha256"],
               consent="not_enabled", result="403_consent_not_enabled")
        raise ShareError("本机未启用显式同意（wake-set），拒绝执行", 403)
    if not ok:
        record(conn, project_id, actor, item_id, "execute", sha256=item["sha256"],
               consent=f"denied:{reason}", result="403_bad_consent")
        raise ShareError(f"本机同意校验失败：{reason}", 403)

    # 一次性 nonce（同意不可重放）
    nonce = nonce or secrets.token_hex(8)
    consent_ref = f"granted:{nonce}"   # 同意凭据：一次性 nonce（防重放）
    if conn.execute("SELECT 1 FROM exchanges WHERE action='execute' AND consent=?",
                    (consent_ref,)).fetchone():
        record(conn, project_id, actor, item_id, "execute", sha256=item["sha256"],
               consent=consent_ref, result="403_consent_replay")
        raise ShareError("同意凭据已被使用（replay）", 403)

    # --- S1：执行前复验签名（篡改即拒收） ---
    content = resolve_content(item["kind"], item["ref"])
    vok, vreason = verify_stored(conn, item, content)
    if not vok:
        record(conn, project_id, actor, item_id, "execute", sha256=item["sha256"],
               signature_ok=0, consent=consent_ref, result=f"REJECT:{vreason}")
        raise ShareError(f"验签失败，拒绝执行：{vreason}", 409)

    # --- S3：沙箱执行 ---
    run = sandbox_run(content, f"item{item_id}", timeout=timeout)
    result = f"exit={run['exit_code']};killed={int(run['killed'])};mode={run['mode']}"
    record(conn, project_id, actor, item_id, "execute", sha256=item["sha256"],
           signature_ok=1, consent=consent_ref, result=result)
    return {"ok": run["exit_code"] == 0, "item_id": item_id, "consent": "granted",
            "nonce": nonce, "sandbox": run, "result": result}


# ----------------------------------------------------------------- 回滚（S6）
def apply_with_rollback(conn, project_id: str, item_id: int, actor: str, dest_rel: str,
                        content: bytes | None = None) -> dict:
    """把条目覆盖到**已存在的目标文件**（=误应用），**先建该文件的快照**；供一键回滚（S6）。"""
    item = get_item(conn, item_id)
    if not item or item["project_id"] != project_id:
        raise ShareError("条目不存在", 404)
    if not member_row(conn, project_id, actor):
        raise ShareError("非项目成员，禁止应用", 403)
    if not dest_rel or dest_rel.startswith("/") or ".." in dest_rel.split("/"):
        raise ShareError("dest 必须是项目内的相对路径", 400)
    dest = ROOT / dest_rel
    if not dest.exists():
        raise ShareError("目标文件不存在：错误应用需可回滚，故只允许覆盖既有文件", 400)
    vok, vreason = verify_stored(conn, item, content)
    if not vok:
        record(conn, project_id, actor, item_id, "execute", sha256=item["sha256"],
               signature_ok=0, result=f"REJECT:{vreason}")
        raise ShareError(f"验签失败，拒绝应用：{vreason}", 409)
    snap = apply_mod.snapshot(paths=[dest_rel])
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(content if content is not None
                     else (resolve_content(item["kind"], item["ref"]) or b""))
    record(conn, project_id, actor, item_id, "execute", sha256=item["sha256"],
           signature_ok=1, result=f"applied:{dest_rel};snapshot={snap.name}")
    return {"ok": True, "snapshot": snap.name, "dest": dest_rel}


def rollback_apply(conn, project_id: str, actor: str, item_id: int | None = None) -> dict:
    """一键回滚到最近快照（复用 `apply.rollback`），并留审计（S6）。没有快照 → 409。"""
    if not member_row(conn, project_id, actor):
        raise ShareError("非项目成员，禁止回滚", 403)
    item = get_item(conn, item_id) if item_id else None
    sha = item["sha256"] if item else None
    snap = apply_mod.rollback()
    if snap is None:
        record(conn, project_id, actor, item_id, "rollback", sha256=sha, result="no_snapshot")
        raise ShareError("无可用快照，无法回滚", 409)
    record(conn, project_id, actor, item_id, "rollback", sha256=sha, signature_ok=1,
           result=f"restored:{snap.name}")
    return {"ok": True, "restored": snap.name}
