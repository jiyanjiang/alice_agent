"""**通用**目录发现（Owner 2026-10-14：RSS 是更通用的方法，很多网站都这么更新）。

目标：**加一个网站 = 只给域名**，不用为每个站写代码：
  1. `find_feed(url)`    —— 自动找到该站的 RSS/Atom（先看首页 `<link rel=alternate>`，再试常见路径）；
  2. `derive_pattern(items)` —— 从目录里的文章链接**反推**「文章 URL 长什么样」（正则），
     喂给准入护栏（fail-closed 仍成立，但不必手写）；
  3. `discover(url)`     —— 一步到位：feed + items + 派生正则 + 建议的 exclude。

**只读目录**（URL/标题/时间），永不读正文。
"""
from __future__ import annotations

import re
import urllib.request
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse

UA = "TeamAI-Reader/1.0 (+human-reads-articles; feed-only)"
COMMON_PATHS = ("/feed/", "/feed", "/rss", "/rss.xml", "/rss-feed/", "/feed/atom/", "/atom.xml",
                "/index.xml", "/feed.xml", "/feeds/", "/feeds/atom.xml", "/news/feed/", "/rss/",
                "/blog/feed/", "/feed/rss", "/feeds/rss")
LINK_RE = re.compile(r'<link[^>]+rel=["\']?alternate["\']?[^>]*>', re.I)
HREF_RE = re.compile(r'href=["\']([^"\']+)["\']', re.I)
TYPE_RE = re.compile(r'type=["\']application/(?:rss|atom)\+xml["\']', re.I)
ID_SEG = re.compile(r"^(?:v?\d+|v\d+\.\d+)$", re.I)


def _get(url: str, timeout: int = 15) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": UA,
                                               "Accept": "text/html,application/xhtml+xml,application/rss+xml,application/xml,text/xml"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "ignore")


def find_feed(site: str) -> dict:
    """找到该站的 RSS/Atom。返回 {feed, found_by, items}；找不到返回 {feed: ""}。"""
    from scripts.feed_pull import parse_feed  # 复用解析（RSS/Atom 都吃）
    home = site if site.startswith("http") else "https://" + site
    cands: list[tuple[str, str]] = []
    try:
        html = _get(home)
        for tag in LINK_RE.findall(html):
            if TYPE_RE.search(tag) or "rss" in tag.lower() or "atom" in tag.lower():
                m = HREF_RE.search(tag)
                if m:
                    href = m.group(1)
                    cands.append((href if href.startswith("http") else home.rstrip("/") + "/" + href.lstrip("/"),
                                  "首页 <link rel=alternate>"))
        items = parse_feed(html)                      # 有些站首页直接就是 feed
        if items:
            return {"feed": home, "found_by": "首页即 feed", "items": items}
    except Exception:  # noqa: BLE001
        pass
    base = "https://" + urlparse(home).netloc
    cands += [(base + p, "常见路径") for p in COMMON_PATHS]
    for u, how in cands:
        try:
            items = parse_feed(_get(u, timeout=12))
            if items:
                return {"feed": u, "found_by": how, "items": items}
        except Exception:  # noqa: BLE001
            continue
    return {"feed": "", "found_by": "", "items": []}


def derive_patterns(urls: list[str], cover: float = 0.9) -> tuple[list[str], float]:
    """反推**一组**文章 URL 形态（覆盖 ≥`cover` 的链接）。

    取最高频形态直到累计覆盖达标——像 arstechnica 这种"栏目多、URL 前缀各异"的站，
    单条正则覆盖不足，必须多条（实测单条只有 20%，多条可到 90%+）。
    """
    if not urls:
        return [], 0.0
    host = urlparse(urls[0]).netloc.replace("www.", "")
    shapes: Counter = Counter()
    for u in urls:
        segs = [s for s in urlparse(u).path.strip("/").split("/") if s]
        if not segs:
            continue
        head = ["[\\w.-]+" if ID_SEG.match(s) else re.escape(s) for s in segs[:-1]]
        shapes["|".join(head)] += 1
    total = sum(shapes.values()) or 1
    picked, acc = [], 0
    for shape, n in shapes.most_common():
        parts = shape.split("|") if shape else []
        mid = "/".join(parts)
        picked.append(rf"^https?://(?:www\.)?{re.escape(host)}/{mid + '/' if mid else ''}[^/?#]+/?$")
        acc += n
        if acc / total >= cover:
            break
    return picked, round(acc / total, 2)


def derive_pattern(urls: list[str], min_ratio: float = 0.6) -> tuple[str, float]:
    """从目录里的文章链接**反推**文章 URL 形态。

    做法：去掉最后一段（slug），把"版本/编号"段（`v18`、`23`）折叠成通配，
    取**最高频形态**；覆盖率作为置信度返回。
    """
    if not urls:
        return "", 0.0
    host = urlparse(urls[0]).netloc.replace("www.", "")
    shapes: Counter = Counter()
    for u in urls:
        segs = [s for s in urlparse(u).path.strip("/").split("/") if s]
        if len(segs) < 1:
            continue
        head = segs[:-1]                       # 末段是 slug/编号 → 通配
        head = ["[\\w.-]+" if ID_SEG.match(s) else re.escape(s) for s in head]
        shapes["|".join(head)] += 1
    if not shapes:
        return "", 0.0
    shape, n = shapes.most_common(1)[0]
    parts = shape.split("|") if shape else []
    mid = "/".join(parts)
    pat = rf"^https?://(?:www\.)?{re.escape(host)}/{mid + '/' if mid else ''}[^/?#]+/?$"
    return pat, n / max(1, len(urls))


def discover(site: str) -> dict:
    """一步到位：找 feed → 解析 → 派生文章 URL 形态。"""
    f = find_feed(site)
    items = f.get("items") or []
    pats, ratio = derive_patterns([it["url"] for it in items])
    return {"feed": f.get("feed", ""), "found_by": f.get("found_by", ""),
            "items": items, "url_patterns": pats, "url_pattern": pats[0] if pats else "", "confidence": ratio,
            "domain": urlparse(items[0]["url"]).netloc.replace("www.", "") if items else ""}


if __name__ == "__main__":          # 自测：不联网也能验"派生"
    urls = ["https://physicsworld.com/a/gluon-x/", "https://physicsworld.com/a/word-flower/",
            "https://physics.aps.org/articles/v18/23", "https://physics.aps.org/articles/v18/7"]
    for grp in (urls[:2], urls[2:]):
        pat, ratio = derive_pattern(grp)
        print(f"  {pat}  (覆盖 {ratio:.0%})")
    ok = "a/[^/?#]" in derive_pattern(urls[:2])[0] and "articles/[\\w.-]+" in derive_pattern(urls[2:])[0]
    print("  自测:", "PASS" if ok else "FAIL")
