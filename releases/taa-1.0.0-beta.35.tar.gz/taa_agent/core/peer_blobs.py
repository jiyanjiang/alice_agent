"""P2P attachment blobs: content-addressed, verified, never sent to center.

A local post/chat attachment is registered under
``$TAA_HOME/blobs/<sha256>``. Peers fetch it from the source node with
``GET /v1/peer/blob/<sha256>`` and re-check the digest before accepting it.
"""
from __future__ import annotations

import hashlib
import mimetypes
import os
import pathlib
import shutil
import urllib.parse
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent.parent
UPLOADS = ROOT / "static" / "uploads"
TAA_HOME = pathlib.Path(os.environ.get("TAA_HOME") or (pathlib.Path.home() / ".taa"))
BLOBS = TAA_HOME / "blobs"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _local_file(url: str) -> pathlib.Path | None:
    raw = str(url or "").strip()
    if not raw.startswith("/static/uploads/"):
        return None
    name = raw.split("?", 1)[0].split("#", 1)[0].rsplit("/", 1)[-1]
    if not name or name in {".", ".."} or "/" in name or "\\" in name:
        return None
    p = UPLOADS / name
    return p if p.is_file() else None


def enrich_attachment(item) -> dict | None:
    """Return {url,name,sha256,size,mime} for a local upload; keep other URLs."""
    if isinstance(item, str):
        item = {"url": item}
    if not isinstance(item, dict):
        return None
    url = str(item.get("url") or "")
    p = _local_file(url)
    if p is None:
        return {**item, "url": url}
    digest = sha256_file(p)
    BLOBS.mkdir(parents=True, exist_ok=True)
    dest = BLOBS / digest
    if not dest.exists():
        try:
            shutil.copy2(p, dest)
        except OSError:
            pass
    return {
        **item,
        "url": url,
        "name": str(item.get("name") or p.name),
        "sha256": digest,
        "size": p.stat().st_size,
        "mime": str(item.get("mime") or mimetypes.guess_type(p.name)[0] or "application/octet-stream"),
    }


def enrich_attachments(items) -> list[dict]:
    out = []
    for item in items or []:
        enriched = enrich_attachment(item)
        if enriched:
            out.append(enriched)
    return out


def attachment_manifest(item) -> dict | None:
    if not item:
        return None
    enriched = enrich_attachment(item)
    if not enriched:
        return None
    # Do not expose a local path; UI can use the remote URL until blob sync maps it.
    return {k: enriched.get(k) for k in ("url", "name", "sha256", "size", "mime") if enriched.get(k) is not None}


def blob_path(digest: str) -> pathlib.Path:
    d = str(digest or "").strip().lower()
    if len(d) != 64 or any(c not in "0123456789abcdef" for c in d):
        raise ValueError("bad sha256")
    BLOBS.mkdir(parents=True, exist_ok=True)
    return BLOBS / d


def put_bytes(digest: str, data: bytes) -> pathlib.Path:
    if sha256_bytes(data) != digest:
        raise ValueError("sha256 mismatch")
    p = blob_path(digest)
    if not p.exists():
        p.write_bytes(data)
    return p


def fetch_blob(base: str, token: str, digest: str, *, timeout: int = 60) -> pathlib.Path:
    """Pull one blob from a peer and verify the digest before storing it."""
    try:
        target = blob_path(digest)
    except ValueError:
        raise
    if target.exists():
        return target
    url = base.rstrip("/") + "/v1/peer/blob/" + digest
    req = urllib.request.Request(url, headers={
        "X-TAA-Peer-Token": token,
        "user-agent": "TAA-Peer/0.1",
    })
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read()
    return put_bytes(digest, data)


def peer_url(item: dict) -> str:
    """Map a verified blob manifest to a local /app URL."""
    digest = str((item or {}).get("sha256") or "").strip().lower()
    if digest:
        try:
            blob_path(digest)
        except ValueError:
            return str((item or {}).get("url") or "")
        name = str((item or {}).get("name") or (digest + ".bin"))
        return "/app/peer-blob/" + digest + "/" + urllib.parse.quote(name, safe="")
    return str((item or {}).get("url") or "")
