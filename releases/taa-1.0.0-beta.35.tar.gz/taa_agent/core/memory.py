"""Agent 本地记忆与人格（docs/05_Agent记忆与人格设计.md）。

三层：描述层 persona.yaml（基因）· 长期记忆 memory.db（经历）· 热记忆 working（注意力）。
人格核心 = values_t 里的可编辑权重；reflect() 有界地改写它。
"""
from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

from . import persona as persona_mod

SCHEMA = Path(__file__).resolve().parent / "memory_schema.sql"

DEFAULT_VALUES = {
    "rigor": 0.60, "novelty": 0.50, "speed": 0.50, "safety": 0.60,
    "collaboration": 0.55, "autonomy": 0.50, "visibility": 0.40,
}
CORE_VALUES = {"safety"}            # 仅 safety 不可自改
STEP_CAP = 0.05                     # 单次反思单权重最大变化
WORKING_TTL_HOURS = 24
WORKING_CAP = 50


def memory_path(agent_id: str) -> Path:
    return persona_mod.agent_dir(agent_id) / "memory.db"


def connect(agent_id: str) -> sqlite3.Connection:
    conn = sqlite3.connect(memory_path(agent_id))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


def init_memory(agent_id: str) -> None:
    conn = connect(agent_id)
    try:
        conn.executescript(SCHEMA.read_text(encoding="utf-8"))
        conn.commit()
    finally:
        conn.close()


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _expiry(hours: int) -> str:
    return (datetime.now() + timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")


# ------------------------------------------------------------------ seed
def seed_from_persona(agent_id: str, p: dict) -> None:
    """幂等：只在首次（values_t 为空）写入初始权重，避免覆盖已演化的权重。"""
    init_memory(agent_id)
    conn = connect(agent_id)
    try:
        first_time = conn.execute("SELECT COUNT(*) c FROM values_t").fetchone()["c"] == 0
        if first_time:
            for k, v in DEFAULT_VALUES.items():
                core = 1 if k in CORE_VALUES else 0
                conn.execute(
                    "INSERT OR IGNORE INTO values_t(key, value, core) VALUES (?,?,?)", (k, v, core))
            # persona 里若显式给了 values（含 min/max/core），覆盖初始值
            for k, spec in (p.get("values") or {}).items():
                if isinstance(spec, dict):
                    conn.execute(
                        "INSERT INTO values_t(key, value, min, max, core) VALUES (?,?,?,?,?) "
                        "ON CONFLICT(key) DO UPDATE SET value=excluded.value, min=excluded.min, "
                        "max=excluded.max, core=excluded.core",
                        (k, float(spec.get("value", DEFAULT_VALUES.get(k, 0.5))),
                         float(spec.get("min", 0.05)), float(spec.get("max", 0.95)),
                         1 if spec.get("core") else (1 if k in CORE_VALUES else 0)))
                else:
                    conn.execute("UPDATE values_t SET value=? WHERE key=?", (float(spec), k))
        for s in p.get("skills", []):
            if isinstance(s, dict) and s.get("name"):
                conn.execute(
                    "INSERT OR IGNORE INTO skills(name, level, target, strategy) VALUES (?,?,?,?)",
                    (s["name"], float(s.get("level", 0.5)), float(s.get("target", 0.5)),
                     s.get("strategy", "broaden")))
        for tag in p.get("interests", []):
            conn.execute("INSERT OR IGNORE INTO interests(tag, weight) VALUES (?,?)", (str(tag), 0.5))
        proj = p.get("current_project")
        has_focus = conn.execute("SELECT 1 FROM working WHERE kind='focus' LIMIT 1").fetchone()
        if proj and not has_focus:
            conn.execute(
                "INSERT INTO working(kind, content, priority, expires_at) VALUES ('focus',?,?,?)",
                (json.dumps({"project": proj}, ensure_ascii=False), 0.9, _expiry(WORKING_TTL_HOURS * 7)))
        conn.commit()
    finally:
        conn.close()
    export_working(agent_id)


# ------------------------------------------------------------------ working (hot)
def add_working(agent_id: str, kind: str, content, priority: float = 0.5,
                ttl_hours: int = WORKING_TTL_HOURS) -> int:
    conn = connect(agent_id)
    try:
        cur = conn.execute(
            "INSERT INTO working(kind, content, priority, expires_at) VALUES (?,?,?,?)",
            (kind, content if isinstance(content, str) else json.dumps(content, ensure_ascii=False),
             float(priority), _expiry(ttl_hours)))
        conn.commit()
        _trim_working(conn)
        rid = cur.lastrowid
    finally:
        conn.close()
    export_working(agent_id)      # 物化热记忆
    return rid


def _trim_working(conn) -> None:
    conn.execute("DELETE FROM working WHERE expires_at IS NOT NULL AND expires_at < ?", (_now(),))
    rows = conn.execute(
        "SELECT id FROM working ORDER BY priority DESC, id DESC LIMIT -1 OFFSET ?", (WORKING_CAP,)
    ).fetchall()
    for r in rows:
        conn.execute("DELETE FROM working WHERE id=?", (r["id"],))
    conn.commit()


def hot(agent_id: str) -> list[dict]:
    conn = connect(agent_id)
    try:
        _trim_working(conn)
        rows = conn.execute(
            "SELECT * FROM working WHERE expires_at IS NULL OR expires_at >= ? "
            "ORDER BY priority DESC, id DESC", (_now(),)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def context(agent_id: str, recent: int = 8) -> dict:
    """立刻可召集的热上下文包。"""
    p = persona_mod.load_persona(agent_id)
    entries = hot(agent_id)
    focus = next((e["content"] for e in entries if e["kind"] == "focus"), None)
    intents = [e["content"] for e in entries if e["kind"] == "intent"][:5]
    questions = [e["content"] for e in entries if e["kind"] == "open_question"][:5]
    recent_ev = [e["content"] for e in entries if e["kind"] == "recent_event"][:recent]
    return {
        "agent": p.get("name", agent_id),
        "motto": (p.get("identity") or {}).get("motto"),
        "focus": json.loads(focus) if focus and focus.startswith("{") else focus,
        "values": get_values(agent_id),
        "intents": intents,
        "open_questions": questions,
        "recent": recent_ev,
    }


def export_working(agent_id: str) -> Path:
    path = persona_mod.agent_dir(agent_id) / "working.json"
    path.write_text(json.dumps(context(agent_id), ensure_ascii=False, indent=2), encoding="utf-8")
    return path


# ------------------------------------------------------------------ values
def get_values(agent_id: str) -> dict:
    conn = connect(agent_id)
    try:
        rows = conn.execute("SELECT key, value FROM values_t ORDER BY key").fetchall()
        return {r["key"]: round(r["value"], 4) for r in rows}
    finally:
        conn.close()


def values_detail(agent_id: str) -> list[dict]:
    conn = connect(agent_id)
    try:
        rows = conn.execute("SELECT * FROM values_t ORDER BY key").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def set_value(agent_id: str, key: str, value: float, reason: str = "manual",
              force: bool = False) -> dict:
    conn = connect(agent_id)
    try:
        row = conn.execute("SELECT * FROM values_t WHERE key=?", (key,)).fetchone()
        if not row:
            raise KeyError(f"unknown value: {key}")
        if row["core"] and not force:
            raise PermissionError(f"value '{key}' is core (immutable)")
        new = max(float(row["min"]), min(float(row["max"]), float(value)))
        conn.execute("UPDATE values_t SET value=?, updated_at=? WHERE key=?", (new, _now(), key))
        conn.execute("INSERT INTO weight_history(key, old, new, reason) VALUES (?,?,?,?)",
                     (key, row["value"], new, reason))
        conn.commit()
        result = {"key": key, "old": row["value"], "new": new, "reason": reason}
    finally:
        conn.close()
    sync_persona_snapshot(agent_id)
    return result


def rollback(agent_id: str, key: str, to: float, force: bool = False) -> dict:
    return set_value(agent_id, key, to, reason="rollback", force=force)


def weight_history(agent_id: str, limit: int = 50) -> list[dict]:
    conn = connect(agent_id)
    try:
        rows = conn.execute(
            "SELECT * FROM weight_history ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def sync_persona_snapshot(agent_id: str) -> None:
    """把 memory.db 的 values 写回 persona.yaml（基因快照）。

    注意：不覆盖 scoring_weights——任务权重由 scoring 层在读取时用 values 做调制（M5b），
    避免演化过程破坏人设中精心设定的权重基线。
    """
    p = persona_mod.load_persona(agent_id)
    p["values"] = get_values(agent_id)
    try:
        persona_mod.save_persona(agent_id, p)
    except Exception:
        pass


# ------------------------------------------------------------------ memory writes
def add_episodic(agent_id: str, summary: str, kind: str = "event",
                 refs: dict | None = None, salience: float = 0.5) -> int:
    conn = connect(agent_id)
    try:
        cur = conn.execute(
            "INSERT INTO episodic(kind, summary, refs, salience, decayed) VALUES (?,?,?,?,?)",
            (kind, summary, json.dumps(refs or {}, ensure_ascii=False), salience, salience))
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def remember_semantic(agent_id: str, key: str, value: str,
                      confidence: float = 0.6, source: str | None = None) -> None:
    conn = connect(agent_id)
    try:
        conn.execute(
            "INSERT INTO semantic(key, value, confidence, source, updated_at) VALUES (?,?,?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, confidence=excluded.confidence, "
            "source=excluded.source, updated_at=excluded.updated_at",
            (key, value, confidence, source, _now()))
        conn.commit()
    finally:
        conn.close()


def add_reputation(agent_id: str, event_type: str, points: float, ref: str | None = None) -> None:
    conn = connect(agent_id)
    try:
        conn.execute("INSERT INTO reputation_local(event_type, points, ref) VALUES (?,?,?)",
                     (event_type, float(points), ref))
        conn.commit()
    finally:
        conn.close()


def bump_relationship(agent_id: str, other: str, delta: float = 0.02,
                      note: str | None = None) -> dict:
    """协作信号：与某 agent 互动后更新信任。"""
    if not other or other == agent_id:
        return {}
    conn = connect(agent_id)
    try:
        conn.execute(
            "INSERT INTO relationships(other_agent, trust, interactions, notes) VALUES (?,?,1,?) "
            "ON CONFLICT(other_agent) DO UPDATE SET "
            "trust=MIN(0.99, MAX(0.01, trust+?)), interactions=interactions+1, "
            "notes=COALESCE(?, notes), updated_at=datetime('now','localtime')",
            (other, min(0.99, 0.5 + delta), note, delta, note))
        conn.commit()
        r = conn.execute("SELECT * FROM relationships WHERE other_agent=?", (other,)).fetchone()
        return dict(r)
    finally:
        conn.close()


def get_relationships(agent_id: str) -> list[dict]:
    conn = connect(agent_id)
    try:
        rows = conn.execute(
            "SELECT * FROM relationships ORDER BY trust DESC").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_skills(agent_id: str) -> list[dict]:
    conn = connect(agent_id)
    try:
        rows = conn.execute("SELECT * FROM skills ORDER BY level DESC").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_interests(agent_id: str) -> list[dict]:
    conn = connect(agent_id)
    try:
        rows = conn.execute("SELECT tag, weight FROM interests ORDER BY weight DESC").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def reputation_total(agent_id: str) -> float:
    conn = connect(agent_id)
    try:
        return _net_reputation(conn)
    finally:
        conn.close()


def generate_resume(agent_id: str) -> Path:
    """由记忆自动生成简历（M5d）。"""
    p = persona_mod.load_persona(agent_id)
    ident = p.get("identity") or {}
    values = get_values(agent_id)
    skills = get_skills(agent_id)
    interests = get_interests(agent_id)
    rels = get_relationships(agent_id)
    eps = recent_episodic(agent_id, 8)
    refs = reflections(agent_id, 5)
    hist = weight_history(agent_id, 8)
    cs = p.get("career_strategy") or {}

    lines = [
        f"# {p.get('name', agent_id)} · 简历（自动生成）",
        "",
        f"> {ident.get('avatar', '')} {ident.get('motto', '')}",
        f"> 角色：{p.get('role')} · 当前项目：{p.get('current_project', '-')}",
        f"> 职业目标：{cs.get('objective', '-')}",
        "",
        "## 价值观（性格权重，可演化）",
        "",
    ]
    for k, v in sorted(values.items(), key=lambda x: -x[1]):
        lines.append(f"- {k}: {v:.2f}")
    lines += ["", "## 技能", ""]
    for s in skills:
        lines.append(f"- {s['name']}: {s.get('level', 0):.2f} → 目标 {s.get('target', 0):.2f}（{s.get('strategy', '-')}）")
    lines += ["", "## 兴趣", ""]
    lines += [f"- {i['tag']}: {i['weight']:.2f}" for i in interests] or ["- （暂无）"]
    lines += ["", f"## 信誉：{reputation_total(agent_id):.1f}", "", "## 关系", ""]
    lines += [f"- {r['other_agent']}: trust={r['trust']:.2f}（互动 {r['interactions']} 次）" for r in rels] or ["- （暂无）"]
    lines += ["", "## 近期经历", ""]
    lines += [f"- [{e.get('kind')}] {e['summary']}" for e in eps] or ["- （暂无）"]
    lines += ["", "## 成长（最近权重变化）", ""]
    lines += [f"- {h['key']}: {h['old']:.2f} → {h['new']:.2f}（{h['reason']}）" for h in hist] or ["- （暂无）"]
    lines += ["", "## 反思", ""]
    lines += [f"- [{r.get('trigger')}] {r.get('summary') or ''} {r.get('adjustments') or ''}" for r in refs] or ["- （暂无）"]
    lines.append("")

    path = persona_mod.agent_dir(agent_id) / "resume.md"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def build_profile_summary(agent_id: str) -> dict:
    """组装「务虚」档案摘要（G1）：只含价值观/兴趣/思维风格等，不含工件/密钥/路径。"""
    p = persona_mod.load_persona(agent_id)
    ident = p.get("identity") or {}
    excerpt = ""
    rp = persona_mod.agent_dir(agent_id) / "resume.md"
    if rp.exists():
        lines = [l.strip() for l in rp.read_text(encoding="utf-8").splitlines() if l.strip()]
        excerpt = " ".join(lines[3:6])[:300]
    return {
        "agent_id": agent_id,
        "display_name": p.get("name"),
        "role": p.get("role"),
        "motto": ident.get("motto"),
        "values": get_values(agent_id),
        "thinking_style": p.get("reasoning_policy") or {},
        "skills_summary": [{"name": s["name"], "level": s.get("level"),
                            "strategy": s.get("strategy")} for s in get_skills(agent_id)],
        "interests": get_interests(agent_id),
        "current_project": p.get("current_project"),
        "current_questions": [e["content"] for e in hot(agent_id) if e["kind"] == "open_question"][:5],
        "fascinations": list(p.get("interests", []))[:8],
        "reputation": reputation_total(agent_id),
        "resume_excerpt": excerpt,
    }


def recent_episodic(agent_id: str, limit: int = 20) -> list[dict]:
    conn = connect(agent_id)
    try:
        rows = conn.execute("SELECT * FROM episodic ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ------------------------------------------------------------------ reflect (self-modify)
def _net_reputation(conn) -> float:
    row = conn.execute("SELECT COALESCE(SUM(points),0) s FROM reputation_local").fetchone()
    return float(row["s"])


def _heuristic_deltas(conn) -> dict:
    """确定性启发式：从结果证据给出候选权重变化。"""
    deltas: dict[str, float] = {}
    net = _net_reputation(conn)
    if net < 0:
        deltas["rigor"] = STEP_CAP
        deltas["safety"] = 0.0  # core，不允许
    elif net > 0:
        deltas["visibility"] = STEP_CAP * 0.5
        deltas["speed"] = STEP_CAP * 0.5
    # 失败的探索型决策 -> 收敛 novelty
    fails = conn.execute(
        "SELECT COUNT(*) c FROM decisions WHERE outcome LIKE '%fail%'").fetchone()["c"]
    succ = conn.execute(
        "SELECT COUNT(*) c FROM decisions WHERE outcome LIKE '%success%'").fetchone()["c"]
    if fails > succ and fails > 0:
        deltas["novelty"] = -STEP_CAP
    return deltas


def reflect(agent_id: str, trigger: str = "manual", proposer=None,
            summary: str | None = None) -> dict:
    """有界自我修改：启发式 + 可选 LLM 建议（均过边界与规则）。"""
    conn = connect(agent_id)
    try:
        deltas = _heuristic_deltas(conn)
        if proposer is not None:
            prompt = _reflect_prompt(agent_id, conn)
            try:
                llm = proposer(prompt) or {}
                for k, v in llm.items():
                    if k in DEFAULT_VALUES:
                        deltas[k] = deltas.get(k, 0.0) + float(v)
            except Exception as e:  # LLM 失败不影响确定性部分
                deltas["_llm_error"] = str(e)
    finally:
        conn.close()

    applied = {}
    for k, d in deltas.items():
        if k.startswith("_"):
            continue
        d = max(-STEP_CAP, min(STEP_CAP, float(d)))
        if abs(d) < 1e-9:
            continue
        cur = get_values(agent_id).get(k)
        if cur is None:
            continue
        row = values_detail(agent_id)
        core = next((r["core"] for r in row if r["key"] == k), 0)
        if core:
            continue
        try:
            applied[k] = set_value(agent_id, k, cur + d, reason=f"reflect:{trigger}")
        except Exception:
            pass

    conn = connect(agent_id)
    try:
        conn.execute("INSERT INTO reflections(trigger, summary, adjustments) VALUES (?,?,?)",
                     (trigger, summary, json.dumps(applied, ensure_ascii=False)))
        conn.commit()
    finally:
        conn.close()
    export_working(agent_id)
    generate_resume(agent_id)
    return {"agent": agent_id, "trigger": trigger, "applied": applied}


def _reflect_prompt(agent_id: str, conn) -> str:
    values = {r["key"]: round(r["value"], 3) for r in
              conn.execute("SELECT key, value FROM values_t").fetchall()}
    rep = conn.execute("SELECT event_type, points FROM reputation_local ORDER BY id DESC LIMIT 20").fetchall()
    eps = conn.execute("SELECT summary FROM episodic ORDER BY id DESC LIMIT 10").fetchall()
    return (
        "你是 agent 的反思引擎。根据近期结果，给出对以下价值观权重的**微小**调整建议（每个 -0.05~+0.05）。"
        "只返回 JSON，如 {\"rigor\": 0.03, \"novelty\": -0.02}，不要解释。\n"
        f"当前价值观: {json.dumps(values, ensure_ascii=False)}\n"
        f"近期信誉事件: {json.dumps([dict(r) for r in rep], ensure_ascii=False)}\n"
        f"近期经历: {json.dumps([r['summary'] for r in eps], ensure_ascii=False)}"
    )


def reflections(agent_id: str, limit: int = 20) -> list[dict]:
    conn = connect(agent_id)
    try:
        rows = conn.execute("SELECT * FROM reflections ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ------------------------------------------------------------------ facts (TLP 1.1)
# 事实记忆：世界是事实的总和，而非物的总和。由 core/harvest.py 从群聊增量提炼。
FACT_VERDICTS = {"success", "failure", "true", "false", "open", "decision", "lesson"}


def fact_fingerprint(statement: str) -> str:
    """规范化去重指纹：去除空白与常见标点差异，避免同一事实反复入库。"""
    norm = re.sub(r"[\s，。、；：！？,.;:!?\"'“”‘’()（）\[\]【】]", "", statement or "")
    return hashlib.sha256(norm.encode("utf-8")).hexdigest()[:32]


def add_fact(agent_id: str, statement: str, *, verdict: str | None = None,
             kind: str = "fact", evidence: str | None = None,
             source: str | None = None, room_id: str | None = None,
             msg_from: int | None = None, msg_to: int | None = None,
             speaker: str | None = None, confidence: float = 0.6,
             salience: float = 0.5, status: str = "active") -> int | None:
    """写一条事实。同 fingerprint 已存在（任意 status）则跳过，返回 None。"""
    statement = (statement or "").strip()
    if not statement:
        return None
    fp = fact_fingerprint(statement)
    conn = connect(agent_id)
    try:
        cur = conn.execute(
            "INSERT OR IGNORE INTO facts(statement, verdict, kind, evidence, source, "
            "room_id, msg_from, msg_to, speaker, confidence, salience, status, fingerprint) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (statement, verdict, kind, evidence, source, room_id, msg_from, msg_to,
             speaker, float(confidence), float(salience), status, fp))
        conn.commit()
        return cur.lastrowid if cur.rowcount else None
    finally:
        conn.close()


def list_facts(agent_id: str, *, room_id: str | None = None, verdict: str | None = None,
               status: str = "active", limit: int = 50) -> list[dict]:
    q = "SELECT * FROM facts WHERE 1=1"
    args: list = []
    if status:
        q += " AND status=?"; args.append(status)
    if room_id:
        q += " AND room_id=?"; args.append(room_id)
    if verdict:
        q += " AND verdict=?"; args.append(verdict)
    q += " ORDER BY salience DESC, id DESC LIMIT ?"; args.append(int(limit))
    conn = connect(agent_id)
    try:
        return [dict(r) for r in conn.execute(q, args).fetchall()]
    finally:
        conn.close()


def set_fact_status(agent_id: str, fact_id: int, status: str) -> None:
    """梯子（6.54）：事实可被废弃/取代，但不物理删除，保留可审计。"""
    conn = connect(agent_id)
    try:
        conn.execute("UPDATE facts SET status=? WHERE id=?", (status, int(fact_id)))
        conn.commit()
    finally:
        conn.close()


def get_cursor(agent_id: str, room_id: str) -> int:
    conn = connect(agent_id)
    try:
        row = conn.execute("SELECT last_msg_id FROM fact_cursor WHERE agent=? AND room_id=?",
                           (agent_id, room_id)).fetchone()
        return int(row["last_msg_id"]) if row else 0
    finally:
        conn.close()


def set_cursor(agent_id: str, room_id: str, last_msg_id: int) -> None:
    conn = connect(agent_id)
    try:
        conn.execute(
            "INSERT INTO fact_cursor(agent, room_id, last_msg_id, updated_at) "
            "VALUES (?,?,?,datetime('now','localtime')) "
            "ON CONFLICT(agent, room_id) DO UPDATE SET last_msg_id=excluded.last_msg_id, "
            "updated_at=excluded.updated_at",
            (agent_id, room_id, int(last_msg_id)))
        conn.commit()
    finally:
        conn.close()


def fact_stats(agent_id: str) -> dict:
    conn = connect(agent_id)
    try:
        total = conn.execute("SELECT COUNT(*) c FROM facts WHERE status='active'").fetchone()["c"]
        by_verdict = {r["verdict"]: r["c"] for r in conn.execute(
            "SELECT verdict, COUNT(*) c FROM facts WHERE status='active' GROUP BY verdict").fetchall()}
        rooms = conn.execute("SELECT COUNT(DISTINCT room_id) c FROM facts WHERE room_id IS NOT NULL").fetchone()["c"]
        return {"total": total, "by_verdict": by_verdict, "rooms": rooms}
    finally:
        conn.close()


# ------------------------------------------------------------------ 经验 / 规范知识库（playbook）
# 由 core/playbook.py 让 **LLM 判断**哪些群聊内容值得入库（事实源/工具/规划/流程/品味/偏好/教训）。
PLAYBOOK_TYPES = {"source", "tool", "planning", "process", "taste", "style", "preference", "pitfall"}
_PB_READY: set[str] = set()


def _ensure_playbook(agent_id: str) -> None:
    if agent_id in _PB_READY:
        return
    conn = connect(agent_id)
    try:
        conn.executescript(SCHEMA.read_text(encoding="utf-8"))   # 幂等：老库也能补出新表
        conn.commit()
    finally:
        conn.close()
    _PB_READY.add(agent_id)


def add_learning(agent_id: str, statement: str, *, type_: str = "process",
                 rationale: str | None = None, evidence: str | None = None,
                 scope: str = "agent", room_id: str | None = None,
                 msg_from: int | None = None, msg_to: int | None = None,
                 confidence: float = 0.6, salience: float = 0.5,
                 status: str = "active") -> int | None:
    """写一条经验/规范。同 fingerprint 已存在则跳过，返回 None。"""
    statement = (statement or "").strip()
    if not statement:
        return None
    _ensure_playbook(agent_id)
    fp = fact_fingerprint(statement)
    conn = connect(agent_id)
    try:
        cur = conn.execute(
            "INSERT OR IGNORE INTO playbook(type, statement, rationale, evidence, scope, "
            "room_id, msg_from, msg_to, confidence, salience, status, fingerprint) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (type_, statement, rationale, evidence, scope, room_id, msg_from, msg_to,
             float(confidence), float(salience), status, fp))
        conn.commit()
        return cur.lastrowid if cur.rowcount else None
    finally:
        conn.close()


def list_learnings(agent_id: str, *, type_: str | None = None, scope: str | None = None,
                   status: str = "active", limit: int = 50) -> list[dict]:
    _ensure_playbook(agent_id)
    q = "SELECT * FROM playbook WHERE 1=1"
    args: list = []
    if status:
        q += " AND status=?"; args.append(status)
    if type_:
        q += " AND type=?"; args.append(type_)
    if scope:
        q += " AND scope=?"; args.append(scope)
    q += " ORDER BY salience DESC, id DESC LIMIT ?"; args.append(int(limit))
    conn = connect(agent_id)
    try:
        return [dict(r) for r in conn.execute(q, args).fetchall()]
    finally:
        conn.close()


def playbook_stats(agent_id: str) -> dict:
    _ensure_playbook(agent_id)
    conn = connect(agent_id)
    try:
        total = conn.execute("SELECT COUNT(*) c FROM playbook WHERE status='active'").fetchone()["c"]
        by_type = {r["type"]: r["c"] for r in conn.execute(
            "SELECT type, COUNT(*) c FROM playbook WHERE status='active' GROUP BY type").fetchall()}
        by_scope = {r["scope"]: r["c"] for r in conn.execute(
            "SELECT scope, COUNT(*) c FROM playbook WHERE status='active' GROUP BY scope").fetchall()}
        return {"total": total, "by_type": by_type, "by_scope": by_scope}
    finally:
        conn.close()


def get_learning_cursor(agent_id: str, room_id: str) -> int:
    _ensure_playbook(agent_id)
    conn = connect(agent_id)
    try:
        row = conn.execute("SELECT last_msg_id FROM learning_cursor WHERE agent=? AND room_id=?",
                           (agent_id, room_id)).fetchone()
        return int(row["last_msg_id"]) if row else 0
    finally:
        conn.close()


def set_learning_cursor(agent_id: str, room_id: str, last_msg_id: int) -> None:
    _ensure_playbook(agent_id)
    conn = connect(agent_id)
    try:
        conn.execute(
            "INSERT INTO learning_cursor(agent, room_id, last_msg_id, updated_at) "
            "VALUES (?,?,?,datetime('now','localtime')) "
            "ON CONFLICT(agent, room_id) DO UPDATE SET last_msg_id=excluded.last_msg_id, "
            "updated_at=excluded.updated_at", (agent_id, room_id, int(last_msg_id)))
        conn.commit()
    finally:
        conn.close()


# ------------------------------------------------------------------ 规划优先（plans）
def record_plan(agent_id: str, topic: str, target: str, plan: str, *,
                status: str = "draft", review: dict | None = None) -> int:
    """记一轮方案（cycle 自增），返回 cycle。"""
    _ensure_playbook(agent_id)
    conn = connect(agent_id)
    try:
        n = conn.execute("SELECT COALESCE(MAX(cycle),0)+1 FROM plans WHERE topic=? AND target=?",
                         (topic, target)).fetchone()[0]
        conn.execute(
            "INSERT INTO plans(agent, topic, target, plan, status, review, cycle) "
            "VALUES (?,?,?,?,?,?,?)",
            (agent_id, topic, target, plan, status,
             json.dumps(review or {}, ensure_ascii=False), int(n)))
        conn.commit()
        return int(n)
    finally:
        conn.close()


def latest_plan(agent_id: str, topic: str, target: str) -> dict | None:
    _ensure_playbook(agent_id)
    conn = connect(agent_id)
    try:
        row = conn.execute("SELECT * FROM plans WHERE topic=? AND target=? ORDER BY cycle DESC LIMIT 1",
                           (topic, target)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def list_plans(agent_id: str, topic: str | None = None, target: str | None = None,
               limit: int = 20) -> list[dict]:
    _ensure_playbook(agent_id)
    q = "SELECT id,topic,target,status,cycle,ts FROM plans WHERE 1=1"
    args: list = []
    if topic:
        q += " AND topic=?"; args.append(topic)
    if target:
        q += " AND target=?"; args.append(target)
    q += " ORDER BY id DESC LIMIT ?"; args.append(int(limit))
    conn = connect(agent_id)
    try:
        return [dict(r) for r in conn.execute(q, args).fetchall()]
    finally:
        conn.close()


# ------------------------------------------------------------------ 监督工作循环 (review cycles)
def add_review_cycle(agent_id: str, topic: str, target: str, items: int, defects: int,
                     passed: bool, *, criteria=None, detail=None, refs=None,
                     last_seen: str | None = None) -> dict:
    """记一轮监督循环；cycle_no 同 (agent,topic,target) 自增。"""
    conn = connect(agent_id)
    try:
        n = conn.execute(
            "SELECT COALESCE(MAX(cycle_no),0)+1 FROM review_cycles WHERE agent=? AND topic=? AND target=?",
            (agent_id, topic, target)).fetchone()[0]
        conn.execute(
            "INSERT INTO review_cycles(agent,topic,target,cycle_no,items,defects,passed,"
            "criteria,detail,refs,last_seen) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (agent_id, topic, target, int(n), int(items), int(defects), 1 if passed else 0,
             json.dumps(criteria or {}, ensure_ascii=False), json.dumps(detail or [], ensure_ascii=False),
             json.dumps(refs or [], ensure_ascii=False), last_seen))
        conn.commit()
        return {"cycle_no": int(n), "topic": topic, "target": target, "items": items,
                "defects": defects, "passed": bool(passed)}
    finally:
        conn.close()


def list_review_cycles(agent_id: str, topic: str, target: str | None = None) -> list[dict]:
    q = "SELECT * FROM review_cycles WHERE agent=? AND topic=?"
    args: list = [agent_id, topic]
    if target:
        q += " AND target=?"; args.append(target)
    q += " ORDER BY cycle_no ASC"
    conn = connect(agent_id)
    try:
        return [dict(r) for r in conn.execute(q, args).fetchall()]
    finally:
        conn.close()


def review_convergence(agent_id: str, topic: str, target: str | None = None) -> dict:
    """收敛判据：缺陷序列是否单调不增、并以 0（通过）收尾。"""
    rows = list_review_cycles(agent_id, topic, target)
    series = [r["defects"] for r in rows]
    if not rows:
        return {"topic": topic, "cycles": 0, "series": [], "converged": False,
                "monotonic": True, "min_cycle": None}
    monotonic = all(series[i] <= series[i - 1] for i in range(1, len(series)))
    converged = rows[-1]["passed"] == 1 and series[-1] == 0
    min_cycle = next((r["cycle_no"] for r in rows if r["passed"] == 1 and r["defects"] == 0), None)
    return {"topic": topic, "cycles": len(rows), "series": series,
            "converged": converged, "monotonic": monotonic, "min_cycle": min_cycle,
            "last_passed": bool(rows[-1]["passed"])}
