"""专著流水线：立意 → 问题树 → 检索 → 事实库 → 生成 → 三自检。

本模块把 `docs/37`（七步）与 `docs/82`（三自检）落成**可执行、可复核**的流水线。
确定性部分（切大纲、问题树、事实校验、统计、门禁）不调 LLM；
只有「检索后的抽取」与「按事实写作」调 `research.ask`（DeepSeek）。

核心纪律：
  · 事实库没有的，稿子里不能有；
  · 每条事实必须能回到**检索到的原文**（quote 逐字校验，找不到就丢）；
  · 问题树有依赖关系（章内链式、章间接力），不是一堆散问题；
  · 生成、论证、文风三道检查各自留报告。

用法见 `scripts/monograph.py`。
"""
from __future__ import annotations

import difflib
import hashlib
import json
import re
import sqlite3
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict
from pathlib import Path

from core import research, retrieval

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / "research"

# ------------------------------------------------------------------ 提示词
FACT_SYSTEM = """你是历史学资料员，服务一部中文历史专著的写作。纪律：
①只从给定材料里抽取，不补全、不推断、不编造；
②每条事实必须附「逐字原文摘录」，不得改写、不得合并两句；
③材料不够就写进 gaps，宁可少一条，不可造一条；
④严格输出 JSON，不要解释。"""

FACT_PROMPT = """研究问题：{question}

本书章节：{chapter}｜小节：{section}
这一问要支撑的判断：{claim}

下面是从公开来源检索到的材料。每条材料有编号、标题、URL、来源分级、正文摘录。

{docs}

请抽取 8–12 条**可核验事实**。每条：
- claim：一句可独立成立的中文陈述（20–120 字），写清人物/地点/年代/制度/数量中的至少两项；不要写“可能/也许/据说”；
- source_id：材料编号（S1…S{max_id}）；
- quote：从该材料正文中**逐字复制**的片段（20–300 字），不得改写、不得拼接；
- grade：primary / official / secondary / weak（不得高于材料标注）；
- used_for：这条事实在本书中的用途（章节 + 论点，20 字内）；
- confidence：high / medium / low。

只输出 JSON：
{{"facts":[{{"claim":"...","source_id":"S1","quote":"...","grade":"secondary","used_for":"...","confidence":"high"}}],"gaps":["..."]}}

若材料与问题无关，facts 返回空数组，并在 gaps 说明缺什么材料。"""

AUDIT_SYSTEM = """你是论证审计员。你只做两件事：判断一条事实对一条主张是支持还是反驳，并给出离散的似然比。
不要计算概率，不要写长文。严格输出 JSON。"""

AUDIT_PROMPT = """主张：{claim}

事实（每条含 claim 与原文摘录）：
{facts}

请逐条判断：这条事实对上述主张是 support 还是 refute？似然比 lr 只能取以下离散值之一：
0.20（强反驳）/ 0.33（反驳）/ 0.50（弱反驳）/ 1（无关）/ 2（弱支持）/ 3（支持）/ 5（强支持）。
并给一句 why（不超过 40 字）。

只输出 JSON：
{{"judgments":[{{"fact":"F0001","stance":"support","lr":3,"why":"..."}}]}}"""

WRITE_SYSTEM = """你是一位中文历史写作者，写一部严肃但可读的学术专著。纪律：
①只使用给定事实；没有事实支撑的判断，明确写成“材料不足，只能存疑”；
②每一处史实后加 [F####] 引用；不得编造 URL、档号、年份、人名；
③文风要像人：短句、具体、少形容词；长短句交错；不用“首先/其次/综上所述/值得注意的是/众所周知”；
④不要项目符号、不要加粗小标题、不要口号式结尾；
⑤每千字至少 3 处口语或文言点缀（我们、其实、未必、恰恰、恐怕、说白了、此说、殊不知、盖、矣），
   但别堆砌；不要用“最后、同时、因此”起句，改用具体动作或转折；
⑥只输出正文 Markdown，不要解释写作过程。"""

WRITE_PROMPT = """请写《{book_title}》的{chapter}：{chapter_title}

本章要支撑的判断：{claim}
目标字数：约 {target_chars} 字（中文，允许 ±20%）。

本章大纲：
{outline}

可用事实（**只能使用这些**；引用时写 [F####]）：
{facts}

写法：
- 开头一段把本章的问题摆出来，不要“本章将……”。
- 按大纲小节推进，**每个小节至少 900 字，分 2–3 段**；不要把一节写成一段就停。
- 每一节至少落到一个具体地点、年代、人物或文书。
- 至少用两处事实制造张力：一处是支持主线的证据，一处是反例、争议或边界。
- 段落长短交错；允许短句下判断，也允许长句展开考据。
- 结尾收在本章真正解决的问题上，不喊口号，不写“综上所述”。
- **全文不少于 {target_chars} 字**；写满所有小节再收尾。
- 直接给正文，不要写“参考文献”，不要重复事实清单。"""


# ------------------------------------------------------------------ 数据
@dataclass
class Section:
    sid: str
    chapter_no: str
    chapter_title: str
    number: str
    title: str
    level: int


@dataclass
class Question:
    qid: str
    chapter_no: str
    chapter_title: str
    section: str
    title: str
    question: str
    queries: list[str]
    depends_on: list[str]
    claim_id: str
    purpose: str
    target_facts: int


CHAPTER_CLAIMS = {
    "C0": ("本书主论断：长江下游沙洲拓殖共同体是一种稳态拓殖型流民集团，以圩为最小契约型武装单元，可层层整合为军政力量。", 0.55, 2.0),
    "C1": ("长江下游动态沙洲的造陆与治理缝隙，为拓殖型流民提供了物理与制度空间。", 0.55, 1.0),
    "C2": ("船民与圩民之间的双向身份转化，构成沙洲拓殖共同体的人口再生产机制。", 0.50, 1.0),
    "C3": ("圩（沙伙）是以契约而非血缘为纽带的基层水利—武装共同体，是中国底层政治的最小原生单元。", 0.45, 1.5),
    "C4": ("单圩通过联圩、沙团、圩局实现中层整合，同时始终面临内部分裂与国家收编。", 0.50, 1.0),
    "C5": ("王朝崩溃期，圩伙武装可向上跃迁为水寨、割据水师等大型军政力量；元末陈友谅是核心案例。", 0.40, 1.5),
    "C6": ("与波利尼西亚、客家围屋、台湾垦户、洞庭湖、珠江沙田对比，可界定拓殖型流民模型的边界与解释力。", 0.50, 1.0),
    "C7": ("拓殖型流民模型有边界：只有同时具备地籍缝隙、水利刚需与武装常态化，才可能长出契约型武装共同体。", 0.50, 1.5),
}

CHAPTER_KEYWORDS = {
    "0": "中国 流民 研究 综述 概念",
    "1": "长江下游 沙洲 成陆 圩田 治理",
    "2": "船民 圩民 移民 沙上人 方言",
    "3": "圩 沙伙 契约 鱼鳞册 产权 械斗",
    "4": "联圩 圩局 沙团 团练 自治",
    "5": "元末 陈友谅 水军 水寨 割据",
    "6": "波利尼西亚 客家围屋 台湾 垦殖 洞庭湖 沙田",
    "7": "沙洲 拓殖 基层治理 结论",
}

# 每章的「锚词」：问题标题常常太抽象（如“研究背景与问题提出”），
# 单靠标题检索会跑偏；锚词负责把查询钉在本书的经验对象上。
CHAPTER_SEEDS = {
    "0": ["中国流民史 研究", "流民 游民 帮会 研究", "编户齐民 流民 政策", "流民 概念 界定"],
    "1": ["长江下游 沙洲 成陆", "扬中 太平洲 地质", "鱼鳞图册 里甲制", "圩田 水利 开垦"],
    "2": ["沙上人 船民 迁徙", "扬中 靖江 常阴沙 崇明 启东 移民", "坍江 迁徙", "沙地话 方言"],
    "3": ["圩 沙伙 契约", "鱼鳞册 田面权 底权", "沙棍 粮户 圩民", "滩涂 械斗 沙案"],
    "4": ["崇明 外沙 圩局", "扬中 洲团 靖江 沙局", "团练 保甲 沙洲", "联圩 公约"],
    "5": ["陈友谅 水军 元末", "朱元璋 张士诚 水寨", "明末 长江 江营", "咸丰 同治 洲团"],
    "6": ["波利尼西亚 拓殖", "客家 围屋 武装", "台湾 垦户 垦首", "洞庭湖 洲土 垦殖", "珠江 沙田 宗族"],
    "7": ["沙洲 拓殖 基层治理"],
}


DOMAIN_TERMS = [
    "流民史", "流民", "游民", "帮会", "编户齐民", "灾荒", "叙事", "固化偏见",
    "沙洲拓殖", "沙洲", "拓殖", "圩田", "圩伙", "圩局", "圩民", "圩", "沙伙", "沙团", "洲团", "联圩",
    "鱼鳞图册", "鱼鳞册", "里甲制", "黄册", "底权", "田面权", "产权", "契约", "文书", "械斗", "沙案",
    "团练", "保甲", "水寨", "水师", "水军", "船帮", "船民", "沙上人", "迁徙", "方言", "宗族",
    "水利", "盐垦", "垦殖", "垦户", "垦首", "波利尼西亚", "客家", "围屋", "洞庭湖", "珠江", "沙田",
    "陈友谅", "朱元璋", "张士诚", "太平天国", "咸丰", "同治", "九段沙", "崇明", "扬中", "靖江",
    "常阴沙", "启东", "海门", "张家港", "太仓", "长江", "江南", "黄海", "滩涂", "盐场",
]


def _query_terms(title: str, limit: int = 4) -> list[str]:
    """从标题里取实词（先匹配领域词表，再退回标点切分），用于拼短查询。"""
    t = re.sub(r"[\\+*`_#]", " ", title or "")
    t = re.sub(r"[（(].*?[）)]", " ", t)
    hits = [w for w in DOMAIN_TERMS if w in t]
    # 长词优先，去重保序
    hits = sorted(set(hits), key=lambda w: (-len(w), t.find(w)))
    out = hits[:limit]
    if out:
        return out
    parts = re.split(r"[：:、，,；;/\s→\-—]+", t)
    for p in parts:
        p = p.strip()
        if len(p) < 2:
            continue
        if p in ("研究", "综述", "背景", "问题", "提出", "概念", "界定", "机制", "模型",
                 "视角", "框架", "创新", "缺陷", "空白", "意义", "启示", "结论", "不足",
                 "方向", "对照", "对比", "异同", "为什么", "什么", "如何", "全书", "主要"):
            continue
        out.append(p)
    return out[:limit]


TOPIC_SEEDS = [
    (r"沙洲|地貌|成陆|滩涂|江心洲|涨坍", "长江下游 沙洲 成陆 地貌"),
    (r"圩|沙伙|圩田|围圩", "圩 沙伙 圩田 契约"),
    (r"船民|圩民|沙上人|迁徙|移民|方言", "船民 圩民 沙上人 迁徙 方言"),
    (r"流民|游民|帮会|灾荒", "流民 游民 帮会 研究"),
    (r"产权|底权|田面|鱼鳞|里甲|黄册", "鱼鳞册 田面权 底权 里甲"),
    (r"团练|保甲|圩局|沙团|洲团|联圩", "团练 保甲 圩局 沙团 联圩"),
    (r"陈友谅|朱元璋|张士诚|水军|水寨|元末", "陈友谅 水军 水寨 元末"),
    (r"波利尼西亚|客家|台湾|洞庭湖|珠江|沙田|垦户|垦首", "波利尼西亚 客家 台湾 洞庭湖 珠江 沙田"),
    (r"宗族|械斗|乡绅|自治|基层", "宗族 械斗 乡绅 基层 自治"),
]


def _queries_for(chapter_no: str, section: str, title: str) -> list[str]:
    terms = _query_terms(title)
    topic = ""
    for pat, seed in TOPIC_SEEDS:
        if re.search(pat, title or ""):
            topic = seed
            break
    if not topic:
        seeds = CHAPTER_SEEDS.get(chapter_no, [""])
        idx = 0
        m = re.match(r"^\d+\.(\d+)", section or "")
        if m:
            idx = min(int(m.group(1)) - 1, len(seeds) - 1)
        topic = seeds[max(idx, 0)]
    q1 = topic
    q2 = topic + " 史料 档案"
    q3 = (" ".join(terms[:3]) + " 研究") if terms else (topic + " 研究")
    return [q1, q2, q3]

# 章号 → 主张
def claim_for(chapter_no: str) -> str:
    if str(chapter_no) == "7":
        return "C0"
    cid = f"C{chapter_no}"
    if cid in CHAPTER_CLAIMS:
        return cid
    return "C0"


def _clean_heading(s: str) -> str:
    return re.sub(r"\\([.．])", r"\1", s).strip()


def parse_outline(text: str) -> dict:
    """把立意文档切成 chapter / section / subsection。"""
    chapters: list[dict] = []
    sections: list[Section] = []
    cur_ch = None
    cur_sec = None
    for raw in (text or "").splitlines():
        line = raw.strip()
        m = re.match(r"^(#{1,4})\s+(.+?)\s*$", line)
        if not m:
            # 提纲里有大量「0\.1\.1 标题」的普通编号行（不是 markdown 标题）；
            # 把它们当作当前小节的子节，否则问题树会漏掉一半。
            if cur_ch is not None and cur_sec is not None:
                mm = re.match(r"^(\d+(?:\\?\.\d+)+)\s+(.+)$", line)
                if mm:
                    num = _clean_heading(mm.group(1))
                    title2 = _clean_heading(mm.group(2))
                    s = Section(sid=f"S{len(sections)+1:03d}", chapter_no=cur_ch["no"],
                                chapter_title=cur_ch["title"], number=num, title=title2, level=4)
                    sections.append(s)
                    cur_ch["sections"].append(s)
            continue
        level, title = len(m.group(1)), _clean_heading(m.group(2))
        if level == 1:
            if title.startswith("附录"):
                cur_ch = {"no": "8", "title": "附录", "sections": []}
                chapters.append(cur_ch)
            elif "提纲" in title:
                cur_ch = None
            else:
                cur_ch = None
            cur_sec = None
            continue
        if level == 2:
            if re.match(r"^第[一二三四五六七八九十]+章", title):
                no = str("一二三四五六七八九十".index(title[1]) + 1) if len(title) > 1 and title[1] in "一二三四五六七八九十" else "?"
                cur_ch = {"no": no, "title": title, "sections": []}
                chapters.append(cur_ch)
            elif title.startswith("绪论"):
                cur_ch = {"no": "0", "title": title, "sections": []}
                chapters.append(cur_ch)
            elif title.startswith("结语"):
                cur_ch = {"no": "7", "title": title, "sections": []}
                chapters.append(cur_ch)
            elif title.startswith("附录"):
                cur_ch = {"no": "8", "title": title, "sections": []}
                chapters.append(cur_ch)
            elif cur_ch is not None:
                # 章内二级标题（如“一、研究动机”）不单独成节
                pass
            cur_sec = None
            continue
        if level == 3 and cur_ch is not None:
            num = ""
            mm = re.match(r"^([0-9]+(?:\.[0-9]+)*)\s+(.*)$", title)
            if mm:
                num, title2 = mm.group(1), mm.group(2)
            else:
                title2 = title
            cur_sec = Section(sid=f"S{len(sections)+1:03d}", chapter_no=cur_ch["no"],
                              chapter_title=cur_ch["title"], number=num, title=title2, level=3)
            sections.append(cur_sec)
            cur_ch["sections"].append(cur_sec)
            continue
        if level == 4 and cur_ch is not None and cur_sec is not None:
            num = ""
            mm = re.match(r"^([0-9]+(?:\.[0-9]+)+)\s+(.*)$", title)
            if mm:
                num, title2 = mm.group(1), mm.group(2)
            else:
                title2 = title
            s = Section(sid=f"S{len(sections)+1:03d}", chapter_no=cur_ch["no"],
                        chapter_title=cur_ch["title"], number=num or cur_sec.number,
                        title=title2, level=4)
            sections.append(s)
            cur_ch["sections"].append(s)
    # 只保留有内容的章
    chapters = [c for c in chapters if c["sections"]]
    return {"chapters": chapters, "sections": sections}


COUNTER_QUESTIONS = [
    ("C7", "洞庭湖洲土为什么没有长出沙洲式武装共同体？", "洞庭湖 洲土 垦殖 宗族 水利 冲突 研究"),
    ("C7", "珠江三角洲沙田为什么走宗族/资本化路径，而不是圩伙路径？", "珠江三角洲 沙田 宗族 资本 垦殖 研究"),
    ("C7", "客家围屋武装与沙洲圩伙的异同在哪里？", "客家 围屋 武装 宗族 防御 研究"),
    ("C7", "台湾垦户、垦首制度与沙洲沙伙的异同在哪里？", "台湾 垦户 垦首 垦殖 契约 研究"),
    ("C7", "波利尼西亚海洋拓殖与长江沙洲拓殖有哪些同构与差异？", "Polynesian expansion settlement comparative history"),
]

# 追加的「专题档案」问题：用来补主问题树覆盖不到的硬材料（地名/制度/事件/文书）。
# 每题仍是 8–12 条事实；放在主树之后，QID 顺延。
EXTRA_QUESTIONS = [
    ("1", "1.x", "扬中太平洲的成陆、分属与设县过程", "扬中 太平洲 成陆 设县 四府六县", "C1", "证据"),
    ("1", "1.x", "靖江沙洲的涨坍与县境形成", "靖江 沙洲 涨坍 县境 成陆", "C1", "证据"),
    ("1", "1.x", "常阴沙的围垦与行政区划变迁", "常阴沙 围垦 行政区划 张家港", "C1", "证据"),
    ("1", "1.x", "崇明外沙的涨坍与圩局", "崇明 外沙 涨坍 圩局", "C4", "证据"),
    ("1", "1.x", "启东、海门的盐垦与设县", "启东 海门 盐垦 设县 张謇", "C2", "证据"),
    ("3", "3.x", "鱼鳞图册在江南的编制与实际施行", "鱼鳞图册 江南 编制 土地 登记", "C3", "证据"),
    ("3", "3.x", "明清圩田契约与合伙开垦文书", "圩田 契约 合伙 开垦 文书 徽州", "C3", "证据"),
    ("3", "3.x", "沙案、滩涂争界与械斗", "沙案 滩涂 争界 械斗 诉讼", "C3", "证据"),
    ("4", "4.x", "崇明圩局与沙团的组织章程", "崇明 圩局 沙团 章程 自治", "C4", "证据"),
    ("4", "4.x", "晚清团练与沙洲地方武装的官方化", "团练 沙洲 地方武装 保甲 晚清", "C4", "证据"),
    ("5", "5.x", "元末水军与长江船帮", "元末 水军 长江 船帮 水寨", "C5", "证据"),
    ("5", "5.x", "陈友谅鄱阳湖之战的人员与船只", "陈友谅 鄱阳湖 之战 水军 船只", "C5", "证据"),
    ("5", "5.x", "张士诚盐民起事与苏北沿海", "张士诚 盐民 起事 苏北 沿海", "C5", "证据"),
    ("5", "5.x", "朱元璋水军的编成与收编", "朱元璋 水军 编成 收编 巢湖", "C5", "证据"),
    ("5", "5.x", "明末长江江营与太湖圩团", "明末 长江 江营 太湖 圩团", "C5", "证据"),
    ("5", "5.x", "咸丰同治年间沙洲洲团的自保", "咸丰 同治 沙洲 洲团 自保", "C5", "证据"),
    ("6", "6.x", "洞庭湖洲土垦殖与宗族水利", "洞庭湖 洲土 垦殖 宗族 水利", "C7", "反例"),
    ("6", "6.x", "珠江三角洲沙田的宗族与资本", "珠江三角洲 沙田 宗族 资本 垦殖", "C7", "反例"),
    ("6", "6.x", "客家围屋的防御结构与宗族组织", "客家 围屋 防御 宗族 组织", "C7", "反例"),
    ("6", "6.x", "台湾垦户、垦首与垦隘制度", "台湾 垦户 垦首 垦隘 制度", "C7", "反例"),
    ("6", "6.x", "波利尼西亚拓殖的航海与定居", "波利尼西亚 拓殖 航海 定居 南岛", "C7", "反例"),
    ("1", "1.x", "九段沙的形成与长江口治理", "九段沙 形成 长江口 治理 围垦", "C1", "背景"),
    ("3", "3.x", "盐场灶户的逃亡与编户控制", "盐场 灶户 逃亡 编户 控制", "C3", "证据"),
    ("2", "2.x", "沙地话与沙上人的族群边界", "沙地话 沙上人 方言 族群 边界", "C2", "证据"),
]


def append_extras(slug: str) -> int:
    c = connect(slug)
    cur = c.execute("SELECT COALESCE(MAX(CAST(SUBSTR(qid,2) AS INTEGER)),0) FROM questions").fetchone()[0]
    added = 0
    for ch, sec, title, query, claim, purpose in EXTRA_QUESTIONS:
        cur += 1
        qid = f"Q{cur:03d}"
        qtext = (f"围绕「{title}」，有哪些可核验的史实、年代、地名、人物、制度与原始文献？"
                 f"这些证据能支持或反驳什么判断？")
        c.execute("INSERT OR REPLACE INTO questions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (qid, ch, f"第{ch}章", sec, title, qtext,
                   json.dumps([query, query + " 史料 档案", query + " 研究"], ensure_ascii=False),
                   json.dumps([], ensure_ascii=False), claim, purpose, 10, "pending", 0, 0, "", ""))
        added += 1
    c.commit()
    c.close()
    return added



def build_questions(outline: dict) -> list[Question]:
    qs: list[Question] = []
    seq = 0
    prev_last = ""
    for ch in outline["chapters"]:
        cno, ctitle = ch["no"], ch["title"]
        ch_qids: list[str] = []
        # 叶子：有四级小节就用四级，否则用三级
        leaves = [s for s in ch["sections"] if s.level == 4]
        if not leaves:
            leaves = [s for s in ch["sections"] if s.level == 3]
        for s in leaves:
            seq += 1
            qid = f"Q{seq:03d}"
            title = s.title
            purpose = "证据"
            if re.search(r"(对比|反例|失败|缺陷|空白|争议)", title):
                purpose = "反例"
            elif re.search(r"(地理|地质|概念|背景|综述)", title):
                purpose = "背景"
            elif re.search(r"(机制|转化|整合|跃迁|产权|契约)", title):
                purpose = "机制"
            kw = CHAPTER_KEYWORDS.get(cno, "")
            qtext = (f"围绕「{title}」，有哪些可核验的史实、年代、地名、人物、制度与原始文献？"
                     f"这些证据能支持或反驳什么判断？")
            queries = _queries_for(cno, s.number, title)
            if cno == "6":
                queries.append(f"{title} English comparative history")
            deps = []
            if ch_qids:
                deps = [ch_qids[-1]]
            elif prev_last:
                deps = [prev_last]
            qs.append(Question(qid=qid, chapter_no=cno, chapter_title=ctitle, section=s.number,
                               title=title, question=qtext, queries=queries, depends_on=deps,
                               claim_id=claim_for(cno), purpose=purpose, target_facts=10))
            ch_qids.append(qid)
        if ch_qids:
            prev_last = ch_qids[-1]
    # 跨章反例questions（挂在最后一章之后，单独成组）
    for claim, qtext, query in COUNTER_QUESTIONS:
        seq += 1
        qid = f"Q{seq:03d}"
        qs.append(Question(qid=qid, chapter_no="6", chapter_title="第六章 模型对比",
                           section="6.x", title=qtext, question=qtext,
                           queries=[query, query + " 史料"], depends_on=[prev_last] if prev_last else [],
                           claim_id=claim, purpose="反例", target_facts=8))
        prev_last = qid
    return qs


# ------------------------------------------------------------------ 存储
def db_path(slug: str) -> Path:
    return WORK / slug / "facts.db"


def connect(slug: str) -> sqlite3.Connection:
    p = db_path(slug)
    p.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(p)
    c.row_factory = sqlite3.Row
    c.executescript("""
    CREATE TABLE IF NOT EXISTS questions(
      qid TEXT PRIMARY KEY, chapter_no TEXT, chapter_title TEXT, section TEXT,
      title TEXT, question TEXT, queries TEXT, depends_on TEXT, claim_id TEXT,
      purpose TEXT, target_facts INTEGER, status TEXT DEFAULT 'pending',
      facts INTEGER DEFAULT 0, rejects INTEGER DEFAULT 0, usage TEXT, updated_at TEXT);
    CREATE TABLE IF NOT EXISTS facts(
      id TEXT PRIMARY KEY, qid TEXT, chapter_no TEXT, section TEXT, claim TEXT,
      url TEXT, grade TEXT, quote TEXT, used_for TEXT, source_title TEXT,
      confidence TEXT, verified INTEGER DEFAULT 0, created_at TEXT);
    CREATE TABLE IF NOT EXISTS claims(
      id TEXT PRIMARY KEY, text TEXT, prior REAL, weight REAL, note TEXT);
    """)
    c.commit()
    return c


def save_questions(slug: str, qs: list[Question]) -> None:
    c = connect(slug)
    c.execute("DELETE FROM questions")
    for q in qs:
        c.execute("INSERT OR REPLACE INTO questions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (q.qid, q.chapter_no, q.chapter_title, q.section, q.title, q.question,
                   json.dumps(q.queries, ensure_ascii=False), json.dumps(q.depends_on),
                   q.claim_id, q.purpose, q.target_facts, "pending", 0, 0, "", ""))
    c.execute("DELETE FROM claims")
    for cid, (text, prior, weight) in CHAPTER_CLAIMS.items():
        c.execute("INSERT OR REPLACE INTO claims VALUES (?,?,?,?,?)", (cid, text, prior, weight, ""))
    c.commit()
    c.close()
    (WORK / slug).mkdir(parents=True, exist_ok=True)
    with (WORK / slug / "QUESTIONS.jsonl").open("w", encoding="utf-8") as f:
        for q in qs:
            f.write(json.dumps(asdict(q), ensure_ascii=False) + "\n")


def load_questions(slug: str) -> list[dict]:
    c = connect(slug)
    rows = [dict(r) for r in c.execute("SELECT * FROM questions ORDER BY qid")]
    c.close()
    for r in rows:
        r["queries"] = json.loads(r["queries"] or "[]")
        r["depends_on"] = json.loads(r["depends_on"] or "[]")
    return rows


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


# ------------------------------------------------------------------ 文档 → 材料
def _docs_block(docs: list[dict], max_chars: int = 2600) -> str:
    out = []
    for d in docs:
        text = (d.get("text") or d.get("snippet") or "").strip()
        text = re.sub(r"\n{2,}", "\n", text)[:max_chars]
        out.append(f"[{d['id']}] {d.get('title','')}\n"
                   f"URL: {d.get('url','')}\n"
                   f"来源分级: {d.get('grade','weak')}\n"
                   f"正文:\n{text}")
    return "\n\n".join(out)


def _norm(s: str) -> str:
    s = (s or "").lower()
    s = re.sub(r"[\s\u00a0]+", "", s)
    s = re.sub(r"[，。；：、！？,.;:!?\"'“”‘’（）()《》<>\[\]【】—\-…·]", "", s)
    return s


def _best_quote(doc_text: str, quote: str) -> tuple[str, float]:
    """把模型给的 quote 对齐到原文；返回（原文片段, 相似度）。0 表示没对上。"""
    doc_text = doc_text or ""
    quote = (quote or "").strip()
    if len(quote) < 12:
        return "", 0.0
    nq, nd = _norm(quote), _norm(doc_text)
    sents = [s.strip() for s in re.split(r"(?<=[。！？；!?;])\s*|\n+", doc_text) if len(s.strip()) >= 12]
    if nq and nq in nd:
        # 返回原文中真实存在的句子（而不是模型改写后的 quote）
        for s in sents:
            if nq in _norm(s):
                return s, 1.0
        return quote, 1.0
    # 按句切，找最像的一句
    best, score = "", 0.0
    for s in sents:
        r = difflib.SequenceMatcher(None, _norm(quote), _norm(s)).ratio()
        if r > score:
            best, score = s, r
    if score >= 0.78:
        return best, score
    return "", score


def _parse_json(text: str) -> dict:
    s = (text or "").strip()
    s = re.sub(r"^```(?:json)?\s*|\s*```$", "", s, flags=re.S)
    i, j = s.find("{"), s.rfind("}")
    if i >= 0 and j > i:
        try:
            return json.loads(s[i:j + 1])
        except Exception:
            pass
    # 截断兜底：从 "facts" 数组里逐个抠完整的 {...} 对象
    m = re.search(r'"facts"\s*:\s*\[', s)
    if not m:
        return {}
    k = m.end()
    depth, in_str, esc, start, objs = 0, False, False, None, []
    for idx in range(k, len(s)):
        ch = s[idx]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            if depth == 0:
                start = idx
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start is not None:
                try:
                    objs.append(json.loads(s[start:idx + 1]))
                except Exception:
                    pass
                start = None
    return {"facts": objs, "gaps": [], "salvaged": True} if objs else {}


# ------------------------------------------------------------------ 单问调研
def _curated_chapter(q: dict) -> str:
    t = q.get("title") or ""
    rules = [
        (r"沙洲|地貌|成陆|滩涂|江心洲|涨坍", "1"),
        (r"船民|圩民|沙上人|迁徙|移民|方言", "2"),
        (r"圩|沙伙|圩田|产权|鱼鳞|里甲|械斗|底权|田面", "3"),
        (r"团练|保甲|圩局|沙团|洲团|联圩|乡绅", "4"),
        (r"陈友谅|朱元璋|张士诚|水军|水寨|元末|太平天国|咸丰|同治", "5"),
        (r"波利尼西亚|客家|台湾|洞庭湖|珠江|沙田|垦户|垦首", "6"),
    ]
    for pat, ch in rules:
        if re.search(pat, t):
            return ch
    return str(q.get("chapter_no") or "0")


def research_one(slug: str, q: dict, *, docs_limit: int = 8, max_tokens: int = 16000) -> dict:
    m = re.search(r"\.(\d+)(?:\.\d+)?$", q.get("section") or "")
    off = (int(m.group(1)) - 1) if m else 0
    docs = retrieval.gather(q["question"], queries=q.get("queries") or [q["question"]],
                            limit=docs_limit, fetch_n=max(3, docs_limit - 2),
                            curated_docs=retrieval.curated(_curated_chapter(q), limit=5, offset=off))
    if not docs:
        return {"qid": q["qid"], "facts": [], "rejects": [], "docs": [],
                "error": "no retrieval results", "usage": {}}
    docs = docs[:docs_limit]
    prompt = FACT_PROMPT.format(
        question=q["question"], chapter=q["chapter_title"], section=q["section"],
        claim=CHAPTER_CLAIMS.get(q["claim_id"], ("",))[0], docs=_docs_block(docs),
        max_id=len(docs))
    try:
        r = research.ask(slug, prompt, system=FACT_SYSTEM, model="deepseek-flash",
                         temperature=0.15, max_tokens=max_tokens, timeout=900,
                         tag=f"{q['qid']}_facts", json_mode=True)
    except Exception as e:
        return {"qid": q["qid"], "facts": [], "rejects": [], "docs": docs,
                "error": f"{type(e).__name__}: {e}", "usage": {}}
    data = _parse_json(r.get("text", ""))
    raw_facts = data.get("facts") or []
    by_id = {d["id"]: d for d in docs}
    facts, rejects = [], []
    for it in raw_facts:
        if not isinstance(it, dict):
            continue
        sid = str(it.get("source_id") or "").strip()
        d = by_id.get(sid)
        if not d:
            rejects.append({"reason": "source_id 不在材料里", "item": it})
            continue
        claim = re.sub(r"\s+", " ", str(it.get("claim") or "")).strip()
        quote = str(it.get("quote") or "").strip()
        if not (12 <= len(claim) <= 400):
            rejects.append({"reason": "claim 长度不合规", "item": it})
            continue
        q2, sim = _best_quote(d.get("text") or d.get("snippet") or "", quote)
        if not q2:
            rejects.append({"reason": f"quote 无法在原文中逐字对齐（相似度 {sim:.2f}）", "item": it})
            continue
        grade = str(it.get("grade") or d.get("grade") or "weak").lower()
        if grade not in ("primary", "official", "secondary", "weak"):
            grade = d.get("grade", "weak")
        # 不得高于材料分级
        order = {"primary": 0, "official": 1, "secondary": 2, "weak": 3}
        if order.get(grade, 3) < order.get(d.get("grade", "weak"), 3):
            grade = d.get("grade", "weak")
        facts.append({"claim": claim, "url": d["url"], "grade": grade, "quote": q2,
                      "used_for": str(it.get("used_for") or f"{q['chapter_title']}/{q['section']}")[:120],
                      "source_title": d.get("title", ""), "confidence": str(it.get("confidence") or "medium"),
                      "qid": q["qid"], "chapter_no": q["chapter_no"], "section": q["section"],
                      "verified": 1})
    return {"qid": q["qid"], "facts": facts, "rejects": rejects, "docs": docs,
            "gaps": data.get("gaps") or [], "usage": r.get("usage", {}), "file": r.get("file", "")}


def save_research(slug: str, result: dict) -> dict:
    c = connect(slug)
    qid = result["qid"]
    # 重跑：先删旧
    c.execute("DELETE FROM facts WHERE qid=?", (qid,))
    existing = {_norm(r[0])[:240] for r in c.execute("SELECT quote FROM facts")}
    start = c.execute("SELECT COALESCE(MAX(CAST(SUBSTR(id,2) AS INTEGER)),0) FROM facts").fetchone()[0]
    added = skipped = 0
    for f in result.get("facts") or []:
        key = _norm(f.get("quote") or "")[:240]
        if not key or key in existing:
            skipped += 1
            continue
        existing.add(key)
        fid = f"F{start + added + 1:04d}"
        c.execute("INSERT OR REPLACE INTO facts VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (fid, qid, f["chapter_no"], f["section"], f["claim"], f["url"], f["grade"],
                   f["quote"], f["used_for"], f["source_title"], f["confidence"], 1, _now()))
        added += 1
    usage = json.dumps(result.get("usage") or {}, ensure_ascii=False)
    c.execute("UPDATE questions SET status=?, facts=?, rejects=?, usage=?, updated_at=? WHERE qid=?",
              ("done" if not result.get("error") else "error", added, len(result.get("rejects") or []),
               usage, _now(), qid))
    c.commit()
    c.close()
    d = WORK / slug
    (d / "sources").mkdir(exist_ok=True)
    (d / "sources" / f"{qid}.json").write_text(
        json.dumps({k: v for k, v in result.items() if k != "facts"}, ensure_ascii=False, indent=1),
        encoding="utf-8")
    if result.get("rejects"):
        with (d / "sources" / "rejects.jsonl").open("a", encoding="utf-8") as fh:
            for r in result["rejects"]:
                fh.write(json.dumps({"qid": qid, **r}, ensure_ascii=False) + "\n")
    return {"qid": qid, "added": added, "rejected": len(result.get("rejects") or []),
            "error": result.get("error", "")}


# ------------------------------------------------------------------ 导出
def export_facts_md(slug: str, title: str | None = None) -> Path:
    c = connect(slug)
    facts = [dict(r) for r in c.execute("SELECT * FROM facts ORDER BY id")]
    c.close()
    d = WORK / slug
    title = title or slug
    lines = [f"# 事实库 · {title}", "",
             "> 每条含 claim / URL / 来源分级 / 原文摘录 / 用于。",
             "> 纪律：事实库中没有的，写作时不得出现。", ""]
    for f in facts:
        lines += [f"## {f['id']}",
                  f"- claim：{f['claim']}",
                  f"- URL：{f['url']}",
                  f"- 来源分级：{f['grade']}",
                  f"- 原文摘录：{f['quote']}",
                  f"- 用于：{f['used_for']}",
                  f"- 出处：{f['source_title']}",
                  f"- 置信度：{f['confidence']}",
                  f"- 关联问题：{f['qid']}",
                  ""]
    p = d / "FACTS.md"
    p.write_text("\n".join(lines), encoding="utf-8")
    with (d / "facts.jsonl").open("w", encoding="utf-8") as fh:
        for f in facts:
            fh.write(json.dumps(f, ensure_ascii=False) + "\n")
    return p


def export_questions_md(slug: str) -> Path:
    c = connect(slug)
    qs = [dict(r) for r in c.execute("SELECT * FROM questions ORDER BY qid")]
    c.close()
    lines = [f"# 问题树 · {slug}", "", "> 章内链式依赖；章间接力；最后一组是反例。", ""]
    cur = None
    for q in qs:
        if q["chapter_title"] != cur:
            cur = q["chapter_title"]
            lines += [f"## {cur}", ""]
        deps = json.loads(q["depends_on"] or "[]")
        lines += [f"### {q['qid']} · {q['section']} {q['title']}",
                  f"- 问题：{q['question']}",
                  f"- 支撑：{q['claim_id']}｜用途：{q['purpose']}｜目标事实：{q['target_facts']}",
                  f"- 依赖：{', '.join(deps) if deps else '（根）'}",
                  f"- 检索式：{'；'.join(json.loads(q['queries'] or '[]'))}",
                  ""]
    p = WORK / slug / "QUESTIONS.md"
    p.write_text("\n".join(lines), encoding="utf-8")
    return p


# ------------------------------------------------------------------ 生成
def dedupe_facts(slug: str, reindex: bool = True) -> dict:
    """按原文摘录/claim 去重；默认重排 F 编号，`reindex=False` 只删重复（保住已引用编号）。"""
    c = connect(slug)
    order = "CASE grade WHEN 'primary' THEN 0 WHEN 'official' THEN 1 WHEN 'secondary' THEN 2 ELSE 3 END, id" if reindex else "id"
    rows = [dict(r) for r in c.execute(f"SELECT * FROM facts ORDER BY {order}")]
    seen, seen_claims, keep, drop = set(), [], [], []
    for r in rows:
        key = _norm(r["quote"] or "")[:240]
        if not key or key in seen:
            drop.append(r["id"])
            continue
        ck = _norm(r["claim"] or "")[:240]
        if ck and any(difflib.SequenceMatcher(None, ck, x).ratio() >= 0.90 for x in seen_claims):
            drop.append(r["id"])
            continue
        seen.add(key)
        seen_claims.append(ck)
        keep.append(r)
    if not reindex:
        if drop:
            c.executemany("DELETE FROM facts WHERE id=?", [(x,) for x in drop])
        c.commit()
        c.close()
        return {"before": len(rows), "after": len(keep), "removed": len(drop)}
    c.execute("BEGIN")
    c.execute("UPDATE facts SET id='T'||id")
    for i, r in enumerate(keep, 1):
        c.execute("UPDATE facts SET id=? WHERE id=?", (f"F{i:04d}", "T" + r["id"]))
    c.execute("DELETE FROM facts WHERE id LIKE 'T%'")
    c.commit()
    c.close()
    return {"before": len(rows), "after": len(keep), "removed": len(rows) - len(keep)}


def facts_for_chapter(slug: str, chapter_no: str, limit: int = 140) -> list[dict]:
    c = connect(slug)
    rows = [dict(r) for r in c.execute(
        "SELECT * FROM facts WHERE chapter_no=? ORDER BY "
        "CASE grade WHEN 'primary' THEN 0 WHEN 'official' THEN 1 WHEN 'secondary' THEN 2 ELSE 3 END, id LIMIT ?",
        (chapter_no, limit))]
    c.close()
    return rows


def _facts_block(facts: list[dict]) -> str:
    out = []
    for f in facts:
        out.append(f"[{f['id']}] ({f['grade']}) {f['claim']}\n"
                   f"  出处：{f['source_title']}｜{f['url']}\n"
                   f"  原文：{f['quote']}\n"
                   f"  用于：{f['used_for']}")
    return "\n\n".join(out)


def _outline_block(slug: str, chapter_no: str) -> str:
    c = connect(slug)
    rows = [dict(r) for r in c.execute("SELECT * FROM questions WHERE chapter_no=? ORDER BY qid", (chapter_no,))]
    c.close()
    lines = []
    for q in rows:
        lines.append(f"- {q['section']} {q['title']}")
    return "\n".join(lines)


def write_chapter(slug: str, chapter_no: str, *, target_chars: int = 10000,
                  max_facts: int = 140, temperature: float = 0.65) -> dict:
    c = connect(slug)
    ch = c.execute("SELECT * FROM questions WHERE chapter_no=? LIMIT 1", (chapter_no,)).fetchone()
    c.close()
    if not ch:
        return {"error": f"没有第 {chapter_no} 章的问题记录"}
    chapter_title = ch["chapter_title"]
    claim = CHAPTER_CLAIMS.get(claim_for(chapter_no), ("",))[0]
    facts = facts_for_chapter(slug, chapter_no, limit=max_facts)
    if len(facts) < 5:
        return {"error": f"第 {chapter_no} 章只有 {len(facts)} 条事实，先补调研"}
    book_title = _book_title(slug)
    style_note = ""
    sp = ROOT / "style" / "corpus" / "darwin.md"
    if sp.exists():
        style_note = ("\n\n风格样本（只学节奏与口气，不学其中的事实）：\n"
                      + sp.read_text(encoding="utf-8")[:1800])
    prompt = WRITE_PROMPT.format(book_title=book_title, chapter=f"第{chapter_no}章" if chapter_no not in ("0", "7", "8") else chapter_title,
                                 chapter_title=chapter_title, claim=claim, target_chars=target_chars,
                                 outline=_outline_block(slug, chapter_no), facts=_facts_block(facts)) + style_note
    r = research.ask(slug, prompt, system=WRITE_SYSTEM, model="deepseek-v4-pro",
                     temperature=temperature, max_tokens=32000, timeout=1800,
                     tag=f"write_ch{chapter_no}")
    text = (r.get("text") or "").strip()
    # 截断/空稿：降目标重试一次（只补写，不改事实）
    if len(re.findall(r"[\u4e00-\u9fff]", text)) < int(target_chars * 0.45):
        prompt2 = prompt + ("\n\n注意：上一次输出被截断或过短。请直接给完整正文，"
                            "控制在目标字数的 80%–100%，不要再解释。")
        r = research.ask(slug, prompt2, system=WRITE_SYSTEM, model="deepseek-v4-pro",
                         temperature=temperature, max_tokens=32000, timeout=1800,
                         tag=f"write_ch{chapter_no}_retry")
        if len(re.findall(r"[\u4e00-\u9fff]", r.get("text") or "")) > len(re.findall(r"[\u4e00-\u9fff]", text)):
            text = (r.get("text") or "").strip()
    d = WORK / slug / "draft"
    d.mkdir(parents=True, exist_ok=True)
    p = d / f"ch{chapter_no}.md"
    p.write_text(text + "\n", encoding="utf-8")
    (d / f"ch{chapter_no}.facts.json").write_text(
        json.dumps([f["id"] for f in facts], ensure_ascii=False), encoding="utf-8")
    return {"file": str(p), "chars": len(re.findall(r"[\u4e00-\u9fff]", text)),
            "usage": r.get("usage", {}), "facts_available": len(facts)}


def write_appendix(slug: str) -> Path:
    """确定性附录：年表 + 名词 + 事实库统计（不调 LLM，全部可回溯）。"""
    c = connect(slug)
    facts = [dict(r) for r in c.execute("SELECT * FROM facts ORDER BY id")]
    c.close()
    d = WORK / slug / "draft"
    d.mkdir(parents=True, exist_ok=True)
    lines = ["# 附录", "", "> 本附录由事实库确定性生成；每条后附 [F####]，可在 `FACTS.md` 回溯。", ""]

    # 年表
    year_rows = []
    for f in facts:
        ys = re.findall(r"(?:公元)?(\d{3,4})\s*年", f["claim"] + " " + f["quote"])
        if not ys:
            continue
        y = int(ys[0])
        if 200 <= y <= 2100:
            year_rows.append((y, f))
    year_rows.sort(key=lambda x: (x[0], x[1]["id"]))
    lines += ["## 附录一 沙洲变迁年表", ""]
    seen_years, seen_claims = {}, set()
    for y, f in year_rows:
        if seen_years.get(y, 0) >= 3:
            continue
        ck = _norm(f["claim"])[:200]
        if ck in seen_claims:
            continue
        seen_claims.add(ck)
        seen_years[y] = seen_years.get(y, 0) + 1
        txt = f["claim"].strip().rstrip("。")
        lines.append(f"- {y} 年：{txt} [{f['id']}]")
    if not year_rows:
        lines.append("- （事实库中暂无可提取的年份）")
    lines.append("")

    # 名词
    terms = [
        ("圩", r"圩田|圩"), ("沙伙", r"沙伙"), ("沙上人", r"沙上人"), ("船民", r"船民|疍民"),
        ("鱼鳞图册", r"鱼鳞图册|鱼鳞册"), ("黄册", r"黄册"), ("里甲", r"里甲"),
        ("田面权", r"田面权"), ("底权", r"底权"), ("坍江", r"坍江|涨坍"),
        ("洲团", r"洲团"), ("圩局", r"圩局"), ("沙案", r"沙案"), ("灶户", r"灶户"),
        ("垦首", r"垦首"), ("垦户", r"垦户"),
    ]
    lines += ["## 附录二 核心名词", ""]
    for name, pat in terms:
        hit = next((f for f in facts if re.search(pat, f["claim"] + f["quote"])), None)
        if hit:
            lines.append(f"- **{name}**：{hit['claim'].strip().rstrip('。')}（见 [{hit['id']}]）")
        else:
            lines.append(f"- **{name}**：正文相关章节讨论；事实库暂无独立条目。")
    lines.append("")

    # 统计
    by_ch, by_grade, domains = {}, {}, {}
    for f in facts:
        by_ch[f["chapter_no"]] = by_ch.get(f["chapter_no"], 0) + 1
        by_grade[f["grade"]] = by_grade.get(f["grade"], 0) + 1
        host = re.sub(r"^https?://([^/]+).*", r"\1", f["url"])
        domains[host] = domains.get(host, 0) + 1
    lines += ["## 附录三 事实库统计", "",
              f"- 事实总数：{len(facts)}",
              f"- 按章：{'；'.join(f'{k} 章 {v} 条' for k, v in sorted(by_ch.items()))}",
              f"- 按来源分级：{'；'.join(f'{k} {v}' for k, v in sorted(by_grade.items()))}",
              f"- 独立域名：{len(domains)}",
              "- 主要来源：" + "；".join(f"{k}（{v}）" for k, v in sorted(domains.items(), key=lambda x: -x[1])[:8]),
              ""]

    # 来源清单
    lines += ["## 附录四 来源清单", ""]
    for host, n in sorted(domains.items(), key=lambda x: -x[1]):
        ex = next((f["id"] for f in facts if host in f["url"]), "")
        lines.append(f"- {host}：{n} 条（例：{ex}）")
    lines.append("")

    # 事实全目（按章）
    lines += ["## 附录五 事实库全目", "",
              "> 按章列出全部独立事实；每条可在 `FACTS.md` 查到 URL、原文摘录与出处。", ""]
    for ch in sorted(by_ch, key=lambda x: int(x) if str(x).isdigit() else 99):
        lines.append(f"### 第 {ch} 章")
        lines.append("")
        for f in facts:
            if str(f["chapter_no"]) == str(ch):
                lines.append(f"- [{f['id']}] {f['claim'].strip().rstrip('。')}（{f['grade']}）")
        lines.append("")

    p = d / "appendix.md"
    p.write_text("\n".join(lines), encoding="utf-8")
    return p


def compile_draft(slug: str) -> Path:
    d = WORK / slug / "draft"
    files = sorted(d.glob("ch*.md"), key=lambda p: int(re.search(r"ch(\d+)", p.name).group(1)))
    parts = [f"# {_book_title(slug)}", ""]
    for p in files:
        no = re.search(r"ch(\d+)", p.name).group(1)
        c = connect(slug)
        ch = c.execute("SELECT chapter_title FROM questions WHERE chapter_no=? LIMIT 1", (no,)).fetchone()
        c.close()
        title = ch["chapter_title"] if ch else f"第{no}章"
        txt = p.read_text(encoding="utf-8").strip()
        # 去掉章文件自带的标题行，避免与合稿标题重复
        lines = txt.splitlines()
        while lines and (not lines[0].strip()
                         or lines[0].lstrip().startswith("#")
                         or re.match(r"^第[一二三四五六七八九十]+章", lines[0].strip())):
            lines.pop(0)
        txt = "\n".join(lines).strip()
        parts += [f"# {title}", "", txt, ""]
    ap = d / "appendix.md"
    if ap.exists():
        parts += [ap.read_text(encoding="utf-8").strip(), ""]
    out = WORK / slug / "DRAFT.md"
    out.write_text("\n".join(parts), encoding="utf-8")
    return out


def _book_title(slug: str) -> str:
    p = WORK / slug / "OUTLINE.md"
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            if line.startswith("# "):
                return line[2:].strip()
    return slug


# ------------------------------------------------------------------ 论证
LR_ALLOWED = [0.2, 0.33, 0.5, 1.0, 2.0, 3.0, 5.0]


def _nearest_lr(x: float) -> float:
    return min(LR_ALLOWED, key=lambda v: abs(v - float(x)))


def audit_arguments(slug: str, *, per_claim: int = 14, use_llm: bool = True) -> dict:
    c = connect(slug)
    claims = [dict(r) for r in c.execute("SELECT * FROM claims ORDER BY id")]
    all_facts = [dict(r) for r in c.execute("SELECT * FROM facts ORDER BY id")]
    c.close()
    if not all_facts:
        return {"error": "事实库为空"}
    by_claim: dict[str, list[dict]] = {}
    for f in all_facts:
        by_claim.setdefault(claim_for(f["chapter_no"]), []).append(f)
    # 反例问题的事实同时记到 C7 与主论断 C0（refute 方向）
    out_facts, judgments = [], []
    for cl in claims:
        fs = by_claim.get(cl["id"], [])
        # 主论断：从各章抽样，外加第六章反例
        if cl["id"] == "C0":
            pick = []
            for cno in ("0", "1", "2", "3", "4", "5", "6"):
                pick += [f for f in all_facts if f["chapter_no"] == cno][:max(2, per_claim // 7)]
            fs = pick[:per_claim]
        fs = fs[:per_claim]
        if not fs:
            continue
        if use_llm:
            prompt = AUDIT_PROMPT.format(
                claim=cl["text"],
                facts="\n\n".join(f"[{f['id']}] {f['claim']}\n  原文：{f['quote'][:180]}" for f in fs))
            try:
                r = research.ask(slug, prompt, system=AUDIT_SYSTEM, model="deepseek-flash",
                                 temperature=0.1, max_tokens=4000, timeout=600,
                                 tag=f"audit_{cl['id']}", json_mode=True)
                data = _parse_json(r.get("text", ""))
                for j in data.get("judgments") or []:
                    fid = str(j.get("fact") or "").strip()
                    if any(f["id"] == fid for f in fs):
                        judgments.append({"claim": cl["id"], "fact": fid,
                                          "stance": "refute" if str(j.get("stance")) == "refute" else "support",
                                          "lr": _nearest_lr(j.get("lr", 2)),
                                          "why": str(j.get("why") or "")[:80]})
            except Exception:
                pass
        # 兜底：没判到的按来源分级给保守 LR
        judged = {j["fact"] for j in judgments if j["claim"] == cl["id"]}
        for f in fs:
            if f["id"] in judged:
                continue
            stance = "refute" if f["chapter_no"] == "6" and cl["id"] == "C0" else "support"
            lr = {"primary": 3.0, "official": 3.0, "secondary": 2.0, "weak": 1.5}.get(f["grade"], 1.0)
            if stance == "refute":
                lr = 0.5
            judgments.append({"claim": cl["id"], "fact": f["id"], "stance": stance,
                              "lr": lr, "why": "按来源分级兜底"})
    for j in judgments:
        out_facts.append({"claim": j["claim"], "fact": j["fact"], "stance": j["stance"],
                          "lr": j["lr"], "grade": next((f["grade"] for f in all_facts if f["id"] == j["fact"]), "secondary"),
                          "why": j["why"]})
    data = {"claims": [{"id": c["id"], "text": c["text"], "prior": c["prior"],
                        "weight": c["weight"], "note": c.get("note") or ""} for c in claims],
            "facts": out_facts}
    (WORK / slug / "ARGUMENTS.json").write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    return data


# ------------------------------------------------------------------ 三自检
def check(slug: str, *, min_facts: int = 100, min_chars: int = 0, max_chars: int = 0,
          min_p: float = 0.6, strict_p: bool = False, allow_partial: bool = False) -> dict:
    d = WORK / slug
    facts_md, draft_md = d / "FACTS.md", d / "DRAFT.md"
    report: dict = {"slug": slug, "checks": [], "ok": True}

    def add(name, ok, detail=""):
        report["checks"].append({"name": name, "ok": bool(ok), "detail": str(detail)[:300]})
        if not ok:
            report["ok"] = False

    if not facts_md.exists() or not draft_md.exists():
        add("文件齐全", False, f"缺 {facts_md if not facts_md.exists() else draft_md}")
        return report
    # ① research.check
    r = research.check(slug, min_words=min_chars, max_words=max_chars)
    for c in r["checks"]:
        add("research/" + c["name"], c["ok"], c["detail"])
    add("事实条数下限", r.get("facts", 0) >= min_facts, f"{r.get('facts', 0)} / {min_facts}")

    # ② 事实覆盖 / 引文
    c = connect(slug)
    facts = [dict(x) for x in c.execute("SELECT * FROM facts ORDER BY id")]
    c.close()
    ftxt = draft_md.read_text(encoding="utf-8")
    cited = set(re.findall(r"\[(F\d{4,})\]", ftxt))
    known = {f["id"] for f in facts}
    invalid = sorted(cited - known)
    add("引文 ID 都存在", not invalid, "无" if not invalid else ", ".join(invalid[:8]))
    provided = set()
    for p in (d / "draft").glob("ch*.facts.json") if (d / "draft").exists() else []:
        try:
            provided |= set(json.loads(p.read_text(encoding="utf-8")))
        except Exception:
            pass
    body_txt = ftxt.split("\n# 附录")[0]
    cited_body = set(re.findall(r"\[(F\d{4,})\]", body_txt)) & known
    outside = sorted(cited_body - provided) if provided else []
    if provided:
        add("正文引文均在本章给定事实内", not outside, "无" if not outside else ", ".join(outside[:8]))
    used = len(cited & known)
    add("正文事实引用率", len(cited_body) >= max(10, int(len(facts) * 0.5)),
        f"正文 {len(cited_body)}/{len(facts)}（附录全目另计）")
    need_used = max(3, int(len(facts) * (0.10 if allow_partial else 0.35)))
    add("事实被引用率", used >= need_used,
        f"{used}/{len(facts)}（{used / max(len(facts), 1):.0%}；门槛 {need_used}）")
    domains = {re.sub(r"^https?://([^/]+).*", r"\1", f["url"]) for f in facts}
    add("独立域名≥5", len(domains) >= 5, f"{len(domains)} 个")
    unverified = [f["id"] for f in facts if not f.get("verified")]
    add("原文逐字校验", not unverified, f"未校验 {len(unverified)} 条")

    # ③ 论证
    arg = d / "ARGUMENTS.json"
    if arg.exists():
        try:
            from core.argument import Claim, Fact, article_p, gaps, verdict2
            data = json.loads(arg.read_text(encoding="utf-8"))
            claims = [Claim(x["id"], x.get("text", ""), float(x.get("prior", .5)), float(x.get("weight", 1))) for x in data["claims"]]
            af = [Fact(x["claim"], x["fact"], x.get("stance", "support"), float(x["lr"]), x.get("grade", "secondary"), x.get("why", "")) for x in data["facts"]]
            art = article_p(claims, af)
            report["argument"] = {"article_p": round(art["p"], 4), "verdict": verdict2(art["p"], min_p),
                                  "claims": [{k: x[k] for k in ("claim", "text", "p")} for x in art["claims"]],
                                  "weakest": art.get("weakest", ""),
                                  "gaps": gaps(claims, af, target=min_p)}
            ok = art["p"] >= min_p or not strict_p
            add("论证可信度", ok, f"文章级 p={art['p']:.3f}（阈值 {min_p}；{'硬门禁' if strict_p else '告警不阻塞'}）")
        except Exception as e:
            add("论证可信度", False, f"{type(e).__name__}: {e}")
    else:
        add("论证可信度", False, "缺 ARGUMENTS.json")

    # ④ 文风
    try:
        sys.path.insert(0, str(ROOT))
        from scripts.style_check import check as style_check
        style_file = ROOT / "style" / "corpus" / "darwin.md"
        sample = style_file.read_text(encoding="utf-8") if style_file.exists() else ""
        st = style_check(body_txt, sample, longform=True)
        report["style"] = {k: st[k] for k in ("chars", "sent_len_cv", "voice_per_1k", "voice_threshold", "score",
                                             "hard_gate_pass", "hard_hits", "soft_hits")}
        add("文风硬门禁（无 AI 套话）", st["hard_gate_pass"], "命中: " + "、".join(st["hard_hits"][:6]))
        add("句长变异≥0.35", st["sent_len_cv"] >= 0.35, str(st["sent_len_cv"]))
        add(f"声音密度≥{st.get('voice_threshold', 0.8)}/千字（长文）",
            st["voice_per_1k"] >= st.get("voice_threshold", 0.8), str(st["voice_per_1k"]))
    except Exception as e:
        add("文风自检", False, f"{type(e).__name__}: {e}")

    # ⑤ 章节完整度
    c = connect(slug)
    qn = c.execute("SELECT COUNT(DISTINCT chapter_no) FROM questions WHERE chapter_no<'8'").fetchone()[0]
    dn = len(list((d / "draft").glob("ch*.md"))) if (d / "draft").exists() else 0
    c.close()
    report["coverage"] = {"chapters_expected": qn, "chapters_written": dn,
                          "facts": len(facts), "cited": used}
    if allow_partial:
        add("章节完整度（分册试跑）", True, f"{dn}/{qn}（--allow-partial）")
    else:
        add("章节完整度", dn >= qn, f"{dn}/{qn}")

    (d / "CHECKS").mkdir(exist_ok=True)
    (d / "CHECKS" / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    lines = [f"# 三自检报告 · {slug}", "", f"- 总判：{'PASS' if report['ok'] else 'FAIL'}", ""]
    for c in report["checks"]:
        lines.append(f"- [{'PASS' if c['ok'] else 'FAIL'}] {c['name']}｜{c['detail']}")
    if report.get("argument"):
        lines += ["", "## 论证", f"- 文章级 p={report['argument']['article_p']}（{report['argument']['verdict']}）"]
        for x in report["argument"]["claims"]:
            lines.append(f"- {x['claim']} p={x['p']:.3f}｜{x['text'][:50]}")
    (d / "CHECKS" / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return report


# ------------------------------------------------------------------ 初始化
def init_from_text(slug: str, title: str, text: str) -> dict:
    d = WORK / slug
    d.mkdir(parents=True, exist_ok=True)
    (d / "OUTLINE.md").write_text(f"# {title}\n\n{text}\n", encoding="utf-8")
    (d / "FACTS.md").write_text(f"# 事实库 · {title}\n", encoding="utf-8")
    (d / "DRAFT.md").write_text(f"# {title}\n", encoding="utf-8")
    outline = parse_outline(text)
    save_questions(slug, build_questions(outline))
    export_questions_md(slug)
    return {"dir": str(d), "chapters": len(outline["chapters"]), "sections": len(outline["sections"]),
            "questions": len(load_questions(slug))}
