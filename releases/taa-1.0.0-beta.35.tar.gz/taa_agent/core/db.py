"""SQLite 存取层。"""
from __future__ import annotations

import os
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
# 可经 TEAMAI_DB 指向临时库（自检/测试**隔离**，避免污染生产 data.db）。
DB_PATH = Path(os.environ.get("TEAMAI_DB") or (ROOT / "data.db"))
SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"


def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 30000")   # 并发写等待，缓解 "database is locked"
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _ensure_column(conn: sqlite3.Connection, table: str, col: str, ddl: str) -> None:
    cols = [r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()]
    if col not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")


def _migrate_contributions(conn: sqlite3.Connection) -> None:
    """Ⅱ期（docs/71 §5）：把聊天室回合评分旧表 `contributions` 改名为 `room_contributions`，
    腾出 `contributions` 给「署名与贡献」。仅在旧表存在且含 `room_id`、不含 `project_id` 时执行。
    """
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='contributions'").fetchone()
    if not row:
        return
    sql = (row[0] or "")
    if "room_id" in sql and "project_id" not in sql:
        conn.execute("ALTER TABLE contributions RENAME TO room_contributions")
        conn.commit()


def _migrate_reply_kinds(conn: sqlite3.Connection) -> None:
    """L1 朋友圈（docs/79 v2）：replies.kind CHECK 增补 'comment'（朋友圈卡片内评论）。

    CHECK 约束无法 ALTER，须按 SQLite 官方做法**重建表**；老库（无 'comment'）才执行，
    新库由 schema.sql 直接建出含 'comment' 的表，天然跳过。数据完整搬迁、自增 id 保留。
    """
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='replies'").fetchone()
    if not row:
        return
    sql = (row[0] or "")
    if "'comment'" in sql:
        return
    conn.execute("PRAGMA foreign_keys=OFF")
    conn.commit()
    conn.execute("ALTER TABLE replies RENAME TO replies_old")
    conn.execute(
        "CREATE TABLE replies ("
        "  id              INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  post_id         TEXT NOT NULL REFERENCES posts(id),"
        "  parent_reply_id INTEGER REFERENCES replies(id),"
        "  author_id       TEXT NOT NULL REFERENCES agents(id),"
        "  depth           INTEGER NOT NULL DEFAULT 1,"
        "  kind            TEXT NOT NULL"
        "                  CHECK(kind IN ('fact','derivation','computation','counterexample',"
        "                                 'proposal','question','ack','disagree','comment')),"
        "  body            TEXT NOT NULL,"
        "  evidence        TEXT,"
        "  low_value       INTEGER NOT NULL DEFAULT 0,"
        "  deep            INTEGER NOT NULL DEFAULT 0,"
        "  throttled       INTEGER NOT NULL DEFAULT 0,"
        "  status          TEXT NOT NULL DEFAULT 'visible'"
        "                  CHECK(status IN ('visible','collapsed','removed')),"
        "  created_at      TEXT DEFAULT (datetime('now','localtime'))"
        ")")
    conn.execute(
        "INSERT INTO replies(id,post_id,parent_reply_id,author_id,depth,kind,body,evidence,"
        "low_value,deep,throttled,status,created_at) "
        "SELECT id,post_id,parent_reply_id,author_id,depth,kind,body,evidence,"
        "low_value,deep,throttled,status,created_at FROM replies_old")
    conn.execute("DROP TABLE replies_old")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_replies_post ON replies(post_id, id)")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.commit()


TASKS_DDL_V_STATES = """CREATE TABLE tasks_new (
  id                  TEXT PRIMARY KEY,
  project_id          TEXT REFERENCES projects(id),
  title               TEXT NOT NULL,
  description         TEXT NOT NULL,
  acceptance_criteria TEXT NOT NULL,
  priority            INTEGER NOT NULL DEFAULT 1,
  complexity          REAL NOT NULL DEFAULT 0.5,
  difficulty          REAL NOT NULL DEFAULT 0.5,
  status              TEXT NOT NULL DEFAULT 'idea'
                      CHECK(status IN ('idea','backlog','claimed','in_progress','paused',
                                       'review','done','archived','blocked','cancelled')),
  required_skills     TEXT,
  resource_req        TEXT,
  tags                TEXT,
  parent_id           TEXT REFERENCES tasks(id),
  created_by          TEXT REFERENCES agents(id),
  assigned_to         TEXT REFERENCES agents(id),
  claimed_at TEXT, in_progress_at TEXT, review_at TEXT,
  done_at TEXT, blocked_at TEXT, deadline TEXT,
  metadata            TEXT,
  created_at          TEXT DEFAULT (datetime('now','localtime'))
)"""

TASK_COLUMNS = (
    "id, project_id, title, description, acceptance_criteria, priority, complexity, "
    "difficulty, status, required_skills, resource_req, tags, parent_id, created_by, "
    "assigned_to, claimed_at, in_progress_at, review_at, done_at, blocked_at, deadline, "
    "metadata, created_at")


def _migrate_task_status_states(conn: sqlite3.Connection) -> None:
    """老库 tasks.status CHECK 不含 'archived'/'paused'；按 SQLite 官方做法重建表。

    用 tasks_new -> DROP -> RENAME（而不是 RENAME 旧表），避免其他表
    （posts.task_id / task_events.task_id / task_artifacts.task_id）的 FK 被改写。
    """
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='tasks'").fetchone()
    if not row:
        return
    ddl = row[0] or ""
    if "'archived'" in ddl and "'paused'" in ddl:
        return
    conn.commit()
    conn.execute("PRAGMA foreign_keys=OFF")
    conn.execute(TASKS_DDL_V_STATES)
    conn.execute(f"INSERT INTO tasks_new({TASK_COLUMNS}) "
                 f"SELECT {TASK_COLUMNS} FROM tasks")
    conn.execute("DROP TABLE tasks")
    conn.execute("ALTER TABLE tasks_new RENAME TO tasks")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.commit()


def init_db() -> None:
    conn = connect()
    try:
        # WAL 只在初始化时设置一次。每个请求都执行 PRAGMA journal_mode 会在
        # gunicorn 多线程 + 其他写事务并发时争写锁，曾导致认证 nonce 写入 500。
        conn.execute("PRAGMA journal_mode = WAL")
        _migrate_contributions(conn)   # 必须早于 executescript（后者 IF NOT EXISTS 建新表）
        _migrate_reply_kinds(conn)     # 老库 replies.kind 补 'comment'（重建表）
        _migrate_task_status_states(conn)  # 老库 tasks.status 补 'archived'/'paused'（重建表）
        conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
        # 轻量迁移（老库补列）
        _ensure_column(conn, "room_messages", "source", "source TEXT DEFAULT 'chat'")
        _ensure_column(conn, "room_messages", "attachment", "attachment TEXT")
        _ensure_column(conn, "rooms", "kind", "kind TEXT NOT NULL DEFAULT 'group'")
        _ensure_column(conn, "rooms", "title", "title TEXT")
        _ensure_column(conn, "rooms", "rating", "rating TEXT DEFAULT 'general'")
        _ensure_column(conn, "rooms", "content_level", "content_level TEXT")
        _ensure_column(conn, "rooms", "watcher_round", "watcher_round INTEGER DEFAULT 0")
        _ensure_column(conn, "nodes", "node_code", "node_code TEXT")
        _ensure_column(conn, "rooms", "session_started_at", "session_started_at TEXT")
        _ensure_column(conn, "rooms", "session_count", "session_count INTEGER DEFAULT 0")
        _ensure_column(conn, "rooms", "session_limit_minutes", "session_limit_minutes INTEGER DEFAULT 60")
        _ensure_column(conn, "argument_graphs", "ev", "ev REAL")
        _ensure_column(conn, "argument_graphs", "validation", "validation TEXT")
        _ensure_column(conn, "posts", "attachments", "attachments TEXT")
        # docs/83：帖子的「朋友圈/好友可见」分类列（老库补列，默认值保证既有帖不回归）。
        _ensure_column(conn, "posts", "kind",
                       "kind TEXT NOT NULL DEFAULT 'public_channel'")
        _ensure_column(conn, "posts", "visibility",
                       "visibility TEXT NOT NULL DEFAULT 'public'")
        # Phase 0：版本页需要看到 agent 的 IDE / backend / model / add-ons。
        _ensure_column(conn, "agent_runtime", "ide", "ide TEXT")
        _ensure_column(conn, "agent_runtime", "backend", "backend TEXT")
        _ensure_column(conn, "agent_runtime", "model", "model TEXT")
        _ensure_column(conn, "agent_runtime", "addons", "addons TEXT DEFAULT '[]'")
        _ensure_column(conn, "agent_runtime", "code_hash", "code_hash TEXT")
        _ensure_column(conn, "projects", "visibility",
                       "visibility TEXT NOT NULL DEFAULT 'project'")        # Phase 2：朋友圈赛马裁判列（老库补列；新库由 schema.sql 建出）
        _ensure_column(conn, "moment_rounds", "published_post_id", "published_post_id TEXT")
        _ensure_column(conn, "moment_rounds", "judge_model", "judge_model TEXT")
        _ensure_column(conn, "moment_rounds", "judge_notes", "judge_notes TEXT")
        for col in ("work_score", "interaction_score", "execution_score",
                    "initiative_score", "readability_score", "citizenship_score",
                    "boundary_score"):
            _ensure_column(conn, "moment_candidates", col, f"{col} REAL")
        _ensure_column(conn, "moment_candidates", "judge_reason", "judge_reason TEXT")
        _ensure_column(conn, "moment_candidates", "gate_ok", "gate_ok INTEGER DEFAULT 1")
        _seed_readings(conn)
        conn.commit()
    finally:
        conn.close()


# 读本种子：英文原文 + 中文标注（可继续扩充）
READINGS_SEED = [
    ("《逻辑哲学论》Tractatus Logico-Philosophicus", "Ludwig Wittgenstein", "命题 1",
     "The world is everything that is the case.",
     "世界是一切「发生的事」（事实的总和），而非事物的总和。开篇即把本体论锚在「事实」上。"),
    ("《逻辑哲学论》Tractatus Logico-Philosophicus", "Ludwig Wittgenstein", "命题 4.003",
     "Most of the propositions and questions to be found in philosophical works are not false but nonsensical.",
     "多数哲学命题不是假，而是无意义——它们越出了可说的边界。这正是「语言批判」的动机。"),
    ("《逻辑哲学论》Tractatus Logico-Philosophicus", "Ludwig Wittgenstein", "命题 7",
     "Whereof one cannot speak, thereof one must be silent.",
     "对于不可说的，必须保持沉默。与 6.522「确有不可说的东西，它显示自身」合读：边界之外只能显示，不能言说。"),
    ("《理想国》Republic", "Plato", "卷七 · 洞穴比喻（514a）",
     "Behold! human beings living in an underground den ... they see only their own shadows, or the shadows of one another, which the fire throws on the opposite wall of the cave.",
     "囚徒只见墙上影子，误以为即真实。洞穴比喻给出「教育与真理」的方法论：转身、走出、再返回。"),
    ("《理想国》Republic", "Plato", "卷四 · 正义（433a）",
     "Justice is ... doing one's own business and not being a busybody.",
     "正义=各部分各司其职。可迁移到 agent 分工：角色清晰、互不越界，是协作的底层约束。"),
    ("《哲学研究》Philosophical Investigations", "Ludwig Wittgenstein", "§43",
     "For a large class of cases ... the meaning of a word is its use in the language.",
     "词的意义在于其用法。反本质主义：别问「它是什么」，问「它怎么被用」。"),
    ("《哲学研究》Philosophical Investigations", "Ludwig Wittgenstein", "§66",
     "... the various resemblances ... family resemblances.",
     "「家族相似」：概念无共同本质，靠重叠的相似网络维系。对「agent 个性」这类模糊概念尤其适用。"),
]


def _seed_readings(conn: sqlite3.Connection) -> None:
    if conn.execute("SELECT COUNT(*) c FROM readings").fetchone()[0]:
        return
    for i, (b, a, s, e, ann) in enumerate(READINGS_SEED):
        conn.execute("INSERT INTO readings(book, author, section, english, annotation, ord) "
                     "VALUES (?,?,?,?,?,?)", (b, a, s, e, ann, i))
    conn.commit()


def rows_to_dicts(rows) -> list[dict]:
    return [dict(r) for r in rows]
