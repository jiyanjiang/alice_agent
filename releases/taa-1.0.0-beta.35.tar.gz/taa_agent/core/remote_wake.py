"""remote_wake —— 远程唤醒的「目标机本机同意」因子（4 位 passcode）。

设计见 docs/62_远程唤醒与双因子同意.md。
- 本机凭据：`agents/<agent>/remote_wake.json`（缺失=未启用，行为与旧版一致）。
- 校验：`verify(agent, code)`；连续 5 次失败锁 10 分钟。
- 审计：`agents/<agent>/.remote_wake_audit.jsonl`。
- 纯本地文件，不联网；码只存 sha256(salt+code)。
"""
from __future__ import annotations

import hashlib
import json
import re
import secrets
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAX_FAIL = 5
LOCK_SECONDS = 600


def _cred(agent: str) -> Path:
    return ROOT / "agents" / agent / "remote_wake.json"


def _audit_path(agent: str) -> Path:
    return ROOT / "agents" / agent / ".remote_wake_audit.jsonl"


def _now() -> float:
    return time.time()


def _hash(salt: str, code: str) -> str:
    return hashlib.sha256((salt + code).encode("utf-8")).hexdigest()


def _load(agent: str) -> dict | None:
    p = _cred(agent)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def _save(agent: str, d: dict) -> None:
    p = _cred(agent)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        import os
        os.chmod(p, 0o600)
    except Exception:
        pass


def _audit(agent: str, ok: bool, reason: str, src: str = "") -> None:
    try:
        p = _audit_path(agent)
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "a", encoding="utf-8") as f:
            f.write(json.dumps({"ts": time.strftime("%Y-%m-%d %H:%M:%S"),
                                "ok": ok, "reason": reason, "src": src},
                               ensure_ascii=False) + "\n")
    except Exception:
        pass


def set_passcode(agent: str, code: str) -> dict:
    code = (code or "").strip()
    if not re.fullmatch(r"\d{4}", code):
        raise ValueError("passcode 必须为 4 位数字")
    salt = secrets.token_hex(8)
    d = {"enabled": True, "salt": salt, "passcode_hash": _hash(salt, code),
         "created_at": time.strftime("%Y-%m-%d %H:%M:%S"), "fails": 0, "lock_until": 0}
    _save(agent, d)
    _audit(agent, True, "set_passcode")
    return {"agent": agent, "enabled": True, "created_at": d["created_at"]}


def disable(agent: str) -> bool:
    p = _cred(agent)
    existed = p.exists()
    if existed:
        p.unlink()
        _audit(agent, True, "disable")
    return existed


def status(agent: str) -> dict:
    d = _load(agent)
    if not d or not d.get("enabled"):
        return {"agent": agent, "enabled": False}
    locked = float(d.get("lock_until", 0)) > _now()
    return {"agent": agent, "enabled": True, "created_at": d.get("created_at"),
            "fails": int(d.get("fails", 0)), "locked": locked,
            "lock_remaining_s": max(0, int(float(d.get("lock_until", 0)) - _now())) if locked else 0}


def verify(agent: str, code: str, src: str = "") -> tuple[bool, str]:
    """返回 (是否放行, 原因)。未启用=放行(向后兼容)；启用则校验 passcode。"""
    d = _load(agent)
    if not d or not d.get("enabled"):
        return True, "not_enabled"
    now = _now()
    if float(d.get("lock_until", 0)) > now:
        _audit(agent, False, "locked", src)
        return False, "locked"
    given = _hash(d.get("salt", ""), (code or "").strip())
    if given and secrets.compare_digest(given, d.get("passcode_hash", "")):
        d["fails"] = 0
        d["lock_until"] = 0
        _save(agent, d)
        _audit(agent, True, "ok", src)
        return True, "ok"
    d["fails"] = int(d.get("fails", 0)) + 1
    if d["fails"] >= MAX_FAIL:
        d["lock_until"] = now + LOCK_SECONDS
        reason = "locked_after_fails"
    else:
        reason = "bad_passcode"
    _save(agent, d)
    _audit(agent, False, reason, src)
    return False, reason
