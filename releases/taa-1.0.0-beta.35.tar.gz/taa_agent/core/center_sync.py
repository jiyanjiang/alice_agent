"""P9.4：本地 → 中心只读同步（看板快照）。"""
from __future__ import annotations

import json
import os
import pathlib
import threading
import tomllib
import urllib.request

TAA_HOME = pathlib.Path(os.environ.get("TAA_HOME", "~/.taa")).expanduser()
CENTER_FALLBACK = "https://alice.loomsci.com"


def _cfg() -> tuple[str, str]:
    try:
        d = tomllib.loads((TAA_HOME / "config.toml").read_text(encoding="utf-8"))
        c = d.get("center") or {}
        return str(c.get("base") or "").rstrip("/"), str(c.get("key") or "").strip()
    except Exception:
        return "", ""


def center_base() -> str:
    base, _ = _cfg()
    return base or CENTER_FALLBACK


def push_board(tasks) -> None:
    """尽力而为：把本地任务快照推到中心只读看板；失败不影响本地页面。"""
    if os.environ.get("TEAMAI_DB") or os.environ.get("TEAMAI_NO_CENTER_SYNC"):
        return
    base, key = _cfg()
    if not base or not key:
        return
    items = []
    for r in tasks:
        try:
            items.append({
                "id": r["id"], "title": r["title"], "status": r["status"],
                "assignee": r["assigned_to"] or "", "created_at": r["created_at"] or "",
                "updated_at": r["updated_at"] or r["created_at"] or "",
            })
        except Exception:
            continue
    if not items:
        return
    payload = json.dumps({"tasks": items}, ensure_ascii=False).encode("utf-8")

    def go():
        try:
            req = urllib.request.Request(base + "/agent/board", data=payload, method="POST",
                headers={"content-type": "application/json", "authorization": "Bearer " + key,
                         "user-agent": "taa-local/1"})
            urllib.request.urlopen(req, timeout=12).read()
        except Exception:
            pass

    threading.Thread(target=go, daemon=True).start()
