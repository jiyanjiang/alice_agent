"""语言风格系统：对话类型判定 + 重复自检 + 风格演化（向真人学习）。

设计要点（替代"禁止套话"的笨办法）：
- 不靠禁用词，而靠**自检重复**（与自己重复 / 与他人重复）+ 主动变换句式；
- 按**对话类型**切换风格（正式 / 非正式 / 闲谈 / 私密）；
- 风格可**周期性更新**（口头禅轮换、从真人语料学句长/节奏）。
"""
from __future__ import annotations

import datetime
import json
import os
import re
import statistics
from pathlib import Path

PUNCT = re.compile(r"[\s，。！？、；：“”‘’（）()\[\]【】…—\-~,.!?;:]+")

DEFAULT_STYLES = {
    "formal": "正式对话：结论先行、给依据，但用第一人称口语，别写成报告或论文。",
    "informal": "非正式交流：松弛、直接抛观点、可以打断和反驳，允许自嘲。",
    "chitchat": "闲谈：短、碎、口语，别论证、别上价值、别总结。",
    "private": "私密场景：放低声音、更坦诚、更短，允许停顿和留白，不端着。",
}


def dialogue_type(room: dict, transcript: list) -> str:
    """按房间分级 + 近期消息形态，判对话类型。"""
    if (room or {}).get("rating") == "nsfw":
        return "private"
    msgs = [m for m in (transcript or []) if m.get("kind") not in ("skip", "system")]
    recent = msgs[-8:]
    if not recent:
        return "informal"
    lens = [len((m.get("body") or "")) for m in recent]
    avg = statistics.mean(lens) if lens else 0
    graphs = sum(1 for m in recent if m.get("graph_id"))
    q = sum(1 for m in recent if m.get("kind") == "question")
    topic = (room or {}).get("topic", "") or ""
    if avg >= 220 or graphs >= 2 or re.search(r"(读书|共读|命题|论证|论文|方案)", topic):
        return "formal"
    if avg < 80 and (q >= 2 or avg < 50):
        return "chitchat"
    return "informal"


NAMES = re.compile(r"(Alice|Bob|human|opencode|MBP)", re.I)


def _shingles(text: str, n: int = 4) -> set:
    t = PUNCT.sub("", NAMES.sub("", text or ""))   # 去掉人名，避免把「Bob你」当重复
    return {t[i:i + n] for i in range(len(t) - n + 1)}


def repetition(text: str, own_recent: list, other_recent: list, n: int = 4, top: int = 6) -> dict:
    """自检：与自己的重复 / 与他人的重复（含开头句式）。"""
    cur = _shingles(text, n)
    own, other = set(), set()
    for m in own_recent or []:
        own |= _shingles(m, n)
    for m in other_recent or []:
        other |= _shingles(m, n)
    norm = lambda s: PUNCT.sub("", NAMES.sub("", (s or "")[:10]))
    op = norm(text)
    own_opens = {norm(m) for m in (own_recent or [])}
    other_opens = {norm(m) for m in (other_recent or [])}
    return {
        "self": sorted(cur & own)[:top],
        "cross": sorted(cur & other)[:top],
        "self_open": bool(op) and op in own_opens,
        "cross_open": bool(op) and op in other_opens,
    }


def has_repetition(rep: dict) -> bool:
    return bool(rep.get("self") or rep.get("cross") or rep.get("self_open") or rep.get("cross_open"))


def style_hint(persona: dict, dtype: str) -> str:
    vo = persona.get("voice") or {}
    styles = vo.get("styles") or {}
    return styles.get(dtype) or DEFAULT_STYLES.get(dtype, "")


def evolve_style(persona: dict, own_texts: list, human_texts: list | None = None,
                 today: datetime.date | None = None) -> dict:
    """周期性更新风格：口头禅轮换 + 从真人语料学节奏（句长/短句比）。"""
    vo = dict(persona.get("voice") or {})
    pool = list(vo.get("pool") or [])
    active = list(vo.get("catchphrases") or [])
    if pool:
        # 轮换：把当前口头禅往后挪，取下一组（错位轮换）
        shift = (int(vo.get("rotate", 0)) + 1) % max(len(pool), 1)
        vo["rotate"] = shift
        active = [pool[(i + shift) % len(pool)] for i in range(min(4, len(pool)))]
    vo["catchphrases"] = active

    learned = dict(vo.get("learned") or {})
    lens = [len(t) for t in (human_texts or []) if t]
    if lens:
        learned["human_avg_len"] = round(statistics.mean(lens), 1)
        learned["human_short_ratio"] = round(sum(1 for x in lens if x < 40) / len(lens), 2)
        # 学真人的节奏：目标句长往真人靠（只记录，供 prompt 参考）
        learned["target_avg_len"] = int(max(20, min(120, statistics.mean(lens))))
    vo["learned"] = learned
    vo["updated_at"] = (today or datetime.date.today()).isoformat()
    return vo


# ------------------------------------------------------------------ 风格学习 v2（LLM 判断，按人设取舍）
# 同一份导师语料，不同人设的 agent 采纳应不同；由 LLM 判断「学什么/学多少/不学什么」，不用关键词规则。
LEARN_MODEL = os.environ.get("TEAMAI_STYLE_MODEL", "deepseek/deepseek-flash")


def _extract_json(text: str) -> dict | None:
    if not text:
        return None
    s = text.strip()
    m = re.search(r"```(?:json)?\s*(.*?)```", s, re.S)
    if m:
        s = m.group(1).strip()
    i, j = s.find("{"), s.rfind("}")
    if i < 0 or j <= i:
        return None
    try:
        d = json.loads(s[i:j + 1], strict=False)
        return d if isinstance(d, dict) else None
    except Exception:
        return None


def _clip(xs, n: int, cap: int = 160) -> str:
    return "\n".join(f"- {(t or '').strip()[:cap]}"
                     for t in (xs or [])[:n] if (t or "").strip())


def _cap_list(xs, keys, n: int = 8) -> list:
    out = []
    for x in (xs or [])[:n]:
        if isinstance(x, dict):
            out.append({k: x.get(k) for k in keys if x.get(k) not in (None, "")})
    return out


def build_learn_prompt(persona: dict, human_texts: list, own_texts: list) -> str:
    name = persona.get("name") or persona.get("id")
    ident = persona.get("identity") or {}
    vo = persona.get("voice") or {}
    soul = persona.get("soul")
    soul_txt = (json.dumps(soul, ensure_ascii=False)[:700] if isinstance(soul, dict)
                else str(soul or "")[:400])
    prof = json.dumps({k: persona.get(k) for k in ("role", "gender", "age", "traits", "interests")
                       if persona.get(k)}, ensure_ascii=False)[:600]
    return (
        f"你在为 agent「{name}」做**语言风格学习**。人设：{prof}\n"
        f"格言：{ident.get('motto', '')}；风格：{vo.get('style', '')}；语气：{vo.get('tone', '')}\n"
        f"灵魂/边界：{soul_txt}\n\n"
        "下面是**导师(真人)**最近的发言（语料），和这位 agent 自己最近的发言。\n"
        "请**判断**：这位 agent 应从导师身上采纳哪些语言特质、采纳到什么程度、哪些**因与人设/边界不符而不采纳**。\n"
        "关键：同一份导师语料，不同人设的 agent 采纳应不同——导师说了尺度较大的话时，是否采纳、采纳多少，"
        "取决于该 agent 的人设与边界（保守的人设少学甚至不学，开放的人设可多学）。\n"
        "并给出该 agent 的目标句长与短句比例（以导师为参照，但按人设调整）。\n\n"
        f"--- 导师语料 ---\n{_clip(human_texts, 30) or '（无）'}\n"
        f"--- 我的历史发言 ---\n{_clip(own_texts, 20) or '（无）'}\n\n"
        "只输出一个 JSON：\n"
        '{"adopt":[{"trait":"…","how":"怎么用","strength":0.0}],'
        '"reject":[{"trait":"…","why":"为何不学"}],'
        '"target_avg_len":45,"human_short_ratio":0.5,"rationale":"一句话"}'
    )


def learn_style(persona: dict, human_texts: list, own_texts: list, *, llm=None,
                model: str = LEARN_MODEL, backend: str = "opencode") -> dict:
    """让 LLM 按人设判断该 agent 采纳哪些语言特质；返回 {ok, learned, adaptation}。"""
    prompt = build_learn_prompt(persona, human_texts, own_texts)
    if llm is None:
        from core.llm import get as llm_get
        llm = llm_get(backend)
        res = llm.run(prompt, model=model, cwd=str(Path(__file__).resolve().parent.parent),
                      title=f"style:{persona.get('id')}", timeout=180)
        text = res.text if res.ok else ""
        if not res.ok:
            return {"ok": False, "error": "llm_failed", "raw": text[-300:]}
    else:
        text = llm(prompt)
    d = _extract_json(text) or {}
    learned = dict((persona.get("voice") or {}).get("learned") or {})
    try:
        if d.get("target_avg_len"):
            learned["target_avg_len"] = int(max(20, min(120, float(d["target_avg_len"]))))
    except (TypeError, ValueError):
        pass
    try:
        if d.get("human_short_ratio") is not None:
            learned["human_short_ratio"] = round(max(0.0, min(1.0, float(d["human_short_ratio"]))), 2)
    except (TypeError, ValueError):
        pass
    adaptation = {
        "adopt": _cap_list(d.get("adopt"), ("trait", "how", "strength")),
        "reject": _cap_list(d.get("reject"), ("trait", "why")),
        "rationale": (d.get("rationale") or "").strip() or None,
        "updated_at": datetime.date.today().isoformat(),
    }
    return {"ok": True, "learned": learned, "adaptation": adaptation}


def style_learned_note(persona: dict) -> str:
    """把「从导师学来、按人设取舍」的风格要点拼成 prompt 块（供生成时注入）。"""
    vo = persona.get("voice") or {}
    learned = vo.get("learned") or {}
    adapt = vo.get("adaptation") or {}
    if not learned and not adapt:
        return ""
    parts = ["【我的语言风格（从导师学、已按我的人设取舍）】"]
    if learned.get("target_avg_len"):
        parts.append(f"目标句长≈{learned['target_avg_len']}字")
    if learned.get("human_short_ratio") is not None:
        parts.append(f"短句比≈{learned['human_short_ratio']}")
    for a in (adapt.get("adopt") or [])[:5]:
        parts.append(f"采纳：{a.get('trait')}（{a.get('how') or ''}）")
    for r in (adapt.get("reject") or [])[:3]:
        parts.append(f"不学：{r.get('trait')}（{r.get('why') or ''}）")
    return "\n" + "；".join(parts) + "\n"


def build_balance_prompt(personas: list) -> str:
    rows = []
    for p in personas or []:
        vo = p.get("voice") or {}
        rows.append({"id": p.get("id"), "role": p.get("role"), "traits": p.get("traits"),
                     "interests": p.get("interests"), "tone": vo.get("tone"),
                     "style": vo.get("style"), "anchor": vo.get("anchor")})
    return (
        "你是团队的**人格均衡师**。下面是全队 agent 的人设摘要。\n"
        "请判断这个群体的人格分布是否**互补平衡**（例如表达开放度：保守↔开放；暖↔冷；严谨↔松弛；主动↔克制）。\n"
        "若偏斜，给出**有界、不破坏各自身份**的互补微调建议（如一个偏保守，另一个可偏外放），使整体社群人格平衡。\n\n"
        f"人设摘要：{json.dumps(rows, ensure_ascii=False)[:2000]}\n\n"
        "只输出一个 JSON：\n"
        '{"assessment":"一句话诊断","axis":"最失衡的轴","skew":0.0,'
        '"suggestions":[{"agent":"id","field":"如 voice.tone / traits.expressiveness",'
        '"from":"现状","to":"建议","why":"为何更互补"}]}'
    )


def balance_team(personas: list, *, llm=None, model: str = LEARN_MODEL,
                 backend: str = "opencode") -> dict:
    """让 LLM 判断全队人格是否互补平衡，并给出有界微调建议（不自动改人设）。"""
    prompt = build_balance_prompt(personas)
    if llm is None:
        from core.llm import get as llm_get
        llm = llm_get(backend)
        res = llm.run(prompt, model=model, cwd=str(Path(__file__).resolve().parent.parent),
                      title="style:balance", timeout=180)
        text = res.text if res.ok else ""
        if not res.ok:
            return {"ok": False, "error": "llm_failed", "raw": text[-300:]}
    else:
        text = llm(prompt)
    d = _extract_json(text) or {}
    return {"ok": True, "assessment": (d.get("assessment") or "").strip(),
            "axis": (d.get("axis") or "").strip(), "skew": d.get("skew"),
            "suggestions": _cap_list(d.get("suggestions"), ("agent", "field", "from", "to", "why"))}
