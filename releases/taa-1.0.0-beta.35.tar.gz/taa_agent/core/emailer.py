"""emailer —— 统一发信（供工具 `email.send` 与 CLI `teamai email` 共用）。

配置优先级：环境变量 > config.yaml(smtp.*) > 内置默认。
    smtp:
      host: smtp.126.com
      port: 465
      sender: xxx@126.com
      auth_code: ******      # 授权码（非登录密码），gitignored
      name: TeamAI
环境变量：SMTP_HOST / SMTP_PORT / SMTP_EMAIL / SMTP_AUTH_CODE / SMTP_NAME
隐私：本模块不内置任何账号/授权码；由 config.yaml(gitignored) 或环境变量提供。
"""
from __future__ import annotations

import smtplib
import ssl
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr
from pathlib import Path

from . import config


def _cfg():
    return {
        "host": config.get("smtp.host", "smtp.126.com", env="SMTP_HOST"),
        "port": config.get_int("smtp.port", 465, env="SMTP_PORT"),
        "sender": config.get("smtp.sender", "", env="SMTP_EMAIL"),
        "auth_code": config.get("smtp.auth_code", "", env="SMTP_AUTH_CODE"),
        "name": config.get("smtp.name", "TeamAI", env="SMTP_NAME"),
    }


def send(to: str | list[str], subject: str, body: str = "", html: str | None = None,
         files: list[str] | None = None, attachments: list[str] | None = None) -> dict:
    """发送邮件。files=按文本并入正文；attachments=作为附件。返回 {ok, to, subject, ...}。"""
    c = _cfg()
    if not c["sender"] or not c["auth_code"]:
        return {"ok": False, "error": "未配置 SMTP（smtp.sender / smtp.auth_code；或 SMTP_EMAIL/SMTP_AUTH_CODE）"}
    to_list = [to] if isinstance(to, str) else list(to)
    to_list = [t.strip() for t in to_list if t and t.strip()]
    if not to_list:
        return {"ok": False, "error": "缺少收件人"}

    # 正文：显式 body + 逐个 file 的内容
    parts_plain = [body] if body else []
    for f in (files or []):
        try:
            parts_plain.append(Path(f).read_text(encoding="utf-8"))
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": f"读取 {f} 失败：{e}"}
    plain = "\n\n".join(p for p in parts_plain if p)

    msg = MIMEMultipart("mixed")
    msg["From"] = formataddr((c["name"], c["sender"]))
    msg["To"] = ", ".join(to_list)
    msg["Subject"] = subject

    alt = MIMEMultipart("alternative")
    alt.attach(MIMEText(plain or "(无正文)", "plain", "utf-8"))
    if html:
        alt.attach(MIMEText(html, "html", "utf-8"))
    msg.attach(alt)

    for a in (attachments or []):
        p = Path(a)
        if not p.is_file():
            return {"ok": False, "error": f"附件不存在：{a}"}
        part = MIMEApplication(p.read_bytes(), _subtype="octet-stream")
        part.add_header("Content-Disposition", "attachment", filename=("utf-8", "", p.name))
        msg.attach(part)

    try:
        ctx = ssl.create_default_context()
        with smtplib.SMTP_SSL(c["host"], int(c["port"]), timeout=25, context=ctx) as s:
            s.login(c["sender"], c["auth_code"])
            s.sendmail(c["sender"], to_list, msg.as_string())
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"{type(e).__name__}: {e}", "to": to_list}
    return {"ok": True, "to": to_list, "subject": subject,
            "attachments": [Path(a).name for a in (attachments or [])],
            "sender": c["sender"]}
