"""运行期依赖自愈（best-effort，绝不致命）。

新节点常见故障：装了 `playwright` 但没跑过 `playwright install chromium`，
于是 `tools/<pkg>/tool.py`（如 physicsworld）与网页截图直接抛
`Executable doesn't exist at .../chromium_headless_shell`，agent 却可能
"抓好了…"却贴不出数据。这里在 join / bootstrap / 驱动启动时做一次幂等安装。

设计原则：
- 幂等：已装即 noop（不触网）。
- 绝不致命：任何异常都吞掉并返回结果字典，不影响主流程。
- 可关：设 `TEAMAI_AUTO_DEPS=0` 关闭自动安装。
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _browser_dirs() -> list[Path]:
    return [Path.home() / ".cache" / "ms-playwright",
            Path.home() / "Library" / "Caches" / "ms-playwright"]


def chromium_installed() -> bool:
    """playwright 浏览器缓存里是否已有 chromium*。"""
    for d in _browser_dirs():
        try:
            if d.exists() and any(p.name.startswith("chromium") for p in d.iterdir()):
                return True
        except OSError:
            continue
    return False


def ensure_chromium(timeout: int = 600, quiet: bool = False) -> dict:
    """确保 playwright Chromium 可用；返回 {ok, action, detail}。幂等、best-effort。

    action: noop（已装）/ install（本次安装）/ skip（无 playwright 或被禁用）。
    """
    if os.environ.get("TEAMAI_AUTO_DEPS", "1").strip() in ("0", "false", "no", "off"):
        return {"ok": True, "action": "skip", "detail": "TEAMAI_AUTO_DEPS=0"}
    try:
        import playwright  # noqa: F401
    except Exception:
        return {"ok": False, "action": "skip",
                "detail": "playwright 未安装（pip install -r requirements.txt）"}
    if chromium_installed():
        return {"ok": True, "action": "noop", "detail": "chromium 已安装"}
    py = sys.executable or "python3"
    try:
        r = subprocess.run([py, "-m", "playwright", "install", "chromium"],
                           capture_output=True, text=True, timeout=timeout)
        ok = r.returncode == 0
        if not quiet:
            print(f"[deps] playwright install chromium -> {'ok' if ok else 'failed'}")
        detail = (r.stdout or r.stderr or "").strip()[-400:]
        return {"ok": ok, "action": "install", "detail": detail}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "action": "install", "detail": f"{type(e).__name__}: {e}"}


# ---- pip 安装的「抗抖动」封装 ------------------------------------------------
# 背景：新机器（尤其 B 机 / 无代理环境）装 requirements 时，官方 PyPI 偶尔
# 握手超时、单包卡住，pip 默认 timeout=15、retries=5 但整轮易被拖垮；
# 这里统一成「官方 → 镜像」的降级链 + 明确的 timeout/retries，可被环境变量覆盖：
#   TEAMAI_PIP_INDEX=https://...   指定唯一源（不降级）
#   TEAMAI_PIP_MIRROR=0            禁用镜像降级（只用官方）
PIP_INDEXES: list[str] = [
    "https://pypi.org/simple",
    "https://pypi.tuna.tsinghua.edu.cn/simple",
    "https://mirrors.aliyun.com/pypi/simple",
]


def pip_indexes() -> list[str]:
    """本次进程要尝试的源列表（第一个优先）。"""
    forced = (os.environ.get("TEAMAI_PIP_INDEX") or "").strip()
    if forced:
        return [forced]
    if os.environ.get("TEAMAI_PIP_MIRROR", "1").strip() in ("0", "false", "no", "off"):
        return PIP_INDEXES[:1]
    return list(PIP_INDEXES)


def pip_install(args: list[str], timeout: int = 900, quiet: bool = False) -> dict:
    """按源降级执行 pip 命令；返回 {ok, index, attempts, detail}。best-effort。"""
    attempts: list[dict] = []
    for index in pip_indexes():
        cmd = [sys.executable, "-m", "pip", "install", *args,
               "--index-url", index, "--timeout", "20", "--retries", "3",
               "--disable-pip-version-check"]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
            ok = r.returncode == 0
            detail = (r.stdout or r.stderr or "").strip()[-400:]
        except Exception as e:  # noqa: BLE001
            ok, detail = False, f"{type(e).__name__}: {e}"
        attempts.append({"index": index, "ok": ok})
        if not quiet:
            print(f"[deps] pip install -> {index} {'ok' if ok else 'failed'}")
        if ok:
            return {"ok": True, "index": index, "attempts": attempts, "detail": detail}
    return {"ok": False, "index": "", "attempts": attempts,
            "detail": attempts and "全部源均失败" or "无可用源"}


if __name__ == "__main__":
    import json
    print(json.dumps(ensure_chromium(), ensure_ascii=False, indent=2))
