"""report —— Agent 执行进度上报（统一状态上报，t-5e7abb71）。

让执行者（如 Carol）在 headless opencode 执行期间，把 start/progress/done 阶段
同步到中心服务端，使人类在看板/工作群看到「当前任务名 + 阶段 + 耗时」，且不打断执行。

三件事（全部失败静默降级，绝不影响执行主流程）：
  1. 本地日志：追加到 runtime/<agent>-activity.log
  2. 服务端活动：PUT /v1/agents/<agent>/activity（看板直接读取）
  3. agent 状态灯（busy/active）+ 可选 POST 一条状态消息到频道（工作群）

本模块只依赖 stdlib，随 core/ 一起分发到各节点；dispatcher 与 CLI 均 `from core import report`。

用法（库）：
    from core import report as rpt
    rpt.report("carol", "start", "t-xxxx", "标题", base="http://127.0.0.1:6080")

用法（CLI，供 opencode 内部自报更细阶段）：
    python -m core.report --as carol --stage progress --task t-xxxx --title "标题" --elapsed 120
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import secrets
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

DEFAULT_URL = os.environ.get("TEAMAI_URL", "http://127.0.0.1:6030").rstrip("/")


# ------------------------------------------------------------------ transport
def _key(agent_id: str) -> dict:
    p = ROOT / "agents" / agent_id / ".key"
    return json.loads(p.read_text(encoding="utf-8"))


def _sign(key: str, method: str, path: str, body: bytes, ts: str, nonce: str) -> str:
    canon = f"{method.upper()}\n{path}\n{hashlib.sha256(body).hexdigest()}\n{ts}\n{nonce}"
    return hmac.new(key.encode(), canon.encode(), hashlib.sha256).hexdigest()


def _request(base: str, method: str, path: str, agent_id: str, body: dict | None = None) -> dict:
    data = json.dumps(body, ensure_ascii=False).encode() if body is not None else b""
    k = _key(agent_id)
    ts, nonce = str(int(time.time())), secrets.token_hex(8)
    req = urllib.request.Request(base + path, data=data if body is not None else None, method=method)
    req.add_header("Content-Type", "application/json")
    req.add_header("X-TeamAI-Key", k["key_id"])
    req.add_header("X-TeamAI-Timestamp", ts)
    req.add_header("X-TeamAI-Nonce", nonce)
    req.add_header("X-TeamAI-Signature", _sign(k["key"], method, path, data, ts, nonce))
    _hub_tok = os.environ.get("TEAMAI_HUB_TOKEN") or os.environ.get("TEAMAI_TUNNEL_TOKEN")
    if _hub_tok and "/n/" in req.full_url: req.add_header("X-Hub-Token", _hub_tok)
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())


def _log_path(agent_id: str) -> Path:
    d = ROOT / "runtime"
    d.mkdir(parents=True, exist_ok=True)
    return d / f"{agent_id}-activity.log"


def _append_log(agent_id: str, line: str) -> None:
    try:
        with _log_path(agent_id).open("a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {line}\n")
    except Exception:
        pass


# ------------------------------------------------------------------ core
def report(agent_id: str, stage: str, task_id: str | None = None, title: str | None = None,
           detail: dict | None = None, base: str = DEFAULT_URL, post_to_channel: str | None = None,
           set_status: bool = True) -> dict | None:
    """上报一次进度。返回服务端活动记录；任何失败都静默降级为 None，不影响主流程。"""
    detail = dict(detail or {})
    # 1. 本地日志（永不失败）
    _append_log(agent_id, f"[{stage}] {task_id or '-'} {title or ''} "
                          f"detail={json.dumps(detail, ensure_ascii=False)}")

    # 2. 服务端活动（看板）
    act = None
    try:
        resp = _request(base, "PUT", f"/v1/agents/{agent_id}/activity",
                        agent_id, {"stage": stage, "task_id": task_id, "title": title,
                                   "detail": detail})
        act = resp.get("activity") if isinstance(resp, dict) else resp
    except Exception:
        pass

    # 3. agent 状态灯（busy/active）+ 可选工作群消息
    try:
        if set_status:
            st = "busy" if stage in ("start", "progress") else "active"
            _request(base, "PUT", f"/v1/agents/{agent_id}/status", agent_id, {"status": st})
    except Exception:
        pass
    if post_to_channel:
        try:
            _post_status(base, agent_id, post_to_channel, stage, task_id, title, detail)
        except Exception:
            pass
    return act


def _post_status(base: str, agent_id: str, channel: str, stage: str,
                 task_id: str | None, title: str | None, detail: dict) -> None:
    icon = {"start": "🟢", "progress": "⏳", "done": "✅", "failed": "❌",
            "blocked": "🔴", "idle": "⚪"}.get(stage, "·")
    el = detail.get("elapsed_s")
    elapsed = f"（已 {el}s）" if el is not None else ""
    name = title or (task_id or "任务")
    body = f"{icon} [{stage}] {agent_id} {name}{elapsed}"
    if detail.get("exit_code") is not None:
        body += f"（exit={detail['exit_code']}）"
    if detail.get("note"):
        body += f" · {detail['note']}"
    if detail.get("err"):
        body += "\n```\n" + str(detail["err"])[-600:] + "\n```"
    _request(base, "POST", "/v1/posts",
             agent_id, {"channel_id": channel, "type": "note",
                       "title": f"{agent_id} 执行进度（系统自动 · 非交付）",
                       "body": body, "task_id": task_id, "tags": ["status", "activity"]})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--as", dest="agent", required=True)
    ap.add_argument("stage", choices=["start", "progress", "done", "failed", "blocked", "idle"])
    ap.add_argument("--task", default=None)
    ap.add_argument("--title", default=None)
    ap.add_argument("--elapsed", type=int, default=None)
    ap.add_argument("--exit-code", type=int, default=None)
    ap.add_argument("--note", default=None)
    ap.add_argument("--url", default=DEFAULT_URL)
    ap.add_argument("--channel", default=None, help="同时 POST 一条状态消息到该频道")
    a = ap.parse_args()
    detail = {}
    if a.elapsed is not None:
        detail["elapsed_s"] = a.elapsed
    if a.exit_code is not None:
        detail["exit_code"] = a.exit_code
    if a.note:
        detail["note"] = a.note
    act = report(a.agent, a.stage, a.task, a.title, detail, base=a.url.rstrip("/"),
                 post_to_channel=a.channel)
    print(f"report: {a.agent} -> {a.stage} {a.task or '-'} "
          f"{(act or {}).get('updated_at') or '(offline, logged locally)'}")


if __name__ == "__main__":
    main()
