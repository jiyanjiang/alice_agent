"""论证可信度引擎（p 值）——贝叶斯证据更新 + 文章级合成。

Owner 2026-10-14 定的口径：
  · 设一个或多个 p 阈值，判断**论证是否有说服力**；
  · 采纳**贝叶斯框架**：允许非常主观的判定，但**有新事实进来时 p 会更新**；
  · 一篇文章可能由几个论证构成 → 可各自算 p，也可合成为**文章级 p**；
  · 立意简单（证成一个论断）→ 一个 p 即可；文章复杂 → 多个 p + 一个判定算法。

设计原则（重要）：
  1. **LLM 只做"判定"，算术不进 LLM**：每条事实对某主张的**似然比 LR** 由 LLM 主观判定并写出理由，
     但**更新与合成规则是确定性的**（可复算、可审计、可回归测试）。
  2. **来源分级约束 LR 上限**（防"用无源事实把结论撑起来"）：
     一手/官方 ≤ 5.0 ｜ 权威二手 ≤ 3.0 ｜ 弱二手 ≤ 2.0 ｜ 无出处 = 1.0（不推动结论）。
  3. **可更新**：事实集变化即重算；每条 LR 与理由留档，便于复查。

用法（见 tests/`scripts/test_writing.py`）：
    claims = [Claim("C1", "X 导致 Y", prior=0.5, weight=1.0)]
    facts  = [Fact("C1", "F003", "support", 3.0, "official", "原始论文 Fig.2")]
    p = claim_p(claims[0], facts)      # 贝叶斯更新后的 p
    p_art = article_p(claims, facts)   # 文章级合成 p
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

# ---- LR 档位（给 LLM 用的离散量表，避免"随便给个数"）----
LR_SCALE = {
    "strong_refute": 0.20,   # 强烈反驳：几乎排除该主张
    "refute": 0.33,
    "weak_refute": 0.50,
    "neutral": 1.00,
    "weak_support": 2.00,
    "support": 3.00,
    "strong_support": 5.00,
}

# ---- 来源分级 → LR 上限（红线：无源不得推动结论）----
GRADE_CAP = {
    "primary": 5.0,      # 一手/官方
    "official": 5.0,
    "secondary": 3.0,    # 权威二手
    "weak": 2.0,         # 弱二手
    "none": 1.0,         # 无出处：不推动
    "": 1.0,
}

# ---- p 阈值（可被 Owner 调整；分批可按领域设不同阈值）----
THRESHOLDS = [
    (0.90, "强（可直接采信）"),
    (0.70, "中（可发表，但应在文中标注不确定性）"),
    (0.50, "弱（需补事实或改立意）"),
    (0.00, "未成立（不得据此立论）"),
]

# Owner 2026-10-14 第 11 条：对外只报**两档**——「合格」与「警告」（Owner 追加：阈值 **0.6**，不必太严，后续可调）。
# 细则（细粒度 4 档）仍保留在 verdict() 里供调试，但门禁与报告用两档：
#   合格：p ≥ PASS_P（默认 0.6）——可发布；
#   警告：p < PASS_P——可以发，但**必须**带告警（标注不确定性 / 触发补事实闭环）。
PASS_P = 0.6


def verdict2(p: float, pass_p: float = PASS_P) -> str:
    """两档判语：合格 / 警告。"""
    return "合格" if p >= pass_p else "警告"


@dataclass
class Claim:
    """一条主张（论断）。weight = 它在整篇立意中的重要性权重（用于合成）。"""
    id: str
    text: str
    prior: float = 0.5          # 先验（可主观；理由应记在 note）
    weight: float = 1.0
    note: str = ""


@dataclass
class Fact:
    """一条事实对某主张的证据（stance + LR + 来源分级）。"""
    claim_id: str
    fact_id: str
    stance: str                 # support | refute
    lr: float
    grade: str = "secondary"
    why: str = ""


def cap_lr(lr: float, grade: str) -> float:
    """按来源分级给 LR 封顶（support 方向才封顶；refute 方向不封顶，避免"用无源材料打压结论"）。"""
    if lr >= 1.0:
        return min(lr, GRADE_CAP.get((grade or "").lower(), 1.0))
    return lr


def posterior(prior: float, lr_product: float) -> float:
    """贝叶斯更新：先验赔率 × 似然比连乘 → 后验概率。"""
    prior = min(max(prior, 1e-6), 1 - 1e-6)
    odds = prior / (1 - prior) * max(lr_product, 1e-9)
    return odds / (1 + odds)


def claim_p(claim: Claim, facts: list[Fact]) -> dict:
    """单条主张的 p（含逐步明细，便于审计）。"""
    items = [f for f in facts if f.claim_id == claim.id]
    prod, trace = 1.0, []
    for f in sorted(items, key=lambda x: x.fact_id):
        eff = cap_lr(float(f.lr), f.grade)
        prod *= eff
        trace.append({"fact": f.fact_id, "stance": f.stance, "lr": float(f.lr),
                      "lr_effective": eff, "grade": f.grade, "why": f.why,
                      "capped": eff != float(f.lr)})
    p = posterior(claim.prior, prod)
    return {"claim": claim.id, "text": claim.text, "prior": claim.prior,
            "lr_product": prod, "p": p, "verdict": verdict(p), "facts": trace}


def _grade(score: float) -> str:
    for th, label in THRESHOLDS:
        if score >= th:
            return label
    return THRESHOLDS[-1][1]


def verdict(p: float) -> str:
    return _grade(p)


def article_p(claims: list[Claim], facts: list[Fact]) -> dict:
    """文章级 p = **加权几何平均**（对低 p 敏感，且单调、可解释）。

    为什么不用算术平均：算术平均会让"一条很弱的主张"被"几条很强的主张"掩盖；
    几何平均能体现"文章要立得住，弱的那条最拖后腿"。权重取 claim.weight（默认 1）。
    """
    per = [claim_p(c, facts) for c in claims if c.weight > 0]
    if not per:
        return {"p": 0.0, "verdict": _grade(0.0), "claims": []}
    wsum = sum(c.weight for c in claims if c.weight > 0)
    logsum = sum(c.weight * math.log(max(r["p"], 1e-6))
                 for c, r in zip([c for c in claims if c.weight > 0], per))
    p = math.exp(logsum / wsum) if wsum else 0.0
    return {"p": p, "verdict": _grade(p), "claims": per,
            "weakest": min(per, key=lambda r: r["p"])["claim"] if per else ""}


def gaps(claims: list[Claim], facts: list[Fact], target: float = 0.70) -> list[dict]:
    """缺口清单：p 低于目标的主张 → 需要补什么（供 LLM 规划"再去查哪些事实"）。

    这是把"事实库编纂"变成**闭环**的一环：低 p ⇒ 定向补事实 ⇒ 重算 p。
    """
    out = []
    for c in claims:
        r = claim_p(c, facts)
        if r["p"] >= target:
            continue
        have = len(r["facts"])
        out.append({
            "claim": c.id, "text": c.text, "p": round(r["p"], 3), "have_facts": have,
            "hint": ("缺事实：至少补 2 条**一手/官方**证据（当前 LR 上限受来源分级约束）"
                     if have < 2 else
                     "证据不足：已有事实的 LR 偏低 → 需要更强的直接证据，或下调该主张的强度"),
        })
    return out
