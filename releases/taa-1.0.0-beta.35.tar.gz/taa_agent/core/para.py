"""PARA 任务模型（docs/326）。

四类对象各自独立：

- 长任务（long）：一个 task_id，多阶段，阶段边界写 checkpoint，只占 1 个 long 执行位；
- 短任务（short）：一个 task_id，一个交付物，完成后归档；
- 方法/工具（method）：从任务沉淀的可复用流程，带版本；
- 档案（archive）：已完成任务与其产物，不删除，可检索/引用。

本模块只做**结构护栏**（阶段契约、产物溯源、方法版本、归档规则）；
"这条任务该不该做/这条方法值不值得沉淀"仍由 agent 判断。
"""
from __future__ import annotations

import hashlib
import json
import re
import uuid
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

LANES = ("long", "short")
ACTIVE_STATUSES = ("claimed", "in_progress", "paused", "review")
LONG_ACTIVE_STATUSES = ("claimed", "in_progress")
ARTIFACT_KINDS = ("file", "dir", "url", "text", "checkpoint", "dataset")
METHOD_STATUSES = ("draft", "active", "archived")
MAX_PAUSED_LONG = 2


class ParaError(ValueError):
    """结构/契约不满足（由 API 转成 409，由 CLI 打印原因）。"""


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _loads(value, default):
    if value is None or value == "":
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(value)
    except Exception:  # noqa: BLE001
        return default


def _dumps(value) -> str:
    return json.dumps(value, ensure_ascii=False)


def _task(conn, task_id: str) -> dict:
    row = conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
    if not row:
        raise ParaError("task not found")
    return dict(row)


def _meta(task: dict) -> dict:
    return _loads(task.get("metadata"), {}) or {}


def _save_meta(conn, task_id: str, meta: dict) -> None:
    conn.execute("UPDATE tasks SET metadata=? WHERE id=?", (_dumps(meta), task_id))


def _owned(task: dict, agent_id: str | None) -> None:
    owner = task.get("assigned_to")
    if agent_id and owner and owner != agent_id:
        raise ParaError(f"task owned by {owner}")


def lane_of(task: dict) -> str:
    lane = (_meta(task).get("lane") or "short")
    return "long" if str(lane) == "long" else "short"


# ------------------------------------------------------------------ phases
def phases_of(task: dict) -> list[dict]:
    phases = _meta(task).get("phases") or []
    return [dict(p) for p in phases if isinstance(p, dict)]


def current_phase(task: dict) -> dict | None:
    meta = _meta(task)
    pid = meta.get("phase")
    phases = phases_of(task)
    for p in phases:
        if p.get("id") == pid:
            return p
    for p in phases:
        if p.get("status") != "done":
            return p
    return phases[-1] if phases else None


def _normalize_phase(raw: dict, index: int) -> dict:
    if not isinstance(raw, dict):
        raise ParaError(f"phase #{index + 1} must be an object")
    title = str(raw.get("title") or "").strip()
    acceptance = str(raw.get("acceptance") or "").strip()
    if not title:
        raise ParaError(f"phase #{index + 1}: title required")
    if not acceptance:
        raise ParaError(f"phase #{index + 1}: acceptance required（阶段完成判据）")
    pid = str(raw.get("id") or f"p{index + 1}").strip()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,32}", pid):
        raise ParaError(f"phase #{index + 1}: bad id {pid!r}")
    budget = raw.get("budget_s")
    if budget is not None:
        try:
            budget = int(budget)
        except (TypeError, ValueError):
            raise ParaError(f"phase {pid}: budget_s must be integer") from None
        if budget <= 0:
            raise ParaError(f"phase {pid}: budget_s must be > 0")
    return {"id": pid, "title": title, "acceptance": acceptance,
            "budget_s": budget, "status": "pending"}


def normalize_phases(phases: list[dict]) -> list[dict]:
    """校验并标准化阶段契约（供建任务时一次性写入）。"""
    if not isinstance(phases, list) or not phases:
        raise ParaError("phases must be a non-empty list")
    normalized = [_normalize_phase(p, i) for i, p in enumerate(phases)]
    ids = [p["id"] for p in normalized]
    if len(ids) != len(set(ids)):
        raise ParaError("duplicate phase id")
    return normalized


def set_phases(conn, task_id: str, agent_id: str | None, phases: list[dict],
               *, force: bool = False) -> dict:
    """为**长任务**写入阶段契约；阶段不是新任务。"""
    task = _task(conn, task_id)
    _owned(task, agent_id)
    if lane_of(task) != "long":
        raise ParaError("phase contract only for long tasks（短任务只需交付物）")
    meta = _meta(task)
    old = meta.get("phases") or []
    if old and any(p.get("status") == "done" for p in old if isinstance(p, dict)) and not force:
        raise ParaError("phases already started; use force=true to reset (会丢阶段进度)")
    normalized = normalize_phases(phases)
    meta["phases"] = normalized
    meta["phase"] = normalized[0]["id"]
    meta["phase_index"] = 0
    meta["phase_status"] = "active"
    meta["checkpoint"] = {"phase": normalized[0]["id"], "completed": [],
                          "next": normalized[0]["id"], "artifacts": []}
    meta["checkpoint_at"] = _now()
    _save_meta(conn, task_id, meta)
    conn.execute(
        "INSERT INTO task_events(task_id, agent_id, from_status, to_status, action, detail) "
        "VALUES (?,?,?,?,?,?)",
        (task_id, agent_id, task["status"], task["status"], "phases_set",
         _dumps({"phases": [{"id": p["id"], "title": p["title"]} for p in normalized]})))
    return _task(conn, task_id)


def complete_phase(conn, task_id: str, agent_id: str | None, phase_id: str | None = None,
                   *, evidence=None, pause_after: bool = False) -> dict:
    """完成一个阶段：必须有该阶段产物或显式证据，然后推进到下一阶段。"""
    task = _task(conn, task_id)
    _owned(task, agent_id)
    if task["status"] not in ("in_progress", "paused"):
        raise ParaError(f"cannot complete phase in status {task['status']}")
    phases = phases_of(task)
    if not phases:
        raise ParaError("no phases defined; set phases first")
    target = None
    if phase_id:
        target = next((p for p in phases if p.get("id") == phase_id), None)
    else:
        target = next((p for p in phases if p.get("status") != "done"), None)
    if not target:
        raise ParaError("phase not found")
    if target.get("status") == "done":
        raise ParaError(f"phase {target['id']} already done")

    arts = conn.execute(
        "SELECT id, path, title, kind FROM task_artifacts "
        "WHERE task_id=? AND phase_id=? AND status='active' ORDER BY created_at",
        (task_id, target["id"])).fetchall()
    if not arts and not evidence:
        raise ParaError(
            f"phase gate: 阶段 {target['id']} 需要至少 1 个产物（task_artifacts）或显式证据")

    now = _now()
    for p in phases:
        if p.get("id") == target["id"]:
            p["status"] = "done"
            p["done_at"] = now
            p["evidence"] = evidence if evidence is not None else [dict(a) for a in arts]
    done_ids = [p["id"] for p in phases if p.get("status") == "done"]
    nxt = next((p for p in phases if p.get("status") != "done"), None)
    idx = next((i for i, p in enumerate(phases) if p.get("id") == (nxt or target)["id"]), 0)

    meta = _meta(task)
    meta["phases"] = phases
    meta["phase"] = (nxt or target)["id"]
    meta["phase_index"] = idx
    meta["phase_status"] = "done" if not nxt else "active"
    meta["checkpoint"] = {
        "phase": (nxt or target)["id"],
        "completed": done_ids,
        "next": nxt["id"] if nxt else None,
        "artifacts": [a["path"] for a in arts if a["path"]],
        "at": now,
    }
    meta["checkpoint_at"] = now
    _save_meta(conn, task_id, meta)
    if pause_after and nxt and task["status"] == "in_progress":
        meta["paused_at"] = now
        _save_meta(conn, task_id, meta)
        conn.execute("UPDATE tasks SET status='paused' WHERE id=?", (task_id,))
        to_status = "paused"
    else:
        to_status = task["status"]
    conn.execute(
        "INSERT INTO task_events(task_id, agent_id, from_status, to_status, action, detail) "
        "VALUES (?,?,?,?,?,?)",
        (task_id, agent_id, task["status"], to_status, "phase_done",
         _dumps({"phase": target["id"], "next": nxt["id"] if nxt else None,
                 "artifacts": [a["id"] for a in arts]})))
    return _task(conn, task_id)


def phase_summary(task: dict) -> dict:
    phases = phases_of(task)
    if not phases:
        return {"phases": [], "current": None, "done": 0, "total": 0}
    cur = current_phase(task)
    return {"phases": phases, "current": cur,
            "done": sum(1 for p in phases if p.get("status") == "done"),
            "total": len(phases)}


# --------------------------------------------------------------- artifacts
def _normalize_path(kind: str, path: str | None) -> tuple[str | None, str | None, int | None]:
    """返回 (stored_path, sha256, bytes)。file/dir 必须真实存在（反幻觉）。"""
    if kind in ("file", "dir"):
        if not path:
            raise ParaError(f"{kind} artifact requires path")
        p = Path(path)
        if not p.is_absolute():
            p = ROOT / p
        p = p.resolve()
        if not p.exists():
            raise ParaError(f"artifact not found: {path}")
        try:
            stored = str(p.relative_to(ROOT))
        except ValueError:
            stored = str(p)
        if kind == "file" and p.is_file():
            h = hashlib.sha256()
            with p.open("rb") as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b""):
                    h.update(chunk)
            return stored, h.hexdigest(), p.stat().st_size
        if kind == "file" and not p.is_file():
            raise ParaError(f"not a file: {path}")
        if kind == "dir" and not p.is_dir():
            raise ParaError(f"not a dir: {path}")
        return stored, None, None
    if kind == "url":
        if not path or not re.match(r"^https?://", path):
            raise ParaError("url artifact requires http(s) url")
        return path, None, None
    if not path:
        raise ParaError(f"{kind} artifact requires content/path")
    return path, None, None


def register_artifact(conn, task_id: str, agent_id: str | None, *,
                      kind: str = "file", path: str | None = None,
                      title: str | None = None, phase_id: str | None = None,
                      sha256: str | None = None, bytes_: int | None = None,
                      meta: dict | None = None) -> dict:
    task = _task(conn, task_id)
    if kind not in ARTIFACT_KINDS:
        raise ParaError(f"kind must be one of {ARTIFACT_KINDS}")
    if phase_id:
        ids = [p.get("id") for p in phases_of(task)]
        if phase_id not in ids:
            raise ParaError(f"phase {phase_id} not defined on task")
    stored, calc_sha, calc_bytes = _normalize_path(kind, path)
    aid = f"a-{uuid.uuid4().hex[:8]}"
    conn.execute(
        "INSERT INTO task_artifacts(id, task_id, phase_id, kind, title, path, sha256, bytes, "
        "meta, created_by) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (aid, task_id, phase_id, kind, title or (Path(stored).name if stored else kind),
         stored, sha256 or calc_sha, bytes_ if bytes_ is not None else calc_bytes,
         _dumps(meta or {}), agent_id))
    conn.execute(
        "INSERT INTO task_events(task_id, agent_id, from_status, to_status, action, detail) "
        "VALUES (?,?,?,?,?,?)",
        (task_id, agent_id, task["status"], task["status"], "artifact_added",
         _dumps({"artifact_id": aid, "phase": phase_id, "path": stored})))
    return get_artifact(conn, aid)


def get_artifact(conn, artifact_id: str) -> dict:
    row = conn.execute("SELECT * FROM task_artifacts WHERE id=?", (artifact_id,)).fetchone()
    if not row:
        raise ParaError("artifact not found")
    out = dict(row)
    out["meta"] = _loads(out.get("meta"), {})
    return out


def list_artifacts(conn, task_id: str | None = None, *, phase_id: str | None = None,
                   include_archived: bool = True, limit: int = 200) -> list[dict]:
    sql = "SELECT * FROM task_artifacts WHERE 1=1"
    params: list = []
    if task_id:
        sql += " AND task_id=?"
        params.append(task_id)
    if phase_id:
        sql += " AND phase_id=?"
        params.append(phase_id)
    if not include_archived:
        sql += " AND status='active'"
    sql += " ORDER BY created_at DESC, id DESC LIMIT ?"
    params.append(int(limit))
    out = []
    for r in conn.execute(sql, params).fetchall():
        d = dict(r)
        d["meta"] = _loads(d.get("meta"), {})
        out.append(d)
    return out


def archive_artifact(conn, artifact_id: str, agent_id: str | None = None) -> dict:
    art = get_artifact(conn, artifact_id)
    conn.execute("UPDATE task_artifacts SET status='archived' WHERE id=?", (artifact_id,))
    conn.execute(
        "INSERT INTO task_events(task_id, agent_id, from_status, to_status, action, detail) "
        "VALUES (?,?,?,?,?,?)",
        (art["task_id"], agent_id, None, None, "artifact_archived",
         _dumps({"artifact_id": artifact_id})))
    return get_artifact(conn, artifact_id)


# ----------------------------------------------------------------- archive
def archive_task(conn, task_id: str, agent_id: str | None = None,
                 reason: str | None = None) -> dict:
    """归档 = 保留 + 可检索；不是删除。

    - done -> archived（复用 tasks.archive：保留交付帖/附件清单）；
    - cancelled 保持 cancelled，只补 archived_at（取消已是终态）；
    - 已 archived 幂等返回。
    """
    task = _task(conn, task_id)
    status = task["status"]
    if status == "archived":
        return task
    if status == "done":
        from . import tasks as task_mod   # 局部导入，避免模块级循环
        return task_mod.archive(conn, task_id, agent_id, reason)
    if status == "cancelled":
        meta = _meta(task)
        if meta.get("archived_at"):
            return task
        meta["archived_at"] = _now()
        _save_meta(conn, task_id, meta)
        conn.execute(
            "INSERT INTO task_events(task_id, agent_id, from_status, to_status, action, detail) "
            "VALUES (?,?,?,?,?,?)",
            (task_id, agent_id, status, status, "archive", _dumps({"reason": reason or ""})))
        return _task(conn, task_id)
    raise ParaError(f"only done/cancelled tasks can be archived (status={status})")


def list_archive(conn, *, agent_id: str | None = None, lane: str | None = None,
                 limit: int = 100) -> list[dict]:
    sql = ("SELECT * FROM tasks WHERE status IN ('done','cancelled','archived')")
    params: list = []
    if agent_id:
        sql += " AND assigned_to=?"
        params.append(agent_id)
    if lane:
        sql += " AND COALESCE(json_extract(metadata, '$.lane'), 'short')=?"
        params.append(lane)
    sql += (" ORDER BY COALESCE(json_extract(metadata, '$.archived_at'), done_at, "
            "created_at) DESC LIMIT ?")
    params.append(int(limit))
    out = []
    for r in conn.execute(sql, params).fetchall():
        d = dict(r)
        d["lane"] = "long" if (_loads(d.get("metadata"), {}) or {}).get("lane") == "long" else "short"
        d["archived_at"] = (_loads(d.get("metadata"), {}) or {}).get("archived_at")
        d["artifact_count"] = conn.execute(
            "SELECT COUNT(*) c FROM task_artifacts WHERE task_id=?", (d["id"],)).fetchone()["c"]
        out.append(d)
    return out


# ----------------------------------------------------------------- methods
def _slugify(slug: str) -> str:
    s = re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "-", (slug or "").strip().lower()).strip("-")
    if not s:
        raise ParaError("method slug required")
    return s[:80]


def _listify(value) -> list:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        return [x.strip() for x in value.splitlines() if x.strip()]
    return [value]


def create_method(conn, agent_id: str | None, *, slug: str, title: str,
                  trigger: str | None = None, inputs=None, steps=None,
                  acceptance: str | None = None, failure_handling: str | None = None,
                  tools=None, version: str | None = None, status: str = "active",
                  source_task_id: str | None = None, project_id: str | None = None,
                  artifact_ids: list[str] | None = None, meta: dict | None = None) -> dict:
    slug = _slugify(slug)
    if not (title or "").strip():
        raise ParaError("method title required")
    if status not in METHOD_STATUSES:
        raise ParaError(f"status must be one of {METHOD_STATUSES}")
    if source_task_id:
        _task(conn, source_task_id)
    if version is None:
        rows = conn.execute("SELECT version FROM methods WHERE slug=?", (slug,)).fetchall()
        nums = [int(r["version"]) for r in rows if str(r["version"]).isdigit()]
        version = str(max(nums + [0]) + 1)
    mid = f"m-{uuid.uuid4().hex[:8]}"
    now = _now()
    conn.execute(
        "INSERT INTO methods(id, slug, title, trigger, inputs, steps, acceptance, "
        "failure_handling, tools, version, status, source_task_id, project_id, meta, "
        "created_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (mid, slug, title.strip(), trigger, _dumps(_listify(inputs)), _dumps(_listify(steps)),
         acceptance, failure_handling, _dumps(_listify(tools)), version, status,
         source_task_id, project_id, _dumps(meta or {}), agent_id, now, now))
    for aid in artifact_ids or []:
        art = get_artifact(conn, aid)
        if source_task_id and art["task_id"] != source_task_id:
            raise ParaError(f"artifact {aid} does not belong to source task")
        conn.execute(
            "INSERT OR IGNORE INTO method_artifacts(method_id, artifact_id) VALUES (?,?)",
            (mid, aid))
    return get_method(conn, mid)


def get_method(conn, key: str, version: str | None = None) -> dict:
    if key.startswith("m-"):
        row = conn.execute("SELECT * FROM methods WHERE id=?", (key,)).fetchone()
    elif version:
        row = conn.execute("SELECT * FROM methods WHERE slug=? AND version=?",
                           (key, version)).fetchone()
    else:
        row = conn.execute(
            "SELECT * FROM methods WHERE slug=? "
            "ORDER BY CAST(version AS INTEGER) DESC, created_at DESC, id DESC LIMIT 1",
            (key,)).fetchone()
    if not row:
        raise ParaError("method not found")
    d = dict(row)
    for f in ("inputs", "steps", "tools", "meta"):
        d[f] = _loads(d.get(f), [] if f != "meta" else {})
    d["artifact_ids"] = [r["artifact_id"] for r in conn.execute(
        "SELECT artifact_id FROM method_artifacts WHERE method_id=?", (d["id"],)).fetchall()]
    return d


def list_methods(conn, *, status: str | None = None, project_id: str | None = None,
                 limit: int = 200) -> list[dict]:
    sql = "SELECT * FROM methods WHERE 1=1"
    params: list = []
    if status:
        sql += " AND status=?"
        params.append(status)
    if project_id:
        sql += " AND project_id=?"
        params.append(project_id)
    sql += " ORDER BY updated_at DESC, created_at DESC LIMIT ?"
    params.append(int(limit))
    return [get_method(conn, r["id"]) for r in conn.execute(sql, params).fetchall()]


def method_from_task(conn, agent_id: str | None, task_id: str, *, slug: str,
                     title: str | None = None, steps=None, trigger: str | None = None,
                     inputs=None, acceptance: str | None = None,
                     failure_handling: str | None = None, tools=None,
                     status: str | None = None) -> dict:
    """从任务沉淀方法；没给 steps 时落 draft（不假装已可复用）。"""
    task = _task(conn, task_id)
    meta = _meta(task)
    arts = list_artifacts(conn, task_id)
    given_steps = _listify(steps)
    steps = given_steps
    if not steps:
        cp = meta.get("checkpoint") or {}
        steps = []
        for pid in cp.get("completed") or []:
            ph = next((p for p in phases_of(task) if p.get("id") == pid), None)
            steps.append(ph.get("title") if ph else f"完成阶段 {pid}")
        if not steps and task.get("description"):
            steps = [s.strip() for s in re.split(r"[\n；;]+", task["description"]) if s.strip()]
    # 只有**显式给出步骤**才可能直接 active；从描述自动推断的流程先落 draft，
    # 由 agent 判断"是否真的可复用"后再升 active（判断权不交给结构规则）。
    if status is None:
        status = "active" if given_steps and acceptance else "draft"
    return create_method(
        conn, agent_id, slug=slug, title=title or task["title"], trigger=trigger or task["title"],
        inputs=inputs, steps=steps, acceptance=acceptance or task.get("acceptance_criteria"),
        failure_handling=failure_handling, tools=tools, status=status,
        source_task_id=task_id, project_id=task.get("project_id"),
        artifact_ids=[a["id"] for a in arts],
        meta={"from_task": task_id, "artifact_paths": [a["path"] for a in arts]})


# ----------------------------------------------------------------- overview
def overview(conn, agent_id: str | None = None) -> dict:
    """一个 agent 的 PARA 现场：长任务 / 短任务 / 方法 / 档案。"""
    where = " AND assigned_to=?" if agent_id else ""
    params = (agent_id,) if agent_id else ()

    long_active = [dict(r) for r in conn.execute(
        "SELECT * FROM tasks WHERE COALESCE(json_extract(metadata,'$.lane'),'short')='long' "
        f"AND status IN ('claimed','in_progress'){where} "
        "ORDER BY CASE status WHEN 'in_progress' THEN 0 ELSE 1 END, created_at", params).fetchall()]
    long_paused = [dict(r) for r in conn.execute(
        "SELECT * FROM tasks WHERE COALESCE(json_extract(metadata,'$.lane'),'short')='long' "
        f"AND status='paused'{where} ORDER BY created_at", params).fetchall()]
    short_open = [dict(r) for r in conn.execute(
        "SELECT * FROM tasks WHERE COALESCE(json_extract(metadata,'$.lane'),'short')='short' "
        f"AND status IN ('claimed','in_progress','review'){where} "
        "ORDER BY CASE status WHEN 'in_progress' THEN 0 WHEN 'claimed' THEN 1 ELSE 2 END, "
        "priority DESC, created_at", params).fetchall()]

    def brief(t):
        return {"id": t["id"], "title": t["title"], "status": t["status"],
                "priority": t["priority"], "project_id": t.get("project_id"),
                "phase": phase_summary(t)["current"],
                "progress": f"{phase_summary(t)['done']}/{phase_summary(t)['total']}"
                if phases_of(t) else None,
                "checkpoint": _meta(t).get("checkpoint")}

    methods = list_methods(conn, status="active", limit=20)
    archive = list_archive(conn, agent_id=agent_id, limit=5)
    return {
        "agent": agent_id,
        "long": [brief(t) for t in long_active],
        "long_paused": [brief(t) for t in long_paused],
        "short": [brief(t) for t in short_open],
        "methods": {"active": len(methods),
                    "recent": [{"id": m["id"], "slug": m["slug"], "title": m["title"],
                                "version": m["version"]} for m in methods[:5]]},
        "archive": {"recent": [{"id": t["id"], "title": t["title"],
                                "status": t["status"], "lane": t["lane"],
                                "artifacts": t["artifact_count"],
                                "archived_at": t["archived_at"]} for t in archive]},
        "rules": {"max_long_active": 1, "max_paused_long": MAX_PAUSED_LONG,
                  "max_short_active": 1, "short_window": "10 tasks / 10 min",
                  "done_is_not_delete": True},
    }


def project_summary(conn, project_id: str) -> dict:
    """项目 = 任务（长/短）+ 方法 + 交付物的组合。"""
    row = conn.execute("SELECT * FROM projects WHERE id=?", (project_id,)).fetchone()
    if not row:
        raise ParaError("project not found")
    tasks = [dict(r) for r in conn.execute(
        "SELECT * FROM tasks WHERE project_id=? ORDER BY created_at", (project_id,)).fetchall()]
    arts = [dict(r) for r in conn.execute(
        "SELECT a.* FROM task_artifacts a JOIN tasks t ON t.id=a.task_id "
        "WHERE t.project_id=? ORDER BY a.created_at DESC", (project_id,)).fetchall()]
    methods = list_methods(conn, project_id=project_id)
    return {"project": dict(row),
            "long": [{"id": t["id"], "title": t["title"], "status": t["status"]}
                     for t in tasks if lane_of(t) == "long"],
            "short": [{"id": t["id"], "title": t["title"], "status": t["status"]}
                      for t in tasks if lane_of(t) == "short"],
            "artifacts": [{"id": a["id"], "task_id": a["task_id"], "path": a["path"], "kind": a["kind"]}
                          for a in arts],
            "methods": [{"id": m["id"], "slug": m["slug"], "title": m["title"],
                         "version": m["version"]} for m in methods]}
