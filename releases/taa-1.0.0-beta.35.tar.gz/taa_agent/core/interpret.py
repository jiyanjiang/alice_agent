"""解读流水线（URL → 中文解读/科普改写 → 草稿帖）——URL→translate/popularize。

依据（本队既有口径，不新造轮子）：
  · docs/83《信源台》：采集→索引→加工→转发；`captures` 表**只存元数据**（无正文列）。
  · docs/82《科普写作流水线》：英文章＝起点 → 生成（风格路由）→ **三自检**。
  · docs/37 七步；风格路由：physicsworld → **奇迹笔记**（research/style/QJ_5.md）。

红线（写进实现，逐条对应任务 t-20c4928b）：
  ① 产出必带**来源标注**（标题 + URL + 站名）+「基于 X 改写」声明；
  ② **不得整段复制原文**：与原文的**连续重合** ≤ 摘录级（脚本 overlap_check.py 判定）；
  ③ 登录后可见的受限内容**不长期入库**：账本 `captures` 表**无正文列**，只留 URL + 哈希 + 长度 + 我们的改写稿；
  ④ 只处理「用户自己有权访问」的内容，**不绕过付费墙**（抓不到就停，不模拟登录/不绕过）；
  ⑤ **按需单篇 + 限流**：canonical_url 去重（命中只更新 last_seen，不重复加工）+ 最小抓取间隔。

设计原则：**LLM 只做「改写/翻译」这一件事**（判定与算术不进 prompt）；结构、去重、重合检测、
来源标注、入库策略全部**确定性**（可复算、可回归）。
"""
from __future__ import annotations

import hashlib
import html as _html
import json
import os
import re
import sqlite3
import tempfile
import time
import urllib.request
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

ROOT = Path(__file__).resolve().parent.parent
LEDGER = ROOT / "data" / "sources.db"
STYLE_QJ5 = ROOT / "research" / "style" / "QJ_5.md"

# 摘录级阈值：连续重合（字符级）上限
MAX_COMMON_RUN = 60          # 汉字/单词连续重合 ≤ 60 ⇒ 摘录级（远低于整段复制）
MIN_FETCH_INTERVAL = 3.0     # 秒：同一进程内两次抓取的最小间隔（限流）

_TRACKING = {"utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
             "fbclid", "gclid", "mc_cid", "mc_eid", "ref", "mc_uid"}


# ---------------------------------------------------------------- 工具
_ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")


def strip_ansi(s: str) -> str:
    return _ANSI.sub("", s or "")


def clean_llm_output(s: str) -> str:
    """优先抽取 `<<<DRAFT>>>…<<<END>>>` 标记区；否则去掉 ANSI 与尾部状态行。"""
    s = strip_ansi(s)
    m = re.search(r"<<<DRAFT>>>([\s\S]*?)<<<END>>>", s)
    if m:
        return m.group(1).strip()
    lines = []
    for ln in s.splitlines():
        if re.match(r"^\s*>\s*\S.*·\s*\S", ln):   # 尾注：> build · deepseek-flash
            continue
        lines.append(ln)
    return "\n".join(lines).strip()


def canonical_url(url: str) -> str:
    """去 utm/锚点等跟踪参数（docs/83 查重键之一）。"""
    p = urlsplit(url.strip())
    q = [(k, v) for k, v in parse_qsl(p.query, keep_blank_values=True) if k.lower() not in _TRACKING]
    return urlunsplit((p.scheme.lower(), p.netloc.lower(), p.path.rstrip("/") or "/",
                       urlencode(q), ""))


def sha1(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8", "ignore")).hexdigest()


# ---------------------------------------------------------------- 抓取 + 正文抽取
def fetch_html(url: str, timeout: int = 30, retries: int = 3) -> tuple[int, str]:
    """极简抓取：只读单页，带 UA；**不模拟登录、不绕付费墙**。网络抖动时重试。"""
    req = urllib.request.Request(url, headers={
        "User-Agent": "TeamAI-Interpreter/1.0 (on-demand single-article; contact: team-ai)",
        "Accept-Language": "en-US,en;q=0.9",
    })
    last: Exception | None = None
    for i in range(max(1, retries)):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return getattr(r, "status", 200), r.read().decode("utf-8", "ignore")
        except Exception as e:          # 网络抖动/TLS reset：退避重试
            last = e
            time.sleep(1.5 * (i + 1))
    raise last if last else RuntimeError("fetch failed")


def _meta(html: str, *names: str) -> str:
    for n in names:
        m = re.search(rf'<meta[^>]+(?:property|name)=["\']{re.escape(n)}["\'][^>]+content=["\']([^"\']+)',
                      html, re.I)
        if m:
            return _html.unescape(m.group(1)).strip()
        m = re.search(rf'<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name)=["\']{re.escape(n)}["\']',
                      html, re.I)
        if m:
            return _html.unescape(m.group(1)).strip()
    return ""


def extract_main(html: str) -> dict:
    """正文级抽取（readability-lite）：取 <article> 内最长文本块，按 <p> 段落拼装。"""
    title = _meta(html, "og:title", "twitter:title") or (
        _html.unescape(re.search(r"<title[^>]*>([\s\S]*?)</title>", html, re.I).group(1)).strip()
        if re.search(r"<title[^>]*>([\s\S]*?)</title>", html, re.I) else "")
    byline = _meta(html, "author", "article:author", "og:article:author")
    date = _meta(html, "article:published_time", "datePublished", "og:article:published_time",
                 "pubdate", "date")
    site = _meta(html, "og:site_name") or (urlsplit("").netloc)

    # 候选容器：article > main > body
    cand = None
    for pat in (r"<article[\s\S]*?</article>", r"<main[\s\S]*?</main>", r"<body[\s\S]*?</body>"):
        for m in re.finditer(pat, html, re.I):
            seg = m.group(0)
            ps = re.findall(r"<p[\s>][\s\S]*?</p>", seg, re.I)
            text_len = sum(len(re.sub(r"<[^>]+>", "", p)) for p in ps)
            if cand is None or text_len > cand[0]:
                cand = (text_len, ps)
        if cand and cand[0] > 800:
            break
    paras = []
    for p in (cand[1] if cand else []):
        t = _html.unescape(re.sub(r"<[^>]+>", " ", p))
        t = re.sub(r"\s+", " ", t).strip()
        if len(t) >= 40:                      # 过滤图注/导航等短块
            paras.append(t)
    text = "\n\n".join(paras)
    images = re.findall(r'<img[^>]+src=["\'](https?://[^"\']+)', html, re.I)[:4]
    # 去掉标题尾巴里的站名/域名（如 "… – Physics World"）
    title = re.sub(r"\s*[–—|\-]\s*(Physics World|physicsworld\.com)\s*$", "", title).strip()
    return {"title": title, "byline": byline, "published_at": date,
            "site": site, "text": text, "images": images}


# ---------------------------------------------------------------- 账本（只存元数据）
SCHEMA = """
CREATE TABLE IF NOT EXISTS captures (
  id TEXT PRIMARY KEY, source_id TEXT, url TEXT, canonical_url TEXT UNIQUE,
  title TEXT, byline TEXT, published_at TEXT, captured_at TEXT, last_seen TEXT,
  content_hash TEXT, text_len INTEGER, images TEXT DEFAULT '[]',
  status TEXT DEFAULT 'raw', processed_post_id TEXT
);  -- 注意：**无 text/html/body 列** —— 受限/原文正文不长期入库（红线③）
CREATE TABLE IF NOT EXISTS drafts (
  id TEXT PRIMARY KEY, capture_id TEXT, mode TEXT, path TEXT, sha1 TEXT, chars INTEGER,
  overlap_max INTEGER, elapsed_s REAL, tokens_in INTEGER, tokens_out INTEGER,
  cost_usd REAL, created_at TEXT
);
"""


def ledger() -> sqlite3.Connection:
    LEDGER.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(LEDGER)
    con.executescript(SCHEMA)
    return con


def find_capture(con: sqlite3.Connection, canon: str) -> dict | None:
    con.row_factory = sqlite3.Row
    r = con.execute("SELECT * FROM captures WHERE canonical_url=?", (canon,)).fetchone()
    return dict(r) if r else None


def upsert_capture(con: sqlite3.Connection, art: dict, url: str) -> tuple[str, bool]:
    canon = canonical_url(url)
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    old = find_capture(con, canon)
    if old:
        con.execute("UPDATE captures SET last_seen=? WHERE canonical_url=?", (now, canon))
        con.commit()
        return old["id"], True
    cid = "cap-" + sha1(canon)[:10]
    con.execute("INSERT OR REPLACE INTO captures(id,source_id,url,canonical_url,title,byline,"
                "published_at,captured_at,last_seen,content_hash,text_len,images,status) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,'raw')",
                (cid, urlsplit(url).netloc, url, canon, art["title"], art["byline"],
                 art["published_at"], now, now, sha1(art["text"]), len(art["text"]),
                 json.dumps(art["images"], ensure_ascii=False)))
    con.commit()
    return cid, False


def add_draft(con: sqlite3.Connection, cid: str, mode: str, path: str, text: str,
              overlap_max: int, elapsed_s: float, tok: dict) -> str:
    did = "drf-" + sha1(f"{cid}:{mode}")[:10]
    con.execute("INSERT OR REPLACE INTO drafts(id,capture_id,mode,path,sha1,chars,overlap_max,"
                "elapsed_s,tokens_in,tokens_out,cost_usd,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (did, cid, mode, path, sha1(text), len(text), overlap_max, round(elapsed_s, 1),
                 tok.get("tokens_in", 0), tok.get("tokens_out", 0), tok.get("cost_usd", 0.0),
                 time.strftime("%Y-%m-%d %H:%M:%S")))
    con.commit()
    return did


# ---------------------------------------------------------------- 连续重合检测（红线②）
def _norm(s: str) -> str:
    return re.sub(r"\s+", "", s or "")


def max_common_run(a: str, b: str) -> int:
    """最长**连续**公共子串长度（字符级，去空白）。用于判定"整段复制"。"""
    a, b = _norm(a), _norm(b)
    if not a or not b:
        return 0
    prev = [0] * (len(b) + 1)
    best = 0
    for i in range(1, len(a) + 1):
        cur = [0] * (len(b) + 1)
        ai = a[i - 1]
        for j in range(1, len(b) + 1):
            if ai == b[j - 1]:
                cur[j] = prev[j - 1] + 1
                if cur[j] > best:
                    best = cur[j]
        prev = cur
    return best


def max_common_words(a: str, b: str) -> int:
    """最长**连续**公共英文词串长度（词级），排除「专名/数字」这类不可避免的重合。"""
    wa = re.findall(r"[A-Za-z]{2,}", a)
    wb = re.findall(r"[A-Za-z]{2,}", b)
    if not wa or not wb:
        return 0
    bset = {}
    for i, w in enumerate(wb):
        bset.setdefault(w.lower(), []).append(i)
    best = 0
    for i in range(len(wa)):
        for j in bset.get(wa[i].lower(), []):
            k = 0
            while i + k < len(wa) and j + k < len(wb) and wa[i + k].lower() == wb[j + k].lower():
                k += 1
            best = max(best, k)
    return best


# ---------------------------------------------------------------- 生成（LLM 只做改写）
_HEADER = """> **来源**：{site} · 《{title}》
> **原文链接**：{url}
> **说明**：本文由 {agent} 基于上述英文报道**{kind}**（基于 {site} 报道改写，非逐段复制；仅保留摘录级引用），
> 供团队内部解读与科普使用。原文版权归原作者/出版方所有。

---

"""

_MODE_KIND = {"translate": "忠实译成中文", "popularize": "科普改写"}


def render_header(art: dict, url: str, agent: str = "Bob@MBP32G", mode: str = "popularize") -> str:
    return _HEADER.format(site=art.get("site") or urlsplit(url).netloc, title=art["title"],
                          url=url, agent=agent, kind=_MODE_KIND.get(mode, "中文解读"))


TRANSLATE_PROMPT = """你在一个**纯文本生成**任务里：你**没有任何工具可用**，禁止读写文件、禁止运行命令、禁止联网搜索。
不要解释，不要汇报，只产出最终正文。

任务：把下面这篇英文科学报道**忠实译成中文**。

硬性要求：
1) 只译，不评、不增删事实、不加"值得注意的是"之类套话；
2) 术语首次出现用「中文（English）」格式；人名/机构/期刊名保留英文原文；
3) 数字、单位、引语务必与原文一致；引语翻成中文但保留"（据 Physics World）"这类归属；
4) 保持段落结构；不要输出原文英文句子（除专名），不要整段照抄英文；
5) **只输出正文**（Markdown）。

输出格式（严格）：先写一行 `<<<DRAFT>>>`，紧接着正文，末尾写一行 `<<<END>>>`。两标记之间不得有任何别的说明。

【英文报道】
{body}
"""

POPULARIZE_PROMPT = """你在一个**纯文本生成**任务里：你**没有任何工具可用**，禁止读写文件、禁止运行命令、禁止联网搜索。
不要解释，不要汇报进度，只产出最终正文。

任务：为中文读者写一篇**科普改写**（不是翻译）。取材＝下面这篇英文科学报道。

写作纪律（文风样本见后）：
1) 面向普通读者，**叙事导向**：先立一个悬念/问题，再讲清 why 与 how；
2) 事实必须来自给定报道，**不许自行添加报道里没有的事实或数字**；不确定就写"据该报道"；
3) 关键术语用「中文（English）」并在紧邻处给一个生活化类比；
4) 语言参照"奇迹笔记"：文白相间、长短句交错、可设问、可用"咱们/我们"，但**不要**机器腔套话
   （不得出现：综上所述/值得注意的是/在当今时代/让我们/由此可见/赋能/闭环 等）；
5) 篇幅 **700–1100 字**（写到这里就停，不要更长，不要重复段落）；
6) **声音密度**：口语/文言的点缀（如 咱们、其实、说白了、未必、偏偏、恐怕、殊不知、玄乎、有意思）
   每千字不少于 3 处——这是"学者聊天"感的硬指标，别写成学术摘要；
7) 结尾回到"这条进展意味着什么"，但**不得夸大**（报道是二手，须说清）；
8) 不要整段复制英文原文。

输出格式（严格）：先写一行 `<<<DRAFT>>>`，紧接着正文（Markdown），末尾写一行 `<<<END>>>`。两标记之间不得有任何别的说明、命令或工具输出。

【英文报道】
{body}

【文风样本（只学语气与节奏，不要抄内容）】
{style}
"""


def _style_excerpt() -> str:
    try:
        t = STYLE_QJ5.read_text(encoding="utf-8", errors="ignore")
        return t[:2600]
    except OSError:
        return "（样本缺失）"


def _sanitize_draft(text: str, cap: int = 6000) -> str:
    """去掉偶发的工具/命令噪音行，并在段落边界处限长（防嵌套 agent 跑偏）。"""
    noise = re.compile(r"^\s*(\$|→|✗|✓|==|<|>|\[(PASS|FAIL|SKIP)\]|python |\.\./venv|opencode )")
    lines = [ln for ln in text.splitlines() if not noise.match(ln)]
    out = "\n".join(lines).strip()
    if len(out) > cap:
        cut = out.rfind("\n\n", 0, cap)
        out = out[:cut if cut > cap * 0.6 else cap].strip()
    return out


def generate(article: dict, mode: str, adapter, *, model: str | None = None) -> dict:
    """调一次 LLM 生成一篇草稿；返回 {text, elapsed_s}。

    注意：生成走**中性工作目录**（无 AGENTS.md）——否则嵌套的 coding agent 会读到团队规程，
    误以为要自己建库/跑脚本，既跑偏又烧 token（实测差 ~100×）。
    """
    body = article["text"][:12000]
    if mode == "translate":
        prompt = TRANSLATE_PROMPT.format(body=body)
    elif mode == "popularize":
        prompt = POPULARIZE_PROMPT.format(body=body, style=_style_excerpt())
    else:
        raise ValueError(f"未知 mode: {mode}")
    neutral = Path(os.environ.get("TEAMAI_INTERPRET_CWD")
                   or (Path(tempfile.gettempdir()) / "teamai-interpret"))
    neutral.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    r = adapter.run(prompt, model=model, cwd=str(neutral), title=f"interpret:{mode}", timeout=420)
    dt = time.time() - t0
    if not r.ok:
        raise RuntimeError(f"LLM 失败 rc={r.returncode}")
    return {"text": _sanitize_draft(clean_llm_output(r.text)), "elapsed_s": dt}


# ---------------------------------------------------------------- 成本（读 opencode 会话库）
def session_cost(title: str, since_ts: float) -> dict:
    """按会话 title 归集 token/花费（team 统一 ds flash；见 core/usage.py）。"""
    db = Path.home() / ".local/share/opencode/opencode.db"
    out = {"tokens_in": 0, "tokens_out": 0, "tokens_reasoning": 0, "tokens_cache_read": 0,
           "cost_usd": 0.0, "model": "?"}
    if not db.exists():
        return out
    con = sqlite3.connect(str(db))
    con.row_factory = sqlite3.Row
    try:
        rows = list(con.execute(
            "SELECT model,cost,tokens_input,tokens_output,tokens_reasoning,tokens_cache_read "
            "FROM session_v2 WHERE title=? AND time_created>=?", (title, int(since_ts * 1000) - 5000)))
    except sqlite3.OperationalError:
        rows = []
    con.close()
    for r in rows:
        out["tokens_in"] += r["tokens_input"] or 0
        out["tokens_out"] += r["tokens_output"] or 0
        out["tokens_reasoning"] += r["tokens_reasoning"] or 0
        out["tokens_cache_read"] += r["tokens_cache_read"] or 0
        out["cost_usd"] += r["cost"] or 0.0
        try:
            out["model"] = (json.loads(r["model"] or "{}") or {}).get("id", "?")
        except Exception:
            pass
    out["tokens_total"] = (out["tokens_in"] + out["tokens_out"]
                           + out["tokens_reasoning"] + out["tokens_cache_read"])
    out["cost_usd"] = round(out["cost_usd"], 6)
    return out
