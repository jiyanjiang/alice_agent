"""本地会话 → opencode 执行器桥。

设计边界：
- 只有本地 Flask 的「执行」按钮（或 /exec 前缀）才会触发；普通聊天不触发。
- 同一房间同一 agent 同时只跑一个任务。
- 执行发生在项目根目录，使用本机 opencode + 本机模型 Key；不经过中心。
"""
from __future__ import annotations

import os
import pathlib
import re
import sqlite3
import subprocess
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass

ROOT = pathlib.Path(__file__).resolve().parent.parent
DB = pathlib.Path(os.environ.get("TEAMAI_UI_DB") or (ROOT / "data.db"))
LOG = ROOT / "runtime" / "executor.log"
RUNNING: set[tuple[str, str, str]] = set()
LOCK = threading.Lock()
# 单机并发工位：父体与子体都算一个槽；默认 4，按机器/额度调（见 docs/332）。
POOL = ThreadPoolExecutor(max_workers=int(os.environ.get("TEAMAI_EXEC_WORKERS", "4")),
                          thread_name_prefix="taa-exec")
_WARM = {"at": 0.0, "ok": False, "ms": 0, "busy": False}


def _log(line: str) -> None:
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        with LOG.open("a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {line}\n")
    except OSError:
        pass


FEED_MIN_SECONDS = int(os.environ.get("TEAMAI_FEED_MIN_SECONDS", "300"))


def write_task_feed(room: str, agent: str, agent_name: str, task: str, text: str,
                    log_path: str = "", elapsed: float = 0.0, ok: bool = True) -> str | None:
    """长任务成功后落一条结构化 Feed；使用已有摘要，不额外调用 LLM。

    幂等键 = room + agent + 原始任务；重复执行只保留一条。
    """
    if not ok or elapsed < FEED_MIN_SECONDS:
        return None
    import hashlib
    import re as _re
    from core import community, redaction
    key = hashlib.sha256(f"{room}:{agent}:{task}".encode("utf-8")).hexdigest()[:16]
    mark = f"<!-- taa-exec-feed:{key} -->"
    task_line = " ".join((task or "").split())[:180]
    summary = (text or "").strip()[:1800]
    feed_body = (
        f"{mark}\n"
        f"## 长任务复盘\n"
        f"**任务**：{task_line or '（未记录任务描述）'}\n\n"
        f"**结论/验证**\n{summary or '执行完成，但没有可读摘要。'}\n"
        + (f"\n**完整输出**：`{log_path}`\n" if log_path else "")
    )
    try:
        if not redaction.scan(feed_body)["pass"]:
            _log(f"feed skipped room={room} agent={agent} reason=redaction")
            return None
    except Exception:
        pass
    c = _conn()
    try:
        if c.execute("SELECT 1 FROM posts WHERE body LIKE ? LIMIT 1", (mark + "%",)).fetchone():
            return None
        task_id = next(iter(_re.findall(r"\bt-[0-9a-f]{8}\b", task or "")), None)
        title = "长任务复盘 · " + (task_line[:72] or "执行完成")
        try:
            from core import community as _community
            pid = _community.create_post(
                c, agent, "#projects/team-ai", "note", feed_body,
                title=title[:160], tags=["长任务", "复盘"], task_id=task_id,
                kind="public_channel", visibility="public")
        except Exception:
            # 频道/额度异常时直接落一条最小 Feed，不让复盘丢失。
            import uuid
            pid = "p-" + uuid.uuid4().hex[:8]
            c.execute("INSERT INTO posts(id,channel_id,author_id,type,title,body,tags,status,"
                      "kind,visibility,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,"
                      "datetime('now','localtime'),datetime('now','localtime'))",
                      (pid, "#general", agent, "note", title[:160], feed_body,
                       '["长任务", "复盘"]', "published", "public_channel", "public"))
            c.commit()
        _log(f"feed written room={room} agent={agent} post={pid} elapsed={int(elapsed)}s")
        return pid
    except Exception as e:  # noqa: BLE001
        _log(f"feed failed room={room} agent={agent}: {e}")
        return None
    finally:
        c.close()


def _conn() -> sqlite3.Connection:
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA busy_timeout = 30000")
    return c


def _say(room: str, agent: str, body: str, source: str = "opencode",
         kind: str = "assertion") -> None:
    c = _conn()
    try:
        row = c.execute("SELECT current_round FROM rooms WHERE id=?", (room,)).fetchone()
        rnd = int(row["current_round"] or 1) if row else 1
        c.execute(
            "INSERT INTO room_messages(room_id,round,agent_id,body,kind,created_at,source) "
            "VALUES(?,?,?,?, ?, datetime('now','localtime'), ?)",
            (room, rnd, agent, body[:4000], kind, source))
        c.commit()
    finally:
        c.close()


def notice(room: str, agent: str, body: str) -> None:
    """规则提示只进系统事件，不进聊天正文。

    聊天正文只允许真实 agent 回复；规则的“未找到本机执行器”不应伪装成 agent 回执。
    """
    _say(room, agent, body, source="system", kind="system")


def _clean(text: str) -> str:
    try:
        from core.dm_runtime import clean_llm_text
        out = clean_llm_text(text or "")
    except Exception:  # noqa: BLE001
        out = (text or "").strip()
    return out.strip()


def _save_raw(room: str, agent: str, body: str, raw: str) -> str:
    try:
        d = ROOT / "runtime" / "executor"
        d.mkdir(parents=True, exist_ok=True)
        name = f"{time.strftime('%Y%m%d-%H%M%S')}-{room}-{agent}.md"
        p = d / name
        p.write_text(f"# opencode raw output\n\n- room: {room}\n- agent: {agent}\n"
                     f"- instruction: {body}\n\n```\n{raw[:200_000]}\n```\n", encoding="utf-8")
        return str(p.relative_to(ROOT))
    except OSError:
        return ""


def classify_failure(text: str, returncode: int | None = None) -> tuple[str, str]:
    """把执行失败归一成可行动类型，而不是把整段 CLI 输出丢给人。"""
    low = (text or "").lower()
    if returncode is None or "timed out" in low or "timeout" in low:
        return "timeout", "执行超时；检查任务是否过大或网络/模型是否卡住。"
    if "no such file" in low or "not found" in low or "未找到命令" in low:
        return "missing_cli", "找不到执行器命令；检查 opencode 安装与 PATH。"
    if "401" in low or "403" in low or "unauthorized" in low or "api key" in low or "invalid key" in low:
        return "auth", "模型 Key 无效或权限不足；到设置检查团队 Key。"
    if "permission denied" in low or "eacces" in low:
        return "permission", "当前用户没有执行权限；检查文件/目录权限。"
    if "usage:" in low or "positional arguments" in low:
        return "bad_command", "执行器只拿到命令帮助；检查任务参数。"
    return "executor_error", "执行器返回非零状态；详见归档输出。"


def warm() -> dict:
    """只预热 CLI 进程解析，不调用模型、不消耗 token。"""
    if _WARM["ok"] and time.time() - _WARM["at"] < 600:
        return dict(_WARM)
    if _WARM["busy"]:
        return dict(_WARM)
    _WARM["busy"] = True
    t0 = time.time()
    try:
        from core.llm import get as llm_get
        cmd = llm_get("opencode").build("", model=None, cwd=str(ROOT))
        # 只跑 --version，不把空 prompt 交给模型。
        import shutil
        exe = shutil.which("opencode") or (cmd[0] if cmd else "opencode")
        subprocess.run([exe, "--version"], cwd=str(ROOT), stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, timeout=5)
        _WARM.update({"at": time.time(), "ok": True, "ms": int((time.time() - t0) * 1000), "busy": False})
        _log(f"warm ok ms={_WARM['ms']}")
    except Exception as e:  # noqa: BLE001
        _WARM.update({"at": time.time(), "ok": False, "ms": int((time.time() - t0) * 1000), "busy": False})
        _log(f"warm failed: {e}")
    return dict(_WARM)


def warm_async() -> None:
    if _WARM["ok"] or _WARM["busy"]:
        return
    threading.Thread(target=warm, name="taa-exec-warm", daemon=True).start()


def health() -> dict:
    """轻量预检：不调用模型，不消耗 token。"""
    try:
        from core.llm import get as llm_get
        cli = llm_get("opencode").available()
    except Exception:
        cli = False
    return {"ok": bool(cli), "cli": "opencode" if cli else "未找到",
            "running": len(RUNNING), "workers": 2,
            "warm": bool(_WARM.get("ok")), "warm_ms": int(_WARM.get("ms") or 0)}


def _elapsed_text(seconds: float) -> str:
    return f"{int(seconds)}s" if seconds < 60 else f"{int(seconds // 60)}m{int(seconds % 60):02d}s"


_HELP_LINE = re.compile(r"^\s*(usage|options|positional arguments)\s*:", re.I)
_REPORT_LINE = re.compile(
    r"^\s*(?:#|##|###|[-*]\s|\d+[.)、）]\s*)?"
    r"(?:结论|验证|产物|风险|未完成|完成|做了什么|下一步|摘要|summary|done|result)",
    re.I)


def _looks_like_help(text: str) -> bool:
    """只有“开头就是命令帮助”才算 help；不能因为尾部工具轨迹出现 usage 就误判。"""
    lines = [ln.strip() for ln in (text or "").replace("\r", "").splitlines() if ln.strip()]
    if not lines:
        return False
    head = "\n".join(lines[:12])
    if not any(_HELP_LINE.match(ln) for ln in lines[:12]):
        return False
    # 有真实报告结构时，帮助行只是过程中的工具输出。
    if _REPORT_LINE.search(head) or _REPORT_LINE.search((text or "")[:5000]):
        return False
    return True


def _strip_tool_trace(text: str) -> str:
    """截掉 opencode 末尾的 shell / 文件浏览轨迹，避免混进摘要。"""
    # 只截行首的 shell 命令/工具输出，不碰报告正文里的 inline code。
    m = re.search(r"(?m)^\s*\$\s+(?:cat|ls|cd|echo|git|python|shasum|file|stat|du|find|grep)\b", text or "")
    if m:
        text = text[:m.start()]
    m2 = re.search(r"(?m)^\s*---\s*(?:WORKING|files|ignored)\s*---", text or "")
    if m2:
        text = text[:m2.start()]
    return text.strip()


def summarize_output(text: str, instruction: str = "") -> str:
    """把 opencode 的原始输出压成人类可读摘要；完整输出留在 executor.log。"""
    raw = _clean(text or "")
    if not raw:
        return "执行完成，但没有返回可读输出。"
    body = _strip_tool_trace(raw)
    if _looks_like_help(body):
        return ("执行结束，但这次只拿到工具帮助/环境输出，没有形成可读结果。"
                "请确认指令是否缺参数；完整输出已写入 runtime/executor.log。")
    # 去掉围栏代码的正文，保留标题/结论/验证等可读行。
    text = re.sub(r"```[\s\S]*?```", "\n[代码块已折叠，完整内容见 executor.log]\n", body)
    lines = [ln.strip() for ln in text.replace("\r", "").splitlines()]
    keep = []
    for ln in lines:
        if not ln:
            continue
        if len(ln) > 420:                 # 长命令行/JSON/日志行不刷屏
            continue
        # 同时接受 1) / 2、/ 3） / 4. 等真实报告编号
        if re.match(r"^(#|##|###|[-*] |\d+[.)、）]\s*|结论|完成|验证|产物|风险|未完成|已|修复|新增|改动|测试)", ln, re.I):
            keep.append(ln)
        elif not keep and len(ln) >= 12:
            keep.append(ln)
        if len("\n".join(keep)) >= 1500:
            break
    out = "\n".join(keep).strip()
    if not out:
        out = text.strip()[:900]
    if len(out) > 1800:
        out = out[:1800].rstrip() + "…"
    return out + ("\n\n（完整过程与代码：runtime/executor.log）" if len(raw) > 1800 or "```" in raw else "")


def should_execute(body: str) -> bool:
    """群聊 @agent 的意图门：状态/解释类问题走 chatwork 快速回复，动作类才开 opencode。"""
    text = (body or "").strip()
    if re.match(r"^\s*/(?:exec|run)\b", text, re.I):
        return True
    action = re.search(r"执行|修复|实现|改成|跑一下|测试|生成|部署|提交|写一份|做一份|安装|构建|调试|抓取|读取文件|整理|优化|新增|删除|更新|迁移|运行|验证|检查代码|检查文件|检查构建", text)
    query = re.search(r"汇报|状态|进展|在吗|看看|解释|介绍|为什么|是否|能否|总结|说说|怎么样|如何", text)
    if query and not re.search(r"执行|修复|实现|跑一下|生成|部署|提交|安装|构建|调试|抓取|读取文件|整理|优化|新增|删除|更新|迁移|运行|验证", text):
        return False
    return bool(action)


def _run(room: str, agent: str, agent_name: str, body: str, sub: str = "") -> None:
    key = (room, agent, sub)
    try:
        task = " ".join((body or "").split())
        try:
            from core import nodeinfo
            where = nodeinfo.saved_alias() or "本机"
        except Exception:
            where = "本机"
        role_tag = f" ·子体 {agent}.{sub}" if sub else ""
        _say(room, agent,
             f"⏳ 收到：{task[:120]}\n"
             f"{where}{role_tag} · opencode 已启动；完成后只回结论/验证/产物摘要，完整输出归档到 runtime/executor/。")
        started = time.time()
        from core.llm import get as llm_get
        persona = ""
        if sub:
            from core import subagents as _sa
            try:
                entry = _sa.get_entry(f"{agent}.{sub}")
                persona = _sa.charter(entry) + "\n"
            except Exception as _e:  # noqa: BLE001
                _log(f"subagent charter failed {agent}.{sub}: {_e}")
        prompt = (
            f"{persona}"
            f"你是 Team AI 的 agent「{agent_name}」。人类在本地 TAA 会话里给你下达了执行指令：\n"
            f"{body}\n\n"
            "请在当前项目目录直接执行（可以读写文件、运行命令、测试）。完成后用中文简短汇报：\n"
            "1) 做了什么；2) 验证结果（命令/退出码/测试）；3) 产物路径；4) 未完成项或风险。\n"
            "不要泄露 API Key；不要执行与指令无关的破坏性操作。最终回复只给：1) 结论 2) 验证命令/结果 3) 产物路径 4) 风险；"
            "不要粘贴大段代码、命令帮助、工具轨迹或过程日志。若失败，只用一句说明原因和下一步。"
            "不要启动可见 Chrome/浏览器窗口，除非用户明确要求；需要抓网页时用无头工具。"
        )
        model = os.environ.get("TEAMAI_EXEC_MODEL") or "deepseek/deepseek-flash"
        timeout = int(os.environ.get("TEAMAI_EXEC_TIMEOUT", "900"))
        _log(f"start room={room} agent={agent} sub={sub or '-'} model={model}")
        res = llm_get("opencode").run(
            prompt, model=model, cwd=str(ROOT),
            title=f"taa-exec:{agent}:{room[-8:]}", timeout=timeout)
        raw = _clean(res.text or "")
        text = summarize_output(raw, body)
        log_path = _save_raw(room, agent, body, raw)
        elapsed = _elapsed_text(time.time() - started)
        if not res.ok:
            kind, hint = classify_failure(raw, res.returncode)
            text = f"❌ 执行失败 · {kind} · {elapsed}\n{hint}\n{text}"[:2400]
        else:
            text = f"✅ 执行完成 · {elapsed}\n{text}"
        if log_path:
            text += f"\n完整输出：{log_path}"
        _say(room, agent, text[:3800])
        _log(f"done room={room} agent={agent} ok={res.ok} rc={res.returncode} elapsed={elapsed}")
        try:
            write_task_feed(room, agent, agent_name, task, text, log_path,
                            time.time() - started, ok=res.ok)
        except Exception as _fe:  # noqa: BLE001
            _log(f"feed hook err room={room} agent={agent}: {_fe}")
    except Exception as e:  # noqa: BLE001
        kind, hint = classify_failure(str(e))
        _log(f"error room={room} agent={agent} kind={kind}: {e}\n{traceback.format_exc()[:1200]}")
        try:
            _say(room, agent, f"❌ 执行失败 · {kind}\n{hint}\n（详情见 runtime/executor.log）")
        except Exception:  # noqa: BLE001
            pass
    finally:
        with LOCK:
            RUNNING.discard(key)


def submit(room: str, agent: str, agent_name: str, body: str, sub: str = "") -> tuple[bool, str]:
    """提交一次执行；返回 (accepted, message)。sub 非空表示子 agent 角色。"""
    if os.environ.get("TEAMAI_EXEC_DISABLED") == "1":
        return False, "执行器已被 TEAMAI_EXEC_DISABLED=1 关闭"
    body = (body or "").strip()
    if not body:
        return False, "空指令"
    warm_async()
    key = (room, agent, sub)
    with LOCK:
        if key in RUNNING:
            return False, "这个会话已有任务在跑，等它结束"
        RUNNING.add(key)
    POOL.submit(_run, room, agent, agent_name, body, sub)
    return True, "已交给执行器"


def is_group(room: str) -> bool:
    """群聊：成员 >2，或包含多个 AI。"""
    c = _conn()
    try:
        row = c.execute("select count(*) n, sum(a.kind='ai') ai from room_members m "
                        "join agents a on a.id=m.agent_id where m.room_id=?", (room,)).fetchone()
        return bool(row and (int(row["n"] or 0) > 2 or int(row["ai"] or 0) > 1))
    finally:
        c.close()


@dataclass(frozen=True)
class Target:
    """一次执行目标：父 agent + 可选子角色（sub 为空 = 父本体）。"""
    agent: str
    name: str
    sub: str = ""


def _local_ais(room: str) -> list[tuple[str, str]]:
    """本机（node_id 为空或本机别名）且在本房间的 AI 成员。"""
    c = _conn()
    try:
        from core import nodeinfo
        local = nodeinfo.saved_alias() or ""
        sql = ("SELECT a.id,a.name FROM room_members m JOIN agents a ON a.id=m.agent_id "
               "WHERE m.room_id=? AND a.kind='ai' AND coalesce(a.full_name,'') NOT LIKE '%@center' ")
        args: list = [room]
        if local:
            sql += "AND (a.node_id IS NULL OR a.node_id='' OR a.node_id=?) "
            args.append(local)
        sql += "ORDER BY m.rowid"
        rows = c.execute(sql, args).fetchall()
    finally:
        c.close()
    return [(r["id"], r["name"] or r["id"]) for r in rows]


def resolve(room: str, body: str) -> list[Target]:
    """把群聊 @ 解析成本机执行目标（含子 agent 角色）。

    - DM 只有一个 AI：直接返回父本体；
    - `@bob.dev`：父 bob + 角色 dev（编制里存在才生效）；
    - `@Bob` / 名字模糊匹配：父本体（兼容旧行为）；
    - 远程/未知：不作为本机目标。
    """
    ais = _local_ais(room)
    c2 = _conn()
    try:
        kr = c2.execute("SELECT kind FROM rooms WHERE id=?", (room,)).fetchone()
        room_kind = (kr["kind"] if kr else "") or ""
    finally:
        c2.close()
    if len(ais) == 1 and room_kind == "dm":
        return [Target(ais[0][0], ais[0][1])]
    mentions = [m.lower() for m in re.findall(r"@([\w.\-]{1,40})", body or "")]
    if not mentions:
        return []
    ids = [aid for aid, _ in ais]
    names = {aid: name for aid, name in ais}
    out: list[Target] = []
    seen: set[tuple[str, str]] = set()
    for m in mentions:
        hit = None
        try:
            from core import subagents as _sa
            hit = _sa.resolve_mention(m, ids)
        except Exception:  # noqa: BLE001
            hit = None
        if hit:
            aid, role = hit
            t = Target(aid, names[aid], role)
            if (t.agent, t.sub) not in seen:
                seen.add((t.agent, t.sub))
                out.append(t)
            continue
        for aid, name in ais:
            al = aid.lower()
            if m == al or m in name.lower() or name.lower() in m:
                t = Target(aid, name)
                if (t.agent, t.sub) not in seen:
                    seen.add((t.agent, t.sub))
                    out.append(t)
    return out


def targets(room: str, body: str) -> list[tuple[str, str]]:
    """兼容旧调用：只返回 (agent_id, name)，丢弃子角色。"""
    return [(t.agent, t.name) for t in resolve(room, body)]


def strip_prefix(body: str) -> tuple[str, bool]:
    """显式 /exec、/run 前缀视为执行指令。"""
    m = re.match(r"^\s*/(?:exec|run)\s+(.+)$", body or "", re.S | re.I)
    if m:
        return m.group(1).strip(), True
    return (body or "").strip(), False
