"""署名与贡献（docs/71 §5 · Ⅱ期 · M4）。

- **谁 / 对哪个工件 / 角色 / 依据**：`contributions(project_id, member_id, kind, artifact, role,
  evidence, responsible, created_at)`；`role ∈ author|reproducer|reviewer|data|tool`。
- **依据可回溯**：`evidence` 由 `post:<id>` / `task:<id>` / `audit:<id>` 引用组成；`evidence_status()`
  能把这些引用解析回真实记录（判「每条有依据」）。
- **交付帖自动附贡献表**：`attach_sheet()` 把贡献表（人 + agent + 角色 + 依据）写进交付帖正文（幂等）。
- **信誉并入**：登记一条贡献即写一条 `reputation_events(event_type='contribution:<role>')`。
- **红线**：agent 与人**同等署名**（同表同字段，`kind` 标注来源）；但**责任人必须为真人**
  （`agents.kind='human'`），否则拒绝写入（400）。

本模块不依赖 Flask，可单测；HTTP 层在 `core/server.py`。
"""
from __future__ import annotations

import csv
import io
import json
import os

ROLES = ("author", "reproducer", "reviewer", "data", "tool")
ROLE_LABEL = {"author": "作者", "reproducer": "复现者", "reviewer": "评审者",
              "data": "数据", "tool": "工具"}
# 科学信誉：不同角色的默认计分（并入 reputation_events）
ROLE_POINTS = {"author": 5.0, "reproducer": 3.0, "reviewer": 2.0, "data": 1.5, "tool": 1.0}
REF_KINDS = ("post", "task", "audit")
# 交付帖正文里的贡献表标记（幂等：已含则不重复追加）
SHEET_MARKER = "## 贡献表（人 + agent + 角色 + 依据）"


class ContributionError(Exception):
    """业务错误 → HTTP 状态码（400=校验失败/责任人非真人）。"""

    def __init__(self, msg: str, code: int = 400):
        super().__init__(msg)
        self.msg = msg
        self.code = code


# ----------------------------------------------------------------- 基础查询
def _agent(conn, agent_id: str):
    if not agent_id:
        return None
    return conn.execute(
        "SELECT id, name, full_name, kind FROM agents WHERE id=?", (agent_id,)).fetchone()


def default_human(conn) -> str | None:
    """默认责任人：显式环境变量 > 库中真人（优先 id='human'）。"""
    env = os.environ.get("TEAMAI_RESPONSIBLE_HUMAN")
    if env:
        return env
    row = conn.execute(
        "SELECT id FROM agents WHERE kind='human' ORDER BY (id='human') DESC, id LIMIT 1"
    ).fetchone()
    return row["id"] if row else None


def _display(row) -> str:
    if not row:
        return "-"
    return row["full_name"] or row["name"] or row["id"]


# ----------------------------------------------------------------- 依据解析
def parse_evidence(evidence: str) -> list[tuple[str, str]]:
    """把 'post:p-x; task:t-y; audit:123' 拆成 [(kind, ref)]（也容忍逗号/空白分隔）。"""
    out: list[tuple[str, str]] = []
    for tok in (evidence or "").replace(",", ";").split(";"):
        tok = tok.strip()
        if not tok:
            continue
        if ":" in tok:
            k, v = tok.split(":", 1)
            out.append((k.strip().lower(), v.strip()))
        else:
            out.append(("", tok))
    return out


def _ref_exists(conn, kind: str, ref: str) -> bool:
    if kind == "post":
        return conn.execute("SELECT 1 FROM posts WHERE id=?", (ref,)).fetchone() is not None
    if kind == "task":
        return conn.execute("SELECT 1 FROM tasks WHERE id=?", (ref,)).fetchone() is not None
    if kind == "audit":
        if not str(ref).isdigit():
            return False
        return conn.execute("SELECT 1 FROM audit_log WHERE id=?", (int(ref),)).fetchone() is not None
    return False


def evidence_status(conn, evidence: str) -> dict:
    """校验依据可回溯：每个 `kind:ref` 都能在真实表里找到。"""
    refs = parse_evidence(evidence)
    detail = []
    for k, v in refs:
        ok = _ref_exists(conn, k, v) if k in REF_KINDS else False
        detail.append({"ref": f"{k}:{v}" if k else v, "kind": k, "resolved": bool(ok)})
    return {"ok": bool(refs) and all(d["resolved"] for d in detail), "refs": detail}


# ----------------------------------------------------------------- 写入
def add(conn, member_id: str, role: str, artifact: str, evidence: str, responsible: str,
        *, project_id: str | None = None, post_id: str | None = None,
        task_id: str | None = None, points: float | None = None,
        audit: bool = True, commit: bool = True) -> dict:
    """登记一条署名/贡献。校验：角色合法、依据非空、署名主体存在、**责任人须为真人**。"""
    if role not in ROLES:
        raise ContributionError(f"role 必须为 {ROLES}", 400)
    if not (artifact or "").strip():
        raise ContributionError("artifact 必填：对哪个工件", 400)
    if not (evidence or "").strip():
        raise ContributionError("evidence 必填：需帖/任务/审计 id（可回溯）", 400)
    member = _agent(conn, member_id)
    if not member:
        raise ContributionError(f"署名主体不存在：{member_id}", 400)
    resp = _agent(conn, responsible)
    if not resp or resp["kind"] != "human":
        raise ContributionError("责任人须为真人（agents.kind='human'）", 400)

    cur = conn.execute(
        "INSERT INTO contributions(project_id, post_id, task_id, member_id, kind, role,"
        " artifact, evidence, responsible) VALUES (?,?,?,?,?,?,?,?,?)",
        (project_id, post_id, task_id, member_id, member["kind"], role, artifact, evidence,
         responsible))
    cid = int(cur.lastrowid or 0)
    pts = float(points) if points is not None else ROLE_POINTS[role]
    # 信誉并入：科学信誉累积到 reputation_events（既有人格/署名不分表）
    conn.execute(
        "INSERT INTO reputation_events(agent_id, task_id, event_type, points, metadata)"
        " VALUES (?,?,?,?,?)",
        (member_id, task_id, f"contribution:{role}", pts,
         json.dumps({"contribution_id": cid, "post_id": post_id, "artifact": artifact,
                     "evidence": evidence, "responsible": responsible}, ensure_ascii=False)))
    if audit:
        conn.execute(
            "INSERT INTO audit_log(actor, action, target, detail) VALUES (?,?,?,?)",
            (responsible, "contribution.add", post_id or task_id or f"c-{cid}",
             json.dumps({"contribution_id": cid, "member_id": member_id,
                         "role": role, "evidence": evidence}, ensure_ascii=False)))
    if commit:
        conn.commit()
    return {"id": cid, "member_id": member_id, "kind": member["kind"], "role": role,
            "points": pts, "responsible": responsible}


# ----------------------------------------------------------------- 读取
def _rows(conn, where: str, args: list) -> list[dict]:
    sql = ("SELECT c.*, ma.full_name AS member_name, ma.name AS member_name_short,"
           " ra.full_name AS responsible_name FROM contributions c"
           " LEFT JOIN agents ma ON ma.id=c.member_id"
           " LEFT JOIN agents ra ON ra.id=c.responsible"
           f" WHERE {where} ORDER BY c.id")
    out: list[dict] = []
    for r in conn.execute(sql, args).fetchall():
        d = dict(r)
        d["role_label"] = ROLE_LABEL.get(d["role"], d["role"])
        d["member_display"] = d.get("member_name") or d.get("member_name_short") or d["member_id"]
        d["responsible_display"] = d.get("responsible_name") or d["responsible"]
        out.append(d)
    return out


def list_(conn, *, post_id=None, task_id=None, project_id=None, member_id=None) -> list[dict]:
    clauses, args = [], []
    for col, val in (("post_id", post_id), ("task_id", task_id),
                     ("project_id", project_id), ("member_id", member_id)):
        if val:
            clauses.append(f"c.{col}=?")
            args.append(val)
    where = " AND ".join(clauses) if clauses else "1=1"
    return _rows(conn, where, args)


def rows_for_post(conn, post_id: str) -> list[dict]:
    return list_(conn, post_id=post_id)


# ----------------------------------------------------------------- 导出
_COLUMNS = ["署名主体", "标识", "类型", "角色", "工件", "依据", "责任人", "时间"]


def export_rows(conn, *, post_id=None, task_id=None, project_id=None) -> list[list[str]]:
    """导出为二维表（首行表头），供 csv/markdown 复用。"""
    out = [_COLUMNS[:]]
    for r in list_(conn, post_id=post_id, task_id=task_id, project_id=project_id):
        out.append([r["member_display"], r["member_id"], r["kind"], r["role_label"],
                    r["artifact"], r["evidence"], r["responsible_display"],
                    r["created_at"] or ""])
    return out


def to_csv(conn, **kw) -> str:
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    for row in export_rows(conn, **kw):
        w.writerow(row)
    return buf.getvalue()


def to_markdown(conn, *, title=None, post_id=None, task_id=None, project_id=None) -> str:
    rows = export_rows(conn, post_id=post_id, task_id=task_id, project_id=project_id)
    head, body = rows[0], rows[1:]
    lines: list[str] = []
    if title:
        lines += [f"### 贡献表 · {title}", ""]
    lines.append("| " + " | ".join(head) + " |")
    lines.append("|" + "|".join(["---"] * len(head)) + "|")
    for r in body:
        lines.append("| " + " | ".join(str(c) for c in r) + " |")
    if not body:
        lines.append("| （暂无署名/贡献记录） |" + "|".join([""] * (len(head) - 1)) + "|")
    return "\n".join(lines)


# ----------------------------------------------------------------- 自动推导 + 附表
def auto_from_task(conn, task_id: str, post_id: str | None, responsible: str,
                   *, commit: bool = True) -> list[dict]:
    """从任务参与者推导贡献：author=交付者，reviewer=验收者（取评审事件/任务创建者）。"""
    task = conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
    if not task:
        return []
    post = conn.execute("SELECT * FROM posts WHERE id=?", (post_id,)).fetchone() if post_id else None
    author = (post["author_id"] if post else None) or task["assigned_to"]
    made: list[dict] = []
    dup = lambda m, r: conn.execute(  # noqa: E731
        "SELECT 1 FROM contributions WHERE post_id IS ? AND task_id=? AND member_id=? AND role=?",
        (post_id, task_id, m, r)).fetchone()

    if author and not dup(author, "author"):
        ev = f"task:{task_id}" + (f"; post:{post_id}" if post_id else "")
        made.append(add(conn, author, "author", artifact=(f"post:{post_id}" if post_id
                                                          else f"task:{task_id}"),
                        evidence=ev, responsible=responsible, post_id=post_id,
                        task_id=task_id, commit=False))
    # 验收者：优先取最后一笔 review 事件的执行者，其次任务创建者（定判据者）
    rev = conn.execute(
        "SELECT agent_id FROM task_events WHERE task_id=? AND action LIKE 'review%'"
        " ORDER BY id DESC LIMIT 1", (task_id,)).fetchone()
    reviewer = rev["agent_id"] if rev else task["created_by"]
    if reviewer and reviewer != author and not dup(reviewer, "reviewer"):
        aref = conn.execute(
            "SELECT id FROM audit_log WHERE action='task_review' AND target=? ORDER BY id DESC LIMIT 1",
            (task_id,)).fetchone()
        ev = f"task:{task_id}" + (f"; audit:{aref['id']}" if aref else "")
        made.append(add(conn, reviewer, "reviewer", artifact=f"task:{task_id}", evidence=ev,
                        responsible=responsible, post_id=post_id, task_id=task_id, commit=False))
    if commit and made:
        conn.commit()
    return made


def attach_sheet(conn, post_id: str, responsible: str | None = None, *,
                 auto: bool = True, commit: bool = True) -> str | None:
    """交付帖（type='artifact'）自动附贡献表（幂等）。返回写入的贡献表 markdown。"""
    post = conn.execute("SELECT * FROM posts WHERE id=?", (post_id,)).fetchone()
    if not post:
        raise ContributionError("post not found", 404)
    if post["type"] != "artifact":
        return None
    responsible = responsible or default_human(conn)
    if not responsible:
        return None
    rows = rows_for_post(conn, post_id)
    task_id = post["task_id"]
    if auto and not rows and task_id:
        auto_from_task(conn, task_id, post_id, responsible, commit=False)
        rows = rows_for_post(conn, post_id)
    body = post["body"] or ""
    if SHEET_MARKER in body or not rows:
        return None
    title = post["title"] or post_id
    sheet = to_markdown(conn, title=title, post_id=post_id)
    new_body = body.rstrip() + "\n\n" + SHEET_MARKER + "\n\n" + sheet + "\n"
    conn.execute("UPDATE posts SET body=?, updated_at=datetime('now','localtime') WHERE id=?",
                 (new_body, post_id))
    if commit:
        conn.commit()
    return sheet
