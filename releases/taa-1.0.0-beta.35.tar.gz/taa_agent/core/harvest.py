"""事实收割 harvest —— 从工作群增量消息中提炼「可说的事实」写入 memory。

设计依据（《逻辑哲学论》→ 工程映射，见 reading/tractatus/ENGINEERING_MAP.md）：
- 1.1 世界是事实的总和，而非物的总和 → 记忆存「事实」(命题)，不存叙事流。
- 4.2 命题的意义 = 其真值可能性 → 每条事实带 verdict（成功/失败/真/假/未决）与证据。
- 4.1212 说 / 显示 → 能写成判据的进 facts；风格/价值（不可说）不入事实。
- 6.54 梯子 → 事实可溯源到消息区间 msg_from..msg_to，可 superseded/discarded。

闭环：读取房间增量 → LLM 辅助判断 → 规则闸门（不盲信 LLM）→ 写 facts + 情景/语义/热记忆。
自检友好：`harvest(..., llm=...)` 可注入假 LLM，全程不触网/不依赖真实模型。
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

from . import memory as mem

ROOT = Path(__file__).resolve().parent.parent

VERDICTS = {"success", "failure", "true", "false", "open", "decision", "lesson"}
KINDS = {"fact", "decision", "lesson", "blocker", "artifact"}
# 事实抽取用便宜快的模型即可；V2 当前暴露 deepseek/deepseek-flash。可用 --model / 环境变量覆盖。
DEFAULT_MODEL = os.environ.get("TEAMAI_HARVEST_MODEL", "deepseek/deepseek-flash")
DEFAULT_MIN_CONFIDENCE = 0.55

# 允许的「不可说」护栏：明显的主观/客套/情绪句式，不进事实库
_OPINION_MARKERS = ("我觉得", "我认为", "感觉", "也许", "可能吧", "哈哈", "谢谢", "客套")


# ------------------------------------------------------------------ transcript
def _fmt_messages(messages: list[dict], body_cap: int = 500) -> str:
    lines = []
    for m in messages:
        body = (m.get("body") or "").strip().replace("\n", " ")
        if not body or m.get("kind") in ("skip", "system"):
            continue
        author = m.get("author") or m.get("agent_id") or "?"
        lines.append(f"[{m.get('id')}] {author}({m.get('kind')}): {body[:body_cap]}")
    return "\n".join(lines)


def _persona_note(agent: str) -> str:
    """把「谁在收割」写进 prompt：同一条群聊，不同身体/角色看到不同的事实与显著度。

    这正是「不同记忆 → 不同人格」的入口：事实层按 agent 自己的关注点取舍。
    """
    try:
        from . import persona as P
        p = P.load_persona(agent)

        def _num(v):
            if isinstance(v, dict):
                v = v.get("value")
            try:
                return float(v)
            except (TypeError, ValueError):
                return 0.0

        # values 可能是扁平 float，也可能是 {value,min,max} 结构（docs/05）
        vals = p.get("values") or {}
        top = sorted(vals.items(), key=lambda kv: -_num(kv[1]))[:3] if isinstance(vals, dict) else []
        ident = p.get("identity") or {}
        return (
            f"\n【你是谁】{p.get('name', agent)}（{p.get('role', '')}）。"
            f"格言：{ident.get('motto', '')}。关注：{'、'.join((p.get('interests') or [])[:5])}。"
            f"高权重：{'、'.join(f'{k}{_num(v):.2f}' for k, v in top)}。\n"
            "请以**你自己的身份与职责**判断哪些是「对你重要的事实」，"
            "salience 反映它对你这具身体/这个角色的价值。\n"
        )
    except Exception:
        return ""


def build_prompt(agent: str, room: dict, messages: list[dict]) -> str:
    topic = (room or {}).get("topic") or room.get("id") if isinstance(room, dict) else str(room)
    rid = room.get("id") if isinstance(room, dict) else str(room)
    return (
        "你是团队的「事实收割器」。世界是事实的总和，不是物的总和（维特根斯坦 TLP 1.1）。\n"
        f"{_persona_note(agent)}"
        f"群聊《{topic}》（{rid}）的新增发言如下；请提炼**可说的事实**交给记忆库。\n\n"
        "规则：\n"
        "1. 只收**可说**的命题：能指明真假/成败/是否的陈述。风格、态度、价值判断、寒暄（不可说）一律丢弃。\n"
        "2. 每条事实必须带 verdict，并给出证据（引用消息编号，如 [12]，或命令/链接）。\n"
        "3. 成功要收，**失败也要收**——失败同样是事实。\n"
        "4. 宁少勿滥：没有证据或只是猜测的，不要收。\n"
        "verdict 取值：success(做到) | failure(没做到/失败) | true(验证为真) | false(被证伪) | "
        "open(未决/待验证) | decision(已拍板的决定) | lesson(可复用教训)。\n"
        "kind：fact | decision | lesson | blocker | artifact。\n\n"
        "----- 新增发言 -----\n"
        f"{_fmt_messages(messages)}\n"
        "-------------------\n\n"
        "只输出一个 JSON（不要多余文字）：\n"
        '{"facts":[{"statement":"一句话事实","verdict":"success|failure|true|false|open|decision|lesson",'
        '"kind":"fact","evidence":"引用的证据[12]","speaker":"谁说的","confidence":0.8,"salience":0.6,'
        '"msg_ids":[12]}]}\n'
        "若没有可说的事实，输出 {\"facts\":[]}。"
    )


# ------------------------------------------------------------------ parse
def extract_json(text: str) -> dict | None:
    if not text:
        return None
    s = text.strip()
    fence = re.search(r"```(?:json)?\s*(.*?)```", s, re.S)
    if fence:
        s = fence.group(1).strip()
    i, j = s.find("{"), s.rfind("}")
    if i < 0 or j <= i:
        return None
    try:
        d = json.loads(s[i:j + 1], strict=False)
        return d if isinstance(d, dict) else None
    except Exception:
        return None


def _norm_verdict(v) -> str | None:
    if not isinstance(v, str):
        return None
    v = v.strip().lower()
    alias = {"成功": "success", "失败": "failure", "真": "true", "假": "false",
             "未决": "open", "决定": "decision", "教训": "lesson", "ok": "success",
             "done": "success", "failed": "failure", "blocker": "failure"}
    v = alias.get(v, v)
    return v if v in VERDICTS else None


def _msg_ids(evidence: str, msg_ids, lo: int, hi: int) -> tuple[int | None, int | None]:
    ids: list[int] = []
    if isinstance(msg_ids, list):
        for x in msg_ids:
            try:
                ids.append(int(x))
            except (TypeError, ValueError):
                pass
    for x in re.findall(r"\[(\d+)\]", evidence or ""):
        ids.append(int(x))
    ids = [x for x in ids if lo <= x <= hi]
    if not ids:
        return None, None
    return min(ids), max(ids)


# ------------------------------------------------------------------ gate（规则闸门，不盲信 LLM）
def gate(raw_facts, lo: int, hi: int, min_confidence: float = DEFAULT_MIN_CONFIDENCE):
    """把 LLM 给的原始条目过滤成「可说」的事实。返回 (accepted, rejected)。"""
    accepted, rejected, seen = [], [], set()
    if not isinstance(raw_facts, list):
        return accepted, rejected

    for r in raw_facts:
        if not isinstance(r, dict):
            continue
        statement = (r.get("statement") or r.get("text") or "").strip()
        verdict = _norm_verdict(r.get("verdict"))
        kind = (r.get("kind") or "fact").strip().lower()
        kind = kind if kind in KINDS else "fact"
        evidence = (r.get("evidence") or "").strip()
        try:
            conf = float(r.get("confidence", 0.6))
        except (TypeError, ValueError):
            conf = 0.6
        conf = max(0.0, min(1.0, conf))
        try:
            sal = float(r.get("salience", 0.5))
        except (TypeError, ValueError):
            sal = 0.5
        sal = max(0.0, min(1.0, sal))

        why = None
        if not (4 <= len(statement) <= 300):
            why = "statement 长度不合规"
        elif verdict is None:
            why = "verdict 非法/缺失"
        elif verdict != "open" and not evidence:
            why = "缺证据（不可说）"
        elif any(m in statement for m in _OPINION_MARKERS) and verdict not in ("open", "decision", "lesson"):
            why = "主观措辞，不可说"
        elif conf < min_confidence:
            why = f"置信度 {conf:.2f} < {min_confidence}"
        else:
            fp = mem.fact_fingerprint(statement)
            if fp in seen:
                why = "批内重复"
            else:
                seen.add(fp)

        if why:
            rejected.append({"statement": statement, "verdict": verdict, "reason": why})
            continue

        mf, mt = _msg_ids(evidence, r.get("msg_ids"), lo, hi)
        accepted.append({
            "statement": statement, "verdict": verdict, "kind": kind, "evidence": evidence,
            "speaker": (r.get("speaker") or "").strip() or None,
            "confidence": conf, "salience": sal, "msg_from": mf, "msg_to": mt,
        })
    return accepted, rejected


# ------------------------------------------------------------------ apply（写记忆）
def apply_facts(agent: str, room_id: str, accepted: list[dict], *, lo: int, hi: int,
                source: str | None = None, dry_run: bool = False) -> dict:
    wrote = {"facts": 0, "episodic": 0, "semantic": 0, "working": 0, "dup": 0}
    if dry_run:
        return {"new": len(accepted), "wrote": wrote, "dry_run": True}

    for f in accepted:
        fid = mem.add_fact(
            agent, f["statement"], verdict=f["verdict"], kind=f["kind"], evidence=f["evidence"],
            source=source or f"room:{room_id}", room_id=room_id,
            msg_from=f.get("msg_from") or lo, msg_to=f.get("msg_to") or hi,
            speaker=f.get("speaker"), confidence=f["confidence"], salience=f["salience"])
        if fid is None:
            wrote["dup"] += 1
            continue
        wrote["facts"] += 1

        # 高显著 / 成败 → 情景记忆（发生了什么）
        if f["salience"] >= 0.7 or f["verdict"] in ("success", "failure"):
            mem.add_episodic(agent, f"[{f['verdict']}] {f['statement']}", kind="fact",
                             refs={"room_id": room_id, "statement": f["statement"],
                                   "evidence": f["evidence"]},
                             salience=f["salience"])
            wrote["episodic"] += 1
        # 决定 / 教训 → 语义记忆（沉淀为知识）
        if f["verdict"] in ("decision", "lesson", "true"):
            mem.remember_semantic(
                agent, f"fact:{room_id}:{mem.fact_fingerprint(f['statement'])[:8]}",
                f["statement"], confidence=f["confidence"], source=source or f"room:{room_id}")
            wrote["semantic"] += 1
        # 未决 → 热记忆（待办/待验证）
        if f["verdict"] == "open":
            mem.add_working(agent, "open_question", f["statement"], priority=f["confidence"])
            wrote["working"] += 1

    mem.set_cursor(agent, room_id, hi)
    return {"new": len(accepted), "wrote": wrote, "dry_run": False}


# ------------------------------------------------------------------ orchestrator
def harvest(agent: str, room_id: str, messages: list[dict], *, room: dict | None = None,
            llm=None, model: str = DEFAULT_MODEL, min_confidence: float = DEFAULT_MIN_CONFIDENCE,
            dry_run: bool = False, cursor: int | None = None, max_msgs: int = 60) -> dict:
    """读取增量消息 → LLM 判事实 → 规则闸门 → 写记忆。返回汇总。

    每批最多处理 max_msgs 条（从最旧开始），游标推进到本批末尾；剩余下次再收。
    """
    all_msgs = [m for m in messages if m.get("id") is not None]
    if cursor is None:
        cursor = mem.get_cursor(agent, room_id)
    pending = sorted((m for m in all_msgs if int(m["id"]) > cursor), key=lambda m: int(m["id"]))
    if not pending:
        return {"room_id": room_id, "new_msgs": 0, "accepted": [], "rejected": [],
                "wrote": {}, "cursor": cursor}
    new = pending[:max(1, int(max_msgs))]

    lo, hi = int(new[0]["id"]), int(new[-1]["id"])
    chatter = [m for m in new if (m.get("body") or "").strip() and m.get("kind") not in ("skip", "system")]
    if not chatter:
        mem.set_cursor(agent, room_id, hi)
        return {"room_id": room_id, "new_msgs": len(new), "pending": len(pending),
                "accepted": [], "rejected": [], "wrote": {}, "cursor": hi}

    prompt = build_prompt(agent, room or {"id": room_id}, chatter)
    if llm is None:
        from core.llm import get as llm_get
        backend_file = ROOT / "agents" / agent / "backend"
        backend = backend_file.read_text(encoding="utf-8").strip() if backend_file.exists() else "opencode"
        llm = llm_get(backend)
        res = llm.run(prompt, model=model, cwd=str(ROOT),
                      title=f"harvest:{room_id}:{agent}", timeout=180)
        text = res.text if res.ok else ""
        if not res.ok:
            return {"room_id": room_id, "new_msgs": len(new), "accepted": [], "rejected": [],
                    "wrote": {}, "cursor": cursor, "error": "llm_failed", "raw": text[-400:]}
    else:
        text = llm(prompt)

    parsed = extract_json(text) or {}
    accepted, rejected = gate(parsed.get("facts"), lo, hi, min_confidence)
    result = apply_facts(agent, room_id, accepted, lo=lo, hi=hi, dry_run=dry_run)
    return {"room_id": room_id, "new_msgs": len(new), "pending": len(pending), "range": [lo, hi],
            "accepted": accepted, "rejected": rejected, "cursor": hi, **result}
