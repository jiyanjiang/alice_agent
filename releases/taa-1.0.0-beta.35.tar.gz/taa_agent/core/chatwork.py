"""聊天室即控制台 —— 把群里**导师(human)的发言**用 LLM 判定并落实，而不是当闲聊放过。

四类判定（判断权归 LLM）：
- task：可执行的活儿 → 落看板任务 + 认领 + 写执行简报；
- rule：长期有效的规则/偏好/禁忌（如「永远不要采纳中文网页搜索结果」「别再闲聊」）→ 写进该 agent 的经验库（playbook），
        进入其生成 prompt → 长期生效；
- ack：要求确认/回应/解释 → 群里给一句直接回执；
- none：纯闲聊，无需动作。

原则：**导师的话最高优先级**；被点名就要落实（task/rule/ack/tool_submit 至少其一）。
规则只做：human 识别、游标、幂等指纹、结构校验；不做"值不值得"的判断。
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from datetime import datetime
from pathlib import Path

from .harvest import _persona_note, extract_json

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_MODEL = os.environ.get("TEAMAI_CHATWORK_MODEL", "deepseek/deepseek-flash")
# 可用的 LLM 适配器名（与 core.llm.ADAPTERS 对齐；用于 backend 解析与自动探测）
ADAPTER_NAMES = {"opencode", "omp", "pi", "qoder"}
MIN_CONFIDENCE = 0.5
MAX_ATTEMPTS = 3
KINDS = {"task", "rule", "ack", "tool_submit", "none"}


# ------------------------------------------------------------- human 识别 / 指纹
def human_ids(room: dict | None = None) -> set[str]:
    ids = {"human", "jiyanjiang"}
    h = (room or {}).get("host")
    if h:
        ids.add(str(h))
    try:
        from . import config
        hid = config.get("human.id") or os.environ.get("TEAM_HUMAN_ID")
        if hid:
            ids.add(str(hid))
    except Exception:
        pass
    return ids


def is_human_msg(m: dict, room: dict | None = None) -> bool:
    ident = str(m.get("agent_id") or m.get("author") or "").split("@")[0].strip()
    return ident in human_ids(room)


_FW = str.maketrans(
    "０１２３４５６７８９ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ",
    "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz")


def fingerprint(title: str) -> str:
    t = (title or "").translate(_FW)
    t = re.sub(r"[\s，。、；：！？,.;:!?\"'“”‘’()（）\[\]【】\-_/]", "", t).lower()
    return hashlib.sha1(t.encode("utf-8")).hexdigest()[:16]


_MENTION = re.compile(r"@\s*([A-Za-z][\w\-]*)")
_BROADCAST = {"all", "everyone", "here"}


def _mentions(agent: str) -> set[str]:
    """@ 可用的本 agent 别名：id + persona name。

    v0.5 的 agent id 是 `agt_...`，显示名是 `alice`；群聊里人只会 @alice。
    只做结构识别，不判断消息值不值得处理。
    """
    out = {str(agent or "").lower()}
    try:
        import yaml
        p = ROOT / "agents" / str(agent) / "persona.yaml"
        if p.exists():
            d = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            for n in (d.get("name"), (d.get("identity") or {}).get("name")):
                if n:
                    out.add(str(n).strip().lower())
    except Exception:
        pass
    # v0.5 bridge agents may not have a local persona.yaml yet; use the
    # canonical core DB name (e.g. agt_... -> alice).
    try:
        from . import db
        conn = db.connect()
        try:
            row = conn.execute("SELECT name FROM agents WHERE id=?", (str(agent),)).fetchone()
            if row and row["name"]:
                out.add(str(row["name"]).strip().lower())
        finally:
            conn.close()
    except Exception:
        pass
    return {x for x in out if x}


def mentions_me(body: str, agent: str) -> bool:
    """结构护栏（不判'值不值得'，只做结构）：明确点名了别的 agent 且不含本 agent → False。

    无点名（可能是对全体）/ 点名含本 agent / 含「@所有人」类词 → True。
    """
    body = body or ""
    if any(w in body for w in ("@所有人", "@全体", "@大家", "@各位", "@全员")):
        return True
    ms = [m.lower() for m in _MENTION.findall(body)]
    if not ms:
        return True
    aliases = _mentions(agent)
    for m in ms:
        if m in _BROADCAST:
            return True
        if any(m == a or a.startswith(m) or m.startswith(a) for a in aliases):
            return True
    return False


def explicit_me(body: str, agent: str) -> bool:
    """真人**显式 @ 点名**本 agent（排除 @所有人 这类广播）。用于节流时保证"被点名必答"。"""
    b = body or ""
    if any(w in b for w in ("@所有人", "@全体", "@大家", "@各位", "@全员")):
        return False
    return bool(_MENTION.search(b)) and mentions_me(b, agent)


# ------------------------------------------------------------- prompt
def build_prompt(agent: str, room: dict, messages: list[dict]) -> str:
    topic = (room or {}).get("topic") or (room or {}).get("id")
    rid = (room or {}).get("id")
    lines = []
    for m in messages:
        body = (m.get("body") or "").strip().replace("\n", " ")
        att = (m.get("attachment") or "").strip()          # ★ 2026-10-14：附件要进提示，否则模型不知道"这条有图"
        tag = f"（附件：{att}）" if att else ""
        lines.append(f"[{m.get('id')}] {m.get('agent_id') or m.get('author')}: {body[:400]}{tag}")
    return (
        "你是「导师指令识别器」。群里**真人(导师/human)**的发言可能有不同作用，请判断**属于哪一类**：\n"
        "- task：可执行的**活儿**（要产出东西/做事）→ 生成任务字段；\n"
        "- rule：一条**长期有效的规则/偏好/禁忌**（如「永远不要采纳中文网页搜索结果」「别再闲聊，要干活」「只用硬源」）"
        "→ 抽成一句可执行规则（会被写进你的长期经验库、以后一直遵守）；\n"
        "- ack：要求**确认/回应/解释**（如「为什么不给我看」）→ 给一句直接回执；\n"
        "- tool_submit：要求把本机一个工具目录提交到中心（如「把这个工具提交到工具库」）→ 给出本机目录 path；\n"
        "- none：纯闲聊，无需动作。\n"
        "**原则：导师的话最高优先级。** 被点名（或明确对全体的要求）就要落实（task/rule/ack/tool_submit 至少其一），不要当闲聊放过。\n"
        "**点名规则**：若真人点名了具体 agent（如 @Carol），则**只有被点名的那个** assigned_to_me=true，其余一律 false；\n"
        "只有明确对全体（@所有人 / 未点名）时才都 true。**别人的活儿不要抢。**\n"
        f"{_persona_note(agent)}"
        "输出一个 JSON（不要多余文字）：\n"
        '{"kind":"task|rule|ack|tool_submit|none","assigned_to_me":true,"confidence":0.0,'
        '"rule":"一句规则(kind=rule)","reply":"一句回执(rule/ack)","needs_plan":true,'
        '"tool":{"path":"本机工具目录(kind=tool_submit)"},'
        '"task":{"title":"","description":"","acceptance_criteria":"","required_skills":[],"tags":[],"priority":1}}\n'
        f"群聊《{topic}》（{rid}）的真人新发言：\n" + "\n".join(lines) + "\n"
    )


# ------------------------------------------------------------- gate（仅结构校验）
def gate(d, *, min_confidence: float = MIN_CONFIDENCE) -> dict:
    if not isinstance(d, dict):
        return {"kind": "none", "confidence": 0.0}
    kind = str(d.get("kind") or ("task" if d.get("is_task") else "none")).lower()
    if kind not in KINDS:
        kind = "none"
    try:
        conf = float(d.get("confidence", 0) or 0)
    except (TypeError, ValueError):
        conf = 0.0
    if kind == "none" or conf < min_confidence:
        return {"kind": "none", "confidence": conf}
    # 点名才动：明确 assigned_to_me=false（这条不是给本 agent 的活儿）→ 不动
    if d.get("assigned_to_me") is False:
        return {"kind": "none", "confidence": conf}
    if kind == "tool_submit":
        tool = d.get("tool") or {}
        path = str(tool.get("path") or "").strip()
        if not path:
            return {"kind": "none", "confidence": conf}
        return {"kind": "tool_submit", "confidence": conf,
                "tool": {"path": path[:500]},
                "reply": str(d.get("reply") or "").strip()}
    if kind == "task":
        t = d.get("task") or {}
        title = str(t.get("title") or "").strip()
        desc = str(t.get("description") or "").strip()
        ac = str(t.get("acceptance_criteria") or "").strip()
        if not (title and desc and ac):
            return {"kind": "none", "confidence": conf}
        try:
            prio = int(t.get("priority") or 1)
        except (TypeError, ValueError):
            prio = 1
        return {"kind": "task", "confidence": conf,
                "task": {"title": title[:80], "description": desc[:1000], "acceptance_criteria": ac[:600],
                         "required_skills": [str(x) for x in (t.get("required_skills") or []) if str(x).strip()][:6],
                         "tags": [str(x) for x in (t.get("tags") or []) if str(x).strip()][:8],
                         "priority": max(1, min(3, prio))},
                "needs_plan": bool(d.get("needs_plan", True)),
                "reply": str(d.get("reply") or "").strip()}
    if kind == "rule":
        rule = str(d.get("rule") or "").strip()
        if not rule:
            return {"kind": "none", "confidence": conf}
        return {"kind": "rule", "confidence": conf, "rule": rule[:300],
                "reply": str(d.get("reply") or "").strip()}
    # ack
    return {"kind": "ack", "confidence": conf, "reply": str(d.get("reply") or "").strip() or "收到。"}


# ------------------------------------------------------------- classify（LLM）
def resolve_backend(agent: str) -> str:
    """聊天室**指令管道**该用哪个 LLM 后端：`agents/<id>/backend` > env `TEAM_AGENT_BACKEND` > 自动探测。

    ★ 2026-10-14 修（Darwin 在 Win16G 报出的**发行版缺陷**）：
    原实现 `classify(..., backend="opencode")` 把后端**硬编码成 opencode**，而 Win16G 装的是 `qoderclicn`、
    没有 `opencode` CLI → `base.run` 抛 FileNotFoundError → 每条人类消息 `llm_failed` 重试 3 次后**放弃**
    （游标前移＝死信）→ **人类在群里问它话，它永远不回应**。
    讽刺的是同一台机器的**闲聊路径**读了 `agents/<id>/backend`（chatroom_agent.py:483），唯独指令管道漏传。
    本函数把三处口径统一，且**自动探测**可避免"装了别的 CLI 就哑掉"。
    """
    p = ROOT / "agents" / agent / "backend"
    try:
        if p.exists():
            b = (p.read_text(encoding="utf-8").strip() or "").lower()
            if b in ADAPTER_NAMES:
                return b
    except OSError:
        pass
    env = (os.environ.get("TEAM_AGENT_BACKEND") or "").strip().lower()
    if env in ADAPTER_NAMES:
        return env
    try:
        from .llm import available as _avail
        av = _avail()
        for name in ("opencode", "qoder", "omp", "pi"):
            if av.get(name):
                return name
    except Exception:  # noqa: BLE001
        pass
    return "opencode"


def classify(agent: str, room: dict, messages: list[dict], *, llm=None,
             model: str = DEFAULT_MODEL, backend: str | None = None,
             files: list[str] | None = None) -> dict:
    """判断真人消息的意图（task/rule/ack/none）。

    ★ 2026-10-14（读图）：新增 `files`——把**消息里的图片文件**交给模型，
    否则"在群里发一张图问它"时，它只看得到文字（`LLMAdapter.run(files=…)` → opencode `-f`；
    我们的默认模型 ds flash 是**视觉模型**）。调用点负责把附件 URL 解析成本机文件路径。
    """
    prompt = build_prompt(agent, room, messages)
    if files:
        prompt += ("\n\n**注意**：本次附带图片文件（见随附文件），请**先看图再判断**；"
                   "若真人问的是图里的内容，按其内容回应，不要假装没看到图。\n")
    if llm is None:
        from core.llm import get as llm_get
        llm = llm_get(backend or resolve_backend(agent))
        res = llm.run(prompt, model=model, cwd=str(ROOT), title=f"chatwork:{agent}",
                      timeout=180, files=files)
        text = res.text if res.ok else ""
        if not res.ok:
            return {"ok": False, "error": "llm_failed", "raw": text[-300:]}
    else:
        text = llm(prompt)
    d = extract_json(text)
    if d is None:
        return {"ok": False, "error": "bad_json", "raw": (text or "")[-300:]}
    return {"ok": True, **gate(d), "raw": d}


# ------------------------------------------------------------- 本地游标（幂等/补捞）
def cursor_path(agent: str, room_id: str) -> Path:
    d = ROOT / "agents" / agent
    d.mkdir(parents=True, exist_ok=True)
    return d / f".chatwork-{room_id}.json"


def load_cursor(agent: str, room_id: str) -> dict:
    try:
        return json.loads(cursor_path(agent, room_id).read_text(encoding="utf-8"))
    except Exception:
        return {"last": 0, "titles": [], "attempts": {}}


def save_cursor(agent: str, room_id: str, cur: dict) -> None:
    try:
        cursor_path(agent, room_id).write_text(
            json.dumps({"last": int(cur.get("last", 0)),
                        "titles": list(cur.get("titles") or [])[-50:],
                        "attempts": cur.get("attempts") or {}}, ensure_ascii=False),
            encoding="utf-8")
    except Exception as e:  # noqa: BLE001
        print("[chatwork] save cursor err:", e)


# ------------------------------------------------------------- 交给执行器（写 inbox 简报）
def write_inbox_brief(agent: str, task_id: str, *, title: str, description: str,
                      acceptance_criteria: str, tags=None, priority: int = 1,
                      channel: str = "#projects/team-ai") -> dict:
    inbox = ROOT / "agents" / agent / "inbox"
    inbox.mkdir(parents=True, exist_ok=True)
    brief = {
        "agent": agent, "task_id": task_id, "title": title,
        "description": description, "acceptance_criteria": acceptance_criteria,
        "tags": list(tags or []), "priority": priority, "channel": channel,
        "claimed_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source": "chatwork",
        "howto": "用 teamai CLI 发帖并 start+submit；详见 dispatcher 生成的 prompt",
    }
    (inbox / f"{task_id}.json").write_text(
        json.dumps(brief, ensure_ascii=False, indent=2), encoding="utf-8")
    return brief
