"""Gossip（S4.2）：局域网 UDP 发现 + HTTP 反熵互拉事件。

- 发现：UDP 广播 {node_id, addr}（默认静默，不弹 UI）。
- 反熵：定期 `GET http://<peer>/v1/events?since=<lamport>` 互拉增量，merge 去重。
- 无选主：只交换事件，状态由各方本地 fold。
"""
from __future__ import annotations

import json
import socket
import threading
import time
import urllib.request

DISCOVER_PORT = int(__import__("os").environ.get("TEAMAI_GOSSIP_PORT", "45999"))


class Gossip:
    def __init__(self, node_id: str, http_addr: str, log, port: int = DISCOVER_PORT,
                 interval: float = 5.0, token: str | None = None, federation_merge=None,
                 seed: dict | None = None):
        self.node_id = node_id
        self.http_addr = http_addr          # 如 192.168.1.5:6080
        self.log = log
        self.port = port
        self.interval = interval
        self.token = token
        self.federation_merge = federation_merge
        self._fed_seq = 0
        self._peers: dict[str, str] = dict(seed or {})   # 手动种子（同机/跨网段联调）
        self._stop = False

    # ---------------- sockets ----------------
    def _sock(self) -> socket.socket:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        return s

    def start(self) -> None:
        threading.Thread(target=self._listen, daemon=True).start()
        threading.Thread(target=self._broadcast, daemon=True).start()
        threading.Thread(target=self._sync, daemon=True).start()

    def stop(self) -> None:
        self._stop = True

    def peers(self) -> dict:
        return dict(self._peers)

    # ---------------- loops ----------------
    def _broadcast(self) -> None:
        s = self._sock()
        msg = json.dumps({"node_id": self.node_id, "addr": self.http_addr}).encode()
        while not self._stop:
            try:
                s.sendto(msg, ("255.255.255.255", self.port))
            except Exception:
                pass
            time.sleep(self.interval)

    def _listen(self) -> None:
        s = self._sock()
        try:
            s.bind(("", self.port))
        except Exception:
            return
        while not self._stop:
            try:
                data, _ = s.recvfrom(4096)
                d = json.loads(data.decode("utf-8"))
                if d.get("node_id") and d["node_id"] != self.node_id and d.get("addr"):
                    self._peers[d["node_id"]] = d["addr"]
            except Exception:
                pass

    def _headers(self) -> dict:
        return {"X-Enroll-Token": self.token} if self.token else {}

    def _sync(self) -> None:
        while not self._stop:
            for addr in list(self._peers.values()):
                try:
                    u = f"http://{addr}/v1/net/events?since={self.log.lamport()}"
                    req = urllib.request.Request(u, headers=self._headers())
                    with urllib.request.urlopen(req, timeout=5) as r:
                        ev = json.loads(r.read().decode()).get("events", [])
                    if ev:
                        self.log.merge(ev)
                except Exception:
                    pass
                if self.federation_merge:
                    try:
                        u = f"http://{addr}/v1/federation/sync?since={self._fed_seq}"
                        req = urllib.request.Request(u, headers=self._headers())
                        with urllib.request.urlopen(req, timeout=5) as r:
                            d = json.loads(r.read().decode())
                        ups = d.get("updates", []) or []
                        props = d.get("proposals", []) or []
                        ranks = d.get("ranks", []) or []
                        if ups:
                            self._fed_seq = max([self._fed_seq] +
                                                [int(u2.get("seq") or 0) for u2 in ups])
                        if ups or props or ranks:
                            self.federation_merge(ups, props, ranks)
                    except Exception:
                        pass
            time.sleep(self.interval)
