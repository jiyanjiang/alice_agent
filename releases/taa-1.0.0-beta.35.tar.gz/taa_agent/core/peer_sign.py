"""P10.5e: per-node Ed25519 signatures for P2P events.

The grant/token authorizes a peer; the signature proves that the event bytes
were produced by the holder of that node key and were not modified in transit.
The private key is local (TAA_HOME/peer_ed25519.key, 0600); the public key is
carried in the event and pinned per node on first accepted use.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import pathlib
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


class SignatureError(ValueError):
    pass


def _home() -> pathlib.Path:
    return pathlib.Path(os.environ.get("TAA_HOME") or (pathlib.Path.home() / ".taa"))


def _key_path() -> pathlib.Path:
    return _home() / "peer_ed25519.key"


def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii")


def _unb64(text: str) -> bytes:
    return base64.urlsafe_b64decode(text.encode("ascii"))


def private_key() -> Ed25519PrivateKey:
    p = _key_path()
    if p.is_file():
        return Ed25519PrivateKey.from_private_bytes(_unb64(p.read_text(encoding="utf-8").strip()))
    sk = Ed25519PrivateKey.generate()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(_b64(sk.private_bytes(serialization.Encoding.Raw,
                                       serialization.PrivateFormat.Raw,
                                       serialization.NoEncryption())), encoding="utf-8")
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass
    return sk


def public_key() -> str:
    return _b64(private_key().public_key().public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw))


def fingerprint() -> str:
    return hashlib.sha256(_unb64(public_key())).hexdigest()[:16]


def _canonical(e: dict) -> bytes:
    body = {
        "id": str(e.get("id") or ""),
        "lamport": int(e.get("lamport") or 0),
        "node_id": str(e.get("node_id") or ""),
        "type": str(e.get("type") or ""),
        "payload": e.get("payload") or {},
        "ts": float(e.get("ts") or 0),
    }
    return json.dumps(body, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def sign_event(event: dict) -> dict:
    e = dict(event)
    node = str(e.get("node_id") or "")
    if not node:
        raise SignatureError("node_id required")
    pub = public_key()
    sig = private_key().sign(_canonical(e))
    e["signed_by"] = node
    e["pubkey"] = pub
    e["signature"] = _b64(sig)
    return e


def sign_events(events: list[dict], *, node_id: str | None = None) -> list[dict]:
    """Sign unsigned local events; never re-sign another node's event."""
    out = []
    for e in events or []:
        if e.get("signature") and e.get("pubkey"):
            out.append(dict(e))
        elif node_id and str(e.get("node_id") or "") != node_id:
            out.append(dict(e))
        else:
            out.append(sign_event(e))
    return out


def verify_event(event: dict, *, known_pubkey: str | None = None) -> bool:
    try:
        node = str(event.get("node_id") or "")
        signed_by = str(event.get("signed_by") or node)
        pub = str(event.get("pubkey") or known_pubkey or "")
        sig = str(event.get("signature") or "")
        if not node or not pub or not sig or signed_by != node:
            return False
        if known_pubkey and pub != known_pubkey:
            return False
        Ed25519PublicKey.from_public_bytes(_unb64(pub)).verify(_unb64(sig), _canonical(event))
        return True
    except Exception:  # noqa: BLE001
        return False


def _ensure(conn) -> None:
    conn.execute("CREATE TABLE IF NOT EXISTS peer_event_keys("
                 "node_id TEXT PRIMARY KEY, pubkey TEXT NOT NULL, first_seen TEXT, last_seen TEXT)")
    conn.commit()


def verify_events(conn, events: list[dict], *, require: bool | None = None,
                  allow_unsigned: bool = False) -> tuple[list[dict], list[str]]:
    """Verify signatures and pin node public keys (TOFU).

    ``require`` defaults to TAA_PEER_REQUIRE_SIGN=1. Unsigned events are accepted
    only when not required; signed-but-invalid events are always rejected.
    """
    if require is None:
        # beta.2 default: signatures are required. Explicit 0 is only for
        # migration/legacy self-tests; it is not the production default.
        raw = (os.environ.get("TAA_PEER_REQUIRE_SIGN") or "").strip().lower()
        require = raw not in ("0", "false", "no", "off")
    _ensure(conn)
    ok, errors = [], []
    for e in events or []:
        node = str(e.get("node_id") or "")
        sig = str(e.get("signature") or "")
        pub = str(e.get("pubkey") or "")
        if not sig or not pub:
            if require and not allow_unsigned:
                errors.append(f"unsigned:{node[:24]}")
            else:
                ok.append(e)
            continue
        row = conn.execute("SELECT pubkey FROM peer_event_keys WHERE node_id=?", (node,)).fetchone()
        known = row["pubkey"] if row else None
        if known and known != pub:
            errors.append(f"key_changed:{node[:24]}")
            continue
        if not verify_event(e, known_pubkey=known or pub):
            errors.append(f"bad_signature:{node[:24]}")
            continue
        conn.execute("INSERT INTO peer_event_keys(node_id,pubkey,first_seen,last_seen) "
                     "VALUES(?,?,datetime('now','localtime'),datetime('now','localtime')) "
                     "ON CONFLICT(node_id) DO UPDATE SET last_seen=excluded.last_seen",
                     (node, pub))
        ok.append(e)
    conn.commit()
    return ok, errors
