"""抽取器契约（薄接口 + 厚适配）：每源一份抽取逻辑，接口统一、可回归。

约定（docs/89 §1.2）：
  sources/<id>/source.yaml     源元数据（domain / url_patterns / style_profile / channel）
  sources/<id>/extractor.py    必须暴露 `extract(html: str, url: str) -> dict`
  sources/<id>/spec.md         选择器链与清洗规则（人读）
  sources/<id>/samples/*.html  黄金样本 + 同名 .expected.json（期望字段）

统一输出 Article：
  {source_id, canonical_url, title, byline[], published_at, body, images[], extractor_version}
"""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SOURCES = ROOT / "sources"

FIELDS = ("title", "published_at", "body")


def load_extractor(source_id: str):
    p = SOURCES / source_id / "extractor.py"
    if not p.exists():
        raise FileNotFoundError(f"no extractor for {source_id}")
    spec = importlib.util.spec_from_file_location(f"extractor_{source_id}", p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)          # type: ignore
    if not hasattr(m, "extract"):
        raise AttributeError(f"{source_id}/extractor.py 缺 extract(html,url)")
    return m


def run_one(source_id: str, sample: Path) -> dict:
    """跑一个样本：返回 {ok, diff[], article}。"""
    m = load_extractor(source_id)
    html = sample.read_text(encoding="utf-8", errors="ignore")
    art = m.extract(html, sample.stem) or {}
    exp_p = sample.with_suffix(".expected.json")
    exp = json.loads(exp_p.read_text(encoding="utf-8")) if exp_p.exists() else {}
    diff = []
    for k, v in exp.items():
        got = art.get(k)
        if isinstance(v, str) and isinstance(got, str):
            if v.strip() not in got.strip() and got.strip() not in v.strip():
                diff.append(f"{k}: 期望≈{v[:40]!r} 实际={got[:40]!r}")
        elif got != v:
            diff.append(f"{k}: 期望={v!r} 实际={got!r}")
    return {"ok": not diff, "diff": diff, "article": art, "sample": sample.name}


def registry() -> list[dict]:
    out = []
    for d in sorted(SOURCES.glob("*/")):
        out.append({"id": d.name,
                    "has_extractor": (d / "extractor.py").exists(),
                    "has_spec": (d / "spec.md").exists(),
                    "samples": len(list((d / "samples").glob("*.html"))) if (d / "samples").is_dir() else 0})
    return out
