"""Deterministic source/fact gate for research.ask.

This module does not decide whether a prose claim is true. It enforces the
minimum evidence contract:

  * at least two independent source domains;
  * at least one official/primary/academic source (not all weak media);
  * the answer cites at least two source ids/URLs from the supplied set;
  * an explicit abstention ("来源不足/无法核验") is never marked verified.

The gate is intentionally conservative: a false negative is preferable to a
false "verified" badge.
"""
from __future__ import annotations

import re
import urllib.parse

_STRONG = {"official", "primary"}


def _host(url: str) -> str:
    try:
        return (urllib.parse.urlparse(url).hostname or "").lower()
    except Exception:
        return ""


def evaluate(answer: str, sources: list[dict]) -> dict:
    text = answer or ""
    srcs = [s for s in (sources or []) if isinstance(s, dict) and s.get("url")]
    domains = {_host(s["url"]) for s in srcs if _host(s["url"])}
    strong = {s.get("id") or s.get("url") for s in srcs
              if str(s.get("grade") or "").lower() in _STRONG}
    ids = {str(s.get("id") or "").upper() for s in srcs if s.get("id")}
    urls = {str(s.get("url") or "") for s in srcs if s.get("url")}

    cited_ids = {x.upper() for x in re.findall(r"\[(S\d+)\]", text, re.I)}
    cited_urls = {u.rstrip(".,);]") for u in re.findall(r"https?://[^\s)>\]]+", text)}
    cited = (cited_ids & ids) | (cited_urls & urls)
    abstain = bool(re.search(r"来源不足|无法核验|未能核验|缺证据|无来源|未核验", text))

    reasons: list[str] = []
    if len(domains) < 2:
        reasons.append(f"独立来源域名不足({len(domains)})")
    if not strong:
        reasons.append("缺少官方/一手/学术来源")
    if len(cited) < 2:
        reasons.append(f"答案引用来源不足({len(cited)})")
    if abstain:
        reasons.append("答案显式声明来源不足/未核验")
    ok = not reasons
    return {
        "ok": ok,
        "status": "verified" if ok else "unverified",
        "reasons": reasons,
        "source_count": len(srcs),
        "domain_count": len(domains),
        "strong_count": len(strong),
        "cited_count": len(cited),
        "cited": sorted(str(x) for x in cited)[:8],
        "abstained": abstain,
    }
