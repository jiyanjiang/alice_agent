"""工具包市场：打包 / 隐私扫描 / 发布 / 安装 `tools/<name>`。

- 工具包 = `tools/<name>/{TOOL.md, tool.py, requirements.txt?}`。
- 发布：打包为确定性 tar.gz，存 `.toolpkg/`，登记 `tool_packages`，并在 `#tools` 发帖（武器库）。
- 安装：从市场取出并解包到 `tools/<name>`，随后热加载。
- 隐私：发布前扫描是否含 key / 绝对路径 / 明文密码。
"""
from __future__ import annotations

import gzip
import hashlib
import io
import re
import tarfile
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS tool_packages (
  name       TEXT,
  version    TEXT,
  sha256     TEXT,
  node_id    TEXT,
  blob       TEXT,
  created_by TEXT,
  created_at TEXT,
  PRIMARY KEY (name, sha256)
);
"""


def _root() -> Path:
    from . import distribution
    return distribution.ROOT


def _tools() -> Path:
    return _root() / "tools"


def _store() -> Path:
    p = _root() / ".toolpkg"
    p.mkdir(parents=True, exist_ok=True)
    return p


def ensure(conn) -> None:
    conn.executescript(SCHEMA)
    conn.commit()


def pack(name: str) -> tuple[bytes, str]:
    d = _tools() / name
    if not (d.is_dir() and (d / "tool.py").exists()):
        raise FileNotFoundError(f"tools/{name}/tool.py 不存在")
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode="w") as tf:
        for f in sorted(d.rglob("*")):
            if f.is_file() and "__pycache__" not in f.parts:
                ti = tf.gettarinfo(str(f), arcname=str(f.relative_to(_tools())))
                ti.mtime = 0
                ti.uid = ti.gid = 0
                ti.uname = ti.gname = ""
                with open(f, "rb") as fh:
                    tf.addfile(ti, fh)
    data = gzip.compress(raw.getvalue(), mtime=0)
    return data, hashlib.sha256(data).hexdigest()


def privacy_scan(name: str) -> list[str]:
    """扫描工具包是否含个人 key / 绝对路径 / 明文密码。"""
    issues: list[str] = []
    d = _tools() / name
    pats = [(r"sk-[A-Za-z0-9]{16,}", "疑似 API key"),
            (r"/Users/[^ \n\"']+", "绝对路径(/Users)"),
            (r"/home/[^ \n\"']+", "绝对路径(/home)"),
            (r"password\s*[:=]\s*['\"][^'\"]+", "疑似明文密码")]
    for f in d.rglob("*"):
        if f.is_file() and f.suffix in (".py", ".md", ".txt", ".json") \
                and "__pycache__" not in f.parts:
            try:
                t = f.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            for rx, why in pats:
                if re.search(rx, t):
                    issues.append(f"{f.name}: {why}")
    return issues


def publish(conn, name: str, node: str, by: str, version: str = "1") -> dict:
    data, sha = pack(name)
    blob = f"{name}-{sha[:12]}.tgz"
    (_store() / blob).write_bytes(data)
    ensure(conn)
    conn.execute(
        "INSERT OR REPLACE INTO tool_packages(name,version,sha256,node_id,blob,created_by,created_at) "
        "VALUES (?,?,?,?,?,?,datetime('now','localtime'))",
        (name, version, sha, node, blob, by))
    conn.commit()
    return {"name": name, "version": version, "sha256": sha, "blob": blob, "size": len(data)}


def list_packages(conn) -> list[dict]:
    ensure(conn)
    return [dict(r) for r in conn.execute(
        "SELECT name,version,sha256,node_id,blob,created_by,created_at "
        "FROM tool_packages ORDER BY created_at DESC")]


def blob_path(blob: str) -> Path | None:
    p = _store() / blob
    return p if p.exists() else None


def install(conn, name: str, sha: str | None = None) -> dict:
    ensure(conn)
    if sha:
        row = conn.execute("SELECT blob,sha256 FROM tool_packages WHERE name=? AND sha256=?",
                           (name, sha)).fetchone()
    else:
        row = conn.execute("SELECT blob,sha256 FROM tool_packages WHERE name=? "
                           "ORDER BY created_at DESC LIMIT 1", (name,)).fetchone()
    if not row:
        raise FileNotFoundError(f"市场里没有工具包 {name}")
    path = blob_path(row["blob"])
    if not path:
        raise FileNotFoundError(f"包文件缺失：{row['blob']}")
    with tarfile.open(fileobj=io.BytesIO(path.read_bytes()), mode="r:gz") as tf:
        names = tf.getnames()
        # ★ 2026-10-08（档 B「只 Call」）：**服务型工具包一律拒绝安装** —— 服务型工具的契约是
        #   数据（service.json），代码不落消费者机器；本检查是防御纵深（`pack()` 本就要求
        #   tool.py，所以服务卡根本打不成包）。
        if any(n.endswith("service.json") for n in names) and not any(
                n.endswith("tool.py") for n in names):
            raise PermissionError(
                f"{name} 是**服务型工具**（call-only）：只允许远程调用，不安装代码。"
                f"请直接用 POST /v1/tools/{name}/call")
        tf.extractall(_tools())
    return {"name": name, "sha256": row["sha256"], "installed_to": f"tools/{name}"}
