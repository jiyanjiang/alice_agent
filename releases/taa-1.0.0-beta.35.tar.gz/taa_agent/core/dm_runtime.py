"""DM 运行时接入（D1-补）：agent 自动「看 / 回 / 进简报」——真人↔agent 的命门。

背景：后端 DM（`core/dm.py` + `/v1/dm/*`）早已可用，但 **agent 运行时里没有任何 DM 处理**：
真人私信发出去，agent 永远不回（实测 60s 后消息数仍为 1）。本模块补上运行时这一侧。

策略（Owner 派单口径，docs/79 §5 请求制之上）：
  * **真人（Owner，kind=human）发来的请求**（`pending_in`）→ **自动 accept**，然后正常回复；
  * **非好友 agent 发来的请求** → **不自动接受**（留给本人 reject/block），只在简报里列出待办；
  * 已 `accepted` 会话有未读对方消息 → 用 agent 自己的 LLM 生成回复 → 回发 → 标已读；
  * 回复**先接人、再答事**（Alice `RESPONSE_MODE.md` §0.5 同款）：先回应对方这个人（收到/你好/抱歉），
    再给判断与选项；不冷冰冰甩清单。

可靠性：
  * 判据是**服务端未读**（`unread_in_thread`：对方发来、未读、未撤回），不依赖本地游标——
    **离线期间的消息恢复后照样处理**（未读不会因为进程不在而丢），天然幂等（回复后标已读 → 未读归零）。
  * 每线程每拍**最多回一条**；LLM 失败**不标已读**，下拍补捞（与 chatwork 同款「不前移游标」策略）。
  * 全流程留审计（`agents/<id>/dm-audit.jsonl`）与简报快照（`agents/<id>/dm-brief.json`）。

本模块**不碰网络细节**：调用方注入 `call(method, path, body=None) -> dict` 与 `llm(prompt) -> str`，
便于在 `chatroom_agent` / `loop` 里复用，也便于在单测里用 Flask test_client + 假 LLM 做确定性验证。
"""
from __future__ import annotations

import json
import os
import re
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# ★ 回声死循环护栏（2026-10-16，缺陷 R-002）：两个 agent 的"自动回复"会互相回敬，永不终止
#   （实测 dm-2385d5a8 近 1 小时 +415 条）。这里只加**结构护栏**（时间窗），不夺 LLM 的"说什么"判断权。
#   对真人（Owner）不限流；仅对 agent↔agent 生效，可直接用环境变量调参。
DM_COOLDOWN_S = int(os.environ.get("TEAMAI_DM_THREAD_COOLDOWN", "900"))
_CD_FILE = ROOT / "data" / "dm_thread_cooldown.json"


def _cd_load(path: "Path | None" = None) -> dict:
    p = path or _CD_FILE
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    except Exception:  # noqa: BLE001
        return {}


def _cd_save(d: dict, path: "Path | None" = None) -> None:
    p = path or _CD_FILE
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(d), encoding="utf-8")
    except OSError:
        pass


def thread_cooled(thread_id: str, now: "float | None" = None, cooldown: "int | None" = None,
                  path: "Path | None" = None) -> bool:
    """同线程冷却窗口内 → True（本拍跳过自动回复）。"""
    now = now if now is not None else datetime.now().timestamp()
    cd = DM_COOLDOWN_S if cooldown is None else cooldown
    if cd <= 0:
        return False
    return (now - float(_cd_load(path).get(thread_id) or 0)) < cd


def thread_touch(thread_id: str, now: "float | None" = None, path: "Path | None" = None) -> None:
    now = now if now is not None else datetime.now().timestamp()
    d = _cd_load(path); d[thread_id] = now; _cd_save(d, path)

MAX_CONTEXT = 10          # 一次喂给 LLM 的最近消息条数
MAX_REPLY_CHARS = 600     # 回复上限（dm.MAX_BODY=2000，留足余量）
# 「先接人」的结构护栏标记（不是"值不值得"的判断，只保证不冷冰冰）
ACK_MARKERS = ("收到", "你好", "您好", "在的", "在。", "嗨", "谢谢", "辛苦", "抱歉",
               "明白", "好的", "好嘞", "嗯", "没问题", "来了", "我在")


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ------------------------------------------------------------------ 身份 / 人格
def human_ids() -> set[str]:
    """Owner/真人的 id 集合（复用 chatwork 口径：env / config / 兜底常量）。"""
    try:
        from . import chatwork
        return chatwork.human_ids()
    except Exception:  # noqa: BLE001
        ids = {"human", "jiyanjiang"}
        hid = os.environ.get("TEAM_HUMAN_ID")
        if hid:
            ids.add(hid)
        return ids


def is_owner(peer: dict) -> bool:
    """对方是不是真人（Owner）：优先看服务端 `kind`，再退回 id 白名单。"""
    if not isinstance(peer, dict):
        return False
    if (peer.get("kind") or "").lower() == "human":
        return True
    return str(peer.get("id") or "") in human_ids()


def _persona_note(agent: str) -> str:
    """极简人设/语气注：人物是「谁」由本地文件决定，不靠 LLM 现编。"""
    motto, role = "", "executor"
    try:
        import yaml
        d = yaml.safe_load((ROOT / "agents" / agent / "persona.yaml").read_text(encoding="utf-8")) or {}
        motto = (d.get("identity") or {}).get("motto") or d.get("motto") or ""
        role = d.get("role") or role
    except Exception:  # noqa: BLE001
        pass
    note = f"你的人设：agent「{agent}」（{role}）"
    if motto:
        note += f"；口头禅/风格：{motto}"
    try:
        from . import style as style_mod
        # 私信 = 一对一私密场景（style.DEFAULT_STYLES["private"]）
        hint = style_mod.style_hint(_load_persona(agent), "private")
        if hint:
            note += f"\n语气参考：{str(hint).strip()[:300]}"
    except Exception:  # noqa: BLE001
        pass
    return note


def _load_persona(agent: str) -> dict:
    try:
        import yaml
        return yaml.safe_load((ROOT / "agents" / agent / "persona.yaml").read_text(encoding="utf-8")) or {}
    except Exception:  # noqa: BLE001
        return {}


# ------------------------------------------------------------------ prompt
def _att_urls(m: dict) -> list[str]:
    """消息里的附件 URL（兼容 list[dict] / list[str] / 单字符串）。"""
    a = (m or {}).get("attachments") or (m or {}).get("attachment")
    if not a:
        return []
    if isinstance(a, str):
        return [a]
    out = []
    for x in a:
        if isinstance(x, str):
            out.append(x)
        elif isinstance(x, dict) and x.get("url"):
            out.append(str(x["url"]))
    return out


def att_local_paths(msgs: list[dict], limit: int = 4) -> list[str]:
    """把 /static/uploads/… 附件映射为**本机文件路径**（供视觉通道传图）；最多 limit 张。"""
    out: list[str] = []
    for m in msgs:
        for u in _att_urls(m):
            if not u.startswith("/static/"):
                continue
            fp = ROOT / u.lstrip("/")
            if fp.exists() and str(fp) not in out:
                out.append(str(fp))
            if len(out) >= limit:
                return out
    return out


def build_reply_prompt(agent: str, thread: dict, messages: list[dict]) -> str:
    """构造「先接人再答事」的私信回复 prompt。

    messages：会话内**时间正序**的消息视图（`from_me` / `body`）。
    """
    peer = thread.get("peer") or {}
    peer_name = peer.get("name") or peer.get("id") or "对方"
    who = "真人 Owner" if is_owner(peer) else f"队友 agent「{peer.get('id')}」"
    hist = []
    for m in messages[-MAX_CONTEXT:]:
        body = (m.get("body") or "").strip().replace("\n", " ")
        if not body:
            continue
        who_said = "我" if m.get("from_me") else peer_name
        urls = _att_urls(m)
        tag = f"（附件：{'、'.join(urls)}）" if urls else ""
        hist.append(f"{who_said}：{body[:400]}{tag}")
    last_in = next((m for m in reversed(messages) if not m.get("from_me") and (m.get("body") or "").strip()), None)
    ask = (last_in.get("body") if last_in else "").strip()
    ask_atts = _att_urls(last_in or {})
    return (
        "你是团队 AI 的 agent，正在**私信（DM）**里和对方一对一对话。\n"
        f"{_persona_note(agent)}\n"
        f"对方是：{who}（{peer_name}）。\n"
        f"会话记录（{thread.get('id')}）：\n" + ("\n".join(hist) if hist else "（无）") + "\n\n"
        "回复纪律（**先接人、再答事**）：\n"
        "1) **先接人**：第一句先回应对方这个人（如「收到」「你好XX，抱歉刚看到」），有情绪先接情绪；\n"
        "2) **再答事**：然后直接、具体地回答对方**最后那条**的问题/要求；能落地就给结论与下一步；\n"
        "3) 你是 agent：不知道/做不到就如实说，并给替代方案，**不要编造**；\n"
        "   **不得臆造具体事实**（进程名/文件路径/时间/命令/数字）——不确定就用「我这边」这类模糊表述；\n"
        "4) 用中文，口语、简短（**不超过 %d 字**），**只输出回复正文**，不要 JSON、不要前后缀。" % MAX_REPLY_CHARS + "\n"
        + (f"\n对方最后一句：{ask[:600]}\n" if ask else "")
        + (f"\n**本条附带图片**（见随附文件）：请**先看图再回答**；对方问的是图里的内容时，按其内容回答，不要假装没看到图。\n"
           if ask_atts else "")
    )


def shorten(text: str, limit: int = MAX_REPLY_CHARS) -> str:
    """超长回复在**句末**截断（不在词中切），并加省略号——避免私信半句话。"""
    t = (text or "").strip()
    if len(t) <= limit:
        return t
    cut = t[:limit]
    for sep in ("\n", "。", "！", "？", "；", ".", "!", "?", ";"):
        i = cut.rfind(sep)
        if i >= int(limit * 0.5):
            return cut[:i + 1].strip()
    return cut.rstrip() + "…"


def ensure_ack(reply: str, peer_name: str) -> str:
    """结构护栏：回复若完全没有「接人」的迹象 → 补一句问候，避免冷冰冰。"""
    r = (reply or "").strip()
    if not r:
        return r
    head = r[:14]
    if any(m in head for m in ACK_MARKERS):
        return r
    return f"{peer_name}，收到。" + r


# ------------------------------------------------------------------ LLM
_ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")


# opencode harness 会把「工具轨迹」写进 stdout（`> build · model → Read a.py …`），
# 直接当私信正文发出去会污染内容——这些行必须过滤（判据① 的「能看」前提）。
_CLI_TRACE = re.compile(r"^(>|→|·)\s*(build|Read|Write|Bash|Grep|Glob|Search|List)", re.I)


def clean_llm_text(s: str) -> str:
    """洗掉 CLI 噪声：ANSI 转义 + opencode 工具轨迹行 + 行内轨迹尾巴 + 首尾空行。"""
    lines = [_ANSI.sub("", ln).rstrip() for ln in (s or "").replace("\r", "").splitlines()]
    lines = [ln for ln in lines if not _CLI_TRACE.match(ln.strip())]
    txt = "\n".join(lines)
    txt = re.split(r"\s*>?\s*build\s*·\s*\S+", txt)[0]      # 行内 `… > build · model → Read …`
    txt = re.split(r"\s*→\s*Read\s+\S+", txt)[0]
    while txt and (txt[0] in "\n \t" or txt.startswith(">")):
        txt = txt[1:]
    return txt.strip()


def resolve_backend(agent: str) -> tuple[str, str]:
    """解析 DM 回复的 `(backend, model)`。

    **默认 = 直连 DeepSeek**：私信是「短、面向真人、对延迟敏感」的消息面——直连又快又干净；
    opencode 这类 harness 更适合房间里的重推理，其实测会把**工具轨迹写进 stdout** 污染私信正文
    （本任务实测：`> build · deepseek-flash → Read agents/…` 混入回复）。
    这条也沿用 `loop.respond_message` 既有的私信回复路径（同源、同 key）。
    需要走 harness 时显式设 `TEAMAI_DM_BACKEND=opencode`。

    model 与 backend 必须匹配：直连 DeepSeek 用 `deepseek-chat`；harness 用 `vendor/model`。
    """
    mf = ROOT / "agents" / agent / "model"
    backend = os.environ.get("TEAMAI_DM_BACKEND") or "deepseek"
    if backend == "deepseek":
        model = (os.environ.get("TEAMAI_DM_MODEL") or os.environ.get("TEAMAI_REPLY_MODEL")
                 or "deepseek-chat")
    else:
        model = (os.environ.get("TEAMAI_DM_MODEL")
                 or (mf.read_text(encoding="utf-8").strip() if mf.exists() else "")
                 or os.environ.get("TEAMAI_OPENCODE_MODEL")
                 or "deepseek/deepseek-flash")
    return backend, model


def default_llm(agent: str):
    """默认回复器：直连 DeepSeek（快、干净）；`TEAMAI_DM_BACKEND` 可切 harness。

    注入点：`TEAMAI_DM_BACKEND`（deepseek|opencode|omp|qoder）、`TEAMAI_DM_MODEL`。
    """
    backend, model = resolve_backend(agent)

    if backend == "deepseek":
        def _ds(prompt: str) -> str:
            key = os.environ.get("DEEPSEEK_API_KEY") or os.environ.get("DS_KEY")
            if not key:
                kp = ROOT / "bootstrap" / "deepseek.key"
                key = kp.read_text(encoding="utf-8").strip() if kp.exists() else None
            if not key:
                raise RuntimeError("no deepseek key")
            import urllib.request
            body = json.dumps({"model": model,
                               "messages": [{"role": "user", "content": prompt}],
                               "temperature": 0.5, "max_tokens": 800}).encode()
            req = urllib.request.Request("https://api.deepseek.com/v1/chat/completions",
                                         data=body, method="POST")
            req.add_header("Content-Type", "application/json")
            req.add_header("Authorization", f"Bearer {key}")
            with urllib.request.urlopen(req, timeout=60) as r:
                return clean_llm_text(json.loads(r.read().decode())["choices"][0]["message"]["content"])
        return _ds

    def _adapter(prompt: str) -> str:
        from .llm import get as llm_get
        res = llm_get(backend).run(prompt, model=model, cwd=str(ROOT),
                                   title=f"dm:{agent}", timeout=180)
        if not res.ok and not res.text:
            raise RuntimeError(f"llm {backend} failed rc={res.returncode}")
        return clean_llm_text(res.text)
    return _adapter


# ------------------------------------------------------------------ 审计 / 简报
def audit_path(agent: str) -> Path:
    d = ROOT / "agents" / agent
    d.mkdir(parents=True, exist_ok=True)
    return d / "dm-audit.jsonl"


def _audit(agent: str, rec: dict) -> None:
    try:
        with audit_path(agent).open("a", encoding="utf-8") as f:
            f.write(json.dumps({"ts": _now(), **rec}, ensure_ascii=False) + "\n")
    except Exception as e:  # noqa: BLE001
        print(f"[dm] audit write err: {e}")


def brief_path(agent: str) -> Path:
    d = ROOT / "agents" / agent
    d.mkdir(parents=True, exist_ok=True)
    return d / "dm-brief.json"


def write_brief(agent: str, summary: dict) -> None:
    try:
        brief_path(agent).write_text(
            json.dumps({"agent": agent, "at": _now(), **summary}, ensure_ascii=False, indent=2),
            encoding="utf-8")
    except Exception as e:  # noqa: BLE001
        print(f"[dm] brief write err: {e}")


def brief_lines(s: dict) -> list[str]:
    """把一次 poll 结果压成心跳/简报可打印的几行（供 loop / chatroom 打印）。"""
    if not s:
        return []
    out: list[str] = []
    if s.get("unread", 0):
        out.append(f"未读 DM {s['unread']} 条 / {s.get('unread_threads', 0)} 个会话")
    for it in s.get("held_requests", []):
        out.append(f"待你裁决：agent「{it.get('peer')}」请求私聊（非好友，未自动接受）")
    for it in s.get("replied", []):
        out.append(f"已回 {it.get('peer')}：{it.get('preview', '')[:40]}")
    for it in s.get("auto_accepted", []):
        out.append(f"已自动接受真人「{it.get('peer')}」的私聊请求")
    return out


# ------------------------------------------------------------------ 主流程
def _preview(text: str, n: int = 80) -> str:
    return re.sub(r"\s+", " ", (text or "").strip())[:n]


def poll_dm(call, agent: str, *, llm=None, model: str | None = None,
            max_replies: int = 5, audit: bool = True, verbose: bool = True,
            tool_router=None) -> dict:
    """拉一次私信并处理。

    `call(method, path, body=None) -> dict`：已签名的 HTTP 调用（见 chatroom_agent.Client）。
    `llm(prompt) -> str`：回复生成器；默认走 `default_llm(agent)`。

    返回 summary（同时写审计与简报）：
      {"unread", "unread_threads", "auto_accepted":[{thread,peer}], "held_requests":[{thread,peer}],
       "replied":[{thread,peer,preview}], "errors":[...]}
    """
    summary = {"unread": 0, "unread_threads": 0, "auto_accepted": [], "held_requests": [],
               "replied": [], "errors": []}
    threads = (call("GET", "/v1/dm/threads") or {}).get("threads") or []
    summary["unread"] = sum(int(t.get("unread") or 0) for t in threads)
    summary["unread_threads"] = sum(1 for t in threads if int(t.get("unread") or 0) > 0)

    replies = 0
    for t in threads:
        tid = t.get("id")
        peer = t.get("peer") or {}
        state = t.get("state")
        unread = int(t.get("unread") or 0)
        try:
            # ---- 请求制：入站请求 ----
            if state == "pending" and t.get("pending_in"):
                if is_owner(peer):
                    call("POST", f"/v1/dm/threads/{tid}/accept", {})
                    summary["auto_accepted"].append({"thread": tid, "peer": peer.get("id")})
                    if verbose:
                        print(f"[dm] 自动接受真人「{peer.get('id')}」的私聊请求 {tid}")
                    if audit:
                        _audit(agent, {"action": "auto_accept_owner", "thread": tid,
                                       "peer": peer.get("id"), "reason": "kind=human"})
                    state = "accepted"          # 接受后即可正常回复
                else:
                    summary["held_requests"].append({"thread": tid, "peer": peer.get("id")})
                    if verbose:
                        print(f"[dm] 请求待裁决（非好友 agent）：{peer.get('id')} @ {tid}（不自动接受）")
                    if audit:
                        _audit(agent, {"action": "hold_request", "thread": tid,
                                       "peer": peer.get("id"), "reason": "non_friend_agent"})
                    continue
            if state == "pending" and t.get("is_requester"):
                continue                        # 我发的请求，等对方接受
            if state not in ("accepted",):
                continue                        # rejected / blocked / 其它
            if unread <= 0:
                continue
            # ★ R-002 护栏：agent↔agent 同线程冷却（真人/Owner 不受限）
            if not is_owner(peer) and thread_cooled(tid):
                summary.setdefault("cooled", []).append(tid)
                if verbose:
                    print(f"[dm] 线程冷却中（{DM_COOLDOWN_S}s），本拍跳过 {tid}")
                if audit:
                    _audit(agent, {"action": "thread_cooldown_skip", "thread": tid,
                                   "peer": peer.get("id") if isinstance(peer, dict) else peer})
                continue
            if replies >= max_replies:
                if verbose:
                    print(f"[dm] 本拍回复额度用尽（{max_replies}），余下下拍继续")
                break

            # ---- 读未读 → LLM 生成 → 回发 → 标已读 ----
            msgs = (call("GET", f"/v1/dm/threads/{tid}/messages?limit={MAX_CONTEXT * 2}") or {}).get("messages") or []
            # ★ DM 方案 B：生图类 DM → 走"接活干活"（受理语+节流+闸门+回图），不走普通回复
            _last_in = next((m for m in reversed(msgs) if not m.get("from_me") and (m.get("body") or "").strip()), None)
            _body = (_last_in or {}).get("body") or ""
            try:
                from . import dm_worker as _dw
                if _dw.wants_image(_body):
                    _peer_id = (peer.get("id") if isinstance(peer, dict) else peer) or ""
                    _res = _dw.handle_task(agent, _peer_id, _body)
                    call("POST", f"/v1/dm/threads/{tid}/read", {})
                    replies += 1
                    if not is_owner(peer):
                        thread_touch(tid)
                    summary["replied"].append({"thread": tid, "peer": _peer_id, "preview": f"[gen_image] {_res.get('status')}"})
                    if verbose:
                        print(f"[dm] 生图件 {_peer_id} → {_res.get('status')}")
                    if audit:
                        _audit(agent, {"action": "gen_image", "thread": tid, "peer": _peer_id, **_res})
                    continue
            except Exception as _e:  # noqa: BLE001
                if audit:
                    _audit(agent, {"action": "gen_image_route_err", "thread": tid, "err": str(_e)[:120]})
            prompt = build_reply_prompt(agent, t, msgs)
            tool_text = ""
            if tool_router and is_owner(peer):
                try:
                    tool_text = str(tool_router(agent, _body) or "").strip()
                except Exception as e:  # noqa: BLE001
                    if audit:
                        _audit(agent, {"action": "dm_tool_error", "thread": tid,
                                       "err": str(e)[:160]})
            if tool_text:
                prompt += ("\n\n【工具真实结果（必须基于它回答；不要编造工具没说的）】\n"
                           + tool_text[:8000])
            atts = [] if llm else att_local_paths(msgs)
            try:
                if atts:      # ★ 2026-10-14：有图 → 走能传图的通道（opencode `-f`；ds flash 是视觉模型）
                    try:
                        from .llm import get as _llm_get, effective_model as _eff
                        _r = _llm_get("opencode").run(prompt, model=_eff(None), cwd=str(ROOT),
                                                      title=f"dm-vision:{agent}", timeout=180, files=atts)
                        text = (_r.text or "").strip()
                        if not _r.ok or not text:      # 视觉通道失败 → 降级纯文本（不静默失败）
                            text = (default_llm(agent)(prompt) or "").strip()
                            if audit:
                                _audit(agent, {"action": "vision_fallback", "thread": tid,
                                               "files": [os.path.basename(x) for x in atts],
                                               "err": str(_r.text)[-120:]})
                    except Exception as e:  # noqa: BLE001
                        text = (default_llm(agent)(prompt) or "").strip()
                        if audit:
                            _audit(agent, {"action": "vision_error", "thread": tid, "err": str(e)[:120]})
                else:
                    fn = llm or default_llm(agent)
                    text = (fn(prompt) or "").strip()
            except Exception as e:  # noqa: BLE001
                if not tool_text:
                    raise
                if audit:
                    _audit(agent, {"action": "dm_llm_fallback_tool", "thread": tid, "err": str(e)[:160]})
                text = ""
            if not text and tool_text:
                text = tool_text
            if not text:
                raise RuntimeError("empty LLM reply")
            text = shorten(ensure_ack(text, peer.get("name") or peer.get("id") or "你好"))
            res = call("POST", f"/v1/dm/threads/{tid}/messages", {"body": text})
            if not (res and res.get("ok")):
                raise RuntimeError(f"send failed: {res}")
            call("POST", f"/v1/dm/threads/{tid}/read", {})
            replies += 1
            if not is_owner(peer):
                thread_touch(tid)
            summary["replied"].append({"thread": tid, "peer": peer.get("id") if isinstance(peer, dict) else peer,
                                       "preview": _preview(text)})
            if verbose:
                print(f"[dm] 已回 {peer.get('id')}（{tid}）：{_preview(text, 60)}")
            if audit:
                _audit(agent, {"action": "reply", "thread": tid, "peer": peer.get("id"),
                               "chars": len(text), "preview": _preview(text, 120)})
        except Exception as e:  # noqa: BLE001  单线程失败不拖垮整拍；不标已读 → 下拍补捞
            summary["errors"].append({"thread": tid, "error": str(e)[:200]})
            if verbose:
                print(f"[dm] 会话 {tid} 处理失败（下拍补捞）：{e}")

    # 审计/简报只在**有事发生**时落盘：常驻运行时每 2s 跑一拍，空闲也写会把日志刷爆。
    active = bool(summary["unread"] or summary["replied"] or summary["held_requests"]
                  or summary["auto_accepted"])
    if audit and active:
        _audit(agent, {"action": "poll", "unread": summary["unread"],
                       "replied": len(summary["replied"]),
                       "held": len(summary["held_requests"]),
                       "auto_accepted": len(summary["auto_accepted"])})
    if active or not brief_path(agent).exists():
        write_brief(agent, summary)
    return summary
