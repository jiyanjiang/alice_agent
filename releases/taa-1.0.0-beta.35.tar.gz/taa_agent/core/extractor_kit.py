"""抽取器工具箱（薄接口 + 厚适配）：DOM 选择器回退链 → 统一 Article。

源文件（`sources/<id>/extractor.py`）只声明「链 + 版本 + 特有点」，公共部分都在这：
  · 选择器链回退（第一个非空结果胜出）
  · 日期解析（**优先 `time[datetime]` 属性**，其次含年份的文本）
  · 作者解析（`meta[name=author]` 优先）
  · 正文清洗：**逐段保留段落结构**（门禁要查段落数），只丢弃「read more / related / subscribe…」这类句
"""
from __future__ import annotations

import re

try:                                   # 作为 core 包成员加载
    from .simple_dom import parse, select_all, attr
    from .simple_dom import text as _text
except ImportError:                    # 被按文件路径加载时
    from core.simple_dom import parse, select_all, attr
    from core.simple_dom import text as _text

DROP_SENT = re.compile(r"(read more|related|subscribe|sign up|newsletter|share this)", re.I)
BODY_SKIP = frozenset({"script", "style", "noscript", "nav", "footer", "form", "aside"})
_YEAR = re.compile(r"(19|20)\d{2}")


def clean_body(raw: str, drop: re.Pattern = DROP_SENT) -> str:
    """按段清洗：**保留段落边界**（`\\n\\n`），段内丢推荐句。"""
    paras: list[str] = []
    for blk in re.split(r"\n{2,}", raw or ""):
        blk = re.sub(r"\s+", " ", blk).strip()
        if not blk:
            continue
        keep = " ".join(s for s in re.split(r"(?<=[.!?])\s+", blk) if not drop.search(s)).strip()
        if keep:
            paras.append(keep)
    return "\n\n".join(paras)[:20000]


def _first_text(dom, chain) -> str:
    for sel in chain:
        for n in select_all(dom, sel):
            t = _text(n, skip=BODY_SKIP)
            if t:
                return t
    return ""


def _first_date(dom, chain) -> str:
    """日期：依次看 `datetime` 属性 → `content` 属性（`meta[property=article:published_time]` 走这条）
    → 元素文本。真站常只把日期放在 meta 的 content 里（实测：physicsworld）。"""
    for sel in chain:
        for n in select_all(dom, sel):
            for k in ("datetime", "content"):
                v = attr(n, k).strip()
                if v and _YEAR.search(v):
                    return v
            t = _text(n, skip=BODY_SKIP)
            if _YEAR.search(t):
                return t
    return ""


def _norm_date(s: str) -> str:
    """`2026-10-14T06:58:48+00:00` → `2026-10-14 06:58`（统一格式，便于排序与浏览）。"""
    m = re.match(r"(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})", (s or "").strip())
    if m:
        return f"{m.group(1)} {m.group(2)}"
    m = re.match(r"(\d{4}-\d{2}-\d{2})", (s or "").strip())
    return m.group(1) if m else (s or "")


def _jsonld_date(html: str) -> str:
    """兜底：JSON-LD 的 `datePublished`（真站几乎都带）。"""
    m = re.search(r'"datePublished"\s*:\s*"([^"]+)"', html or "")
    return m.group(1).strip() if m else ""


def _split_names(s: str) -> list[str]:
    return [x.strip() for x in re.split(r"[,;，；]| and ", s or "") if x.strip()]


def _byline(dom, chain) -> list[str]:
    for n in select_all(dom, "meta[name=author]"):
        c = attr(n, "content")
        if c.strip():
            return _split_names(c)
    for sel in chain:
        for n in select_all(dom, sel):
            t = _text(n, skip=BODY_SKIP)
            if t:
                return _split_names(t)
    return []


def _images(dom, sel) -> list[str]:
    out: list[str] = []
    for n in select_all(dom, sel):
        s = attr(n, "src") or attr(n, "data-src")
        if s and not s.startswith("data:") and s not in out:
            out.append(s)
    return out[:12]


def _img_info(n) -> dict:
    """从 <img> 取 src/尺寸/srcset 最大变体（点击放大用）。"""
    ss, largest, best = attr(n, "srcset"), "", 0
    for part in (ss or "").split(","):
        bits = part.strip().split()
        if len(bits) >= 2 and bits[1].endswith("w"):
            try:
                w = int(bits[1][:-1])
            except ValueError:
                continue
            if w > best:
                best, largest = w, bits[0]
    return {"src": attr(n, "src") or attr(n, "data-src"), "width": attr(n, "width"),
            "height": attr(n, "height"), "srcset_largest": largest}


def _hero(dom) -> dict:
    """题图：class 含 headline/size-full/aligncenter 的图优先（**不限于 article 内**——实测真页题图常在 figure 里），
    其次 og:image（不登录即可得）。"""
    # 首选**带 srcset 的正文图**（不靠猜类名；真页属性常分多行、类名也未必含 headline）
    best = None
    for sel in ("article img[srcset]", "figure img[srcset]", "img[srcset]"):
        for n in select_all(dom, sel):
            info = _img_info(n)
            if not info["src"] or "/uploads/" not in info["src"] or "icon" in attr(n, "class"):
                continue
            if best is None or len(info.get("srcset_largest") or "") < len(best.get("srcset_largest") or ""):
                pass
            best = best or info
            if info.get("srcset_largest"):
                return info
    if best:
        return best
    for n in select_all(dom, "meta[property=og:image]"):
        if attr(n, "content"):
            return {"src": attr(n, "content"), "width": "", "height": "", "srcset_largest": ""}
    return {}


def _canonical(dom, fallback: str) -> str:
    """页面声明的 `<link rel=canonical>` 优先——这才是**文章全文 URL**（去重口径）。"""
    for n in select_all(dom, "link[rel=canonical]"):
        href = attr(n, "href").strip()
        if href.startswith("http"):
            return href
    return fallback


def extract_article(html: str, url: str = "", *, source_id: str, version: str,
                    title_chain, date_chain, byline_chain, body_chain,
                    images_sel: str = "article img", drop: re.Pattern = DROP_SENT) -> dict:
    dom = parse(html)
    date = _norm_date(_first_date(dom, date_chain) or _jsonld_date(html))
    return {
        "source_id": source_id,
        "canonical_url": _canonical(dom, url),
        "title": _first_text(dom, title_chain),
        "byline": _byline(dom, byline_chain),
        "published_at": date,
        "body": clean_body(_first_text(dom, body_chain), drop),
        "images": _images(dom, images_sel),
        "hero_image": _hero(dom),
        "extractor_version": version,
    }
