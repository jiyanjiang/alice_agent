"""朋友圈赛马：扫描点、候选、裁判 dry-run。

Phase 1：只收集候选；
Phase 2：增加多维裁判与赛马结果，仍不自动发布。

关键口径：
  * 7 个扫描点：10/12/14/16/18/20/22；
  * 每扫描点最多 1 个赢家；
  * 单 agent 每天最多 2 条；团队每天上限 = 真人 + agent 总数（当前 5）；
  * 硬门槛（隐私/证据/重复/合规）一票否决；
  * 没有候选或没有过阈值 → 空过。
"""
from __future__ import annotations

import json
import os
import re
import urllib.request
import uuid
from datetime import datetime, timedelta

from . import redaction

SCAN_HOURS = (10, 12, 14, 16, 18, 20, 22)
AGENT_DAILY_CAP = 2
TEAM_ROSTER_EXCLUDED = ("agent", "human", "codebuddy")
DRY_RUN = True
JUDGE_THRESHOLD = 68.0
WEIGHTS = {
    "work": 30, "interaction": 25, "execution": 15, "initiative": 10,
    "readability": 10, "citizenship": 5, "boundary": 5,
}
PUBLISH_LOCAL = {"alice", "bob"}
LOCAL_DAILY_CAP = 1


def _now(now=None) -> datetime:
    return now or datetime.now()


def _slot_dt(day: datetime, hour: int) -> datetime:
    return day.replace(hour=hour, minute=0, second=0, microsecond=0)


def _day_str(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d")


def _slot_str(hour: int) -> str:
    return f"{hour:02d}:00"


def _new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"


def _safe(text: str) -> bool:
    try:
        return redaction.scan(text or "")["pass"]
    except Exception:  # noqa: BLE001
        return True


def roster_size(conn) -> int:
    row = conn.execute(
        "SELECT COUNT(*) AS n FROM agents WHERE id NOT IN (?,?,?)",
        TEAM_ROSTER_EXCLUDED).fetchone()
    return max(1, int(row["n"] if row else 1))


def publish_mode(conn) -> str:
    """off | local | all。env 优先；否则读 feature_flags.moment_publish。"""
    env = (os.environ.get("TEAMAI_MOMENT_PUBLISH") or "").strip().lower()
    if env in ("off", "local", "all"):
        return env
    try:
        row = conn.execute("SELECT state FROM feature_flags WHERE key='moment_publish'").fetchone()
    except Exception:  # noqa: BLE001
        row = None
    state = (row["state"] if row else "off") or "off"
    if state == "active":
        return "all"
    if state == "experimental":
        return "local"
    return "off"


def _published_today(conn, day: str) -> int:
    row = conn.execute("SELECT COUNT(*) AS n FROM moment_rounds WHERE day=? AND status='published'",
                       (day,)).fetchone()
    return int(row["n"] if row else 0)


def active_ai(conn) -> list[str]:
    rows = conn.execute(
        "SELECT id FROM agents WHERE kind='ai' AND status<>'paused' "
        "AND id NOT IN (?,?,?) ORDER BY id", TEAM_ROSTER_EXCLUDED).fetchall()
    return [r["id"] for r in rows]


def ensure_rounds(conn, now=None) -> list[dict]:
    now = _now(now)
    today = _day_str(now)
    due = [h for h in SCAN_HOURS if _slot_dt(now, h) <= now]
    for h in due:
        conn.execute(
            "INSERT OR IGNORE INTO moment_rounds(id,day,slot,status,created_at,updated_at) "
            "VALUES (?,?,?,?,?,?)",
            (f"mr-{today}-{h:02d}", today, _slot_str(h), "open",
             now.strftime("%Y-%m-%d %H:%M:%S"), now.strftime("%Y-%m-%d %H:%M:%S")))
    if due:
        conn.execute(
            "UPDATE moment_rounds SET status='missed',updated_at=? "
            "WHERE day=? AND slot<? AND status='open'",
            (now.strftime("%Y-%m-%d %H:%M:%S"), today, _slot_str(due[-1])))
    conn.commit()
    return [dict(r) for r in conn.execute(
        "SELECT * FROM moment_rounds WHERE day=? ORDER BY slot", (today,)).fetchall()]


def current_round(conn, now=None) -> dict | None:
    now = _now(now)
    ensure_rounds(conn, now)
    row = conn.execute(
        "SELECT * FROM moment_rounds WHERE day=? AND status='open' "
        "ORDER BY slot DESC LIMIT 1", (_day_str(now),)).fetchone()
    return dict(row) if row else None


def _interaction_stats(conn, agent_id: str, since: str) -> tuple[int, int]:
    """只算“点名/私聊”的真人互动，不把同房间所有闲聊都算成该 agent 的互动。"""
    a = conn.execute("SELECT name FROM agents WHERE id=?", (agent_id,)).fetchone()
    name = (a["name"] if a else agent_id) or agent_id
    like_id = f"%{agent_id.lower()}%"
    like_name = f"%{name.lower()}%"
    room = conn.execute(
        "SELECT COUNT(*) AS n FROM room_messages rm "
        "JOIN room_members mem ON mem.room_id=rm.room_id AND mem.agent_id=? "
        "JOIN agents h ON h.id=rm.agent_id AND h.kind='human' "
        "WHERE rm.created_at>=? AND (lower(rm.body) LIKE ? OR lower(rm.body) LIKE ?)",
        (agent_id, since, like_id, like_name)).fetchone()
    dm = conn.execute(
        "SELECT COUNT(*) AS n FROM dm_messages m "
        "JOIN dm_threads t ON t.id=m.thread_id "
        "JOIN agents h ON h.id=m.sender_id AND h.kind='human' "
        "WHERE (t.a_id=? OR t.b_id=?) AND m.created_at>=?", (agent_id, agent_id, since)).fetchone()
    return int(room["n"] if room else 0), int(dm["n"] if dm else 0)


PROCESS_MARKERS = ("执行进度", "系统自动", "非交付", "回归自检", "自检", "测试回执",
                   "API 链路", "粘贴链路", "临时任务", "回执")


def _is_process(*parts) -> bool:
    text = " ".join(str(x or "") for x in parts)
    return any(m in text for m in PROCESS_MARKERS)


def _task_post(conn, task_id: str):
    """优先用任务关联的已发布产物帖做候选，而不是只拿任务卡流水。"""
    row = conn.execute(
        "SELECT id,title,body,type,tags FROM posts WHERE task_id=? AND status='published' "
        "AND type IN ('artifact','share','reading','note') "
        "ORDER BY created_at DESC LIMIT 1", (task_id,)).fetchone()
    if row and _is_process(row["title"], row["body"], row["tags"]):
        return None
    return row


def _interaction_sample(conn, agent_id: str, since: str):
    """取该 agent 自己在真人互动中的一条回应，作为可评估的互动证据；不取真人私聊原文。"""
    room = conn.execute(
        "SELECT rm.id, rm.room_id, rm.body FROM room_messages rm "
        "JOIN room_members hm ON hm.room_id=rm.room_id AND hm.kind='human' "
        "WHERE rm.agent_id=? AND rm.created_at>=? AND length(trim(rm.body))>=20 "
        "ORDER BY rm.id DESC LIMIT 1", (agent_id, since)).fetchone()
    if room:
        return {"body": room["body"], "ref": f"room:{room['room_id']}#m{room['id']}"}
    dm = conn.execute(
        "SELECT m.id, m.thread_id, m.body FROM dm_messages m "
        "JOIN dm_threads t ON t.id=m.thread_id "
        "JOIN agents h ON h.id=CASE WHEN t.a_id=? THEN t.b_id ELSE t.a_id END AND h.kind='human' "
        "WHERE m.sender_id=? AND m.created_at>=? AND length(trim(m.body))>=20 "
        "ORDER BY m.rowid DESC LIMIT 1", (agent_id, agent_id, since)).fetchone()
    if dm:
        return {"body": dm["body"], "ref": f"dm:{dm['thread_id']}#m{dm['id']}"}
    return None


def _candidate_rows(conn, round_row: dict, now: datetime, local_only: bool = False) -> list[dict]:
    """候选来源：近 24h 真人与该 agent 的互动，不再使用任务/交付流水。

    Moments 是生活层，不是工作汇报；任务完成信息留给 Feed。
    每个 agent 每轮最多 1 张互动卡。
    """
    active = active_ai(conn)
    if local_only:
        active = [a for a in active if a in PUBLISH_LOCAL]
    if not active:
        return []
    since = (now - timedelta(hours=24)).strftime("%Y-%m-%d %H:%M:%S")
    out = []
    for aid in active:
        room_n, dm_n = _interaction_stats(conn, aid, since)
        sample = _interaction_sample(conn, aid, since)
        if not sample or not _safe(sample["body"]):
            continue
        out.append({
            "id": _new_id("mc"), "round_id": round_row["id"], "agent_id": aid,
            "source_kind": "interaction",
            "source_ref": f"interaction:{sample['ref']}",
            "title": "和真人的一次对话回应",
            "hook": sample["body"][:300],
            "evidence": sample["ref"],
            "self_score": None,
        })
    # 每 agent 最多 1 张
    capped, seen = [], set()
    for c in out:
        if c["agent_id"] in seen:
            continue
        seen.add(c["agent_id"])
        capped.append(c)
    return capped

def _total(scores: dict) -> float:
    return round(sum(float(scores.get(k, 0) or 0) * w / 5.0 for k, w in WEIGHTS.items()), 1)


def _extract_json(text: str) -> dict:
    t = (text or "").strip()
    t = re.sub(r"^```(?:json)?\s*", "", t)
    t = re.sub(r"\s*```$", "", t)
    return json.loads(t)


def queue_agent_publish(conn, round_row: dict, candidate: dict, *, now=None) -> dict:
    """把发布任务交给 winner 的本地 runtime；server 不再代写。"""
    from . import commands as commands_mod
    now = _now(now)
    a = conn.execute("SELECT name FROM agents WHERE id=?", (candidate["agent_id"],)).fetchone()
    name = (a["name"] if a else candidate["agent_id"]) or candidate["agent_id"]
    payload = {
        "round_id": round_row["id"], "candidate_id": candidate["id"],
        "agent_id": candidate["agent_id"], "agent_name": name,
        "channel": "#lobby",
        "candidate": {"title": candidate.get("title") or "",
                      "hook": candidate.get("hook") or "",
                      "evidence": candidate.get("evidence") or ""},
        "constraints": {"min_chars": 80, "max_chars": 180,
                        "no_task_ids": True, "no_private_dims": True,
                        "no_status_or_test": True, "redaction_required": True},
        "idempotency_key": f"moment:{round_row['day']}:{round_row['slot']}:{candidate['agent_id']}",
    }
    cid = commands_mod.push(conn, candidate["agent_id"], "moment.publish", payload)
    conn.execute("UPDATE moment_rounds SET status='collected',judge_notes=?,updated_at=? WHERE id=?",
                 (f"AGENT_QUEUED:{cid}", now.strftime("%Y-%m-%d %H:%M:%S"), round_row["id"]))
    conn.commit()
    return {"queued": True, "command_id": cid, "agent_id": candidate["agent_id"]}


def mark_agent_result(conn, round_id: str, agent_id: str, *, post_id: str | None = None,
                      error: str = "", now=None) -> dict:
    """agent 回写发布结果；幂等，重复成功返回同一 post。"""
    now = _now(now)
    row = conn.execute(
        "SELECT r.*, c.agent_id AS winner_agent FROM moment_rounds r "
        "LEFT JOIN moment_candidates c ON c.id=r.winner_candidate_id WHERE r.id=?",
        (round_id,)).fetchone()
    if not row:
        return {"ok": False, "error": "round not found"}
    if row["winner_agent"] != agent_id:
        return {"ok": False, "error": "not winner"}
    if post_id:
        p = conn.execute("SELECT author_id,kind FROM posts WHERE id=?", (post_id,)).fetchone()
        if not p or p["author_id"] != agent_id:
            return {"ok": False, "error": "post author mismatch"}
        if row["published_post_id"] and row["published_post_id"] != post_id:
            return {"ok": False, "error": "already published", "post_id": row["published_post_id"]}
        conn.execute("UPDATE moment_rounds SET status='published',published_post_id=?,updated_at=? WHERE id=?",
                     (post_id, now.strftime("%Y-%m-%d %H:%M:%S"), round_id))
        conn.commit()
        return {"ok": True, "post_id": post_id, "idempotent": bool(row["published_post_id"])}
    msg = ("AGENT_ERROR: " + (error or "unknown"))[:500]
    conn.execute("UPDATE moment_rounds SET status='collected',judge_notes=?,updated_at=? WHERE id=?",
                 (msg, now.strftime("%Y-%m-%d %H:%M:%S"), round_id))
    conn.commit()
    return {"ok": True, "error": error}


def judge_candidates(candidates: list[dict], *, model: str | None = None,
                     timeout: int = 60) -> dict:
    """一次统一裁判；返回结构化评分。失败时抛异常，由调用方记录 judge_error。"""
    from .config import deepseek_key
    key = deepseek_key()
    if not key:
        raise RuntimeError("no deepseek key")
    model = model or os.environ.get("TEAMAI_MOMENT_JUDGE_MODEL", "deepseek-flash")
    cards = [{
        "candidate_id": c["id"], "source_kind": c["source_kind"],
        "title": c["title"], "hook": c["hook"], "evidence": c["evidence"],
    } for c in candidates]
    prompt = (
        "你是 Team AI 朋友圈赛马的统一裁判。候选已匿名。请按 0-5 分打分：\n"
        "work=生活感/真实场景（不是工作完成度），interaction=真人互动质量，"
        "execution=现场细节与具体性，initiative=个性/新意，readability=可读性，"
        "citizenship=团队公民行为，boundary=边界判断（同意/隐私/拒绝/替代方案）。\n"
        "硬门槛：工作汇报、任务/交付/测试/代码/工具流水、隐私/证据/合规；"
        "任一不通过则 gate=false。\n"
        "朋友圈只收生活、个性、观察、审美；没有真实生活内容不得高分。\n"
        "只返回 JSON：{\"cards\":[{\"candidate_id\":\"...\",\"work\":0,\"interaction\":0,"
        "\"execution\":0,\"initiative\":0,\"readability\":0,\"citizenship\":0,\"boundary\":0,"
        "\"gate\":true,\"reason\":\"一句话\"}]}\n"
        f"候选：{json.dumps(cards, ensure_ascii=False)}"
    )
    body = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": "你只输出 JSON，不输出 Markdown。"},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.1,
        "max_tokens": 1800,
        "stream": False,
    }, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        "https://api.deepseek.com/chat/completions", data=body, method="POST",
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {key}"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.loads(r.read().decode("utf-8"))
    text = ((data.get("choices") or [{}])[0].get("message") or {}).get("content", "")
    return {"model": model, "data": _extract_json(text), "usage": data.get("usage", {})}


def _winner_counts(conn, day: str) -> tuple[int, dict[str, int]]:
    rows = conn.execute(
        "SELECT c.agent_id, COUNT(*) AS n FROM moment_candidates c "
        "JOIN moment_rounds r ON r.id=c.round_id "
        "WHERE r.day=? AND c.status='winner' GROUP BY c.agent_id", (day,)).fetchall()
    counts = {r["agent_id"]: int(r["n"]) for r in rows}
    return sum(counts.values()), counts


def apply_judgement(conn, round_row: dict, judged: dict, now: datetime) -> dict:
    data = judged.get("data") or {}
    cards = {c["candidate_id"]: c for c in (data.get("cards") or [])}
    rows = conn.execute("SELECT * FROM moment_candidates WHERE round_id=? ORDER BY id",
                        (round_row["id"],)).fetchall()
    scored = []
    for r in rows:
        c = cards.get(r["id"]) or {}
        scores = {k: max(0.0, min(5.0, float(c.get(k, 0) or 0))) for k in WEIGHTS}
        gate = c.get("gate") is True or str(c.get("gate", "")).lower() in ("true", "1", "yes")
        total = _total(scores) if gate else 0.0
        scored.append((r, scores, total, gate, str(c.get("reason") or "")[:500]))
    team_n, agent_n = _winner_counts(conn, round_row["day"])
    team_cap = roster_size(conn)
    eligible = [x for x in scored if x[3] and x[2] >= JUDGE_THRESHOLD
                and agent_n.get(x[0]["agent_id"], 0) < AGENT_DAILY_CAP]
    eligible.sort(key=lambda x: (-x[2], x[0]["id"]))
    winner_id = eligible[0][0]["id"] if eligible and team_n < team_cap else None
    for r, scores, total, gate, reason in scored:
        status = "winner" if r["id"] == winner_id else "rejected"
        conn.execute(
            "UPDATE moment_candidates SET work_score=?,interaction_score=?,execution_score=?,"
            "initiative_score=?,readability_score=?,citizenship_score=?,boundary_score=?,"
            "total_score=?,judge_reason=?,gate_ok=?,status=? WHERE id=?",
            (scores["work"], scores["interaction"], scores["execution"], scores["initiative"],
             scores["readability"], scores["citizenship"], scores["boundary"], total,
             reason, 1 if gate else 0, status, r["id"]))
    conn.execute(
        "UPDATE moment_rounds SET status='collected',winner_candidate_id=?,judge_model=?,"
        "judge_notes=?,updated_at=? WHERE id=?",
        (winner_id, judged.get("model"), str((judged.get("usage") or {}))[:500],
         now.strftime("%Y-%m-%d %H:%M:%S"), round_row["id"]))
    conn.commit()
    return {"ok": True, "round": round_row["id"], "winner": winner_id,
            "scores": len(scored), "threshold": JUDGE_THRESHOLD,
            "dry_run": publish_mode(conn) == "off"}


def tick(conn, now=None, judge=None) -> dict:
    """推进当前扫描点；有 judge 则评分 dry-run，没有则只收集。"""
    now = _now(now)
    round_row = current_round(conn, now)
    if not round_row:
        return {"ok": True, "skipped": "no_open_round"}
    mode = publish_mode(conn)
    rows = _candidate_rows(conn, round_row, now, local_only=(mode == "local"))
    for c in rows:
        conn.execute(
            "INSERT OR IGNORE INTO moment_candidates"
            "(id,round_id,agent_id,source_kind,source_ref,title,hook,evidence,self_score,status,created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (c["id"], c["round_id"], c["agent_id"], c["source_kind"], c["source_ref"],
             c["title"], c["hook"], c["evidence"], c["self_score"], "pending",
             now.strftime("%Y-%m-%d %H:%M:%S")))
    n = conn.execute("SELECT COUNT(*) AS n FROM moment_candidates WHERE round_id=?",
                     (round_row["id"],)).fetchone()["n"]
    if not n:
        conn.execute("UPDATE moment_rounds SET status='empty',updated_at=? WHERE id=?",
                     (now.strftime("%Y-%m-%d %H:%M:%S"), round_row["id"]))
        conn.commit()
        return {"ok": True, "round": round_row["id"], "status": "empty", "candidates": 0}
    if judge is None:
        conn.execute("UPDATE moment_rounds SET status='dry_run',updated_at=? WHERE id=?",
                     (now.strftime("%Y-%m-%d %H:%M:%S"), round_row["id"]))
        conn.commit()
        return {"ok": True, "round": round_row["id"], "status": "dry_run",
                "candidates": n, "dry_run": True}
    cands = [dict(r) for r in conn.execute(
        "SELECT * FROM moment_candidates WHERE round_id=? AND status='pending'",
        (round_row["id"],)).fetchall()]
    try:
        judged = judge(cands)
        result = apply_judgement(conn, round_row, judged, now)
        if result.get("winner") and mode != "off":
            c = conn.execute("SELECT * FROM moment_candidates WHERE id=?",
                             (result["winner"],)).fetchone()
            if c:
                local_ok = mode != "local" or c["agent_id"] in PUBLISH_LOCAL
                if local_ok and (mode != "local" or _published_today(conn, round_row["day"]) < LOCAL_DAILY_CAP):
                    q = queue_agent_publish(conn, round_row, dict(c), now=now)
                    result.update({"queued": True, "agent_id": c["agent_id"],
                                   "command_id": q.get("command_id")})
                else:
                    result["publish_skipped"] = "not_local" if not local_ok else "local_daily_cap"
        return result
    except Exception as e:  # noqa: BLE001
        conn.execute("UPDATE moment_rounds SET status='dry_run',judge_notes=?,updated_at=? WHERE id=?",
                     (("JUDGE_ERROR: " + str(e))[:500], now.strftime("%Y-%m-%d %H:%M:%S"), round_row["id"]))
        conn.commit()
        return {"ok": False, "round": round_row["id"], "status": "dry_run",
                "error": str(e)[:300], "candidates": n}


def summary(conn, now=None) -> dict:
    now = _now(now)
    today = _day_str(now)
    future = [h for h in SCAN_HOURS if _slot_dt(now, h) > now]
    if future:
        next_hour, next_day = future[0], False
    else:
        next_hour, next_day = SCAN_HOURS[0], True
    rounds = conn.execute(
        "SELECT COUNT(*) AS n FROM moment_rounds WHERE day=?", (today,)).fetchone()["n"]
    candidates = conn.execute(
        "SELECT COUNT(*) AS n FROM moment_candidates c JOIN moment_rounds r ON r.id=c.round_id "
        "WHERE r.day=?", (today,)).fetchone()["n"]
    last = conn.execute(
        "SELECT r.slot,r.status,r.published_post_id,c.agent_id,a.name AS agent_name FROM moment_rounds r "
        "LEFT JOIN moment_candidates c ON c.id=r.winner_candidate_id "
        "LEFT JOIN agents a ON a.id=c.agent_id "
        "WHERE r.day=? ORDER BY r.slot DESC LIMIT 1", (today,)).fetchone()
    return {
        "team_cap": roster_size(conn),
        "agent_cap": AGENT_DAILY_CAP,
        "next_slot": _slot_str(next_hour),
        "next_day": next_day,
        "rounds": int(rounds or 0),
        "candidates": int(candidates or 0),
        "last_slot": last["slot"] if last else "",
        "last_status": last["status"] if last else "",
        "last_winner": last["agent_name"] if last and last["agent_name"] else "",
        "last_post": last["published_post_id"] if last and last["published_post_id"] else "",
        "publish_mode": publish_mode(conn),
        "dry_run": publish_mode(conn) == "off",
    }
