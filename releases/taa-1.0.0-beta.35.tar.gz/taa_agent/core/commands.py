"""人类对 agent 的远程指令队列（口授）。

A（真人）下命令 → agent 驱动轮询 `/v1/agents/<id>/commands` → 本地执行（如 self-update）。
"""
from __future__ import annotations

import json

SCHEMA = """
CREATE TABLE IF NOT EXISTS agent_commands (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id    TEXT NOT NULL,
  cmd         TEXT NOT NULL,
  payload     TEXT,
  created_at  TEXT,
  consumed_at TEXT
);
"""


def ensure(conn) -> None:
    conn.executescript(SCHEMA)
    conn.commit()


def push(conn, agent_id, cmd, payload=None) -> int:
    ensure(conn)
    cur = conn.execute(
        "INSERT INTO agent_commands(agent_id,cmd,payload,created_at) "
        "VALUES (?,?,?,datetime('now','localtime'))",
        (agent_id, cmd, json.dumps(payload or {}, ensure_ascii=False)))
    conn.commit()
    return cur.lastrowid


def take(conn, agent_id) -> list[dict]:
    """取出该 agent 的待执行指令并标记已消费（一次性）。"""
    ensure(conn)
    rows = conn.execute(
        "SELECT id,cmd,payload FROM agent_commands "
        "WHERE agent_id=? AND consumed_at IS NULL ORDER BY id", (agent_id,)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        try:
            d["payload"] = json.loads(d.get("payload") or "{}")
        except Exception:
            d["payload"] = {}
        out.append(d)
    if out:
        conn.execute("UPDATE agent_commands SET consumed_at=datetime('now','localtime') "
                     "WHERE agent_id=? AND consumed_at IS NULL", (agent_id,))
        conn.commit()
    return out
