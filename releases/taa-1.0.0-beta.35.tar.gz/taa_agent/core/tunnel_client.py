"""跨局域网协作 · 节点侧隧道客户端（只出站，把 /n/<node>/… 转给本机 6080）。

与 `core/tunnel.py` 配对；节点无需公网 IP。请求路径已由中心剥掉 `/n/<node>` 前缀，
因此本机 HMAC 签名（只签 `/v1/...`）原样有效。

配置：
    tunnel:
      enabled: true
      hub_url: "https://hub.example.com"   # 留空则复用 hub.url
      token: "<强随机串>"                  # 留空则复用 hub.token
      node_id: ""                          # 留空用本机别名（如 MBP32G）
      local: "http://127.0.0.1:6080"
"""
from __future__ import annotations

import base64
import concurrent.futures
import http.client
import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

UA = "taa-tunnel/1"
FORWARD_HEADERS = ("content-type", "accept", "authorization", "user-agent",
                   "x-teamai-key", "x-teamai-timestamp", "x-teamai-nonce", "x-teamai-signature",
                   "x-enroll-token", "x-forwarded-for")
RESP_HEADERS = ("content-type", "location", "set-cookie", "cache-control", "etag")


class TunnelClient:
    def __init__(self, hub_url: str, token: str, node_id: str,
                 local: str = "http://127.0.0.1:6080", workers: int = 8,
                 pull_wait: float = 20.0, timeout: float = 45.0):
        self.hub_url = (hub_url or "").rstrip("/")
        self.token = (token or "").strip()
        self.node_id = node_id or "node"
        self.local = (local or "http://127.0.0.1:6080").rstrip("/")
        self.pull_wait = max(1.0, float(pull_wait or 20))
        self.timeout = max(5.0, float(timeout or 45))
        self._quote = urllib.parse.quote(self.node_id, safe="")
        self._prefix = f"/n/{self._quote}"
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._pool = concurrent.futures.ThreadPoolExecutor(max_workers=max(1, int(workers or 8)),
                                                           thread_name_prefix="tunnel")
        self._lock = threading.RLock()
        self._last_ok = 0.0
        self._last_error = ""
        self._served = 0
        self._errors = 0

    # ---------------- 生命周期 ----------------
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="tunnel-client", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        t = self._thread
        if t and t.is_alive() and t is not threading.current_thread():
            t.join(timeout=3)
        self._pool.shutdown(wait=False, cancel_futures=True)

    def status(self) -> dict:
        with self._lock:
            return {"enabled": True, "node_id": self.node_id, "hub_url": self.hub_url,
                    "connected": bool(self._last_ok and time.time() - self._last_ok < 30),
                    "last_ok_at": self._last_ok or None, "last_error": self._last_error,
                    "served": self._served, "errors": self._errors}

    # ---------------- 主循环 ----------------
    def _loop(self) -> None:
        backoff = 1.0
        while not self._stop.is_set():
            try:
                # 首次/长时间未成功时先做一次 wait=0 探测：长轮询会挂起到有请求或超时，
                # 若只靠它更新状态，页面会误报"未连接"最多 pull_wait 秒。
                if not self._last_ok or time.time() - self._last_ok > 60:
                    self._probe()
                req = self._pull()
                self._mark_ok()
                backoff = 1.0
                if req:
                    self._pool.submit(self._handle, req)
                    continue
            except Exception as e:  # noqa: BLE001
                self._mark_error(e)
                self._stop.wait(backoff)
                backoff = min(backoff * 2, 30.0)

    def _mark_ok(self) -> None:
        with self._lock:
            self._last_ok = time.time()
            self._last_error = ""

    def _mark_error(self, e: Exception) -> None:
        with self._lock:
            self._last_error = f"{type(e).__name__}: {str(e)[:200]}"

    # ---------------- 中心 HTTP ----------------
    def _headers(self) -> dict:
        return {"content-type": "application/json", "user-agent": UA,
                "x-hub-token": self.token}

    def _probe(self) -> None:
        """wait=0：注册节点并确认中心可达（立即 204）。"""
        url = f"{self.hub_url}/v1/tunnel/{self._quote}/pull?wait=0"
        req = urllib.request.Request(url, headers=self._headers())
        with urllib.request.urlopen(req, timeout=10) as r:
            r.read()
        self._mark_ok()

    def _pull(self) -> dict | None:
        url = f"{self.hub_url}/v1/tunnel/{self._quote}/pull?wait={self.pull_wait:g}"
        req = urllib.request.Request(url, headers=self._headers())
        with urllib.request.urlopen(req, timeout=self.pull_wait + 15) as r:
            if r.status == 204:
                return None
            raw = r.read()
            return json.loads(raw.decode("utf-8")) if raw else None

    def _handle(self, r: dict) -> None:
        rid = r.get("rid")
        body = base64.b64decode(r.get("body") or "")
        headers = {k: v for k, v in (r.get("headers") or []) if k.lower() in FORWARD_HEADERS}
        path = r.get("path") or "/"
        status, rh, rb = 502, [("content-type", "application/json")], b'{"ok":false,"error":"local unreachable"}'
        try:
            status, rh, rb = self._dispatch(r.get("method") or "GET", path, headers, body)
            rh, rb = self._rewrite_proxy_paths(rh, rb)
            with self._lock:
                self._served += 1
        except Exception as e:  # noqa: BLE001
            with self._lock:
                self._errors += 1
            rb = json.dumps({"ok": False, "error": f"tunnel local error: {e}"[:300]}).encode()
            rh = [("content-type", "application/json")]
        try:
            payload = json.dumps({"rid": rid, "status": status, "headers": rh,
                                  "body": base64.b64encode(rb).decode("ascii")}).encode()
            req = urllib.request.Request(
                f"{self.hub_url}/v1/tunnel/{self._quote}/respond", data=payload, method="POST",
                headers=self._headers())
            urllib.request.urlopen(req, timeout=15).read()
        except Exception as e:  # noqa: BLE001
            self._mark_error(e)

    def _rewrite_proxy_paths(self, headers: list[tuple[str, str]], body: bytes):
        """Keep root-relative app/static URLs inside the /n/<node>/ proxy prefix.

        The API/CLI path does not need this; this makes the existing /app UI work
        through the reverse tunnel without a second app or per-page base paths.
        """
        content_type = ""
        for k, v in headers:
            if k.lower() == "content-type":
                content_type = v.lower()
                break
        text_like = any(x in content_type for x in ("text/html", "text/css", "javascript"))
        if text_like and body:
            try:
                text = body.decode("utf-8")
            except UnicodeDecodeError:
                text = body.decode("utf-8", "ignore")
            for root in ("/app", "/static", "/avatar", "/setup", "/ca.crt", "/ca.sha256"):
                for quote_char in ('"', "'"):
                    token = quote_char + root
                    text = text.replace(token, quote_char + self._prefix + root)
            body = text.encode("utf-8")
        out = []
        for k, v in headers:
            if k.lower() == "location" and v.startswith("/"):
                v = self._prefix + v
            out.append((k, v))
        return out, body

    def _dispatch(self, method: str, path: str, headers: dict, body: bytes):
        """把请求打到本机服务；用 http.client 以保留状态码/多值头。"""
        u = urllib.parse.urlsplit(self.local)
        conn = http.client.HTTPConnection(u.hostname, u.port or 80, timeout=self.timeout)
        try:
            conn.request(method, path, body=body or None, headers=headers or {})
            resp = conn.getresponse()
            data = resp.read()
            rh = [(k, v) for k in resp.headers.keys() if k.lower() in RESP_HEADERS
                  for v in resp.headers.get_all(k)]
            # get_all 可能重复，去重保序
            seen, out = set(), []
            for k, v in rh:
                if (k.lower(), v) not in seen:
                    seen.add((k.lower(), v))
                    out.append((k, v))
            return resp.status, out, data
        finally:
            conn.close()
