"""确定性任务打分（D8/D9）——选任务不靠 LLM 自由发挥。

Score = Σ w_pos · feature − Σ w_neg · penalty   （feature ∈ [0,1]）
LLM 只负责把任务卡抽成结构化特征、写一句认领理由。
"""
from __future__ import annotations

from .persona import DEFAULT_WEIGHTS

POSITIVE = ("skill_fit", "career_gain", "strategy_align",
            "priority_bias", "interest_novelty", "resource_fit")
NEGATIVE = ("load_penalty", "risk_penalty")

MIN_SCORE = 0.15

# 价值观 -> 任务权重（调制，不覆写基线）
VALUE_TO_WEIGHT = {
    "novelty": "interest_novelty",
    "rigor": "skill_fit",
    "collaboration": "strategy_align",
    "speed": "priority_bias",
}


def modulate_weights(weights: dict, values: dict | None) -> dict:
    """用价值观对权重做有界乘法调制（0.5+v ∈ [0.5,1.5]）。"""
    out = dict(weights)
    for vk, wk in VALUE_TO_WEIGHT.items():
        v = (values or {}).get(vk)
        if v is None:
            continue
        out[wk] = round(out.get(wk, 0.1) * (0.5 + float(v)), 4)
    return out


def _skill_index(persona: dict) -> dict:
    return {str(s.get("name", "")).lower(): s for s in persona.get("skills", [])}


def _req_skills(task: dict) -> list[dict]:
    out = []
    for r in task.get("required_skills") or []:
        if isinstance(r, dict):
            out.append({"name": str(r.get("name", "")), "level": float(r.get("level", 0.5))})
        else:
            out.append({"name": str(r), "level": 0.5})
    return out


def skill_fit(persona: dict, task: dict) -> float:
    req = _req_skills(task)
    if not req:
        return 0.5
    idx = _skill_index(persona)
    vals = []
    for r in req:
        s = idx.get(r["name"].lower())
        lvl = float(s.get("level", 0.0)) if s else 0.0
        need = max(r["level"], 0.05)
        vals.append(min(lvl / need, 1.0))
    return sum(vals) / len(vals)


def career_gain(persona: dict, task: dict) -> float:
    """任务对目标技能的成长预期：长板型看重 deepen，多面手看重 broaden/new。"""
    cs = persona.get("career_strategy", {})
    prefer_new = float(cs.get("prefer_new_skill", 0.4))
    idx = _skill_index(persona)
    req = _req_skills(task)
    if not req:
        return 0.4
    gains = []
    for r in req:
        s = idx.get(r["name"].lower())
        if not s:
            gains.append(0.6 if prefer_new >= 0.5 else 0.3)
            continue
        lvl = float(s.get("level", 0.0))
        target = float(s.get("target", lvl))
        strategy = s.get("strategy", "broaden")
        room = max(0.0, min(1.0, target - lvl))
        gains.append(room if strategy == "deepen" else 0.5)
    return sum(gains) / len(gains)


def strategy_align(persona: dict, task: dict) -> float:
    tags = {str(t).lower() for t in (task.get("tags") or [])}
    if not tags:
        return 0.5
    known = {str(i).lower() for i in persona.get("interests", [])}
    known |= set(_skill_index(persona))
    return len(tags & known) / len(tags)


def priority_bias(task: dict) -> float:
    # ★ 2026-10-09 修复（Carol@B 机定位 / Alice 上游等价实现）：
    #   原 `priority/5.0` 与「P1 最高」约定相反（P1→0.2 最低），导致 for_agent 把高优先级压到底、
    #   自动认领永远先挑陈旧任务。改为 P1→1.0 … P5→0.2。
    p = min(max(int(task.get("priority", 1)), 1), 5)
    return (6 - p) / 5.0


def interest_novelty(persona: dict, task: dict) -> float:
    return 1.0 - strategy_align(persona, task)


def resource_fit(task: dict, node: dict | None) -> float:
    if not node:
        return 0.5
    req = task.get("resource_req") or {}
    ok = 1.0
    if req.get("min_ram_gb") and float(req["min_ram_gb"]) > float(node.get("ram_gb") or 0):
        ok = 0.2
    if req.get("min_disk_gb") and float(req["min_disk_gb"]) > float(node.get("disk_free_gb") or 0):
        ok = 0.2
    if req.get("gpu") and not (node.get("gpu") or ""):
        ok = min(ok, 0.4)
    return ok


def load_penalty(persona: dict, wip: int) -> float:
    max_par = int(persona.get("collaboration", {}).get("max_parallel_tasks", 2)) or 2
    return min(wip / max_par, 1.0)


def risk_penalty(persona: dict, task: dict) -> float:
    cs = persona.get("career_strategy", {})
    appetite = float(cs.get("risk_appetite", 0.5))
    diff = float(task.get("complexity", task.get("difficulty", 0.5)) or 0.5)
    return diff * (1.0 - appetite)


def score_task(persona: dict, task: dict, wip: int, node: dict | None = None,
               values: dict | None = None) -> tuple[float, dict]:
    feats = {
        "skill_fit": skill_fit(persona, task),
        "career_gain": career_gain(persona, task),
        "strategy_align": strategy_align(persona, task),
        "priority_bias": priority_bias(task),
        "interest_novelty": interest_novelty(persona, task),
        "resource_fit": resource_fit(task, node),
        "load_penalty": load_penalty(persona, wip),
        "risk_penalty": risk_penalty(persona, task),
    }
    weights = {**DEFAULT_WEIGHTS, **persona.get("scoring_weights", {})}
    if values:
        weights = modulate_weights(weights, values)
    score = 0.0
    for k in POSITIVE:
        score += weights.get(k, 0.0) * feats[k]
    for k in NEGATIVE:
        score -= weights.get(k, 0.0) * feats[k]
    return round(score, 4), {k: round(v, 4) for k, v in feats.items()}
