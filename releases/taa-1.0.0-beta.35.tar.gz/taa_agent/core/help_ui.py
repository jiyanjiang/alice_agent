"""本地帮助页：模型 Key、HTTPS/CA。"""


def page_https_help(shell, host: str, port: int, fingerprint: str, ca_url: str,
                    side: str = "", detail: str = "") -> str:
    app_url = f"https://{host}:{port}/app"
    body = f"""
  <section class="card" style="padding:20px 22px">
    <div class="kicker">本地访问 · HTTPS / CA</div>
    <h2 style="margin:6px 0 8px">HTTPS 已启用，CA 需要信任一次</h2>
    <p class="dim" style="margin:0 0 14px">浏览器或远程 TAA 第一次访问 HTTPS 时，需要信任这张本地证书。证书只含公钥，不包含私钥。</p>
    <div class="kv"><span>稳定地址</span><b><a href="{app_url}">{app_url}</a></b></div>
    <div class="kv"><span>CA 地址</span><b><a href="{ca_url}">{ca_url}</a></b></div>
    <div class="kv"><span>SHA-256</span><b class="mono">{fingerprint}</b></div>
  </section>

  <section class="card" style="padding:18px 20px;margin-top:12px">
    <div class="kicker">1 · 下载并校验</div>
    <pre>curl -fsS {ca_url} -o ~/.taa/server.crt
shasum -a 256 ~/.taa/server.crt
# 期望
{fingerprint}  server.crt</pre>
    <p class="dim">远程 TAA 也用同一张证书；不要使用 <code>--insecure</code> 代替校验。</p>
  </section>

  <section class="card" style="padding:18px 20px;margin-top:12px">
    <div class="kicker">2 · 本机信任（macOS）</div>
    <pre>sudo security add-trusted-cert -d -r trustRoot \\
  -k /Library/Keychains/System.keychain ~/.taa/server.crt</pre>
    <p class="dim">执行后重开浏览器。不要删除私钥；需要撤销时从钥匙串移除该证书。</p>
  </section>

  <section class="card" style="padding:18px 20px;margin-top:12px">
    <div class="kicker">2b · iPhone / 华为 Android 信任</div>
    <p style="margin:6px 0 8px"><b>iPhone：</b>用 Safari 打开 <code>{ca_url}</code>，允许下载描述文件；设置 → 已下载描述文件 → 安装；设置 → 通用 → 关于本机 → 证书信任设置 → 打开 <code>teamai</code> 完全信任。</p>
    <p style="margin:6px 0 8px"><b>华为 / Android：</b>用系统浏览器（不要用微信内置浏览器）打开 <code>{ca_url}</code> 下载 CA；设置 → 安全 → 更多安全设置 → 加密和凭据 → 安装证书 → CA 证书 → 选择下载的 <code>server.crt</code>；完成后重开微信。</p>
    <p class="dim">证书只包含公钥；安装 CA 不会泄露私钥。若仍警告，确认 SAN 含当前 IP，且安装的是本机 <code>server.crt</code>。部分 Android 版微信不信任用户 CA，此时继续访问只读分享，或改用有公网有效证书的入口。</p>
  </section>

  <section class="card" style="padding:18px 20px;margin-top:12px">
    <div class="kicker">3 · 远程 TAA</div>
    <pre>--url https://{host}:{port}
--ca ~/.taa/server.crt</pre>
    <p class="dim">先用 <code>curl --cacert ~/.taa/server.crt {app_url.replace('/app','/v1/health')}</code> 验证 200，再切换进程；旧 HTTP 兼容口不要先关。</p>
  </section>

  <section class="card" style="padding:18px 20px;margin-top:12px">
    <div class="kicker">常见问题</div>
    <div class="faq"><b>浏览器仍警告</b><span>证书未安装到系统钥匙串，或证书 SAN 不包含当前地址；重新生成证书后需要重新信任。</span></div>
    <div class="faq"><b>curl 报证书错误</b><span>确认命令带 <code>--cacert ~/.taa/server.crt</code>；不要只改 HTTPS 而继续用 HTTP 的旧证书。</span></div>
    <div class="faq"><b>远程节点连不上</b><span>先用 curl 验证 6443，再检查防火墙；不要先关闭 6080。</span></div>
  </section>

  <style>
  .kv b.mono{{font-size:12px;word-break:break-all}}
  .faq{{display:grid;grid-template-columns:130px 1fr;gap:10px;padding:8px 0;border-bottom:1px solid var(--hair);font-size:13.5px;line-height:1.7}}
  .faq:last-child{{border-bottom:0}}.faq span{{color:var(--ink-soft)}}
  @media(max-width:640px){{.faq{{grid-template-columns:1fr;gap:2px}}}}
  </style>"""
    if not side:
        side = ('<div class="sidebox"><div class="shead">HTTPS HELP</div>'
                '<a class="citem on" href="#"><span class="cname">CA 与信任</span></a>'
                '<a class="citem" href="/app/settings"><span class="cname">回设置 →</span></a></div>')
    return shell("HTTPS / CA 帮助", body, "tools", "本地证书与远程节点",
                 side=side, detail=detail)



def page_keys_help(shell, side: str = "") -> str:
    body = """
  <section class="card" style="padding:20px 22px" id="agentkey">
    <div class="kicker">使用帮助 · AGENT KEY</div>
    <h2 style="margin:6px 0 8px">Agent Key 管身份，模型 Key 管调用</h2>
    <p class="dim" style="margin:0 0 12px">Agent key（<code>taa_...</code>）用于安装/激活和身份；模型 key（<code>sk-...</code>）用于调用模型。两者都不要发到群聊、帖子、截图或公开仓库。</p>
    <p style="margin:8px 0 4px"><b>公开包安装（下载不需要 key；安装必须有 agent key）：</b></p>
    <pre>curl -fL https://raw.githubusercontent.com/jiyanjiang/team_ai_alice/main/releases/taa-complete-0.4.1.tar.gz -o /tmp/taa.tgz
mkdir -p /tmp/taa-install &amp;&amp; tar xzf /tmp/taa.tgz -C /tmp/taa-install
/tmp/taa-install/taa_agent/install.sh --key taa_xxx</pre>
    <p style="margin:8px 0 4px"><b>同 LAN 有在线节点时优先：</b></p>
    <pre>curl -fL "http://&lt;node-ip&gt;:6080/install.sh" -o /tmp/taa-install.sh
bash /tmp/taa-install.sh --key taa_xxx \
  --from "http://&lt;node-ip&gt;:6080/dist/taa-complete-latest.tar.gz"</pre>
    <p class="dim" style="margin:10px 0 0">没有 key 时安装器会退出，不写配置。第二台电脑请在中心新建第二个 agent + 第二把 key；同一台电脑再加一个 agent 用 <code>taa agent add --key &lt;second-key&gt;</code>。完整公开文档见 <a href="https://github.com/jiyanjiang/team_ai_alice" target="_blank" rel="noopener">team_ai_alice</a>。</p>
  </section>

  <section class="card" style="padding:20px 22px;margin-top:12px" id="keys">
    <div class="kicker">使用帮助 · 模型 KEY</div>
    <h2 style="margin:6px 0 8px">两个模型 Key，任选其一；建议都配</h2>
    <p class="dim" style="margin:0 0 12px">TAA 的 AI 写 PPT 需要模型 Key。Key 只存本机（<code>~/.taa/config.toml</code>，权限 600），中心不保存、也不代扣费。</p>
    <div class="helpgrid">
      <div class="helpcard">
        <div class="kicker">推荐 1 · 最容易上手</div>
        <h3>DeepSeek</h3>
        <ol>
          <li>打开 <a href="https://platform.deepseek.com/" target="_blank" rel="noopener">platform.deepseek.com</a>，注册 / 登录。</li>
          <li>进入「充值 / Billing」，按量付费，先充小额即可。</li>
          <li>进入「API keys」→ 创建 Key → 复制 <code>sk-...</code>（通常只显示一次）。</li>
          <li>回到 TAA：设置 → 模型 KEY → 更新 DeepSeek key → 保存。</li>
        </ol>
      </div>
      <div class="helpcard">
        <div class="kicker">推荐 2 · 国内直连</div>
        <h3>阿里云百炼</h3>
        <ol>
          <li>打开 <a href="https://bailian.console.aliyun.com/" target="_blank" rel="noopener">bailian.console.aliyun.com</a>，开通百炼（需阿里云实名）。</li>
          <li>在控制台充值 / 领取免费额度；模型选 <code>qwen-plus</code> 即可。</li>
          <li>进入「API-KEY 管理」→ 创建 API-KEY → 复制 <code>sk-...</code>。</li>
          <li>回到 TAA：设置 → 模型 KEY → 更新阿里云百炼 key → 保存。</li>
        </ol>
        <p class="dim">注意：要的是百炼「API-KEY」，不是阿里云账号的 AccessKey。</p>
      </div>
    </div>
    <p class="dim" style="margin:12px 0 0">详细说明与常见报错见 <a href="https://alice.loomsci.com/guide#keys" target="_blank" rel="noopener">中心使用指引 · 模型 Key</a>。PPT 默认先试 DeepSeek，未配置或调用失败时自动改用阿里云百炼。</p>
  </section>

  <section class="card" style="padding:18px 20px;margin-top:12px" id="where">
    <div class="kicker">在哪里填</div>
    <p style="margin:6px 0 8px">本地 TAA → 设置 → 模型 KEY。保存后立即生效，不需要重启服务。</p>
    <p class="dim" style="margin:0">Key 不会上传中心；不要把 Key 发到群聊、帖子、截图或 git。怀疑泄露就到平台控制台删除并新建。</p>
  </section>

  <section class="card" style="padding:18px 20px;margin-top:12px" id="cost">
    <div class="kicker">费用怎么算</div>
    <p style="margin:6px 0 8px">按 token 计费。一版 4–8 页 PPT 通常只调用一次模型，费用很低；先充 10–20 元足够试很多次。</p>
    <p class="dim" style="margin:0">如果生成失败，不会产生“半成品扣费”之外的额外费用；平台按实际请求计费。</p>
  </section>

  <section class="card" style="padding:18px 20px;margin-top:12px" id="faq">
    <div class="kicker">常见问题</div>
    <div class="faq"><b>401 / 403</b><span>Key 复制错、已删除、未开通模型，或账号欠费。重新创建 Key，确认余额。</span></div>
    <div class="faq"><b>余额不足</b><span>到对应平台充值；阿里云百炼记得开通的是“百炼”服务。</span></div>
    <div class="faq"><b>阿里云用哪个 Key</b><span>用百炼控制台的 API-KEY（<code>sk-...</code>），不是 AccessKey ID / Secret。</span></div>
    <div class="faq"><b>生成很慢</b><span>模型在排队或网络抖动；TAA 会先试 DeepSeek，再回退阿里。稍后重试即可。</span></div>
  </section>

  <section class="card" style="padding:18px 20px;margin-top:12px" id="agent">
    <div class="kicker">不想自己看？让你的 agent 来</div>
    <p class="dim" style="margin:6px 0 8px">把下面这段话复制给本地 agent（IDE 或聊天界面）——它比你更熟配置文件和报错。</p>
    <pre class="agentprompt" id="agentprompt">请按 TAA 使用指引，帮我检查本机 ~/.taa/config.toml 里是否配置了 DeepSeek 或阿里云百炼的模型 Key。
不要读取或输出完整 Key；只告诉我：1) 是否已配置；2) 缺哪个；3) 下一步在 TAA 设置 → 模型 KEY 怎么填；4) 如何用 4 页 PPT 做一次最小验证。</pre>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn" type="button" onclick="navigator.clipboard&&navigator.clipboard.writeText(document.getElementById('agentprompt').textContent);this.textContent='已复制'">复制给 agent</button>
      <a class="btn" href="/app/chats">去会话里问 agent →</a>
    </div>
  </section>

  <style>
  .helpgrid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .helpcard{background:var(--porcelain);border:1px solid var(--hair);border-radius:14px;padding:14px 16px}
  .helpcard h3{margin:4px 0 8px;font-family:var(--serif);font-size:19px}
  .helpcard ol{margin:0;padding-left:20px;font-size:13.5px;line-height:1.85;color:var(--ink-soft)}
  .helpcard a{color:var(--ink);text-decoration:underline;text-underline-offset:3px}
  .helpcard code,.agentprompt{background:var(--lace);border:1px solid var(--hair);border-radius:6px;padding:1px 5px;font-size:12.5px}
  .faq{display:grid;grid-template-columns:110px 1fr;gap:10px;padding:8px 0;border-bottom:1px solid var(--hair);font-size:13.5px;line-height:1.7}
  .faq:last-child{border-bottom:0}.faq span{color:var(--ink-soft)}
  .agentprompt{display:block;padding:12px;white-space:pre-wrap;line-height:1.7;margin:8px 0 10px}
  @media(max-width:720px){.helpgrid{grid-template-columns:1fr}.faq{grid-template-columns:1fr;gap:2px}}
  </style>"""
    if not side:
        side = ('<div class="sidebox"><div class="shead">KEY HELP</div>'
                '<a class="citem" href="#agentkey"><span class="cname">Agent key / 安装</span></a>'
                '<a class="citem on" href="#keys"><span class="cname">模型 Key 申请</span></a>'
                '<a class="citem" href="#cost"><span class="cname">费用</span></a>'
                '<a class="citem" href="#faq"><span class="cname">常见问题</span></a>'
                '<a class="citem" href="#agent"><span class="cname">让 agent 帮我</span></a>'
                '<a class="citem" href="/app/settings#models"><span class="cname">去设置 Key →</span></a></div>')
    detail = ('<div class="card" style="padding:16px 18px"><div class="kicker">安全</div>'
              '<p class="dim" style="margin:8px 0 0">Agent key 管身份，模型 key 管调用。两者都只留本机；中心、群聊、帖子都不需要它们。不要把 Key 截图发人。</p>'
              '<p class="dim" style="margin:8px 0 0"><a href="https://github.com/jiyanjiang/team_ai_alice" target="_blank" rel="noopener">公开文档</a> · '
              '<a href="https://alice.loomsci.com/guide" target="_blank" rel="noopener">中心使用指引</a></p></div>')
    return shell("Key 帮助", body, "tools", "Agent key / DeepSeek / 阿里云百炼", side=side, detail=detail)
