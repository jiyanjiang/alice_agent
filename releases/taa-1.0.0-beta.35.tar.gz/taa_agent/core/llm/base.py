"""LLM 适配层基类：把"调用某个 coding agent CLI"统一成一个接口。

- 我们**直接调用** LLM/agent CLI（opencode / omp / qoder），不把它当业务状态。
- 统一接口：build()（拼命令，便于单测）+ run()（执行，含超时/杀进程组）。
"""
from __future__ import annotations

import os
import shutil
import signal
import subprocess
from dataclasses import dataclass


@dataclass
class LLMResult:
    ok: bool
    text: str
    returncode: int | None = None


# ---- 成本策略：全队默认模型（Owner 2026-10-14：「所有生成统一用 ds flash，更便宜更快」）----
DEFAULT_MODEL = "deepseek/deepseek-flash"     # DeepSeek V4.1 Flash


def effective_model(model: str | None) -> str:
    """决定"这次到底用哪个模型"——**单一覆盖点**，不必逐个调用点改。

    优先级：config `llm.model` / 环境变量 `TEAMAI_MODEL`（**一律覆盖调用点传参**，便于全局降本）
            > 调用点显式传入 > DEFAULT_MODEL。
    需要临时用贵模型（如 ds v4 pro）：设 `TEAMAI_MODEL=deepseek/deepseek-v4-pro`；
    需要让调用点的显式选择重新生效：设 `TEAMAI_MODEL_ALLOW_OVERRIDE=1`。
    """
    from .. import config as _cfg
    forced = (_cfg.get("llm.model", env="TEAMAI_MODEL") or "").strip()
    if forced and os.environ.get("TEAMAI_MODEL_ALLOW_OVERRIDE") != "1":
        return forced
    return model or forced or DEFAULT_MODEL


class LLMAdapter:
    name = "base"

    def available(self) -> bool:
        return True

    def build(self, prompt: str, *, model: str | None = None, cwd: str = ".",
              files: list[str] | None = None, title: str | None = None) -> list[str]:
        raise NotImplementedError
    def env(self, extra: dict | None = None) -> dict:
        e = dict(os.environ)
        if extra:
            e.update(extra)
        return e

    def run(self, prompt: str, *, model: str | None = None, cwd: str = ".",
            files: list[str] | None = None, title: str | None = None, timeout: int = 180,
            env_extra: dict | None = None, stdin_text: str | None = None) -> LLMResult:
        cmd = self.build(prompt, model=effective_model(model), cwd=cwd, files=files, title=title)
        try:
            proc = subprocess.Popen(cmd, cwd=str(cwd), env=self.env(env_extra),
                                    stdin=(subprocess.PIPE if stdin_text is not None else subprocess.DEVNULL),
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                                    start_new_session=True)
        except FileNotFoundError:
            return LLMResult(False, f"[llm] 未找到命令：{cmd[0]}", None)
        try:
            out, err = proc.communicate(input=stdin_text, timeout=timeout)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)   # 杀整组，避免孙进程占管道
            except Exception:
                proc.kill()
            out, err = proc.communicate()
            return LLMResult(False, (out or "") + (err or ""), None)
        return LLMResult(proc.returncode == 0, (out or "") + (err or ""), proc.returncode)
