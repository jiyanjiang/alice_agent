"""opencode 适配器：`opencode run --dir <cwd> --model <m> --title <t> "<prompt>" [-f file]`。"""
from __future__ import annotations

from core.binpath import resolve as _resolve

import json
import os
import shutil
from pathlib import Path

from .base import LLMAdapter

ROOT = Path(__file__).resolve().parent.parent.parent

# 随包声明的可用模型（缺哪个补哪个，不覆盖本地已有）
# deepseek-flash = DeepSeek-V4.1-Flash，input_modalities 含 image → **视觉模型**
DEEPSEEK_MODELS = {
    "deepseek-chat": {"name": "DeepSeek Chat (flash)"},
    "deepseek-reasoner": {"name": "DeepSeek Reasoner"},
    "deepseek-v4-pro": {"name": "DeepSeek V4 Pro"},
    "deepseek-flash": {"name": "DeepSeek V4.1 Flash (vision)"},
    "deepseek-v4-flash-vision-exp": {"name": "DeepSeek V4 Flash Vision Exp"},
}


def _candidates(name: str) -> list[str]:
    """服务进程 PATH 被收窄（launchd 下只有 /usr/bin:/bin）→ 必须解析**绝对路径**。
    自查：终端里能找到、服务里找不到，就是这个坑（与 ffmpeg 那次同型）。"""
    import os as _os, shutil as _sh
    out = [_os.environ.get("OPENCODE_BIN") or "",
           _sh.which(name) or "",
           f"/opt/homebrew/bin/{name}", f"/usr/local/bin/{name}",
           _os.path.expanduser(f"~/.opencode/bin/{name}"),
           _os.path.expanduser(f"~/.local/bin/{name}"),
           _os.path.expanduser(f"~/.bun/bin/{name}")]
    return [c for c in out if c]


def _bin(name: str = "opencode") -> str:
    return _resolve(name)             # 统一解析（见 core/binpath.py）


def _deepseek_key(root: Path) -> str | None:
    try:
        from .. import config
        k = config.deepseek_key()
        if k:
            return k
    except Exception:
        pass
    for p in (root / "bootstrap" / "deepseek.key",):
        try:
            v = p.read_text(encoding="utf-8").strip()
            if v:
                return v
        except OSError:
            pass
    return os.environ.get("DEEPSEEK_API_KEY") or os.environ.get("DS_KEY")


def ensure_config(root: Path = ROOT) -> Path | None:
    """确保 `runtime/opencode.deepseek.json` 存在且包含随包声明的模型（合并式）。

    保留本地已有 provider/模型/自定义项；只补缺的模型，并更新 key（若有稳定来源）。
    """
    key = _deepseek_key(root)
    cfg = root / "runtime" / "opencode.deepseek.json"
    try:
        cur = json.loads(cfg.read_text(encoding="utf-8"))
    except Exception:
        cur = {}
    if not key and not cur:
        return None
    cfg.parent.mkdir(parents=True, exist_ok=True)
    prov = cur.setdefault("provider", {}).setdefault("deepseek", {})
    prov.setdefault("npm", "@ai-sdk/openai-compatible")
    prov.setdefault("name", "DeepSeek (self key)")
    opts = prov.setdefault("options", {})
    opts.setdefault("baseURL", "https://api.deepseek.com/v1")
    if key:
        opts["apiKey"] = key
    models = prov.setdefault("models", {})
    for mid, spec in DEEPSEEK_MODELS.items():
        if mid not in models:
            models[mid] = dict(spec)
    cur.setdefault("model", "deepseek/deepseek-flash")
    cfg.write_text(json.dumps(cur, ensure_ascii=False, indent=2), encoding="utf-8")
    return cfg


class OpencodeAdapter(LLMAdapter):
    name = "opencode"

    def available(self) -> bool:
        return _bin() != "opencode" or shutil.which("opencode") is not None

    def build(self, prompt, *, model=None, cwd=".", files=None, title=None):
        # 注意：opencode V2 取消了 `run --dir`；工作目录由 subprocess 的 cwd 决定（base.run 已设）。
        cmd = [_bin(), "run"]
        if model:
            cmd += ["--model", model]
        if title:
            cmd += ["--title", title]
        cmd.append(prompt)
        for f in (files or []):
            cmd += ["-f", f]
        return cmd

    def env(self, extra: dict | None = None) -> dict:
        e = super().env(extra)
        cfg = ROOT / "runtime" / "opencode.deepseek.json"
        if cfg.exists():
            e.setdefault("OPENCODE_CONFIG", str(cfg))
        return e
