"""LLM 适配层：opencode / omp(oh-my-pi) / qoder。

用法：
    from app.llm import get, default
    r = get("opencode").run(prompt, model="deepseek/deepseek-chat", cwd=ROOT, files=[...])
"""
from __future__ import annotations

from .base import DEFAULT_MODEL, LLMAdapter, LLMResult, effective_model
from .omp import OmpAdapter
from .opencode import OpencodeAdapter
from .qoder import QoderAdapter

ADAPTERS: dict[str, type[LLMAdapter]] = {
    "opencode": OpencodeAdapter,
    "omp": OmpAdapter,
    "pi": OmpAdapter,       # pi 的发行版 oh-my-pi 即 omp
    "qoder": QoderAdapter,
}

DEFAULT = "opencode"


def get(name: str | None = None) -> LLMAdapter:
    return ADAPTERS.get((name or DEFAULT).lower(), OpencodeAdapter)()


def default() -> LLMAdapter:
    return get(DEFAULT)


def available() -> dict[str, bool]:
    return {k: v().available() for k, v in ADAPTERS.items()}


__all__ = ["get", "default", "available", "ADAPTERS", "LLMAdapter", "LLMResult",
           "DEFAULT_MODEL", "effective_model"]
