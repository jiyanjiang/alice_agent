"""omp（oh my pi）适配器：`omp -p "<prompt>" --cwd <cwd> [--model <m>]`。

非交互用 `-p/--print`；`--mode json` 可拿结构化输出（后续需要时用）。
"""
from __future__ import annotations

import shutil

from .base import LLMAdapter


class OmpAdapter(LLMAdapter):
    name = "omp"

    def available(self) -> bool:
        return shutil.which("omp") is not None

    def build(self, prompt, *, model=None, cwd=".", files=None, title=None):
        cmd = ["omp", "-p", prompt, "--cwd", str(cwd)]
        if model:
            cmd += ["--model", model]
        # omp 支持在消息里用 @file 引用文件；这里把 files 拼进 prompt 由调用方决定，保持简单
        return cmd
