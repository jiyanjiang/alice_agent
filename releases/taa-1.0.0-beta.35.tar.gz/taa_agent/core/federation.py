"""联邦自我演化（R32/R33）：更新历史 + 改进提案与协商。

- updates：append-only 迭代历史（proposal/adopt/reject/install/rollback）。
- proposals：改进提案 + 采纳/拒绝投票 + 收敛视图。
- merge：幂等合并对端增量（供 gossip 反熵）。
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS updates (
  seq            INTEGER PRIMARY KEY AUTOINCREMENT,
  update_id      TEXT UNIQUE,
  node_id        TEXT NOT NULL,
  kind           TEXT NOT NULL,
  title          TEXT NOT NULL,
  summary        TEXT,
  target_version TEXT,
  artifact_hash  TEXT,
  meta           TEXT,
  created_at     TEXT
);
CREATE TABLE IF NOT EXISTS proposals (
  proposal_id    TEXT PRIMARY KEY,
  node_id        TEXT NOT NULL,
  title          TEXT NOT NULL,
  summary        TEXT,
  kind           TEXT,
  target_version TEXT,
  artifact_hash  TEXT,
  bundle_url     TEXT,
  capability     TEXT,
  priority       REAL DEFAULT 0,
  topic          TEXT,
  created_at     TEXT
);
CREATE TABLE IF NOT EXISTS proposal_votes (
  proposal_id    TEXT NOT NULL,
  node_id        TEXT NOT NULL,
  vote           TEXT NOT NULL,
  reason         TEXT,
  created_at     TEXT,
  PRIMARY KEY (proposal_id, node_id)
);
CREATE TABLE IF NOT EXISTS proposal_ranks (
  node_id        TEXT NOT NULL,
  topic          TEXT NOT NULL,
  order_json     TEXT NOT NULL,
  created_at     TEXT,
  PRIMARY KEY (node_id, topic)
);
CREATE TABLE IF NOT EXISTS peer_versions (
  node_id     TEXT PRIMARY KEY,
  version     TEXT,
  bundle_sha  TEXT,
  serial      INTEGER,
  manifest    TEXT,
  received_at TEXT
);
"""


def ensure(conn) -> None:
    conn.executescript(SCHEMA)
    for ddl in ("ALTER TABLE proposals ADD COLUMN priority REAL DEFAULT 0",
                "ALTER TABLE proposals ADD COLUMN topic TEXT"):
        try:
            conn.execute(ddl)
        except sqlite3.OperationalError:
            pass
    conn.commit()


def _rep(conn, agent_id: str) -> float:
    """agent 的累计信誉（用于提案加权）。"""
    try:
        row = conn.execute("SELECT COALESCE(SUM(points),0) s FROM reputation_events "
                           "WHERE agent_id=?", (agent_id,)).fetchone()
        return float(row["s"]) if row else 0.0
    except sqlite3.Error:
        return 0.0


def _hid(*parts) -> str:
    return hashlib.sha1("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()[:20]


# ---------------- 更新历史 ----------------
def append_update(conn, node_id, kind, title, summary="", target_version="",
                  artifact_hash="", meta=None):
    ensure(conn)
    uid = _hid(node_id, kind, title, artifact_hash, time.time())
    conn.execute(
        "INSERT OR IGNORE INTO updates(update_id,node_id,kind,title,summary,"
        "target_version,artifact_hash,meta,created_at) "
        "VALUES (?,?,?,?,?,?,?,?,datetime('now','localtime'))",
        (uid, node_id, kind, title, summary, target_version, artifact_hash,
         json.dumps(meta or {}, ensure_ascii=False)))
    conn.commit()
    return uid


def list_updates(conn, since=0, limit=500):
    ensure(conn)
    rows = conn.execute("SELECT * FROM updates WHERE seq>? ORDER BY seq LIMIT ?",
                        (int(since), int(limit))).fetchall()
    return [dict(r) for r in rows]


# ---------------- 对等版本登记（双向同步）----------------
def record_version(conn, node_id, manifest, bundle_sha=None) -> None:
    ensure(conn)
    conn.execute(
        "INSERT INTO peer_versions(node_id,version,bundle_sha,serial,manifest,received_at) "
        "VALUES (?,?,?,?,?,datetime('now','localtime')) "
        "ON CONFLICT(node_id) DO UPDATE SET version=excluded.version, "
        "bundle_sha=excluded.bundle_sha, serial=excluded.serial, "
        "manifest=excluded.manifest, received_at=excluded.received_at",
        (node_id, manifest.get("runtime_version"),
         bundle_sha or (manifest.get("bundle") or {}).get("sha256"),
         manifest.get("serial"), json.dumps(manifest, ensure_ascii=False)))
    conn.commit()


def list_versions(conn):
    ensure(conn)
    return [dict(r) for r in conn.execute(
        "SELECT * FROM peer_versions ORDER BY received_at DESC").fetchall()]


# ---------------- 提案与协商 ----------------
def publish(conn, node_id, data):
    ensure(conn)
    title = (data.get("title") or "").strip()
    if not title:
        raise ValueError("title required")
    pid = data.get("proposal_id") or _hid(
        node_id, title, data.get("artifact_hash", ""), time.time())
    conn.execute(
        "INSERT OR IGNORE INTO proposals(proposal_id,node_id,title,summary,kind,"
        "target_version,artifact_hash,bundle_url,capability,priority,topic,created_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,datetime('now','localtime'))",
        (pid, node_id, title, data.get("summary", ""), data.get("kind", "feature"),
         data.get("target_version", ""), data.get("artifact_hash", ""),
         data.get("bundle_url", ""), data.get("capability", ""),
         float(data.get("priority") or 0), (data.get("topic") or "").strip()))
    append_update(conn, node_id, "proposal", title, data.get("summary", ""),
                  data.get("target_version", ""), data.get("artifact_hash", ""),
                  {"proposal_id": pid})
    conn.commit()
    return pid


def _with_votes(conn, p: dict) -> dict:
    votes = conn.execute(
        "SELECT node_id, vote, reason, created_at FROM proposal_votes "
        "WHERE proposal_id=? ORDER BY created_at", (p["proposal_id"],)).fetchall()
    p["adopted_by"] = [dict(v) for v in votes if v["vote"] == "adopt"]
    p["rejected_by"] = [dict(v) for v in votes if v["vote"] == "reject"]
    p["status"] = ("adopted" if p["adopted_by"] else
                   ("rejected" if p["rejected_by"] else "open"))
    p["weight"] = round(
        float(p.get("priority") or 0) + len(p["adopted_by"])
        + sum(_rep(conn, v["node_id"]) for v in p["adopted_by"]) / 100.0, 2)
    return p


def list_proposals(conn, limit=200):
    ensure(conn)
    rows = conn.execute("SELECT * FROM proposals LIMIT ?", (int(limit),)).fetchall()
    out = [_with_votes(conn, dict(r)) for r in rows]
    out.sort(key=lambda p: (p["weight"], p["created_at"]), reverse=True)
    return out


def rank(conn, node_id, topic, order):
    """某节点对某 topic 的提案排序（Borda 投票）。"""
    ensure(conn)
    if not topic:
        raise ValueError("topic required")
    order = [str(x) for x in (order or []) if x]
    conn.execute(
        "INSERT OR REPLACE INTO proposal_ranks(node_id,topic,order_json,created_at) "
        "VALUES (?,?,?,datetime('now','localtime'))",
        (node_id, topic, json.dumps(order, ensure_ascii=False)))
    append_update(conn, node_id, "rank", f"rank {topic}", meta={"topic": topic, "order": order})
    conn.commit()
    return order


def list_ranks(conn, topic=None):
    ensure(conn)
    if topic:
        rows = conn.execute("SELECT * FROM proposal_ranks WHERE topic=?", (topic,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM proposal_ranks").fetchall()
    return [dict(r) for r in rows]


def borda(conn, topic, pids):
    """Borda 计数：排名第 i 的提案得 (N-i) 分；跨节点求和。"""
    scores = {pid: 0.0 for pid in pids}
    n = len(pids)
    for r in conn.execute("SELECT order_json FROM proposal_ranks WHERE topic=?", (topic,)):
        try:
            order = json.loads(r["order_json"])
        except Exception:
            continue
        for i, pid in enumerate(order):
            if pid in scores:
                scores[pid] += (n - i)
    return scores


def conflicts(conn):
    """同一 topic 的多个提案 = 冲突；score = weight + Borda，推荐 score 最高者。"""
    ensure(conn)
    groups: dict[str, list] = {}
    for p in list_proposals(conn, limit=1000):
        if p.get("topic"):
            groups.setdefault(p["topic"], []).append(p)
    out = []
    for topic, ps in groups.items():
        if len(ps) < 2:
            continue
        bs = borda(conn, topic, [p["proposal_id"] for p in ps])
        for p in ps:
            p["borda"] = bs.get(p["proposal_id"], 0)
            p["score"] = round(float(p["weight"]) + p["borda"], 2)
        ps.sort(key=lambda x: (x["score"], x["weight"]), reverse=True)
        out.append({"topic": topic, "count": len(ps), "winner": ps[0]["proposal_id"],
                    "winner_title": ps[0]["title"], "proposals": ps})
    out.sort(key=lambda g: g["count"], reverse=True)
    return out


def get_proposal(conn, pid):
    ensure(conn)
    r = conn.execute("SELECT * FROM proposals WHERE proposal_id=?", (pid,)).fetchone()
    return _with_votes(conn, dict(r)) if r else None


def vote(conn, pid, node_id, vote_, reason=""):
    ensure(conn)
    if vote_ not in ("adopt", "reject"):
        raise ValueError("vote must be adopt|reject")
    if not conn.execute("SELECT 1 FROM proposals WHERE proposal_id=?", (pid,)).fetchone():
        raise KeyError(pid)
    conn.execute(
        "INSERT OR REPLACE INTO proposal_votes(proposal_id,node_id,vote,reason,created_at) "
        "VALUES (?,?,?,?,datetime('now','localtime'))", (pid, node_id, vote_, reason))
    append_update(conn, node_id, vote_, f"{vote_} proposal {pid}", reason,
                  meta={"proposal_id": pid})
    conn.commit()
    r = conn.execute("SELECT * FROM proposals WHERE proposal_id=?", (pid,)).fetchone()
    return _with_votes(conn, dict(r))


# ---------------- 幂等合并（gossip 反熵）----------------
def merge(conn, updates=None, proposals=None, ranks=None) -> int:
    ensure(conn)
    n = 0
    for r in (ranks or []):
        cur = conn.execute(
            "INSERT OR IGNORE INTO proposal_ranks(node_id,topic,order_json,created_at) "
            "VALUES (?,?,?,?)",
            (r.get("node_id"), r.get("topic"), r.get("order_json"), r.get("created_at")))
        n += cur.rowcount
    for u in (updates or []):
        cur = conn.execute(
            "INSERT OR IGNORE INTO updates(update_id,node_id,kind,title,summary,"
            "target_version,artifact_hash,meta,created_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (u.get("update_id"), u.get("node_id"), u.get("kind"), u.get("title"),
             u.get("summary", ""), u.get("target_version", ""),
             u.get("artifact_hash", ""), u.get("meta", "{}"), u.get("created_at")))
        n += cur.rowcount
    for p in (proposals or []):
        cur = conn.execute(
            "INSERT OR IGNORE INTO proposals(proposal_id,node_id,title,summary,kind,"
            "target_version,artifact_hash,bundle_url,capability,priority,topic,created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (p.get("proposal_id"), p.get("node_id"), p.get("title"),
             p.get("summary", ""), p.get("kind", ""), p.get("target_version", ""),
             p.get("artifact_hash", ""), p.get("bundle_url", ""),
             p.get("capability", ""), float(p.get("priority") or 0),
             p.get("topic", ""), p.get("created_at")))
        n += cur.rowcount
        for v in (p.get("adopted_by", []) + p.get("rejected_by", [])):
            conn.execute(
                "INSERT OR IGNORE INTO proposal_votes(proposal_id,node_id,vote,reason,created_at) "
                "VALUES (?,?,?,?,?)",
                (p.get("proposal_id"), v.get("node_id"), v.get("vote"),
                 v.get("reason", ""), v.get("created_at")))
    conn.commit()
    return n
