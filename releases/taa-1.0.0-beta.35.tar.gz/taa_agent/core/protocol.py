"""协议契约（R30）：版本化接口 + 能力协商。

各节点代码可微差，靠本契约互通：
- major 不同 -> 硬拒（提示升级）
- minor 不同 -> 记录并优雅降级（未知能力/字段忽略）
"""
from __future__ import annotations

PROTOCOL_MAJOR = 1
PROTOCOL_MINOR = 0
PROTOCOL_VERSION = f"{PROTOCOL_MAJOR}.{PROTOCOL_MINOR}"

CAPABILITIES = [
    "handshake",    # 入网握手
    "events",       # 事件溯源 /v1/events
    "gossip",       # UDP 发现 + 反熵
    "dist",         # 发行版清单 / 单文件下载
    "bundle",       # 全量签名包
    "updates",      # 更新历史
    "proposals",    # 改进提案与协商
    "soul",         # 结构化 soul + 演化
    "node_code",    # 唯一机器码
    "init",         # 一键建档 / 自然语言 / 模板
]


def parse(v: str) -> tuple[int, int]:
    try:
        a, b = str(v).lstrip("v").split(".")[:2]
        return int(a), int(b)
    except Exception:
        return (0, 0)


def compat(client_version: str) -> str:
    """返回 ok | minor | major | unknown。"""
    if not client_version:
        return "unknown"
    cmaj, cmin = parse(client_version)
    if cmaj != PROTOCOL_MAJOR:
        return "major"
    if cmin != PROTOCOL_MINOR:
        return "minor"
    return "ok"


def info() -> dict:
    return {"protocol_version": PROTOCOL_VERSION, "major": PROTOCOL_MAJOR,
            "minor": PROTOCOL_MINOR, "capabilities": CAPABILITIES}
