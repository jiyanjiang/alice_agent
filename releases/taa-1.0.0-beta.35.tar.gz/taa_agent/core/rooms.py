"""聊天室式读书会（docs/11）。房间、成员、邀请、回合状态机、转写、打分骨架。"""
from __future__ import annotations

import json
import os
import re
import secrets
import uuid
from datetime import datetime, timedelta
from pathlib import Path

from . import arguments

ROOT = Path(__file__).resolve().parent.parent

SESSION_FIRST_MINUTES = 60   # 首次会话最长 1 小时，之后强制结束
SESSION_NEXT_MINUTES = 30    # 真人重开后每场 30 分钟，可无限重开
PREPARE_SECONDS = 30      # 统一 30 秒：AI 回合窗口
COMMIT_SECONDS = 30       # 统一 30 秒：AI 提交窗口
HUMAN_SECONDS = 30        # 统一 30 秒：真人回合窗口（工具轮会按需延长）
HUMAN_IDLE_SKIP = 60
HUMAN_GRACE_MINUTES = int(os.environ.get("TEAMAI_HUMAN_GRACE_MIN", "30"))
HUMAN_ACTIVE_MINUTES = int(os.environ.get("TEAMAI_HUMAN_ACTIVE_MIN", "10"))

BASE_SCORE = {"assertion": 1.0, "fact": 0.6, "question": 0.5, "emotion": 0.3,
              "skip": 0.0, "system": 0.0}
W_N, W_R, W_E = 0.3, 0.3, 0.4


def _is_human(conn, agent_id: str) -> bool:
    """按 kind 判定是否为人类所有者（id 可自定义，如 jiyanjiang）。"""
    if not agent_id:
        return False
    row = conn.execute("SELECT kind FROM agents WHERE id=?", (agent_id,)).fetchone()
    return bool(row and row["kind"] == "human")


def human_id(conn) -> str:
    """人类所有者的 id（按 kind 查，找不到回退 'human'）。"""
    row = conn.execute("SELECT id FROM agents WHERE kind='human' "
                       "AND id NOT LIKE 'remote-human-%' ORDER BY created_at LIMIT 1").fetchone()
    return row["id"] if row else "human"


def new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _plus(seconds: int) -> str:
    return (datetime.now() + timedelta(seconds=seconds)).strftime("%Y-%m-%d %H:%M:%S")


def _past(ts: str | None) -> bool:
    return bool(ts) and ts < _now()


def _loads(v, default):
    if v in (None, ""):
        return default
    try:
        return json.loads(v)
    except (TypeError, ValueError):
        return default


# ------------------------------------------------------------------ rooms / members
def create_room(conn, host_id, topic, channel_id=None, expected_minutes=30,
                prepare_seconds=PREPARE_SECONDS, commit_seconds=COMMIT_SECONDS,
                human_seconds=HUMAN_SECONDS, rating="general", content_level=None,
                kind="group", title=None) -> str:
    rid = new_id("room")
    kind = kind if kind in ("group", "dm", "reading", "archived") else "group"
    conn.execute(
        "INSERT INTO rooms(id, topic, kind, title, channel_id, expected_minutes, prepare_seconds, "
        "commit_seconds, human_seconds, rating, content_level, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        (rid, topic, kind, title or topic, channel_id, expected_minutes, prepare_seconds, commit_seconds,
         human_seconds, rating, content_level, host_id))
    add_member(conn, rid, host_id, role="host")
    conn.commit()
    return rid




def ensure_dm(conn, human: str, agent: str, name: str = "") -> str:
    """找到/创建人类与单个 agent 的私信房；自动开始，保留 7 天。

    Only kind=dm rooms are eligible. A legacy two-member reading/group room must
    be migrated or archived explicitly; it must never be silently reused as DM.
    """
    row = conn.execute(
        "SELECT r.id FROM rooms r "
        "JOIN room_members h ON h.room_id=r.id AND h.agent_id=? AND h.kind='human' "
        "JOIN room_members a ON a.room_id=r.id AND a.agent_id=? AND a.kind='ai' "
        "WHERE r.kind='dm' AND (SELECT COUNT(*) FROM room_members WHERE room_id=r.id)=2 "
        "ORDER BY r.created_at DESC LIMIT 1", (human, agent)).fetchone()
    title = f"私信 · {name or agent}"
    if row:
        rid = row["id"]
    else:
        rid = create_room(conn, human, title, expected_minutes=10080, kind="dm", title=title)
        add_member(conn, rid, agent, role="member")
    r = conn.execute("SELECT status FROM rooms WHERE id=?", (rid,)).fetchone()
    if not r or r["status"] != "running":
        start_room(conn, rid)
    conn.execute("UPDATE rooms SET kind='dm', title=?, session_limit_minutes=10080 WHERE id=?",
                 (title, rid))
    conn.commit()
    return rid


def add_member(conn, room_id, agent_id, role="member") -> None:
    kind = "human" if _is_human(conn, agent_id) else "ai"
    conn.execute("INSERT OR IGNORE INTO room_members(room_id, agent_id, kind, role) "
                 "VALUES (?,?,?,?)", (room_id, agent_id, kind, role))
    conn.commit()


def ensure_human_member(conn, room_id: str, human: str | None = None) -> str | None:
    """旧群房可能只有 AI；真人打开/发言时补齐，避免 host/权限/名单不一致。"""
    human = human or human_id(conn)
    if not human:
        return None
    add_member(conn, room_id, human, role="member")
    return human


def _order(conn, room_id) -> list[str]:
    rows = conn.execute(
        "SELECT agent_id FROM room_members WHERE room_id=? "
        "ORDER BY (role='host') DESC, joined_at, agent_id", (room_id,)).fetchall()
    return [r["agent_id"] for r in rows]


def get_room(conn, room_id) -> dict | None:
    r = conn.execute("SELECT * FROM rooms WHERE id=?", (room_id,)).fetchone()
    if not r:
        return None
    d = dict(r)
    d["members"] = [dict(x) for x in conn.execute(
        "SELECT agent_id, kind, role FROM room_members WHERE room_id=? ORDER BY joined_at", (room_id,)).fetchall()]
    d["order"] = _order(conn, room_id)
    # 主持人：真人在场则真人为主持人，否则创建者(role=host)
    human = next((m["agent_id"] for m in d["members"] if m["kind"] == "human"), None)
    d["host"] = human or next((m["agent_id"] for m in d["members"] if m["role"] == "host"), None)
    return d


def list_rooms(conn) -> list[dict]:
    return [dict(r) for r in conn.execute("SELECT * FROM rooms ORDER BY created_at DESC").fetchall()]


# ------------------------------------------------------------------ invitations
def evaluate_invite(conn, agent_id, topic, expected_minutes) -> tuple[bool, str]:
    """规则式：可用时间 + 话题-人设匹配 + 负载。"""
    a = conn.execute("SELECT * FROM agents WHERE id=?", (agent_id,)).fetchone()
    if not a:
        return False, "unknown agent"
    if _is_human(conn, agent_id):
        return True, "真人（可插拔）"
    if a["status"] == "busy":
        return False, "busy（无连续时间）"
    p = _loads(a["persona_json"], {})
    interests = [str(i).lower() for i in p.get("interests", [])]
    skills = [str(s.get("name", "")).lower() for s in p.get("skills", []) if isinstance(s, dict)]
    toks = re.findall(r"[\w\u4e00-\u9fff]+", (topic or "").lower())
    match = sum(1 for t in toks if any(t in i or i in t for i in interests + skills))
    match_ratio = match / max(len(toks), 1)
    wip = conn.execute(
        "SELECT COUNT(*) c FROM tasks WHERE assigned_to=? AND status IN "
        "('claimed','in_progress','review')", (agent_id,)).fetchone()["c"]
    if wip >= 2:
        return False, f"负载高（WIP={wip}）"
    openness = float((p.get("traits") or {}).get("openness", 0.5))
    # 规则：不 busy、WIP<2，且（话题匹配 / 高开放性愿尝试陌生话题 / 话题宽泛）即接受
    if match_ratio >= 0.15 or openness >= 0.7 or len(toks) <= 2:
        why = (f"接受：话题匹配 {match_ratio:.2f}" if match_ratio >= 0.15
               else f"接受：高开放性({openness:.2f})愿尝试陌生话题")
        return True, f"{why}，预计 {expected_minutes} 分钟"
    return False, f"拒绝：匹配度低({match_ratio:.2f}) 且开放性低({openness:.2f})"


def invite(conn, room_id, agent_id, reason=None) -> dict:
    ok, why = evaluate_invite(conn, agent_id, get_room(conn, room_id)["topic"],
                              get_room(conn, room_id)["expected_minutes"])
    status = "accepted" if ok else "declined"
    conn.execute("INSERT INTO room_invitations(room_id, agent_id, status, reason) VALUES (?,?,?,?)",
                 (room_id, agent_id, status, reason or why))
    if ok:
        add_member(conn, room_id, agent_id)
    conn.commit()
    return {"agent_id": agent_id, "accepted": ok, "reason": reason or why}


# ------------------------------------------------------------------ turn engine (lazy)
def force_add_member(conn, room_id, agent_id, role="member") -> dict:
    """主持人直接拉人入伙（跳过规则式接受，用于组队）。"""
    if not get_room(conn, room_id):
        raise ValueError("room not found")
    if not conn.execute("SELECT 1 FROM agents WHERE id=?", (agent_id,)).fetchone():
        raise ValueError("unknown agent")
    add_member(conn, room_id, agent_id, role=role)
    return {"agent_id": agent_id, "added": True}


def share_token(conn, room_id, by=None, as_agent=None, ttl_hours=48) -> str:
    """生成房间分享令牌（手机扫码后以此身份入会）。"""
    if not get_room(conn, room_id):
        raise ValueError("room not found")
    if not as_agent:
        as_agent = human_id(conn)
    tok = secrets.token_urlsafe(24)
    exp = (datetime.now() + timedelta(hours=ttl_hours)).strftime("%Y-%m-%d %H:%M:%S")
    conn.execute("INSERT INTO room_shares(token, room_id, as_agent, created_by, expires_at) "
                 "VALUES (?,?,?,?,?)", (tok, room_id, as_agent, by, exp))
    conn.commit()
    return tok


def resolve_share(conn, token) -> dict | None:
    row = conn.execute("SELECT * FROM room_shares WHERE token=?", (token,)).fetchone()
    if not row:
        return None
    d = dict(row)
    if d.get("expires_at") and d["expires_at"] < _now():
        return None
    return d


def _current_turn(conn, room) -> dict | None:
    order = room["order"]
    if not order:
        return None
    idx = room["current_idx"] % len(order)
    agent_id = order[idx]
    row = conn.execute(
        "SELECT * FROM room_turns WHERE room_id=? AND round=? AND agent_id=?",
        (room["id"], room["current_round"], agent_id)).fetchone()
    if not row:
        conn.execute("INSERT INTO room_turns(room_id, round, agent_id, state) VALUES (?,?,?, 'waiting')",
                     (room["id"], room["current_round"], agent_id))
        conn.commit()
        row = conn.execute(
            "SELECT * FROM room_turns WHERE room_id=? AND round=? AND agent_id=?",
            (room["id"], room["current_round"], agent_id)).fetchone()
    return dict(row)


def _next_turn(conn, room) -> None:
    order = room["order"]
    idx = (room["current_idx"] + 1) % max(len(order), 1)
    rnd = room["current_round"] + (1 if idx == 0 else 0)
    conn.execute("UPDATE rooms SET current_idx=?, current_round=? WHERE id=?",
                 (idx, rnd, room["id"]))
    conn.commit()


def _human_active(conn, room_id: str) -> bool:
    """真人最后发言后的主动发言窗口（默认 10 分钟）。

    窗口结束后 agent 不再主动接话，但真人新发言/@ 会重新打开窗口。
    """
    row = conn.execute(
        "SELECT MAX(created_at) t FROM room_messages WHERE room_id=? AND agent_id=? "
        "AND kind NOT IN ('system','skip')", (room_id, human_id(conn))).fetchone()
    if not row or not row["t"]:
        return False
    try:
        last = datetime.strptime(str(row["t"])[:19], "%Y-%m-%d %H:%M:%S")
    except (ValueError, TypeError):
        return False
    return (datetime.now() - last).total_seconds() < HUMAN_ACTIVE_MINUTES * 60


def advance(conn, room_id) -> dict | None:
    """懒推进：根据截止时间把回合状态向前推，超时判跳过。"""
    room = get_room(conn, room_id)
    if not room or room["status"] != "running":
        return room
    if auto_end_if_due(conn, room_id):     # 会话超时 → 强制结束
        return get_room(conn, room_id)
    active = _human_active(conn, room_id)
    for _ in range(len(room["order"]) + 2):
        t = _current_turn(conn, room)
        if not t:
            break
        st = t["state"]
        is_human = _is_human(conn, t["agent_id"])
        # 10 分钟主动窗口关闭后，AI 不再主动接话；不插入 skip 消息，避免聊天流被“跳过”刷屏。
        if not is_human and not active and st in ("waiting", "prepare", "open"):
            conn.execute("UPDATE room_turns SET state='skipped', prepare_deadline=NULL, "
                         "open_deadline=NULL WHERE id=?", (t["id"],))
            conn.commit()
            _next_turn(conn, room)
            room = get_room(conn, room_id)
            continue
        if st == "waiting":
            if is_human:
                conn.execute("UPDATE room_turns SET state='open', open_deadline=? WHERE id=?",
                             (_plus(room["human_seconds"]), t["id"]))
            else:
                conn.execute("UPDATE room_turns SET state='prepare', prepare_deadline=? WHERE id=?",
                             (_plus(room["prepare_seconds"]), t["id"]))
            conn.commit()
            room = get_room(conn, room_id)
            continue
        if st == "prepare":
            if _past(t["prepare_deadline"]):
                conn.execute("UPDATE room_turns SET state='open', open_deadline=? WHERE id=?",
                             (_plus(room["commit_seconds"]), t["id"]))
                conn.commit()
                room = get_room(conn, room_id)
                continue
            break  # 仍在准备
        if st == "open":
            if _past(t["open_deadline"]):
                conn.execute("UPDATE room_turns SET state='skipped' WHERE id=?", (t["id"],))
                if not _spoke_this_turn(conn, room_id, t["round"], t["agent_id"]):
                    conn.execute("INSERT INTO room_messages(room_id, round, agent_id, body, kind, score) "
                                 "VALUES (?,?,?,?, 'skip', 0)", (room_id, t["round"], t["agent_id"], "（跳过）"))
                conn.commit()
                _next_turn(conn, room)
                room = get_room(conn, room_id)
                continue
            break  # 等待 commit
        # spoken / skipped / rehash：推进
        _next_turn(conn, room)
        room = get_room(conn, room_id)
    return get_room(conn, room_id)


def prioritize_mentions(conn, room_id: str, body: str) -> str | None:
    """真人 @ 点名时，把当前回合切给被点名的 AI。

    群聊默认按成员顺序轮转；真人插话不会自动改回合，因此 @Bob 可能排在
    当前 Carol 回合后面，甚至 Bob 本轮已被 skip，表现为“没人理”。
    这里只处理**真人显式点名**：把当前回合让给目标；原当前回合回到
    waiting，后续仍会轮到，不丢失。
    """
    room = get_room(conn, room_id)
    if not room or room.get("status") != "running":
        return None
    ais = conn.execute(
        "SELECT a.id,a.name FROM room_members m JOIN agents a ON a.id=m.agent_id "
        "WHERE m.room_id=? AND a.kind='ai' ORDER BY m.rowid", (room_id,)).fetchall()
    if len(ais) < 2:
        return None
    mentions = [m.lower() for m in re.findall(r"@([\w.\-]{1,40})", body or "")]
    if not mentions:
        return None
    target = None
    for a in ais:
        al = str(a["id"]).lower()
        nl = str(a["name"] or "").lower()
        if any(m == al or m == nl or m in nl or nl in m for m in mentions):
            target = str(a["id"])
            break
    if not target:
        return None
    order = room["order"]
    if target not in order:
        return None
    idx = order.index(target)
    cur = _current_turn(conn, room)
    # 目标已经是当前回合：prepare/open 让它继续；spoken/skipped 则重置再排一次。
    if cur and cur["agent_id"] == target:
        if cur["state"] in ("prepare", "open"):
            return target
        conn.execute("UPDATE room_turns SET state='waiting', prepare_deadline=NULL, "
                     "open_deadline=NULL WHERE id=?", (cur["id"],))
        conn.commit()
        advance(conn, room_id)
        return target
    # 目标在当前轮的旧状态：被跳过/已说话都重置为 waiting，允许这次点名重新发言。
    old = conn.execute(
        "SELECT id,state FROM room_turns WHERE room_id=? AND round=? AND agent_id=?",
        (room_id, room["current_round"], target)).fetchone()
    if old:
        conn.execute("UPDATE room_turns SET state='waiting', prepare_deadline=NULL, "
                     "open_deadline=NULL WHERE id=?", (old["id"],))
    # 让当前回合回到 waiting，不插入 skip；它会在被点名者之后继续排到。
    if cur and cur["agent_id"] != target and cur["state"] in ("prepare", "open"):
        conn.execute("UPDATE room_turns SET state='waiting', prepare_deadline=NULL, "
                     "open_deadline=NULL WHERE id=?", (cur["id"],))
    conn.execute("UPDATE rooms SET current_idx=? WHERE id=?", (idx, room_id))
    conn.commit()
    advance(conn, room_id)
    print(f"[rooms] mention priority room={room_id} target={target} idx={idx}")
    return target


def start_room(conn, room_id) -> None:
    # 重开房间：清掉旧回合，避免复用历史回合状态导致状态机卡死
    row = conn.execute("SELECT session_count FROM rooms WHERE id=?", (room_id,)).fetchone()
    cnt = (row["session_count"] or 0) + 1 if row else 1
    limit = SESSION_FIRST_MINUTES if cnt == 1 else SESSION_NEXT_MINUTES
    conn.execute("DELETE FROM room_turns WHERE room_id=?", (room_id,))
    conn.execute("UPDATE rooms SET status='running', current_round=1, current_idx=0, "
                 "session_started_at=datetime('now','localtime'), session_count=?, "
                 "session_limit_minutes=? WHERE id=?", (cnt, limit, room_id))
    conn.commit()
    advance(conn, room_id)


def auto_end_if_due(conn, room_id) -> bool:
    """会话超过本场时限 → 强制结束（真人可再次 start 重开，可无限次）。"""
    room = get_room(conn, room_id)
    if not room or room["status"] != "running":
        return False
    # 2026-10-19：以「真人最后一条发言」为锚点 +30 分钟；
    # 真人离开后，agents 仍可继续互动，而不是从开场就 30 分钟硬切。
    last_human = conn.execute(
        "SELECT MAX(created_at) t FROM room_messages WHERE room_id=? AND agent_id=? "
        "AND kind NOT IN ('system','skip')", (room_id, human_id(conn))).fetchone()
    candidates = [x for x in (room.get("session_started_at"),
                              (last_human["t"] if last_human else None)) if x]
    anchor = max(candidates) if candidates else None
    if not anchor:
        return False
    try:
        elapsed = (datetime.now() - datetime.strptime(anchor, "%Y-%m-%d %H:%M:%S")).total_seconds()
    except (ValueError, TypeError):
        return False
    limit = HUMAN_GRACE_MINUTES
    if elapsed >= limit * 60:
        conn.execute("INSERT INTO room_messages(room_id, round, agent_id, body, kind, score, source) "
                     "VALUES (?,?,?,?, 'system', NULL, 'session')",
                     (room_id, room["current_round"], human_id(conn),
                      f"⏳ 本场真人已 {limit} 分钟未发言，自动结束；随时输入即可重新开始。"))
        end_room(conn, room_id)
        return True
    return False


def end_room(conn, room_id) -> None:
    conn.execute("UPDATE rooms SET status='ended' WHERE id=?", (room_id,))
    conn.commit()


def close_running_except(conn, keep_id: str) -> list[str]:
    """规则「最多一个活跃主聊天室」：把除 keep_id 外的 running 房标记 ended。返回被关的 id。"""
    rows = conn.execute("SELECT id FROM rooms WHERE status='running' AND id!=?",
                        (keep_id,)).fetchall()
    ids = [r["id"] if hasattr(r, "keys") else r[0] for r in rows]
    for rid in ids:
        conn.execute("UPDATE rooms SET status='ended' WHERE id=? AND status='running'", (rid,))
    conn.commit()
    return ids


# ------------------------------------------------------------------ scoring (M1 骨架)
def _tokens(s: str) -> set:
    return set(re.findall(r"[\w\u4e00-\u9fff]{2,}", (s or "").lower()))


def _novelty(conn, room_id, body) -> float:
    prev = [r["body"] for r in conn.execute(
        "SELECT body FROM room_messages WHERE room_id=? ORDER BY id DESC LIMIT 50", (room_id,))]
    if not prev:
        return 1.0
    cur = _tokens(body)
    if not cur:
        return 0.0
    sim = max((len(cur & _tokens(p)) / max(len(cur | _tokens(p)), 1)) for p in prev)
    return round(1.0 - sim, 3)


def _evidence_rigor(body, kind) -> tuple[float, float]:
    if kind != "assertion":
        return 0.5, 0.4
    ev = 0.5
    if re.search(r"(TLP|命题|坐标|§|\d+\.\d+|引用|文献|证明|推导|计算|测试|数据)", body):
        ev = 0.8
    rigor = 0.7 if len(body) >= 120 else 0.5
    return ev, rigor


def classify_kind(text: str) -> str:
    """自动判定发言类型（取消前端 4 选 1，交给模型/规则判定）。"""
    t = (text or "").strip()
    if not t:
        return "assertion"
    if re.search(r"[?？]", t) or re.search(r"(吗|呢|为什么|怎么|如何|是否|请问|谁知道|哪个|多少)", t):
        return "question"
    if re.search(r"(开心|难过|担心|焦虑|害怕|喜欢|讨厌|感动|生气|兴奋|失望|痛苦|快乐|爽|烦|累)", t):
        return "emotion"
    if re.search(r"(\d|数据|统计|引用|文献|根据|报告|测试|事实|来源|§|命题)", t):
        return "fact"
    return "assertion"


def _spoke_this_turn(conn, room_id, round, agent_id) -> bool:
    r = conn.execute(
        "SELECT COUNT(*) c FROM room_messages WHERE room_id=? AND round=? AND agent_id=? "
        "AND kind NOT IN ('skip','system')", (room_id, round, agent_id)).fetchone()
    return bool(r["c"])


def say(conn, room_id, agent_id, body, kind=None, graph=None, attachment=None) -> dict:
    room = get_room(conn, room_id)
    if not room or room["status"] != "running":
        raise ValueError("room not running")
    if not kind or kind == "auto":
        kind = classify_kind(body)
    t = _current_turn(conn, room)
    is_human = _is_human(conn, agent_id)
    my_turn = bool(t and t["agent_id"] == agent_id)
    # 真人自由发言：任何时候都可插话；AI 仍按回合纪律
    if not is_human and not my_turn:
        raise ValueError("not your turn")
    rnd = t["round"] if t else room["current_round"]
    novelty = _novelty(conn, room_id, body)
    g = None
    validation, ev_val = None, None
    if kind == "assertion":
        ev = arguments.evaluate(body, kind, graph)
        evidence, rigor, g = ev["evidence"], ev["rigor"], ev["graph"]
        validation, ev_val = ev.get("validation"), ev.get("ev")
        # 平凡图不画：单节点或没有边，画出来是浪费（需求 #77）
        if g and (len(g.get("nodes", [])) < 2 or len(g.get("edges", [])) == 0):
            g = None
    else:
        evidence, rigor = 0.5, 0.4
    score = round(BASE_SCORE.get(kind, 0.5) * (W_N * novelty + W_R * rigor + W_E * evidence), 4)
    is_rehash = kind == "assertion" and novelty < 0.05
    cur = conn.execute(
        "INSERT INTO room_messages(room_id, round, agent_id, body, kind, score, attachment) "
        "VALUES (?,?,?,?,?,?,?)",
        (room_id, rnd, agent_id, body, kind, score, attachment))
    mid = cur.lastrowid
    png = None
    if g:
        conn.execute("INSERT INTO argument_graphs(message_id, graph_json, posterior, n_nodes, n_edges, "
                     "ev, validation) VALUES (?,?,?,?,?,?,?)",
                     (mid, json.dumps(g, ensure_ascii=False), evidence,
                      len(g.get("nodes", [])), len(g.get("edges", [])),
                      ev_val, json.dumps(validation, ensure_ascii=False) if validation else None))
        try:
            png = arguments.render_png(g, ROOT / "rooms" / room_id / f"msg-{mid}.png")
        except Exception as e:
            print(f"[rooms] render_png err: {e}")
    conn.execute("INSERT INTO room_contributions(room_id, round, agent_id, novelty, rigor, evidence, "
                 "engagement, total) VALUES (?,?,?,?,?,?,?,?)",
                 (room_id, rnd, agent_id, novelty, rigor, evidence, 0, score))
    if is_human:
        # 真人：回合内可反复发言，但整段发言时长固定为 human_seconds（不因每次发言重置）
        conn.commit()
        try:
            prioritize_mentions(conn, room_id, body)
        except Exception as e:  # noqa: BLE001 —— 调度失败不能回滚真人消息
            print(f"[rooms] mention priority err: {e}")
    else:
        conn.execute("UPDATE room_turns SET state=?, latency_ms=0 WHERE id=?",
                     ("rehash" if is_rehash else "spoken", t["id"]))
        conn.commit()
        _next_turn(conn, get_room(conn, room_id))
    return {"message_id": mid, "score": score, "novelty": novelty,
            "evidence": evidence, "rigor": rigor, "rehash": is_rehash, "graph_png": png}


def skip(conn, room_id, agent_id) -> None:
    room = get_room(conn, room_id)
    t = _current_turn(conn, room)
    if not t or t["agent_id"] != agent_id:
        raise ValueError("not your turn")
    conn.execute("UPDATE room_turns SET state='skipped' WHERE id=?", (t["id"],))
    if not _spoke_this_turn(conn, room_id, t["round"], agent_id):
        conn.execute("INSERT INTO room_messages(room_id, round, agent_id, body, kind, score) "
                     "VALUES (?,?,?,?, 'skip', 0)", (room_id, t["round"], agent_id, "（跳过）"))
    conn.commit()
    _next_turn(conn, room)


def report(conn, room_id, agent_id, text) -> dict:
    """开发日志：让 agent 代表 opencode 汇报进度（不计分、不进回合）。"""
    room = get_room(conn, room_id)
    if not room:
        raise ValueError("room not found")
    rnd = room["current_round"]
    cur = conn.execute(
        "INSERT INTO room_messages(room_id, round, agent_id, body, kind, score, source) "
        "VALUES (?,?,?,?, 'system', NULL, 'opencode')", (room_id, rnd, agent_id, text))
    conn.commit()
    return {"message_id": cur.lastrowid, "round": rnd}


# ------------------------------------------------------------------ transcript / summary
def transcript(conn, room_id, limit=200, after=0) -> list[dict]:
    """房间消息。默认返回**最新** limit 条（升序）；after>0 时返回 id>after 的前 limit 条（增量）。"""
    cols = ("m.*, a.full_name AS author, g.id AS graph_id, g.posterior AS graph_posterior, "
            "g.n_nodes AS graph_nodes, g.n_edges AS graph_edges, g.ev AS graph_ev, "
            "g.validation AS graph_validation "
            "FROM room_messages m "
            "LEFT JOIN agents a ON a.id=m.agent_id "
            "LEFT JOIN argument_graphs g ON g.message_id=m.id ")
    if after and int(after) > 0:
        rows = conn.execute(
            "SELECT " + cols + "WHERE m.room_id=? AND m.id>? ORDER BY m.id LIMIT ?",
            (room_id, int(after), limit)).fetchall()
        return [dict(r) for r in rows]
    rows = conn.execute(
        "SELECT " + cols + "WHERE m.room_id=? ORDER BY m.id DESC LIMIT ?",
        (room_id, limit)).fetchall()
    return [dict(r) for r in reversed(rows)]


def extend_turn(conn, room_id, agent_id, seconds: int = 120) -> None:
    """当前 agent 正在用工具时，按需延长自己的回合截止时间。"""
    room = get_room(conn, room_id)
    if not room or room["status"] != "running":
        return
    t = _current_turn(conn, room)
    if not t or t["agent_id"] != agent_id:
        return
    for col in ("prepare_deadline", "open_deadline"):
        ts = t[col]
        if ts and t["state"] in ("prepare", "open"):
            try:
                base = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
                conn.execute(f"UPDATE room_turns SET {col}=? WHERE id=?",
                             ((base + timedelta(seconds=seconds)).strftime("%Y-%m-%d %H:%M:%S"), t["id"]))
            except ValueError:
                pass
    conn.commit()


def mark_read(conn, room_id, agent_id, last_id) -> None:
    conn.execute(
        "INSERT INTO room_reads(agent_id, room_id, last_read_id, updated_at) "
        "VALUES (?,?,?,datetime('now','localtime')) "
        "ON CONFLICT(agent_id, room_id) DO UPDATE SET last_read_id=excluded.last_read_id, "
        "updated_at=excluded.updated_at", (agent_id, room_id, int(last_id)))
    conn.commit()


def unread_count(conn, room_id, agent_id) -> int:
    row = conn.execute("SELECT last_read_id FROM room_reads WHERE agent_id=? AND room_id=?",
                       (agent_id, room_id)).fetchone()
    since = row["last_read_id"] if row else 0
    r = conn.execute("SELECT COUNT(*) c FROM room_messages WHERE room_id=? AND id>? AND agent_id!=?",
                     (room_id, since, agent_id)).fetchone()
    return r["c"]


def list_graphs(conn, room_id, limit=200) -> list[dict]:
    """房间内的论证图列表（照片墙用）。"""
    rows = conn.execute(
        "SELECT g.message_id, g.posterior, g.n_nodes, g.n_edges, g.ev, g.validation, g.created_at, "
        "m.agent_id, m.round, m.body FROM argument_graphs g "
        "JOIN room_messages m ON m.id=g.message_id "
        "WHERE m.room_id=? AND g.n_nodes >= 2 AND g.n_edges >= 1 "
        "ORDER BY g.id DESC LIMIT ?", (room_id, limit)).fetchall()
    return [dict(r) for r in rows]


def arena_rank(conn, room_id) -> list[dict]:
    rows = conn.execute(
        "SELECT c.agent_id, ROUND(SUM(c.total),3) AS score, COUNT(*) AS turns, "
        "ROUND(SUM(c.engagement),2) AS engagement FROM room_contributions c WHERE c.room_id=? "
        "GROUP BY c.agent_id ORDER BY score DESC", (room_id,)).fetchall()
    out = []
    for i, r in enumerate(rows, 1):
        d = dict(r)
        d["rank"] = i
        out.append(d)
    return out


# ------------------------------------------------------------------ M4: 时间变量 / 审美 / 需求池
def reeval_room(conn, room_id) -> dict:
    """对房间内论证图重算后验，比较 t0 与现在是否一致（稳定审美）。"""
    rows = conn.execute(
        "SELECT g.* FROM argument_graphs g JOIN room_messages m ON m.id=g.message_id "
        "WHERE m.room_id=? ORDER BY g.id", (room_id,)).fetchall()
    out, consistent = [], 0
    for r in rows:
        try:
            g = json.loads(r["graph_json"])
        except Exception:
            continue
        after = arguments.posterior(g)
        before = r["posterior"]
        ok = abs((after or 0) - (before or 0)) < 1e-6
        consistent += 1 if ok else 0
        conn.execute("INSERT INTO reevals(room_id, message_id, posterior_before, posterior_after, "
                     "consistent) VALUES (?,?,?,?,?)",
                     (room_id, r["message_id"], before, after, 1 if ok else 0))
        out.append({"message_id": r["message_id"], "before": before, "after": after, "consistent": ok})
    conn.commit()
    return {"room_id": room_id, "total": len(out), "consistent": consistent, "items": out}


def extract_aesthetic(conn, agent_id) -> list[dict]:
    """从 agent 的发言/论证图抽取审美与技能偏好（快照）。"""
    graphs = conn.execute(
        "SELECT g.graph_json, length(m.body) AS blen FROM argument_graphs g "
        "JOIN room_messages m ON m.id=g.message_id WHERE m.agent_id=?", (agent_id,)).fetchall()
    st_count: dict[str, int] = {}
    blens = []
    for r in graphs:
        try:
            g = json.loads(r["graph_json"])
        except Exception:
            continue
        for n in g.get("nodes", []):
            if n.get("id") != g.get("conclusion"):
                st_count[n.get("source_type", "assertion")] = st_count.get(n.get("source_type", "assertion"), 0) + 1
        blens.append(r["blen"] or 0)
    rows = []
    if st_count:
        dom = max(st_count, key=st_count.get)
        zh = {"citation": "重引用/坐标", "computation": "重计算/实证", "observation": "重观察/复现",
              "assertion": "重断言/观点"}
        rows.append(("证据偏好", f"倾向 {zh.get(dom, dom)}", json.dumps(st_count, ensure_ascii=False)))
    if blens:
        avg = sum(blens) / len(blens)
        style = "简练" if avg < 120 else ("详尽" if avg > 260 else "适中")
        rows.append(("表达风格", f"{style}（均长 {avg:.0f} 字）", f"avg_len={avg:.0f}"))
    interests = conn.execute("SELECT tag FROM agent_interests WHERE agent_id=? ORDER BY weight DESC LIMIT 5",
                             (agent_id,)).fetchall()
    if interests:
        rows.append(("关注领域", "、".join(r["tag"] for r in interests), "agent_interests"))
    # 快照：清旧写新
    conn.execute("DELETE FROM agent_aesthetic WHERE agent_id=?", (agent_id,))
    for dim, stmt, ev in rows:
        conn.execute("INSERT INTO agent_aesthetic(agent_id, dimension, statement, evidence) "
                     "VALUES (?,?,?,?)", (agent_id, dim, stmt, ev))
    conn.commit()
    return [{"dimension": d, "statement": s, "evidence": e} for d, s, e in rows]


def get_aesthetic(conn, agent_id) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT dimension, statement, evidence, t0 FROM agent_aesthetic WHERE agent_id=?",
        (agent_id,)).fetchall()]


REQ_RX = re.compile(r"(需要|应该|建议|改进|需求|痛点|下一步|feature|bug|重构|优化)")


def extract_requirements(conn, room_id, only_human=False) -> list[dict]:
    """把聊天室内容蒸馏为「需求池」条目。only_human=True 时只看真人发言（自升级闭环用）。"""
    rows = conn.execute(
        "SELECT round, agent_id, body, source FROM room_messages WHERE room_id=? AND kind!='skip' "
        "ORDER BY id", (room_id,)).fetchall()
    added = []
    for r in rows:
        if (r["source"] or "chat") == "opencode":
            continue
        if only_human and not _is_human(conn, r["agent_id"]):
            continue
        for sent in re.split(r"[。；;\n]", r["body"] or ""):
            if REQ_RX.search(sent) and len(sent.strip()) >= 6:
                text = sent.strip()[:200]
                exists = conn.execute("SELECT 1 FROM requirements WHERE source_room=? AND text=?",
                                      (room_id, text)).fetchone()
                if exists:
                    continue
                conn.execute("INSERT INTO requirements(source_room, source_round, source_agent, text, kind) "
                             "VALUES (?,?,?,?, 'idea')", (room_id, r["round"], r["agent_id"], text))
                added.append({"text": text, "agent": r["agent_id"], "round": r["round"]})
    conn.commit()
    return added


def extract_requirements_from_posts(conn, channel_id=None) -> list[dict]:
    """所有频道通用：从帖子（及回贴）蒸馏需求池条目。"""
    added = []
    sql = "SELECT id, channel_id, author_id, title, body FROM posts"
    params = []
    if channel_id:
        sql += " WHERE channel_id=?"
        params.append(channel_id)
    for r in conn.execute(sql, params).fetchall():
        text_all = (r["title"] or "") + "。" + (r["body"] or "")
        for sent in re.split(r"[。；;\n]", text_all):
            if REQ_RX.search(sent) and len(sent.strip()) >= 6:
                text = sent.strip()[:200]
                if conn.execute("SELECT 1 FROM requirements WHERE source_room=? AND text=?",
                                (r["channel_id"], text)).fetchone():
                    continue
                conn.execute(
                    "INSERT INTO requirements(source_room, source_round, source_agent, text, kind) "
                    "VALUES (?,?,?,?, 'idea')",
                    (r["channel_id"], None, r["author_id"], text))
                added.append({"channel": r["channel_id"], "text": text, "agent": r["author_id"]})
    # 回贴
    for r in conn.execute(
            "SELECT r.body, r.author_id, p.channel_id FROM replies r JOIN posts p ON p.id=r.post_id").fetchall():
        for sent in re.split(r"[。；;\n]", r["body"] or ""):
            if REQ_RX.search(sent) and len(sent.strip()) >= 6:
                text = sent.strip()[:200]
                if conn.execute("SELECT 1 FROM requirements WHERE source_room=? AND text=?",
                                (r["channel_id"], text)).fetchone():
                    continue
                conn.execute(
                    "INSERT INTO requirements(source_room, source_round, source_agent, text, kind) "
                    "VALUES (?,?,?,?, 'idea')", (r["channel_id"], None, r["author_id"], text))
                added.append({"channel": r["channel_id"], "text": text, "agent": r["author_id"]})
    conn.commit()
    return added


def list_requirements(conn, status=None) -> list[dict]:
    sql = "SELECT * FROM requirements"
    params = []
    if status:
        sql += " WHERE status=?"
        params.append(status)
    sql += " ORDER BY created_at DESC LIMIT 200"
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def team_profile(conn) -> list[dict]:
    out = []
    for a in conn.execute("SELECT id, full_name, role FROM agents WHERE kind='ai'").fetchall():
        out.append({"agent_id": a["id"], "full_name": a["full_name"], "role": a["role"],
                    "aesthetic": get_aesthetic(conn, a["id"])})
    return out


def summary(conn, room_id) -> dict:
    room = get_room(conn, room_id)
    msgs = transcript(conn, room_id)
    per = {}
    for m in msgs:
        a = per.setdefault(m["agent_id"], {"point": 0, "skip": 0, "rehash": 0})
        if m["kind"] == "skip":
            a["skip"] += 1
        else:
            a["point"] += 1
    return {"room": room, "messages": msgs, "per_agent": per, "arena": arena_rank(conn, room_id)}


def clear_room_messages(conn, room_id: str) -> None:
    """清空一个房间的内容，但保留房间/成员（私聊“清空聊天记录”）。"""
    conn.execute("DELETE FROM argument_graphs WHERE message_id IN "
                 "(SELECT id FROM room_messages WHERE room_id=?)", (room_id,))
    for table in ("reevals", "arena", "room_contributions", "room_turns", "room_shares"):
        conn.execute(f"DELETE FROM {table} WHERE room_id=?", (room_id,))
    conn.execute("DELETE FROM room_messages WHERE room_id=?", (room_id,))
    conn.execute("DELETE FROM room_reads WHERE room_id=?", (room_id,))
    conn.commit()


def purge_room(conn, room_id: str) -> None:
    """彻底删除群聊：先清所有引用 rooms 的表，再删房间，避免 FK 500。"""
    conn.execute("DELETE FROM argument_graphs WHERE message_id IN "
                 "(SELECT id FROM room_messages WHERE room_id=?)", (room_id,))
    for table in ("reevals", "arena", "room_contributions", "room_turns",
                  "room_invitations", "room_reads", "room_shares"):
        conn.execute(f"DELETE FROM {table} WHERE room_id=?", (room_id,))
    conn.execute("DELETE FROM room_messages WHERE room_id=?", (room_id,))
    conn.execute("DELETE FROM room_members WHERE room_id=?", (room_id,))
    conn.execute("DELETE FROM rooms WHERE id=?", (room_id,))
    conn.commit()
