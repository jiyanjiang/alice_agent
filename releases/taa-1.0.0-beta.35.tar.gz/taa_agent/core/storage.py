"""存储治理：硬盘用量监控 + 分级删除（标记 → 软删除 → 物理删除）+ 质量优先淘汰。

导师口径（2026-10-22，工作群/本地 TAA 会话）：
  * tokens 会越来越便宜 → **判质量交给模型通读**，不用关键词规则；
  * 删除必须**分梯次**：先在数据库里**标记**，再**删除**（软删/进回收站），最后**物理删除**；
  * 但**最终一定会发生物理删除**（信息爆炸 + 硬盘有限），所以**监控硬盘用量是核心需求**，
    没有用量曲线就做不了删除规划（"我不愿意删视频/图片，但紧张时必须自动删差质量的那批"）；
  * 不变的东西是**提示词 / 生产流程 / 自检标准**——淘汰的是素材，不是标准。

本模块只做**确定性的护栏**（规则只做"不能说/不能删"的兜底，不做"值不值得"）：
  * 分级状态机：`marked`（台账标记，可撤回）→ `deleted`（物理挪进 `.trash/`）→ `purged`（清空回收站）；
  * 每级都有**冷静期** `grace_days`，**不可跳级**、不可缩短；
  * **质量分只作提示**：`confident=False`（读不出元数据）的文件**永不自动淘汰**；
  * **DB 仍引用的文件一律保护**（帖子/消息/朋友圈/任务附件出现过即保护）；
  * 只动白名单根目录内的普通文件；符号链接、隐藏文件、根目录外路径一律拒绝；
  * 默认 **DRY-RUN**，只有 `apply=True` 才动盘；所有动作落 `storage_marks` 台账（谁、何时、为什么）。

用法：
    from . import storage
    storage.status()                                  # 硬盘用量 + 分级计数（人看/机读）
    storage.scan()                                    # 盘点 + 打分（不写库）
    storage.mark(apply=False)                         # 生成淘汰候选（DRY-RUN）
    storage.advise()                                  # 删除建议：按可释放空间排序 + 重复信息优先
    storage.apply_trash(apply=True)                   # marked → .trash/（软删）
    storage.purge(apply=True)                         # .trash → 真删（物理删除）
    storage.restore("static/uploads/xxx.png")         # 撤回（未物理删除前都能救回）
"""
from __future__ import annotations

import hashlib
import os
import re
import shutil
import sqlite3
import time
from datetime import datetime
from pathlib import Path

from . import config

ROOT = Path(__file__).resolve().parent.parent
TRASH_DIR = ROOT / ".trash"

# 扫描/清理白名单（相对 ROOT）。不在此列的路径永不被本模块删除。
DEFAULT_ROOTS = ("static/uploads", "deliverables")

IMG_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".heic", ".tif", ".tiff"}
VIDEO_EXTS = {".mp4", ".mov", ".m4v", ".webm", ".avi", ".mkv"}
MEDIA_EXTS = IMG_EXTS | VIDEO_EXTS

TIERS = ("marked", "deleted", "purged")
HASH_LIMIT = 128 * 1024 * 1024        # 超过此大小不算 sha256（避免单文件拖死盘点）
HASH_CHUNK = 1024 * 1024

DDL = """
CREATE TABLE IF NOT EXISTS storage_usage (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  day        TEXT NOT NULL,                     -- YYYY-MM-DD（本地日）
  root       TEXT NOT NULL,                     -- 相对路径；'__disk__' 表示整块盘
  bytes      INTEGER NOT NULL DEFAULT 0,
  files      INTEGER NOT NULL DEFAULT 0,
  disk_used  INTEGER,
  disk_total INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_storage_usage ON storage_usage(root, day);

CREATE TABLE IF NOT EXISTS storage_marks (
  rel         TEXT PRIMARY KEY,                 -- 相对 ROOT 的 posix 路径
  bytes       INTEGER NOT NULL DEFAULT 0,
  sha256      TEXT,
  kind        TEXT,                             -- image / video / doc / other
  score       REAL,                             -- 质量分 0..1（高=好）
  reason      TEXT,                             -- 命中原因（tiny / duplicate / broken / age / watermark）
  tier        TEXT NOT NULL DEFAULT 'marked'
              CHECK(tier IN ('marked','deleted','purged')),
  actor       TEXT,
  marked_at   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  deleted_at  TEXT,
  purged_at   TEXT,
  note        TEXT
);
CREATE INDEX IF NOT EXISTS idx_storage_marks_tier ON storage_marks(tier, marked_at);
"""


# --------------------------------------------------------------------- 基础工具
def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _parse(ts: str | None) -> datetime | None:
    if not ts:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(str(ts)[:19], fmt)
        except ValueError:
            continue
    return None


def _age_days(ts: str | None) -> float:
    dt = _parse(ts)
    return 1e9 if dt is None else (datetime.now() - dt).total_seconds() / 86400.0


def _rel(path: Path) -> str:
    try:
        return path.resolve().relative_to(ROOT.resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def _roots(roots=None) -> list[Path]:
    out = []
    for r in (roots or config.get("storage.roots", list(DEFAULT_ROOTS))):
        p = Path(r)
        out.append(p if p.is_absolute() else ROOT / p)
    return out


def safe_path(rel: str) -> Path | None:
    """把台账里的相对路径还原为**白名单内**的普通文件路径；不合法返回 None。"""
    if not rel or rel.startswith("/") or ".." in Path(rel).parts:
        return None
    p = (ROOT / rel)
    try:
        resolved = p.resolve(strict=False)
        resolved.relative_to(ROOT.resolve())
    except (ValueError, OSError):
        return None
    if not any(resolved == r.resolve(strict=False) or r.resolve(strict=False) in resolved.parents
               for r in _roots()):
        return None
    return p


def _human(n: int | float) -> str:
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024 or unit == "TB":
            return f"{n:.1f}{unit}" if unit != "B" else f"{int(n)}B"
        n /= 1024
    return f"{n:.1f}TB"


# --------------------------------------------------------------------- 配置/策略
DEFAULTS = {
    "hot_watermark": 85,       # 盘用量 ≥ 85% 视为"紧张"，自动规划淘汰
    "target_watermark": 75,    # 淘汰到 ≤75% 即停手（不为了删而删）
    "min_age_days": 14,        # 只淘汰"至少 N 天没被改过"的文件
    "min_score": 0.35,         # 质量分低于此值才进候选（越高越严）
    "grace_days": 3,           # 每一级冷静期（marked→deleted→purged 都要等）
    "max_files": 200,          # 单次动作上限（防手滑一次清空）
    "kind": "media",           # media=只动图片/视频；all=连文档/压缩包一起
    "protect": [],             # 额外保护的 glob（相对路径）
    "roots": list(DEFAULT_ROOTS),
}


def policy(overrides: dict | None = None) -> dict:
    """生效策略：env > config.yaml(`storage.*`) > 默认值。"""
    p = dict(DEFAULTS)
    env_keys = {
        "hot_watermark": "TEAMAI_STORAGE_HOT",
        "target_watermark": "TEAMAI_STORAGE_TARGET",
        "min_age_days": "TEAMAI_STORAGE_MIN_AGE_DAYS",
        "min_score": "TEAMAI_STORAGE_MIN_SCORE",
        "grace_days": "TEAMAI_STORAGE_GRACE_DAYS",
        "max_files": "TEAMAI_STORAGE_MAX_FILES",
        "kind": "TEAMAI_STORAGE_KIND",
    }
    for k, default in DEFAULTS.items():
        if k in ("roots", "protect"):
            v = config.get(f"storage.{k}", default)
        elif isinstance(default, float):
            v = config.get(f"storage.{k}", default, env=env_keys.get(k))
            try:
                v = float(v)
            except (TypeError, ValueError):
                v = default
        elif isinstance(default, int):
            v = config.get_int(f"storage.{k}", default, env=env_keys.get(k))
        else:
            v = config.get(f"storage.{k}", default, env=env_keys.get(k))
        p[k] = v
    if overrides:
        p.update({k: v for k, v in overrides.items() if v is not None})
    p["grace_days"] = max(0, int(p["grace_days"]))
    p["max_files"] = max(1, int(p["max_files"]))
    return p


# --------------------------------------------------------------------- 台账/用量
def connect(db_path=None) -> sqlite3.Connection:
    path = Path(db_path) if db_path else Path(os.environ.get("TEAMAI_DB") or (ROOT / "data.db"))
    conn = sqlite3.connect(path, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 30000")
    return conn


def ensure_schema(conn: sqlite3.Connection) -> None:
    """建表（幂等）。已存在时**不写库**——避免只读巡检在服务运行中被写锁挡住。"""
    try:
        have = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name IN ('storage_usage','storage_marks')")}
        if len(have) == 2:
            return
    except sqlite3.Error:
        pass
    conn.executescript(DDL)
    conn.commit()


def disk(path=None) -> dict:
    """整块盘的用量（percent 用 used/(used+free)，与 df 的 Capacity 同口径）。"""
    target = Path(path or ROOT)
    while not target.exists() and target != target.parent:
        target = target.parent
    u = shutil.disk_usage(target)
    used_pct = (u.used / (u.used + u.free) * 100.0) if (u.used + u.free) else 0.0
    return {"total": u.total, "used": u.used, "free": u.free, "percent": round(used_pct, 2)}


def _root_stats(roots) -> list[dict]:
    out = []
    for r in roots:
        files = 0
        size = 0
        if r.exists():
            for dirpath, _dirs, names in os.walk(r):
                for n in names:
                    p = Path(dirpath) / n
                    try:
                        if p.is_symlink() or not p.is_file():
                            continue
                        size += p.stat().st_size
                        files += 1
                    except OSError:
                        continue
        out.append({"root": _rel(r), "bytes": size, "files": files})
    return out


def ensure_usage(conn: sqlite3.Connection, roots=None, record: bool = True) -> dict:
    """当日快照（同一天同一根只留最后一次，避免重复干活把历史淹掉）。"""
    d = disk()
    stats = _root_stats(_roots(roots))
    if record:
        ensure_schema(conn)
        day = datetime.now().strftime("%Y-%m-%d")
        for s in stats:
            conn.execute("DELETE FROM storage_usage WHERE day=? AND root=?", (day, s["root"]))
            conn.execute(
                "INSERT INTO storage_usage(day, root, bytes, files, disk_used, disk_total) "
                "VALUES (?,?,?,?,?,?)",
                (day, s["root"], s["bytes"], s["files"], d["used"], d["total"]))
        conn.execute("DELETE FROM storage_usage WHERE day=? AND root='__disk__'", (day,))
        conn.execute(
            "INSERT INTO storage_usage(day, root, bytes, files, disk_used, disk_total) "
            "VALUES (?,?,?,?,?,?)",
            (day, "__disk__", d["used"], 0, d["used"], d["total"]))
        conn.commit()
    return {"disk": d, "roots": stats}


def growth(conn: sqlite3.Connection, root: str = "__disk__", days: int = 14) -> dict:
    """按用量历史估增速与"还有几天满"——删除规划的依据。"""
    try:
        rows = list(conn.execute(
            "SELECT day, bytes, disk_used FROM storage_usage WHERE root=? "
            "ORDER BY day DESC LIMIT ?", (root, max(2, days))))
    except sqlite3.Error:
        return {"per_day": 0, "days": 0, "days_until_full": None}
    rows = [r for r in rows if r["bytes"] is not None]
    if len(rows) < 2:
        return {"per_day": 0, "days": 0, "days_until_full": None}
    newest, oldest = rows[0], rows[-1]
    span = (_parse(newest["day"]) - _parse(oldest["day"])).days or 1
    per_day = (newest["bytes"] - oldest["bytes"]) / span
    d = disk()
    days_until_full = int(d["free"] / per_day) if per_day > 0 else None
    return {"per_day": int(per_day), "days": span, "days_until_full": days_until_full}


def tier_counts(conn: sqlite3.Connection) -> dict:
    try:
        rows = list(conn.execute(
            "SELECT tier, COUNT(*) n, COALESCE(SUM(bytes),0) b FROM storage_marks GROUP BY tier"))
    except sqlite3.Error:
        return {t: {"files": 0, "bytes": 0} for t in TIERS}
    out = {t: {"files": 0, "bytes": 0} for t in TIERS}
    for r in rows:
        if r["tier"] in out:
            out[r["tier"]] = {"files": int(r["n"]), "bytes": int(r["b"])}
    return out


# --------------------------------------------------------------------- 引用保护
_REF_RE = re.compile(r"(?:/static/)?uploads/([\w.\-]+(?:/[\w.\-]+)*)")


def referenced(db_path=None) -> set[str]:
    """全库扫一遍"被引用过的 uploads 路径"（帖子/消息/朋友圈/任务附件都算）。

    规则只做结构护栏：只要某个 uploads 路径在**任何文本列**里出现过，就保护
    （含其父目录与文件名），宁可少删、不可删错。
    """
    path = Path(db_path) if db_path else Path(os.environ.get("TEAMAI_DB") or (ROOT / "data.db"))
    refs: set[str] = set()
    if not path.exists():
        return refs
    conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=30)
    try:
        tables = [r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        for t in tables:
            try:
                cols = [r[1] for r in conn.execute(f'PRAGMA table_info("{t}")')]
            except sqlite3.Error:
                continue
            for c in cols:
                try:
                    rows = conn.execute(
                        f'SELECT "{c}" FROM "{t}" WHERE CAST("{c}" AS TEXT) LIKE \'%uploads/%\' '
                        f'LIMIT 5000')
                except sqlite3.Error:
                    continue
                for (val,) in rows:
                    if not val:
                        continue
                    for m in _REF_RE.finditer(str(val)):
                        rel = m.group(1)
                        parts = rel.split("/")
                        for i in range(1, len(parts) + 1):
                            refs.add("/".join(parts[:i]))
                        refs.add(parts[-1])
    finally:
        conn.close()
    return refs


def _is_protected(rel: str, refs: set[str], protect_globs) -> str | None:
    p = Path(rel)
    if p.name.startswith("."):
        return "hidden"
    inner = rel.split("/", 1)[1] if "/" in rel else rel
    inner_parts = inner.split("/")
    for i in range(1, len(inner_parts) + 1):
        if "/".join(inner_parts[:i]) in refs:
            return "referenced"
    if p.name in refs:
        return "referenced"
    for g in protect_globs or []:
        if p.match(g) or Path(inner).match(g):
            return f"protect:{g}"
    return None


def _keep_file() -> set[str]:
    """仓库根 `.storage-keep`：一行一个相对路径/前缀，手工钉死不删的清单。"""
    f = ROOT / ".storage-keep"
    if not f.exists():
        return set()
    return {ln.strip() for ln in f.read_text(encoding="utf-8", errors="ignore").splitlines()
            if ln.strip() and not ln.startswith("#")}


# --------------------------------------------------------------------- 质量评分
def _sha256(path: Path) -> str | None:
    try:
        if path.stat().st_size > HASH_LIMIT:
            return None
        h = hashlib.sha256()
        with path.open("rb") as f:
            while True:
                b = f.read(HASH_CHUNK)
                if not b:
                    break
                h.update(b)
        return h.hexdigest()
    except OSError:
        return None


def _mp4_meta(path: Path) -> dict:
    """无 ffprobe 也能读 mp4/mov 的时长与分辨率（只读 box 头，不解码）。"""

    def boxes(f, start, end):
        pos = start
        while pos + 8 <= end:
            f.seek(pos)
            hdr = f.read(8)
            if len(hdr) < 8:
                return
            size = int.from_bytes(hdr[0:4], "big")
            typ = hdr[4:8].decode("latin-1", "ignore")
            hsize = 8
            if size == 1:
                ext = f.read(8)
                if len(ext) < 8:
                    return
                size = int.from_bytes(ext, "big")
                hsize = 16
            elif size == 0:
                size = end - pos
            if size < hsize:
                return
            yield typ, pos + hsize, min(pos + size, end)
            pos += size

    out: dict = {}
    try:
        with path.open("rb") as f:
            f.seek(0, 2)
            total = f.tell()
            for typ, s, e in boxes(f, 0, total):
                if typ != "moov":
                    continue
                for t2, s2, e2 in boxes(f, s, e):
                    if t2 == "mvhd":
                        f.seek(s2)
                        data = f.read(min(32, e2 - s2))
                        if len(data) >= 20:
                            if data[0] == 1 and len(data) >= 32:
                                ts = int.from_bytes(data[20:24], "big")
                                du = int.from_bytes(data[24:32], "big")
                            else:
                                ts = int.from_bytes(data[12:16], "big")
                                du = int.from_bytes(data[16:20], "big")
                            if ts:
                                out["duration"] = du / ts
                    elif t2 == "trak":
                        for t3, s3, e3 in boxes(f, s2, e2):
                            if t3 != "tkhd":
                                continue
                            f.seek(s3)
                            data = f.read(min(92, e3 - s3))
                            off = 88 if data[:1] == b"\x01" else 76
                            if len(data) >= off + 8:
                                w = int.from_bytes(data[off:off + 4], "big") / 65536.0
                                h = int.from_bytes(data[off + 4:off + 8], "big") / 65536.0
                                if w and h and "width" not in out:
                                    out["width"], out["height"] = int(w), int(h)
    except (OSError, ValueError):
        return {}
    return out


def score_media(path: Path, kind: str) -> dict:
    """质量分 0..1（高=好）。`confident=False` 时**不得自动淘汰**。

    图片：分辨率 / 边缘清晰度 / 曝光，再乘压缩惩罚；
    视频：分辨率 / 码率（时长可读时）；读不出元数据 → 低置信度。
    """
    size = 0
    try:
        size = path.stat().st_size
    except OSError:
        return {"score": 0.0, "reason": "unreadable", "confident": False, "meta": {}}
    meta: dict = {"bytes": size}
    if kind == "image":
        try:
            from PIL import Image, ImageFilter, ImageStat
        except Exception:                    # 没装 Pillow → 只按大小兜底，低置信度
            return {"score": 0.5, "reason": "no_pillow", "confident": False, "meta": meta}
        try:
            with Image.open(path) as im:
                im.verify()
            with Image.open(path) as im:
                w, h = im.size
                meta.update({"width": w, "height": h})
                gray = im.convert("L")
                thumb = gray.copy()
                thumb.thumbnail((256, 256))
                edges = thumb.filter(ImageFilter.FIND_EDGES)
                ew, eh = edges.size
                if ew > 12 and eh > 12:     # 去掉滤镜自带的边框假边缘
                    edges = edges.crop((3, 3, ew - 3, eh - 3))
                sharp_raw = ImageStat.Stat(edges).var[0] or 0.0
                mean = ImageStat.Stat(thumb).mean[0] or 0.0
        except Exception:
            return {"score": 0.0, "reason": "broken", "confident": True, "meta": meta}
        px = max(1, w * h)
        res = min(1.0, (px / (1280 * 720)) ** 0.5)
        sharp = min(1.0, sharp_raw / 150.0)
        exposure = 1.0 - min(1.0, abs(mean - 128) / 128.0)
        if mean < 8 or mean > 250:
            exposure *= 0.3
        bpp = size / px
        compress = 1.0 if bpp >= 0.02 else max(0.4, bpp / 0.02)
        score = (0.45 * res + 0.30 * sharp + 0.25 * exposure) * compress
        meta.update({"sharp_raw": round(sharp_raw, 1), "mean": round(mean, 1),
                     "bytes_per_px": round(bpp, 4), "compress": round(compress, 2)})
        reasons = []
        if px < 64 * 64:
            reasons.append("tiny")
        if sharp_raw < 8:
            reasons.append("blurry")
        if mean < 12 or mean > 244:
            reasons.append("bad_exposure")
        if bpp < 0.01:
            reasons.append("over_compressed")
        return {"score": round(min(1.0, score), 3), "reason": ",".join(reasons) or "ok",
                "confident": True, "meta": meta}
    if kind == "video":
        m = _mp4_meta(path) if path.suffix.lower() in (".mp4", ".mov", ".m4v") else {}
        meta.update(m)
        w, h, dur = m.get("width"), m.get("height"), m.get("duration")
        if not (w and h):
            return {"score": 0.4, "reason": "no_meta", "confident": False, "meta": meta}
        res = min(1.0, ((w * h) / (1920 * 1080)) ** 0.5)
        kbps = (size * 8 / 1000.0 / dur) if dur else None
        br = min(1.0, (kbps or 800) / 2500.0)
        meta["kbps"] = round(kbps, 1) if kbps else None
        score = 0.65 * res + 0.35 * br
        reasons = []
        if w * h < 320 * 240:
            reasons.append("tiny")
        if kbps and kbps < 150:
            reasons.append("low_bitrate")
        return {"score": round(min(1.0, score), 3), "reason": ",".join(reasons) or "ok",
                "confident": True, "meta": meta}
    # 文档/压缩包：没有"画质"概念，只按体积与年龄做用量清理，不参与质量淘汰
    return {"score": None, "reason": "not_media", "confident": False, "meta": meta}


def kind_of(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in IMG_EXTS:
        return "image"
    if ext in VIDEO_EXTS:
        return "video"
    return "doc"


# --------------------------------------------------------------------- 盘点
def inventory(roots=None) -> list[dict]:
    items: list[dict] = []
    for r in _roots(roots):
        if not r.exists():
            continue
        for dirpath, dirs, names in os.walk(r):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            for n in names:
                p = Path(dirpath) / n
                try:
                    if p.is_symlink() or not p.is_file():
                        continue
                    st = p.stat()
                except OSError:
                    continue
                items.append({"path": p, "rel": _rel(p), "name": n, "size": st.st_size,
                              "mtime": st.st_mtime, "ext": p.suffix.lower(), "kind": kind_of(p)})
    return items


def scan(roots=None, do_hash: bool = True, limit: int | None = None) -> dict:
    """盘点 + 打分（纯只读，不写库、不动盘）。"""
    items = inventory(roots)
    for it in items:
        if do_hash and it["kind"] in ("image", "video"):
            it["sha256"] = _sha256(it["path"])
        if it["kind"] in ("image", "video"):
            it.update(score_media(it["path"], it["kind"]))
        else:
            it.update({"score": None, "reason": "not_media", "confident": False, "meta": {}})
    items.sort(key=lambda x: -x["size"])
    total = sum(i["size"] for i in items)
    by_kind: dict = {}
    for i in items:
        b = by_kind.setdefault(i["kind"], {"files": 0, "bytes": 0})
        b["files"] += 1
        b["bytes"] += i["size"]
    return {"items": items[:limit] if limit else items, "count": len(items), "bytes": total,
            "by_kind": by_kind}


# --------------------------------------------------------------------- 候选规划
def evaluate(roots=None, policy_over: dict | None = None, db_path=None) -> dict:
    """一次盘点 → 全量判定（只读）：候选 / 保护 / 重复组 / 年龄，供 plan 与 advise 共用。

    候选规则（全部满足才进）：
      ① 在白名单根目录内、普通文件、非隐藏；
      ② 未被 DB 引用、未在 `.storage-keep`、未命中 protect glob；
      ③ 文件 mtime 早于 `min_age_days`；
      ④ kind=media 时：质量分 < `min_score` 且 `confident=True`（读不出元数据不自动删）；
      ⑤ 完全重复（sha256 相同）时保留最大/最新的一个，其余进候选；
      ⑥ 单次不超过 `max_files`、按"体积大到小"排序（先省空间）。
    """
    pol = policy(policy_over)
    refs = referenced(db_path)
    keep = _keep_file()
    inv = scan(roots)
    min_age = float(pol["min_age_days"])
    min_score = float(pol["min_score"])

    # 重复组：同 sha256 多个 → 留最优
    raw_groups: dict = {}
    for it in inv["items"]:
        if it.get("sha256"):
            raw_groups.setdefault(it["sha256"], []).append(it)

    items: list[dict] = []
    for it in inv["items"]:
        why = _is_protected(it["rel"], refs, pol.get("protect"))
        if not why and any(it["rel"] == k or it["rel"].startswith(k.rstrip("/") + "/") for k in keep):
            why = "storage-keep"
        age = (time.time() - it["mtime"]) / 86400.0
        reasons: list[str] = []
        peers = [x for x in raw_groups.get(it.get("sha256") or "", []) if x is not it]
        best = max([it] + peers, key=lambda x: (x["size"], x["mtime"])) if peers else it
        dup_of = best["rel"] if peers and best is not it else None
        if not why and age >= min_age:
            if it["kind"] in ("image", "video"):
                if it.get("confident") and (it.get("score") or 0) < min_score:
                    reasons.append(it.get("reason") or "low_score")
                if dup_of:
                    reasons.append("duplicate")
            elif pol["kind"] == "all":
                reasons.append("age")
        items.append({**it, "protected_by": why, "age_days": round(age, 1),
                      "dup_of": dup_of, "reasons": reasons, "candidate": bool(reasons)})

    # 对外用"已判定"的 items 组重复组（带 protected_by / age_days，调用方可直接用）
    groups: dict = {}
    for it in items:
        if it.get("sha256"):
            groups.setdefault(it["sha256"], []).append(it)

    return {"policy": pol, "refs": refs, "scanned": {"files": inv["count"],
                                                    "bytes": inv["bytes"],
                                                    "by_kind": inv["by_kind"]},
            "items": items, "groups": {k: v for k, v in groups.items() if len(v) > 1}}


def plan(conn: sqlite3.Connection, roots=None, policy_over: dict | None = None,
         db_path=None) -> dict:
    """生成淘汰候选（只读）：返回候选/保护/量级，不写库。规则见 `evaluate()`。"""
    ev = evaluate(roots=roots, policy_over=policy_over, db_path=db_path)
    pol = ev["policy"]
    candidates = [{k: v for k, v in it.items() if k != "protected_by"}
                  for it in ev["items"] if it["candidate"]]
    protected = [{**{k: v for k, v in it.items() if k != "candidate"},
                  "protected_by": it["protected_by"]}
                 for it in ev["items"] if it["protected_by"]]

    candidates.sort(key=lambda x: -x["size"])
    capped = candidates[: int(pol["max_files"])]
    return {
        "policy": pol,
        "disk": disk(),
        "scanned": ev["scanned"],
        "candidates": capped,
        "candidate_count": len(candidates),
        "candidate_bytes": sum(c["size"] for c in candidates),
        "reclaim_bytes": sum(c["size"] for c in capped),
        "protected": protected[:50],
        "protected_count": len(protected),
    }


def mark(apply: bool = False, roots=None, policy_over: dict | None = None,
         db_path=None, actor: str | None = None) -> dict:
    """第一级：在数据库里**标记**候选（可撤回；不动盘）。"""
    conn = connect(db_path)
    try:
        ensure_schema(conn)
        p = plan(conn, roots=roots, policy_over=policy_over, db_path=db_path)
        if apply:
            for c in p["candidates"]:
                conn.execute(
                    "INSERT INTO storage_marks(rel, bytes, sha256, kind, score, reason, tier, actor) "
                    "VALUES (?,?,?,?,?,?, 'marked', ?) "
                    "ON CONFLICT(rel) DO UPDATE SET bytes=excluded.bytes, sha256=excluded.sha256, "
                    "kind=excluded.kind, score=excluded.score, reason=excluded.reason, "
                    "actor=excluded.actor, marked_at=datetime('now','localtime') "
                    "WHERE storage_marks.tier='marked'",
                    (c["rel"], c["size"], c.get("sha256"), c["kind"], c.get("score"),
                     ",".join(c["reasons"]), actor or os.environ.get("USER", "unknown")))
            conn.commit()
        p["marked"] = len(p["candidates"]) if apply else 0
        p["dry_run"] = not apply
        p["tiers"] = tier_counts(conn)
        return p
    finally:
        conn.close()


# --------------------------------------------------------------------- 二/三级
def _eligible(conn: sqlite3.Connection, tier: str, grace_days: int, max_files: int):
    ts_col = "marked_at" if tier == "marked" else "deleted_at"
    rows = list(conn.execute(
        f"SELECT * FROM storage_marks WHERE tier=? ORDER BY bytes DESC", (tier,)))
    out = []
    for r in rows:
        if _age_days(r[ts_col]) >= grace_days:
            out.append(r)
        if len(out) >= max_files:
            break
    return out


def apply_trash(apply: bool = False, grace_days: int | None = None, max_files: int | None = None,
                db_path=None, actor: str | None = None) -> dict:
    """第二级：`marked → deleted`（把文件挪进 `.trash/<日期>/…`，可 restore）。"""
    pol = policy()
    grace = pol["grace_days"] if grace_days is None else int(grace_days)
    cap = int(max_files or pol["max_files"])
    conn = connect(db_path)
    moved, skipped, bytes_moved = [], [], 0
    try:
        ensure_schema(conn)
        for r in _eligible(conn, "marked", grace, cap):
            src = safe_path(r["rel"])
            if src is None or not src.exists():
                skipped.append({"rel": r["rel"], "why": "missing_or_out_of_scope"})
                continue
            dest = TRASH_DIR / datetime.now().strftime("%Y%m%d") / r["rel"]
            if not apply:
                moved.append({"rel": r["rel"], "bytes": r["bytes"], "dest": _rel(dest)})
                bytes_moved += r["bytes"]
                continue
            try:
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(src), str(dest))
            except OSError as e:
                skipped.append({"rel": r["rel"], "why": f"move_failed:{e}"})
                continue
            conn.execute(
                "UPDATE storage_marks SET tier='deleted', deleted_at=datetime('now','localtime'), "
                "actor=?, note=COALESCE(note,'')||? WHERE rel=?",
                (actor or os.environ.get("USER", "unknown"), f" trash={_rel(dest)}", r["rel"]))
            moved.append({"rel": r["rel"], "bytes": r["bytes"], "dest": _rel(dest)})
            bytes_moved += r["bytes"]
        if apply:
            conn.commit()
        return {"dry_run": not apply, "grace_days": grace, "moved": moved,
                "moved_count": len(moved), "bytes": bytes_moved, "skipped": skipped,
                "tiers": tier_counts(conn)}
    finally:
        conn.close()


def purge(apply: bool = False, grace_days: int | None = None, max_files: int | None = None,
          db_path=None, actor: str | None = None) -> dict:
    """第三级：`deleted → purged`（物理删除回收站里的文件，不可恢复）。"""
    pol = policy()
    grace = pol["grace_days"] if grace_days is None else int(grace_days)
    cap = int(max_files or pol["max_files"])
    conn = connect(db_path)
    out, skipped, freed = [], [], 0
    try:
        ensure_schema(conn)
        for r in _eligible(conn, "deleted", grace, cap):
            note = r["note"] or ""
            m = re.search(r"trash=(\S+)", note)
            rel_trash = m.group(1) if m else None
            dest = (ROOT / rel_trash) if rel_trash else None
            if dest is None or TRASH_DIR.resolve() not in dest.resolve(strict=False).parents:
                skipped.append({"rel": r["rel"], "why": "trash_path_unresolved"})
                continue
            if not dest.exists():
                if apply:
                    conn.execute("UPDATE storage_marks SET tier='purged', "
                                 "purged_at=datetime('now','localtime') WHERE rel=?", (r["rel"],))
                out.append({"rel": r["rel"], "bytes": r["bytes"], "why": "already_gone"})
                freed += r["bytes"]
                continue
            if not apply:
                out.append({"rel": r["rel"], "bytes": r["bytes"]})
                freed += r["bytes"]
                continue
            try:
                size = dest.stat().st_size
                dest.unlink()
            except OSError as e:
                skipped.append({"rel": r["rel"], "why": f"unlink_failed:{e}"})
                continue
            freed += size
            conn.execute("UPDATE storage_marks SET tier='purged', "
                         "purged_at=datetime('now','localtime'), actor=? WHERE rel=?",
                         (actor or os.environ.get("USER", "unknown"), r["rel"]))
            out.append({"rel": r["rel"], "bytes": size})
        if apply:
            # 清空空的回收站目录（只删空目录，不递归删文件）
            if TRASH_DIR.exists():
                for dirpath, dirs, names in os.walk(TRASH_DIR, topdown=False):
                    if not dirs and not names:
                        try:
                            Path(dirpath).rmdir()
                        except OSError:
                            pass
            conn.commit()
        return {"dry_run": not apply, "grace_days": grace, "purged": out,
                "purged_count": len(out), "freed_bytes": freed, "skipped": skipped,
                "tiers": tier_counts(conn)}
    finally:
        conn.close()


def restore(rel: str, db_path=None) -> dict:
    """撤回：把 `.trash` 里的文件搬回原位（仅 `deleted` 级可用）。"""
    conn = connect(db_path)
    try:
        ensure_schema(conn)
        row = conn.execute("SELECT * FROM storage_marks WHERE rel=?", (rel,)).fetchone()
        if not row:
            return {"ok": False, "why": "not_in_ledger"}
        if row["tier"] == "purged":
            return {"ok": False, "why": "already_purged"}
        m = re.search(r"trash=(\S+)", row["note"] or "")
        if not m:
            return {"ok": False, "why": "no_trash_path"}
        src = ROOT / m.group(1)
        if not src.exists():
            return {"ok": False, "why": "trash_file_missing"}
        dest = safe_path(rel)
        if dest is None:
            return {"ok": False, "why": "out_of_scope"}
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dest))
        conn.execute("DELETE FROM storage_marks WHERE rel=?", (rel,))
        conn.commit()
        return {"ok": True, "rel": rel, "bytes": row["bytes"]}
    finally:
        conn.close()


# --------------------------------------------------------------------- 总览/报告
def status(roots=None, db_path=None, record: bool = True) -> dict:
    conn = connect(db_path)
    try:
        snap = ensure_usage(conn, roots=roots, record=record)
        return {
            "disk": snap["disk"],
            "roots": snap["roots"],
            "tiers": tier_counts(conn),
            "growth": growth(conn),
            "policy": policy(),
            "trash_bytes": _root_stats([TRASH_DIR])[0]["bytes"],
            "trash_files": _root_stats([TRASH_DIR])[0]["files"],
        }
    finally:
        conn.close()


def report(roots=None, db_path=None, top: int = 10) -> dict:
    """给"删除规划"用：现状 + 增速 + 候选量 + 三级台账 + 建议动作（收效排序）。

    一次盘点出全部结论（内部走 `advise()`，不再重复 scan）。
    """
    adv = advise(roots=roots, db_path=db_path, top=top, record=True)
    st, pol, d = adv["status"], adv["policy"], adv["disk"]
    advice = []
    if adv["urgency"] == "hot":
        advice.append(f"盘用量 {d['percent']}% ≥ 阈值 {pol['hot_watermark']}%：执行 "
                      f"`teamai storage mark --apply` 建候选，再按冷静期 apply/purge")
    else:
        advice.append(f"盘用量 {d['percent']}% < 阈值 {pol['hot_watermark']}%：只监控，不必淘汰")
    if st["tiers"]["deleted"]["files"]:
        advice.append(f"回收站有 {st['tiers']['deleted']['files']} 个文件"
                      f"（{_human(st['tiers']['deleted']['bytes'])}）：冷静期满后可 purge")
    if st["growth"].get("days_until_full"):
        advice.append(f"按近 {st['growth']['days']} 天增速 {_human(st['growth']['per_day'])}/天，"
                      f"约 {st['growth']['days_until_full']} 天写满")
    if adv["recommendations"]:
        top1 = adv["recommendations"][0]
        advice.append(f"收效最大：{_human(top1['bytes'])}（{top1['category']}）→ {top1['next_cmd']}")
    return {"status": st, "plan": adv["plan"], "advice": advice,
            "advise": adv, "recommendations": adv["recommendations"]}


# --------------------------------------------------------------------- 删除建议（收效排序）
BACKUP_GLOBS = ("data.db.bak-*", "data.db.snap-*", "data.db.step*.bak", "memory.db.bak-*")


def advise(roots=None, db_path=None, top: int = 10, record: bool = False,
           deep: bool = True, big_bytes: int = 50 * 1024 * 1024) -> dict:
    """删除建议（只读）：把"该删什么、能省多少、先删哪个"排成一张可决策的表。

    口径（2026-10-22 导师指令：分级删除 + 监控用量 + 每次自检给建议）：
      * **收效 = 最终可释放字节**，按体积降序；`frees_now` 区分"立即腾地方"与"只是进流水线"
        —— `.trash/` 与仓库同盘，所以一级（标记）/二级（软删）**不释放空间**，只有
        `purged` 才真回收；不把"标了"当成"省了"。
      * **重复信息优先**：sha256 完全相同的组单独成条（保留哪个、删哪个、省多少）；
        受 DB 引用保护/未过 `min_age_days` 的重复件也照实列出（标 `需先解引用`），不隐藏。
      * 盘用量 + 增速 + 目标水位一起给："还差多少、几天写满、删完延后几天"。
      * 只给建议，**不写库、不动盘**；`record=True` 只落当日用量快照（同日覆盖、幂等）。
    """
    conn = connect(db_path)
    try:
        ensure_schema(conn)
        st = status(roots=roots, db_path=db_path, record=record)
        ev = evaluate(roots=roots, db_path=db_path) if deep else None
        pol = ev["policy"] if ev else policy()
        grace = int(pol["grace_days"])
        cap = int(pol["max_files"])
        min_age = float(pol["min_age_days"])
        d = st["disk"]
        total = max(1, int(d["total"]))
        recs: list[dict] = []

        def add(**kw):
            rec = {"id": kw.get("id") or kw["category"],
                   "category": kw["category"], "action": kw.get("action", "review"),
                   "tier": kw.get("tier", "-"), "duplicate": bool(kw.get("duplicate")),
                   "bytes": int(kw.get("bytes", 0) or 0), "files": int(kw.get("files", 0) or 0),
                   "frees_now": bool(kw.get("frees_now")),
                   "release_days": int(kw.get("release_days", 0) or 0),
                   "risk": kw.get("risk", "low"), "note": kw.get("note", ""),
                   "next_cmd": kw.get("next_cmd", ""), "objects": kw.get("objects", [])}
            if rec["bytes"] > 0:
                recs.append(rec)
            return rec

        dup_group_count = 0
        rows = {"marked": {}, "deleted": {}}
        for r in conn.execute("SELECT * FROM storage_marks WHERE tier IN ('marked','deleted')"):
            rows[r["tier"]][r["rel"]] = dict(r)

        # ① 三级：回收站里冷静期满的 → 物理删除（唯一"立即释放空间"的一步）
        ready = _eligible(conn, "deleted", grace, cap)
        if ready:
            b = sum(int(r["bytes"] or 0) for r in ready)
            add(id="purge-trash", category="trash_purge", action="purge", tier="deleted",
                bytes=b, files=len(ready), frees_now=True, release_days=0, risk="low",
                note=f"已在 `.trash/` 且冷静期 {grace} 天已满；purge 后不可恢复，先抽查",
                next_cmd="teamai storage purge --apply",
                objects=[_human(r["bytes"]) + "  " + r["rel"] for r in ready[:5]])
        waiting = [r for r in rows["deleted"].values() if _age_days(r["deleted_at"]) < grace]
        if waiting:
            b = sum(int(r["bytes"] or 0) for r in waiting)
            add(id="wait-trash", category="waiting", action="wait", tier="deleted",
                bytes=b, files=len(waiting), release_days=grace, risk="low",
                note="软删已生效但仍在冷静期（期间不释放空间，可 restore 反悔）",
                next_cmd=f"等待至冷静期满后 teamai storage purge --apply")

        if ev:
            items = ev["items"]
            by_rel = {it["rel"]: it for it in items}

            # ② 重复信息（同 sha256）：按类别聚合成一条，避免几百行表格没法决策
            dup_fresh: list[dict] = []
            dup_blocked: list[dict] = []
            for sha, group in ev["groups"].items():
                best = max(group, key=lambda x: (x["size"], x["mtime"]))
                for x in group:
                    if x is best or x["rel"] in rows["marked"] or x["rel"] in rows["deleted"]:
                        continue
                    rec = {**x, "best": best["rel"]}
                    (dup_fresh if (not x["protected_by"] and x["age_days"] >= min_age)
                     else dup_blocked).append(rec)
            if dup_fresh:
                dup_fresh.sort(key=lambda x: -x["size"])
                n_groups = len({x["sha256"] for x in dup_fresh})
                dup_group_count = n_groups
                add(id="dup", category="duplicate", action="mark", tier="marked",
                    duplicate=True, bytes=sum(x["size"] for x in dup_fresh),
                    files=len(dup_fresh), release_days=2 * grace, risk="low",
                    note=f"{n_groups} 组字节级相同（sha256）：每组保留体积/时间最优的一份，"
                         f"其余删掉；mark→软删→purge 约 {2 * grace} 天后真正释放",
                    next_cmd="teamai storage mark --apply",
                    objects=[f"{_human(x['size'])}  {x['rel']} ← 保留 {x['best']}"
                             for x in dup_fresh[:5]])
            if dup_blocked:
                dup_blocked.sort(key=lambda x: -x["size"])
                why: dict = {}
                for x in dup_blocked:
                    why[x["protected_by"] or "min_age"] = why.get(x["protected_by"] or "min_age", 0) + 1
                detail = "、".join(f"{k}×{v}" for k, v in sorted(why.items(), key=lambda kv: -kv[1]))
                add(id="dup-blocked", category="duplicate_blocked", action="unref",
                    tier="-", duplicate=True, bytes=sum(x["size"] for x in dup_blocked),
                    files=len(dup_blocked), release_days=2 * grace, risk="medium",
                    note=f"重复件但被保护（{detail}）：删前须先解引用或等过最小年龄；"
                         f"工具不会自动动它们（引用即保护）",
                    next_cmd="先解引用（改 DB/`.storage-keep` 中的引用）→ 再 teamai storage mark --apply",
                    objects=[f"{_human(x['size'])}  {x['rel']} ← 保留 {x['best']}"
                             for x in dup_blocked[:5]])

            # ③ 质量分低的媒体 / 坏文件（低分但高置信才进，规则不越界）
            lowq = [it for it in items
                    if it["candidate"] and "duplicate" not in it["reasons"]
                    and it["rel"] not in rows["marked"] and it["rel"] not in rows["deleted"]]
            if lowq:
                lowq.sort(key=lambda x: -x["size"])
                risky = any((it.get("score") or 0) >= 0.2 for it in lowq)
                add(id="lowq", category="low_quality", action="mark", tier="marked",
                    bytes=sum(it["size"] for it in lowq), files=len(lowq),
                    release_days=2 * grace, risk="medium" if risky else "low",
                    note=f"{len(lowq)} 个媒体件质量分 < {pol['min_score']}"
                         f"（坏文件/极小/模糊/码率低），只处理 confident=True 的；读不出元数据的不动",
                    next_cmd="teamai storage mark --apply",
                    objects=[f"{_human(it['size'])}  {it['rel']}"
                             f"（分 {it.get('score')} {','.join(it['reasons'])}）"
                             for it in lowq[:5]])

            # ④ 未引用的大件（doc/产物）：默认 kind=media 不自动处理，等人拍板
            bigs = [it for it in items if it["kind"] == "doc" and not it["protected_by"]
                    and it["age_days"] >= min_age and it["size"] >= big_bytes
                    and it["rel"] not in rows["marked"] and it["rel"] not in rows["deleted"]]
            for it in sorted(bigs, key=lambda x: -x["size"])[:5]:
                add(id="big:" + it["rel"], category="big_unreferenced", action="review",
                    tier="-", bytes=it["size"], files=1, release_days=2 * grace,
                    risk="medium",
                    note=f"未被 DB 引用的大件（{it['age_days']:.0f} 天未改）；"
                         f"可能是任务证据，需人工确认后 `--kind all` 才进候选",
                    next_cmd="人工确认后：teamai storage mark --apply --kind all",
                    objects=[f"{_human(it['size'])}  {it['rel']}"])

            # ⑤ 已标记但当前不再是候选（受保护/文件缺失）→ 台账复核
            stale = [r for rel, r in rows["marked"].items() if rel not in by_rel]
            if stale:
                add(id="marked-stale", category="ledger_stale", action="review", tier="marked",
                    bytes=sum(int(r["bytes"] or 0) for r in stale), files=len(stale),
                    risk="medium", note="台账里有标记，但盘上文件已不在/已不在白名单：核对后 restore 或清理台账",
                    next_cmd="teamai storage status --json（核对 rel）",
                    objects=[r["rel"] for r in stale[:5]])

        # ⑥ 仓库根历史备份（不在白名单，工具永不自动删 → 只提示人工）
        backups = []
        for pat in BACKUP_GLOBS:
            for p in ROOT.glob(pat):
                try:
                    if p.is_file() and p.stat().st_size >= 1024 * 1024:
                        backups.append(p)
                except OSError:
                    continue
        if backups:
            b = sum(p.stat().st_size for p in backups)
            add(id="repo-backup", category="repo_backup", action="review", tier="-",
                bytes=b, files=len(backups), frees_now=True, risk="medium",
                note="仓库根的历史备份（不在白名单，工具不代删）：人工确认后可弃，rm 即释放",
                next_cmd="人工确认：ls -lh data.db.bak-* data.db.snap-* 后 rm",
                objects=[f"{_human(p.stat().st_size)}  {p.name}" for p in backups[:5]])

        # ---- 候选视图（与 plan() 同口径，供 report/CLI 复用，避免二次盘点）----
        plan_view: dict = {"candidate_count": 0, "candidate_bytes": 0, "reclaim_bytes": 0,
                           "protected_count": 0, "candidates": []}
        if ev:
            cands = [{k: v for k, v in it.items() if k != "protected_by"}
                     for it in ev["items"] if it["candidate"]]
            cands.sort(key=lambda x: -x["size"])
            cap = int(pol["max_files"])
            plan_view = {"candidate_count": len(cands),
                         "candidate_bytes": sum(c["size"] for c in cands),
                         "reclaim_bytes": sum(c["size"] for c in cands[:cap]),
                         "protected_count": len([it for it in ev["items"] if it["protected_by"]]),
                         "candidates": cands[:cap]}

        # ---- 排序与累计：收效（字节）降序，重复信息优先同档 ----
        recs.sort(key=lambda r: (r["bytes"], 1 if r["duplicate"] else 0), reverse=True)
        cum = cum_now = 0
        for r in recs:
            cum += r["bytes"]
            cum_now += r["bytes"] if r["frees_now"] else 0
            r["pct"] = round(r["bytes"] / total * 100, 4)
            r["cum_bytes"] = cum
            r["cum_pct"] = round(cum / total * 100, 4)

        target = float(pol["target_watermark"])
        avail = int(d["used"]) + int(d["free"])
        need = max(0, int(d["used"] - avail * target / 100.0))
        take, acc = 0, 0
        for r in recs:
            if acc >= need:
                break
            acc += r["bytes"]
            take += 1
        g = st["growth"]
        per_day = g.get("per_day") or 0
        freed_now = cum_now
        after = int(d["used"]) - freed_now
        gain_days = int(freed_now / per_day) if per_day > 0 else None

        subtotals: dict = {}
        for r in recs:
            s = subtotals.setdefault(r["category"], {"files": 0, "bytes": 0})
            s["files"] += r["files"]
            s["bytes"] += r["bytes"]

        return {
            "when": _now(), "disk": d, "growth": g, "policy": pol,
            "urgency": "hot" if d["percent"] >= float(pol["hot_watermark"])
                       else ("watch" if d["percent"] >= target else "ok"),
            "status": st,
            "target": {"watermark": target, "need_bytes": need, "top_n_to_target": take},
            "totals": {"reclaim_pipeline": cum, "frees_now": cum_now,
                       "duplicate_bytes": sum(r["bytes"] for r in recs if r["duplicate"]),
                       "dup_groups": dup_group_count,
                       "ledger": st["tiers"], "trash_bytes": st["trash_bytes"]},
            "days": {"min_pipeline_days": 2 * int(pol["grace_days"]),
                     "grace_days": int(pol["grace_days"]),
                     "days_until_full": g.get("days_until_full"),
                     "gain_days_after_freed": gain_days,
                     "percent_after_freed_now": round(after / max(1, avail) * 100, 2)},
            "subtotals": subtotals,
            "plan": plan_view,
            "recommendations": recs,
            "top": recs[: int(top)] if top else recs,
            "deep": bool(deep),
        }
    finally:
        conn.close()


# --------------------------------------------------------------------- 展示
def human_advise(adv: dict, top: int = 10) -> str:
    """把建议渲染成一张"先删哪个、省多少"的决策表（人看）。"""
    d, pol, tg, tot = adv["disk"], adv["policy"], adv["target"], adv["totals"]
    lines = [f"== 删除建议（按收效排序）· {adv['when']} ==",
             f"  磁盘 {_human(d['used'])}/{_human(d['total'])}（{d['percent']}%）"
             f" · 可用 {_human(d['free'])} · 目标水位 {tg['watermark']}%"
             + (f"，还需释放 {_human(tg['need_bytes'])}"
                if tg["need_bytes"] else "（已低于目标，不必淘汰）")]
    g, dy = adv["growth"], adv["days"]
    if g.get("days"):
        lines.append(f"  增速 {_human(g['per_day'])}/天（近 {g['days']} 天）· 预计 "
                     + (f"{g['days_until_full']} 天写满" if g.get("days_until_full") else "短期不会写满"))
    cur = adv["urgency"]
    verdict = ("⚠ 已过热阈值，建议立刻推进" if cur == "hot"
               else ("· 观察区：可低优先处理重复信息" if cur == "watch"
                     else f"· 未到目标水位（{d['percent']}% ≤ {tg['watermark']}%）：只监控，"
                          f"重复信息可顺手清"))
    lines.append(f"  结论：{verdict}"
                 f" ｜ 全流程最快 {dy['min_pipeline_days']} 天（两级冷静期各 {dy['grace_days']} 天）")
    lines.append(f"  合计：可回收 {_human(tot['reclaim_pipeline'])}（其中立即释放 "
                 f"{_human(tot['frees_now'])}）· 重复信息 {tot['dup_groups']} 组 / "
                 f"{_human(tot['duplicate_bytes'])}")
    if not adv["recommendations"]:
        lines.append("  · 无建议项：盘上无重复/低质/未引用大件，回收站也空 —— 无需动作。")
        return "\n".join(lines)
    lines.append("")
    lines.append(f"  {'#':<3}{'可释放':>9}{'占盘':>8}{'累计':>8}  {'类别':<12}{'梯度':<9}"
                 f"{'立即':<5}{'风险':<5}对象 / 理由")
    label = {"duplicate": "重复信息", "duplicate_blocked": "重复·受阻",
             "low_quality": "低质媒体", "big_unreferenced": "大件未引用",
             "trash_purge": "回收站待清", "waiting": "冷静期中",
             "repo_backup": "历史备份", "ledger_stale": "台账复核"}
    risk = {"low": "低", "medium": "中", "high": "高"}
    for i, r in enumerate(adv["recommendations"][:top], 1):
        obj = r["objects"][0] if r["objects"] else ""
        if r["files"] > 1:
            obj = f"{obj} …等 {r['files']} 项"
        lines.append(f"  {i:<3}{_human(r['bytes']):>9}{r['pct']:>7.2f}%{r['cum_pct']:>7.2f}%  "
                     f"{label.get(r['category'], r['category']):<12}{r['tier']:<9}"
                     f"{'是' if r['frees_now'] else '否':<5}{risk.get(r['risk'], r['risk']):<5}{obj}")
        if r["note"] and i <= 3:
            lines.append(f"     ↳ {r['note']}  〔{r['next_cmd']}〕")
    rest = len(adv["recommendations"]) - top
    if rest > 0:
        lines.append(f"  … 另有 {rest} 条（--top {len(adv['recommendations'])} 查看全部）")
    first = adv["recommendations"][0]
    lines.append("")
    lines.append(f"  ✅ 收效最大：#{1} {label.get(first['category'], first['category'])} "
                 f"{_human(first['bytes'])} —— {first['next_cmd']}")
    if not tot["frees_now"]:
        lines.append("  ⚠ 一级（标记）/二级（软删）**不释放空间**（`.trash/` 与仓库同盘）："
                     f"要真腾地方必须走到 purge（最快 {dy['min_pipeline_days']} 天后）。")
    if dy.get("gain_days_after_freed") is not None:
        lines.append(f"  · 立即释放后：盘用量约 {dy['percent_after_freed_now']}%，"
                     f"可多撑约 {dy['gain_days_after_freed']} 天。")
    return "\n".join(lines)


def human_status(st: dict) -> str:
    d = st["disk"]
    lines = [f"== 存储治理 · {datetime.now():%Y-%m-%d %H:%M} ==",
             f"  磁盘：{_human(d['used'])}/{_human(d['total'])}（{d['percent']}%）"
             f"  可用 {_human(d['free'])}"]
    for r in st["roots"]:
        lines.append(f"  {r['root']:<22}{_human(r['bytes']):>9}  {r['files']:>6} 个文件")
    t = st["tiers"]
    lines.append(f"  台账：marked={t['marked']['files']}({_human(t['marked']['bytes'])})  "
                 f"deleted={t['deleted']['files']}({_human(t['deleted']['bytes'])})  "
                 f"purged={t['purged']['files']}({_human(t['purged']['bytes'])})")
    lines.append(f"  回收站：{st['trash_files']} 个 / {_human(st['trash_bytes'])}")
    g = st["growth"]
    if g.get("days"):
        lines.append(f"  增速：{_human(g['per_day'])}/天（近 {g['days']} 天）；"
                     f"预计 {g['days_until_full'] if g.get('days_until_full') else '—'} 天写满")
    return "\n".join(lines)
