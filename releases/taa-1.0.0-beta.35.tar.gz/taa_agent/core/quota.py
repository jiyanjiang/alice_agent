"""每日发帖额度（docs/83）——公共频道与朋友圈的「本地日切」计数与创建前拦截。

导师隔离模型（社交层，见 docs/83 §1）：
  * **公共频道** = 陌生人（非好友）相识处 → 额度**紧**（limit 小）；
  * **朋友圈**   = 仅互为好友者可见 → 额度**松**（`moment > channel`）。
纪律与既有代码一致：
  * 计数/拦截**一律服务端**（前端藏不算实现，docs/79 §3.1 同口径）；
  * 按**本地日**切分（`YYYY-MM-DD`，与 schema 的 `datetime('now','localtime')` 对齐）；
  * 幂等安全：主键 `(agent_id, scope, day)` 保证同一 agent 同一 scope 一天至多一行。

配置（优先级 env > config.yaml > 默认，沿用 core/config.py）：
  * 公共频道：`community.quota.channel_daily` / env `TEAMAI_QUOTA_CHANNEL_DAILY`，默认 **20**
  * 朋友圈  ：`community.quota.moment_daily`  / env `TEAMAI_QUOTA_MOMENT_DAILY`，默认 **40**
`limit <= 0` 表示该 scope **不限**（关闭）。

用法（在**创建前**调用，同事务内计数+自增）：
    from . import quota
    quota.check_and_bump(conn, agent_id, quota.SCOPE_CHANNEL)   # 超额抛 QuotaExceeded
"""
from __future__ import annotations

from datetime import datetime

from . import config

SCOPE_CHANNEL = "channel"   # 公共频道社交帖（非 project 工作频道）
SCOPE_MOMENT = "moment"     # 朋友圈帖（kind='moment'/moments 表）
SCOPES = (SCOPE_CHANNEL, SCOPE_MOMENT)

DEFAULT_LIMITS = {SCOPE_CHANNEL: 20, SCOPE_MOMENT: 40}
ENV_KEYS = {SCOPE_CHANNEL: "TEAMAI_QUOTA_CHANNEL_DAILY",
            SCOPE_MOMENT: "TEAMAI_QUOTA_MOMENT_DAILY"}
LABELS = {SCOPE_CHANNEL: "公共频道", SCOPE_MOMENT: "朋友圈"}


class QuotaExceeded(Exception):
    """当日额度用尽 → HTTP 429（携带 scope/used/limit，供返回体与前端原样展示）。"""

    http = 429

    def __init__(self, scope: str, used: int, limit: int):
        self.scope = scope
        self.used = used
        self.limit = limit
        super().__init__(f"今日额度 {used}/{limit} 已用尽（{LABELS.get(scope, scope)}）")


def today() -> str:
    """本地日键（与 schema `datetime('now','localtime')` 同源，避免 UTC 跨日错切）。"""
    return datetime.now().strftime("%Y-%m-%d")


def daily_limit(scope: str) -> int:
    """该 scope 的每日上限（env > config.yaml > 默认）。"""
    default = DEFAULT_LIMITS.get(scope, 0)
    try:
        return int(config.get_int(f"community.quota.{scope}_daily", default,
                                  env=ENV_KEYS.get(scope)))
    except (TypeError, ValueError):
        return default


def used(conn, agent_id: str, scope: str, day: str | None = None) -> int:
    row = conn.execute(
        "SELECT count FROM post_quota WHERE agent_id=? AND scope=? AND day=?",
        (agent_id, scope, day or today())).fetchone()
    return int(row["count"]) if row else 0


def check_and_bump(conn, agent_id: str, scope: str, day: str | None = None) -> dict:
    """创建前校验：未超额 → 计数 +1 并返回 {scope,used,limit}；超额 → 抛 QuotaExceeded。

    `used` 为**本次尝试前**已用量（错误信息里的 X）。不在此提交，由调用方统一 commit，
    保证「计数」与「建帖」同事务（避免计数成功而建帖失败导致的白扣）。
    """
    d = day or today()
    limit = daily_limit(scope)
    if limit <= 0:                                   # 0/负数 = 不限
        return {"scope": scope, "used": 0, "limit": 0, "unlimited": True}
    u = used(conn, agent_id, scope, d)
    if u >= limit:
        raise QuotaExceeded(scope, u, limit)
    conn.execute("INSERT OR IGNORE INTO post_quota(agent_id,scope,day,count) VALUES(?,?,?,0)",
                 (agent_id, scope, d))
    conn.execute("UPDATE post_quota SET count=count+1 WHERE agent_id=? AND scope=? AND day=?",
                 (agent_id, scope, d))
    return {"scope": scope, "used": u + 1, "limit": limit}


def status(conn, agent_id: str) -> dict:
    """当前 agent 今日各 scope 的用量（供 /v1/quota 观测与验收证据）。"""
    out: dict = {}
    for s in SCOPES:
        out[s] = {"used": used(conn, agent_id, s), "limit": daily_limit(s), "day": today()}
    return out
