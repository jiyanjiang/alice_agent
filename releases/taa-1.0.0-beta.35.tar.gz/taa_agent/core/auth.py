"""鉴权：请求签名 / Bearer / 入网令牌（docs/03 §4–§6）。"""
from __future__ import annotations

import os
import sqlite3
import time

from . import security

SIGN_WINDOW = int(os.environ.get("TEAM_SIGN_WINDOW", "300"))
NONCE_TTL_MIN = 10


def _path_of(request) -> str:
    qs = request.query_string.decode()
    return request.path + (f"?{qs}" if qs else "")


def _agent_by_key(conn, key_row) -> dict | None:
    row = conn.execute("SELECT * FROM agents WHERE id=?", (key_row["agent_id"],)).fetchone()
    return dict(row) if row else None


def _active_key(conn, key_id: str):
    row = conn.execute("SELECT * FROM keys WHERE key_id=?", (key_id,)).fetchone()
    if not row or row["revoked_at"]:
        return None
    if row["expires_at"] and row["expires_at"] < time.strftime("%Y-%m-%d %H:%M:%S"):
        return None
    return row


def verify_signature(conn, request):
    key_id = request.headers.get("X-TeamAI-Key")
    ts = request.headers.get("X-TeamAI-Timestamp")
    nonce = request.headers.get("X-TeamAI-Nonce")
    sig = request.headers.get("X-TeamAI-Signature")
    if not all((key_id, ts, nonce, sig)):
        return None, "missing signature headers"
    try:
        t = int(ts)
    except ValueError:
        return None, "bad timestamp"
    if abs(time.time() - t) > SIGN_WINDOW:
        return None, "timestamp out of window"
    row = _active_key(conn, key_id)
    if not row:
        return None, "unknown or revoked key"
    key = security.decrypt(row["key_enc"])
    body = request.get_data() or b""
    if not security.verify(key, request.method, _path_of(request), body, ts, nonce, sig):
        return None, "bad signature"
    # 不要先 SELECT nonce 再 INSERT：多线程下每个连接先持有读快照，再升级写
    # 会触发 SQLITE_BUSY_SNAPSHOT，busy_timeout 也救不了；直接原子 INSERT 判重。
    for attempt in range(3):
        try:
            conn.commit()  # 结束鉴权读取的旧快照，避免读事务升级写
            cur = conn.execute("INSERT OR IGNORE INTO nonces(nonce, key_id) VALUES (?,?)",
                               (nonce, key_id))
            if cur.rowcount == 0:
                conn.rollback()
                return None, "nonce replay"
            conn.execute("UPDATE keys SET last_used_at=datetime('now','localtime') WHERE key_id=?",
                         (key_id,))
            conn.commit()  # nonce 必须立即持久化，否则重放可绕过（含只读路由）
            return _agent_by_key(conn, row), None
        except sqlite3.OperationalError as e:
            conn.rollback()
            if "locked" not in str(e).lower() or attempt == 2:
                return None, "auth store busy"
            time.sleep(0.05 * (attempt + 1))
    return None, "auth store busy"


def verify_bearer(conn, request):
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return None, "no bearer token"
    cred = auth[7:].strip()
    if "." in cred:
        key_id, key = cred.split(".", 1)
        row = _active_key(conn, key_id)
    else:
        key = cred
        row = conn.execute("SELECT * FROM keys WHERE key_hash=?", (security.hash_secret(key),)).fetchone()
        if row and row["revoked_at"]:
            row = None
    if not row:
        return None, "bad key"
    if row["key_hash"] != security.hash_secret(key):
        return None, "bad key"
    conn.execute("UPDATE keys SET last_used_at=datetime('now','localtime') WHERE key_id=?",
                 (row["key_id"],))
    return _agent_by_key(conn, row), None


def authenticate(conn, request):
    """返回 (agent_dict, None) 或 (None, error)。"""
    if request.headers.get("X-TeamAI-Signature"):
        return verify_signature(conn, request)
    if os.environ.get("TEAM_ALLOW_BEARER") == "1":
        return verify_bearer(conn, request)
    return None, "request signature required"


def enroll_token_row(conn, token: str):
    if not token:
        return None
    row = conn.execute("SELECT * FROM enroll_tokens WHERE token_hash=?",
                       (security.hash_secret(token),)).fetchone()
    if not row or row["revoked_at"]:
        return None
    if row["expires_at"] and row["expires_at"] < time.strftime("%Y-%m-%d %H:%M:%S"):
        return None
    if row["max_uses"] is not None and row["uses"] >= row["max_uses"]:
        return None
    return row


def is_root(conn, token: str) -> bool:
    row = enroll_token_row(conn, token)
    return bool(row and row["kind"] == "root")


def consume_enroll_token(conn, token: str) -> bool:
    row = enroll_token_row(conn, token)
    if not row:
        return False
    conn.execute("UPDATE enroll_tokens SET uses=uses+1 WHERE token_id=?", (row["token_id"],))
    return True


def cleanup_nonces(conn) -> None:
    conn.execute("DELETE FROM nonces WHERE created_at < datetime('now','localtime', ?)",
                 (f"-{NONCE_TTL_MIN} minutes",))
