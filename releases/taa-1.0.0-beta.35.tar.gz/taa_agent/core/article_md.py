"""完整文章落盘为 **Markdown**（Owner 2026-10-14：**"完整文章自动保存为 md，我自然就可以按时间降序浏览它们"**）。

一条完整文章 = 一个 `.md` 文件：
  `data/articles/<YYYY-MM-DD>/<HHMM>-<source>-<slug>.md`
  · 目录按**日期**分 → 文件系统层面天然按时间可浏览（时间降序 = 目录/文件名倒序）；
  · 文件头是 YAML front-matter（源/URL/标题/作者/日期/采集时间/停留时长/指纹），正文是文章本体；
  · 不完整、未登录、付费墙的文章**不会**有 md（不完整 → 不保存，见 `core/captures.py`）。
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ARTICLES = Path(os.environ.get("TEAMAI_ARTICLES_DIR") or (ROOT / "data" / "articles"))


def slugify(text: str, maxlen: int = 60) -> str:
    s = re.sub(r"[^\w\s-]", "", (text or "").lower(), flags=re.UNICODE)
    s = re.sub(r"[\s_]+", "-", s).strip("-")
    return (s[:maxlen].rstrip("-")) or "untitled"


def write_article_md(*, source_id: str, url: str, title: str, byline, published_at: str,
                     body: str, captured_at: str, dwell_s: int = 0, content_hash: str = "",
                     extractor_version: str = "", channel: str = "", root: Path | None = None,
                     hero: dict | None = None) -> str:
    """写一个 md，返回**相对项目根**的路径（写进 `captures.path`）。"""
    base = (root or ARTICLES)
    day = (captured_at or "")[:10] or "unknown-day"
    hhmm = ((captured_at or "")[11:16] or "0000").replace(":", "")
    name = f"{hhmm}-{slugify(source_id, 20)}-{slugify(title, 60)}.md"
    d = base / day
    d.mkdir(parents=True, exist_ok=True)
    p = d / name
    fm = {
        "source": source_id,
        "url": url,
        "title": title,
        "byline": list(byline or []),
        "published_at": published_at,
        "captured_at": captured_at,
        "dwell_s": int(dwell_s or 0),
        "content_hash": content_hash,
        "extractor_version": extractor_version,
    }
    if channel:
        fm["channel"] = channel
    if hero and hero.get("src"):
        fm["hero_image"] = hero.get("src")
        fm["hero_width"] = hero.get("width") or ""
        fm["hero_height"] = hero.get("height") or ""
        fm["hero_largest"] = hero.get("srcset_largest") or ""
    head = "---\n" + "\n".join(f"{k}: {json.dumps(v, ensure_ascii=False)}" for k, v in fm.items()) + "\n---\n"
    md = f"{head}\n# {title}\n\n{body.strip()}\n"
    p.write_text(md, encoding="utf-8")
    try:
        return str(p.relative_to(ROOT))
    except ValueError:
        return str(p)
