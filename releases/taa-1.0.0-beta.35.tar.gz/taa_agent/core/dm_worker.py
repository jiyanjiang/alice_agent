"""DM 方案 B 的工作队列件（Owner 2026-10-14 定：`docs/9?`/帖 p-af8a5fba）：

**DM 里 agent 不是"聊天"，是"接活干活"**——且 Owner 接受慢（30s～1min 一次）。
本模块只放**可测的决策与执行**，接线在 `dm_runtime.py`（一处 5 行）。

规则：
  · **受理即回**（不静默）由 dm_runtime 负责；
  · **节流**：同一 agent 的 DM 工作 **每 ≥interval 秒执行 1 件**（默认 30，可 60）；
  · **闸门**：单次生图 ≤ `PER_RUN`（默认 4）；每日 ≤ `PER_DAY`（默认 20）；单件超时 `TIMEOUT`（默认 180s）；
  · **失败不许静默**：返回原始报错摘要；
  · 触发词（中英）→ 生图意图；其余走普通回复。
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PER_RUN = int(os.environ.get("TEAMAI_DM_GEN_PER_RUN", "4"))
PER_DAY = int(os.environ.get("TEAMAI_DM_GEN_PER_DAY", "20"))
TIMEOUT = int(os.environ.get("TEAMAI_DM_GEN_TIMEOUT", "180"))
INTERVAL = int(os.environ.get("TEAMAI_DM_WORK_INTERVAL", "30"))

GEN_HINTS = ["生成", "画一", "画张", "画一张", "出图", "生图", "配图", "照片", "图片",
             "draw", "generate an image", "make an image", "render"]


# ★ 回声防护（2026-10-16，缺陷 R-001）：自动回复文本里含"生成"等触发词，
#   会被对方的关键词触发再次命中 → alice↔carol 无限回声（实测该线程 2527 条、峰值 19 条/分钟）。
#   按纪律只加"结构护栏/去重"：自动回复打机器标记 + 已知模板一并屏蔽。
AUTO_MARK = "⟦auto⟧"
_AUTO_TEMPLATES = (
    "收到，我这就生成",
    "我刚生成过一件，节流中",
    "今天的生图额度用完了",
    "好了——这是按你的要求生成的图",
    "没做成，原始报错",
)


def is_auto_reply(body: str) -> bool:
    """机器自己发出的自动回复（打标记或命中已知模板）——永不作为新一轮任务的触发源。"""
    b = (body or "").strip()
    return b.startswith(AUTO_MARK) or any(t in b for t in _AUTO_TEMPLATES)


def wants_image(body: str) -> bool:
    if is_auto_reply(body):
        return False                       # ★ 破回声环：自动回复不触发新任务
    b = (body or "").lower()
    return any(h.lower() in b for h in GEN_HINTS)


def image_prompt(body: str) -> str:
    """把指令里的"生成/发我/作为测试"等噪声剥掉，留下可用的画面描述。"""
    p = re.sub(r"(作为测试|测试一下|请|帮我|给我|生成|画一?张|画|出图|生图|配图|照片|图片|发我|发给我|"
               r"generate an image of|draw|render)", " ", body or "", flags=re.I)
    p = re.sub(r"[，,。.;；]+", " ", p)
    return " ".join(p.split())[:200]


def should_run(now: float, last_ts: float, interval: int = INTERVAL) -> bool:
    """节流：距上次 ≥ interval 才允许再干一件（Owner：30s，甚至 1 分钟都行）。"""
    return (now - float(last_ts or 0)) >= max(1, int(interval))


def budget_ok(today_count: int, per_day: int = PER_DAY) -> bool:
    return int(today_count or 0) < max(1, int(per_day))


def gen_image(agent: str, prompt: str, base: str, n: int = 1) -> dict:
    """执行生图（复用既有 media-gen CLI）→ 返回 {ok, urls[], err}。"""
    n = max(1, min(int(n), PER_RUN))
    urls: list[str] = []
    err = ""
    for _ in range(n):
        cmd = [sys.executable, str(ROOT / "cli" / "teamai.py"), "media-gen",
               "--as", agent, "--url", base, prompt]
        try:
            r = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True, timeout=TIMEOUT)
            out = (r.stdout or "") + (r.stderr or "")
            m = re.search(r"/static/uploads/[\w.\-]+", out)
            if m:
                urls.append(m.group(0))
            else:
                err = out.strip()[-200:] or f"rc={r.returncode}"
        except subprocess.TimeoutExpired:
            err = f"timeout({TIMEOUT}s)"
        except Exception as e:  # noqa: BLE001
            err = f"{type(e).__name__}: {e}"
    return {"ok": bool(urls), "urls": urls, "err": err}


def reply_attachment(agent: str, peers: list[str], body: str, urls: list[str], base: str) -> dict:
    """回图文（dm send --attach）。"""
    cmd = [sys.executable, str(ROOT / "cli" / "teamai.py"), "dm", "send",
           "--to", peers[0], "--as", agent, "--url", base, "--body", body]
    for u in urls:
        cmd += ["--attach", u]
    try:
        r = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True, timeout=90)
        return {"ok": r.returncode == 0, "err": ((r.stdout or "") + (r.stderr or "")).strip()[-200:]}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "err": f"{type(e).__name__}: {e}"}


# ---------------- 一件活的完整处置（供 dm_runtime 调用） ----------------
def _state_path(agent: str) -> Path:
    d = ROOT / "agents" / agent
    d.mkdir(parents=True, exist_ok=True)
    return d / "dm-work.json"


def _load_state(agent: str) -> dict:
    import json
    f = _state_path(agent)
    try:
        return json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    except Exception:  # noqa: BLE001
        return {}


def _save_state(agent: str, st: dict) -> None:
    import json
    try:
        _state_path(agent).write_text(json.dumps(st), encoding="utf-8")
    except OSError:
        pass


def _say(agent: str, peer: str, base: str, body: str, urls: list[str] | None = None) -> bool:
    if not body.startswith(AUTO_MARK):
        body = AUTO_MARK + body            # ★ 机器标记：接收方可据此跳过，破回声环
    cmd = [sys.executable, str(ROOT / "cli" / "teamai.py"), "dm", "send", "--to", peer,
           "--as", agent, "--url", base, "--body", body]
    for u in (urls or []):
        cmd += ["--attach", u]
    try:
        r = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True, timeout=120)
        return r.returncode == 0
    except Exception:  # noqa: BLE001
        return False


def handle_task(agent: str, peer: str, body: str, base: str | None = None) -> dict:
    """DM 里的一件"活"：受理→节流→预算→执行→回图；**任何情况都回话**。"""
    base = base or os.environ.get("TEAMAI_URL") or "http://127.0.0.1:6080"
    t0 = time.time()
    today = time.strftime("%Y-%m-%d")
    st = _load_state(agent)
    if st.get("day") != today:
        st = {"day": today, "count": 0, "last_ts": 0.0}

    _say(agent, peer, base, "收到，我这就生成，稍等 30 秒左右。")      # ① 受理即回（不静默）

    if not should_run(t0, st.get("last_ts", 0.0), INTERVAL):
        wait = int(INTERVAL - (t0 - float(st.get("last_ts") or 0)))
        _say(agent, peer, base, f"我刚生成过一件，节流中——约 {max(1, wait)} 秒后再给你。")
        return {"status": "throttled", "waited": wait}
    if not budget_ok(st.get("count", 0), PER_DAY):                     # ③ 闸门
        _say(agent, peer, base, f"今天的生图额度用完了（{PER_DAY} 张）。明天再给你；要现在就加额度请直接说。")
        return {"status": "budget_exceeded", "used": st.get("count")}

    prompt = image_prompt(body) or body[:200]
    r = gen_image(agent, prompt, base, n=1)
    st["last_ts"] = t0
    st["count"] = int(st.get("count", 0)) + (1 if r["ok"] else 0)
    _save_state(agent, st)

    if r["ok"]:                                                        # ④ 回图文
        _say(agent, peer, base, f"好了——这是按你的要求生成的图（约 {int(t0 - 0) and 1} 张）。"
                                f"（说明：AI 生成，非实拍）", r["urls"])
        return {"status": "ok", "urls": r["urls"], "elapsed_s": round(time.time() - t0, 1)}
    _say(agent, peer, base, f"没做成，原始报错：{r['err']}")            # ⑤ 失败不许静默
    return {"status": "failed", "err": r["err"], "elapsed_s": round(time.time() - t0, 1)}
