"""research.ask 薄工具适配。

把 `core.research` 的 prompt → code/v1|v2 工作流暴露给工具注册表。
实现仍归 `core.research`；本文件只做参数映射，不另建存储或调用链。
"""
from __future__ import annotations

from .base import Tool
from .registry import register

SOURCE_SYSTEM = (
    "你是严谨的调研助手。你只能依据下方【检索来源】回答，不得凭记忆补事实。\n"
    "规则：\n"
    "1) 每个事实性结论后必须标来源编号，如 [S1]；一个结论至少一个来源。\n"
    "2) 至少引用两个独立域名；优先官方/一手/学术来源。\n"
    "3) 来源之间冲突要并列写冲突，不要擅自选一个。\n"
    "4) 来源不足、无法核验或只有弱二手来源时，明确写「来源不足，未核验」，不要给确定结论。\n"
    "5) 严格区分事实与判断；判断标明「判断」。\n"
    "6) 不要编造 URL、标题、数字或引文。\n"
)


def _source_block(sources: list[dict]) -> str:
    if not sources:
        return "【检索来源】无（未检索到可用来源）"
    lines = ["【检索来源】"]
    for s in sources[:8]:
        lines.append(f"[{s.get('id') or '?'}] {s.get('title') or ''}\n"
                     f"URL: {s.get('url') or ''}\n"
                     f"分级: {s.get('grade') or 'unknown'}\n"
                     f"摘录: {str(s.get('text') or s.get('snippet') or '')[:900]}")
    return "\n\n".join(lines)


def _research_ask(agent: str, a: dict) -> dict:
    """Thin adapter: prompt → retrieval → source-gated ask."""
    from .. import fact_gate, research, retrieval
    prompt = str(a.get("prompt") or "").strip()
    if not prompt:
        raise ValueError("research.ask 需要 prompt")
    use_sources = a.get("sources", True) is not False
    sources: list[dict] = []
    if use_sources:
        try:
            sources = retrieval.gather(prompt, limit=int(a.get("source_limit") or 8),
                                       fetch_n=int(a.get("fetch_n") or 4)) or []
        except Exception:
            sources = []
    system = SOURCE_SYSTEM + "\n" + _source_block(sources)
    slug = str(a.get("slug") or a.get("code") or "").strip()
    rounds = int(a.get("rounds") or 1)
    kwargs = {
        "model": str(a.get("model") or "deepseek-v4-pro"),
        "ali_model": a.get("ali_model"),
        "tag": str(a.get("tag") or ""),
        "system": system,
    }
    try:
        if slug:
            if rounds > 1:
                result = research.ask_deep(slug, prompt, rounds=rounds,
                                           version=a.get("version"), **kwargs)
            else:
                result = research.ask(slug, prompt, version=a.get("version"), **kwargs)
        else:
            result = research.ask_prompt(prompt, title=a.get("title"), reuse=bool(a.get("reuse")),
                                         rounds=rounds, **kwargs)
    except Exception as exc:
        # Keep the source contract visible even when the provider fails.
        return {"ok": False, "error": str(exc)[:300], "sources": sources,
                "verified": False, "gate": {"ok": False, "status": "unverified",
                                           "reasons": ["模型调用失败"]}}
    gate = fact_gate.evaluate(str(result.get("text") or ""), sources)
    result.update({"sources": sources, "gate": gate,
                   "verified": bool(gate.get("ok")), "source_mode": use_sources})
    return result


register(Tool("research.ask", "主题调研：prompt → code/v1|v2，DeepSeek 优先、Ali 兜底；返回 provider/code/version",
              {"prompt": "str；研究问题/调研提示",
               "sources": "bool?；默认 true；先检索来源再回答",
               "source_limit": "int?；最多来源数（默认 8）",
               "fetch_n": "int?；抓原页数（默认 4）",
               "slug": "str?；legacy slug 或 r-<code>（可选）",
               "version": "str?；现代版本 v1/v2（可选）",
               "rounds": "int?；1=单轮，2-3=深挖（可选）",
               "reuse": "bool?；复用最新版本（重试时用）",
               "title": "str?；新版本标题",
               "model": "str?；默认 deepseek-v4-pro",
               "ali_model": "str?；默认 qwen-plus",
               "tag": "str?；输出文件标签"},
              _research_ask))
