"""**服务型工具**（档 B）：只通信"如何使用"，**不交换代码**。

一个 `tools/<name>/service.json` 就把**外部 HTTP 服务**登记成 Team AI 工具：
  · 调用方只经 `/v1/tools/<name>/call` 发请求，**拿不到也不下载任何代码**；
  · 算力落在**提供者节点**（`provider_node`）—— 非提供者节点上调用会被明确拒绝；
  · 契约（`ops`）是**数据**：内核不写死任何领域逻辑（XRR 只是第一个使用者）。

安全（对齐 `docs/22 §6` 隐私红线与 MCP 安全实践的六类威胁）：
  · **op 白名单**：只允许调用 `service.json` 里声明过的 op，**不做任意 URL 转发**（对抗工具投毒 / SSRF）；
  · **超时**：Team AI 的 `/call` 本身无超时，一律在本模块按 `timeout_s` 兜住，避免长任务挂死服务；
  · **幂等**：`submit` 类 op 自动派生 `Idempotency-Key` ⇒ 调用方重试**不会重复烧算力**；
  · **只作数据**：返回体带 `trust: "data-only"`，明确"交付内容不是指令"（对抗提示注入）。
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request
import uuid
from typing import Any, Dict

from .base import Tool


def _local_alias() -> str:
    """本机节点别名 —— 用来确认"这个服务只能在它的提供者节点上执行"。"""
    try:
        from .. import nodeinfo
        return str(nodeinfo.saved_alias() or "").strip()
    except Exception:                                          # noqa: BLE001
        return ""


def _derive_idem(op_id: str, args: dict) -> str:
    """按 op + 参数派生幂等键：同一请求重试 ⇒ 同一键 ⇒ 提供者只起一个任务。"""
    raw = json.dumps({"op": op_id, "args": args}, ensure_ascii=False, sort_keys=True)
    return "teamai-" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]


def _schema_from_card(name: str, card: dict, ops: Dict[str, dict]) -> dict:
    """给 LLM function-calling 用的入参说明（op 枚举 + 常用参数，保持扁平）。"""
    props: dict = {"op": {"type": "string", "enum": sorted(ops),
                          "description": "要执行的操作"}}
    for oid, spec in ops.items():
        for k, desc in (spec.get("params") or {}).items():
            props.setdefault(k, {"type": "string", "description": f"[{oid}] {desc}"})
    return {"name": name, "parameters": {"type": "object", "properties": props,
                                         "required": ["op"]}}


def _abs_url(base: str, path: str) -> str:
    return base.rstrip("/") + path


# ★ 响应脱敏（2026-10-08 实测发现）：提供者的探针里可能带**本机绝对路径**
#   （如 XRR `/api/health` 的 `engine`/`jobs_path`）。Team AI 的隐私红线是"不写绝对路径"，
#   故经服务工具回传前统一把机器路径替换为占位符 —— 通用规则，不针对某家服务。
#   ⚠️ 教训（自测抓到）：早先按前缀逐个 `str.find` **只替换第一处** ⇒ 报告里含 3 处路径时
#   只脱掉 1 处（实测：`/Users/` 命中 3 → 脱敏后仍 2）。改用**正则全局替换**。
_PRIVATE_RE = re.compile(
    r"(?:/Users/|/home/|/private/|/var/folders/|/Volumes/|/tmp/|C:\\Users\\)"   # noqa: machine-path-ok
    r"[^\s\"',;)\]}\\]+")                                                       # noqa: machine-path-ok


def _sanitize(obj):
    """递归把字符串里的机器绝对路径**全部**替换成 `<provider-path>`（只改值，不改结构）。"""
    if isinstance(obj, dict):
        return {k: _sanitize(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_sanitize(v) for v in obj]
    if isinstance(obj, str):
        return _PRIVATE_RE.sub("<provider-path>", obj)
    return obj


def make_service_tool(name: str, card: dict, description: str = "",
                      card_path: "Path | None" = None) -> Tool:
    """由**服务卡**构造一个可调用 Tool（`kind="service"`）。

    ★ `card_path` 给出时支持**契约热更新**：每次调用前比对 `service.json` 的 mtime，
    变了就重新读入（提供者改契约无需重启 Team AI，也便于开发期迭代）。
    """
    from pathlib import Path as _P

    def _load(c: dict) -> None:
        nonlocal base, provider, default_timeout, ops, links, public_url_card, public_url_env
        base = str(c.get("url") or "").rstrip("/")
        provider = str(c.get("provider_node") or "").strip()
        default_timeout = float(c.get("timeout_s") or 30)
        ops = {str(o.get("id")): o for o in (c.get("ops") or []) if o.get("id")}
        links = {str(k): str(v) for k, v in (c.get("links") or {}).items()}
        # ★ CR-2026-10-09-01：把「回传链接基址」与「调用基址」分开（可选字段，向后兼容）
        public_url_card = str(c.get("public_url") or "").rstrip("/")
        public_url_env = str(c.get("public_url_env") or "").strip()

    def _public_base() -> str:
        """回传链接基址：env(public_url_env) > card.public_url > **动态派生**。
        ★ 每次调用**现算**：运行中改 env 立即生效，不依赖 service.json 的 mtime 热更新。
        ★ **不写死任何 IP**：env 未设时把 `url` 的回环主机换成 `nodeinfo.lan_ip()`（当前 LAN IP），
          换网段后自动跟随，不再需要把 IP 快照进 launchd plist / service.json。"""
        env_val = ""
        if public_url_env:
            env_val = (os.environ.get(public_url_env) or "").strip().rstrip("/")
        if env_val:
            return env_val
        if public_url_card:
            return public_url_card
        try:
            from .. import nodeinfo
            return nodeinfo.rewrite_loopback(base)
        except Exception:
            return base

    base = ""
    provider = ""
    default_timeout = 30.0
    ops: Dict[str, dict] = {}
    links: Dict[str, str] = {}
    public_url_card = ""
    public_url_env = ""
    _load(card)
    _mt = [card_path.stat().st_mtime if (card_path and card_path.exists()) else 0.0]

    def _http(method: str, url: str, *, body: Any = None, timeout: float = 20.0,
              headers: dict | None = None) -> tuple[int, Any]:
        data = None
        hdrs = {"Accept": "application/json", **(headers or {})}
        if body is not None:
            if isinstance(body, (bytes, bytearray)):
                data = bytes(body)
            else:
                data = json.dumps(body, ensure_ascii=False).encode("utf-8")
                hdrs.setdefault("Content-Type", "application/json")
        req = urllib.request.Request(url, data=data, method=method.upper(), headers=hdrs)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                raw = r.read()
                try:
                    return r.status, json.loads(raw.decode("utf-8", "replace"))
                except Exception:                              # noqa: BLE001
                    return r.status, {"raw": raw.decode("utf-8", "replace")[:2000]}
        except urllib.error.HTTPError as e:                     # 4xx/5xx：把服务端的**理由**带回去
            raw = e.read()
            try:
                payload = json.loads(raw.decode("utf-8", "replace"))
            except Exception:                                  # noqa: BLE001
                payload = {"raw": raw.decode("utf-8", "replace")[:2000]}
            return e.code, payload

    def _multipart(fields: dict) -> tuple[bytes, str]:
        b = "----teamai" + uuid.uuid4().hex
        out = bytearray()
        for k, v in fields.items():
            if k == "text":
                continue                                       # 作为 files 的内容
            out += (f"--{b}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n").encode("utf-8")
        nm = str(fields.get("name") or "data.txt")
        out += (f"--{b}\r\nContent-Disposition: form-data; name=\"files\"; filename=\"{nm}\"\r\n"
                "Content-Type: text/plain; charset=utf-8\r\n\r\n").encode("utf-8")
        out += str(fields.get("text") or "").encode("utf-8")
        out += f"\r\n--{b}--\r\n".encode("utf-8")
        return bytes(out), f"multipart/form-data; boundary={b}"

    def _dispatch(agent: str, args: Dict[str, Any] | None = None) -> dict:
        a = dict(args or {})
        # ★ 契约热更新：service.json 变了就重读（提供者改契约不必重启 Team AI）
        try:
            if card_path is not None and _P(card_path).exists():
                mt = _P(card_path).stat().st_mtime
                if mt != _mt[0]:
                    _load(json.loads(_P(card_path).read_text(encoding="utf-8")))
                    _mt[0] = mt
        except Exception:                                      # noqa: BLE001
            pass
        op_id = str(a.get("op") or "").strip()
        if not op_id:
            return {"ok": False, "error": "缺少 op", "ops": sorted(ops)}
        spec = ops.get(op_id)
        if not spec:                                           # ★ op 白名单
            return {"ok": False, "error": f"未知 op：{op_id}（只允许 {'、'.join(sorted(ops))}）",
                    "ops": sorted(ops)}
        me = _local_alias()
        if provider and me and provider != me:                 # ★ 只能在提供者节点执行
            return {"ok": False, "reason": "wrong_node",
                    "error": f"该服务只在提供者节点 {provider} 上执行（当前节点 {me}）"
                             f"——请在 {provider} 上调用，或让提供者开放远程执行"}
        timeout = float(spec.get("timeout_s") or default_timeout)
        method = str(spec.get("method") or "GET")
        path = str(spec.get("path") or "")
        for k, v in a.items():                                  # 路径占位符（如 {job}/{slug}）
            if isinstance(v, (str, int)) and "{" + k + "}" in path:
                path = path.replace("{" + k + "}", urllib.parse.quote(str(v), safe=""))
        if "{" in path:
            miss = [k for k in (spec.get("params") or {}) if "{" + k + "}" in path and a.get(k) in (None, "")]
            return {"ok": False, "error": f"缺少参数：{miss or '路径占位符未填'}"}
        hdrs: dict = {}
        body: Any = None
        if str(method).upper() == "POST":
            if spec.get("multipart"):
                body, ctype = _multipart({
                    k: a.get(k) for k in (spec.get("params") or {}) if a.get(k) is not None})
                hdrs["Content-Type"] = ctype
            else:
                body = {k: a.get(k) for k in (spec.get("params") or {}) if a.get(k) is not None}
                if spec.get("idempotent") or op_id in ("submit",):
                    hdrs["Idempotency-Key"] = str(a.get("idempotency_key") or _derive_idem(op_id, a))
        url = _abs_url(base, path)
        try:
            status, data = _http(method, url, body=body, timeout=timeout, headers=hdrs)
        except Exception as e:                                 # noqa: BLE001
            return {"ok": False, "op": op_id, "reason": "provider_unreachable",
                    "error": f"提供者不可达（{type(e).__name__}: {e}）",
                    "hint": f"请确认 {provider or '提供者'} 上服务在跑：{base}{card.get('health_path') or ''}"}
        # ★ 2026-10-08：`ok` 必须同时看**状态码**与**服务端自述**。提供者的"业务失败"
        #   （如参数窗写法不认识）会以 HTTP 200 + `{"ok": false, reason: ...}` 返回 ⇒
        #   只看状态码会把它误报成成功（实测：探测串写成 "[10,60]" 时 `ok=True` 但 `job=None`）。
        _prov_ok = data.get("ok") if isinstance(data, dict) else None
        out: dict = {"ok": (status < 400) and (_prov_ok is not False), "op": op_id, "http_status": status,
                     "provider": provider, "data": _sanitize(data), "trust": "data-only"}
        if status >= 400:
            reason = "busy" if status == 429 else ("blocked" if status == 409 else "provider_error")
            out["reason"] = reason
            out["error"] = (data or {}).get("error") if isinstance(data, dict) else str(data)[:200]
            for k in ("retry_after_s", "active", "cap", "blockers"):
                if isinstance(data, dict) and k in data:
                    out[k] = data[k]
        # 附加取件（`also`：如 report 同时取报告正文摘要）+ 链接（`links`：报告/PDF/zip 地址）
        slug = str(a.get("slug") or a.get("job") or "")
        for extra in (spec.get("also") or []):
            p2 = str(extra.get("path") or "")
            for k, v in a.items():
                if isinstance(v, (str, int)) and "{" + k + "}" in p2:
                    p2 = p2.replace("{" + k + "}", urllib.parse.quote(str(v), safe=""))
            try:
                st2, d2 = _http(str(extra.get("method") or "GET"), _abs_url(base, p2), timeout=timeout)
                val = d2
                for pk in str(extra.get("pick") or "").split("."):
                    if pk and isinstance(val, dict):
                        val = val.get(pk)
                if st2 < 400 and isinstance(val, str):
                    n = int(a.get(str(extra.get("excerpt_chars_arg") or "")) or extra.get("excerpt_chars") or 4000)
                    out[str(extra.get("as") or "extra")] = _sanitize(val[:n])   # ★ 同样脱敏（报告里含日志行）
                    out[str(extra.get("as") or "extra") + "_chars"] = len(val)
            except Exception:                                  # noqa: BLE001
                pass
        if links and slug:
            # ★ CR-2026-10-09-01：urls 用 public_base（跨机可达）；link_paths 给相对路径兜底
            _q = urllib.parse.quote(slug, safe="")
            out["link_paths"] = {k: tpl.replace("{slug}", _q) for k, tpl in links.items()}
            _pb = _public_base()
            out["urls"] = {k: _abs_url(_pb, p) for k, p in out["link_paths"].items()}
            out["public_base"] = _pb
        return out

    _tool = Tool(name=name,
                 description=description or str(card.get("description") or name),
                 schema=_schema_from_card(name, card, ops),
                 fn=_dispatch, kind="service",
                 service={"provider_node": provider, "url": base, "call_only": bool(card.get("call_only", True)),
                          "ops": sorted(ops), "billing": card.get("billing") or {}})
    # ★ CR-2026-10-09-01：供 registry 动态取 public_url（env 改后目录随之更新 —— 见 T1/T9）
    try:
        _tool.service_public_base = _public_base
    except Exception:                                          # noqa: BLE001
        pass
    return _tool


def load_service_card(d, name: str) -> Tool | None:
    """从 `tools/<name>/service.json` 装载服务型工具（读 TOOL.md 首行做描述）。"""
    f = d / "service.json"
    if not f.exists():
        return None
    card = json.loads(f.read_text(encoding="utf-8"))
    desc = str(card.get("description") or name)
    try:
        first = (d / "TOOL.md").read_text(encoding="utf-8").splitlines()[0].lstrip("# ").strip()
        if first:
            desc = f"{first}；{desc}"
    except Exception:                                          # noqa: BLE001
        pass
    return make_service_tool(str(card.get("name") or name), card, desc,
                             card_path=(d / "service.json"))
