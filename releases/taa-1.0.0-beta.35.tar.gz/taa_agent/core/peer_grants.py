"""Owner/group-scoped peer grants for P2P sync.

The legacy ``TAA_PEER_TOKEN`` remains a local/test wildcard. Production-style
access uses a pending/approved grant:

    collab group (owner + members)
      + peer grant (hashed bearer token, room allowlist, scopes)
      -> /v1/peer/events and /v1/peer/blob

A grant is inert until the local owner approves it. Approval binds the already
hashed token; the token itself is never stored and never returned by the API.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
from typing import Any

SCOPES = {"rooms", "posts", "blob"}
DEFAULT_SCOPES = ["rooms", "blob"]


def ensure(conn) -> None:
    conn.executescript("""
CREATE TABLE IF NOT EXISTS collab_groups(
  group_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_by TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS collab_group_members(
  group_id TEXT NOT NULL,
  owner_id TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'member',
  added_by TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY(group_id, owner_id)
);
CREATE TABLE IF NOT EXISTS peer_grants(
  grant_id TEXT PRIMARY KEY,
  group_id TEXT,
  peer_node TEXT NOT NULL,
  peer_owner TEXT NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  scopes TEXT NOT NULL DEFAULT '["rooms","blob"]',
  room_ids TEXT NOT NULL DEFAULT '[]',
  allow_unsigned INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending',
  requested_at TEXT DEFAULT (datetime('now','localtime')),
  decided_at TEXT,
  decided_by TEXT,
  revoked_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_peer_grants_status ON peer_grants(status);
""")
    # additive migration for already-created local DBs
    try:
        cols = {r[1] for r in conn.execute("PRAGMA table_info(peer_grants)").fetchall()}
        if "allow_unsigned" not in cols:
            conn.execute("ALTER TABLE peer_grants ADD COLUMN allow_unsigned INTEGER NOT NULL DEFAULT 0")
            conn.commit()
    except Exception:  # noqa: BLE001
        pass


def _hash(token: str) -> str:
    return hashlib.sha256(str(token or "").encode("utf-8")).hexdigest()


def _clean_id(value: Any, limit: int = 120) -> str:
    raw = str(value or "").strip()
    return re.sub(r"[^A-Za-z0-9_.:@#/\-]", "", raw)[:limit]


def _clean_rooms(raw) -> list[str]:
    if isinstance(raw, str):
        raw = [raw]
    out = []
    for x in raw if isinstance(raw, list) else []:
        s = _clean_id(x, 120)
        if s and s not in out:
            out.append(s)
    return out[:200]


def _clean_scopes(raw) -> list[str]:
    if isinstance(raw, str):
        raw = [raw]
    out = []
    for x in raw if isinstance(raw, list) else []:
        s = str(x or "").strip()
        if s in SCOPES and s not in out:
            out.append(s)
    return out or DEFAULT_SCOPES


def _row(r) -> dict:
    if not r:
        return {}
    d = dict(r)
    try:
        d["scopes"] = json.loads(d.get("scopes") or "[]")
    except Exception:
        d["scopes"] = []
    try:
        d["room_ids"] = json.loads(d.get("room_ids") or "[]")
    except Exception:
        d["room_ids"] = []
    d["allow_unsigned"] = bool(d.get("allow_unsigned"))
    return d


def create_group(conn, group_id: str, name: str, owner_id: str) -> dict:
    ensure(conn)
    gid = _clean_id(group_id, 80)
    owner = _clean_id(owner_id, 80)
    if not gid or not owner:
        raise ValueError("group_id and owner_id required")
    conn.execute("INSERT OR REPLACE INTO collab_groups(group_id,name,created_by) VALUES(?,?,?)",
                 (gid, str(name or gid)[:120], owner))
    conn.execute("INSERT OR REPLACE INTO collab_group_members(group_id,owner_id,role,added_by) "
                 "VALUES(?,?, 'owner', ?)", (gid, owner, owner))
    conn.commit()
    return {"group_id": gid, "name": str(name or gid)[:120], "owner_id": owner}


def add_member(conn, group_id: str, owner_id: str, role: str = "member",
               added_by: str | None = None) -> dict:
    ensure(conn)
    gid, oid = _clean_id(group_id, 80), _clean_id(owner_id, 80)
    if not gid or not oid:
        raise ValueError("group_id and owner_id required")
    if role not in ("owner", "member"):
        role = "member"
    conn.execute("INSERT OR REPLACE INTO collab_group_members(group_id,owner_id,role,added_by) "
                 "VALUES(?,?,?,?)", (gid, oid, role, _clean_id(added_by or oid, 80)))
    conn.commit()
    return {"group_id": gid, "owner_id": oid, "role": role}


def is_group_member(conn, group_id: str, owner_id: str) -> bool:
    ensure(conn)
    return bool(conn.execute("SELECT 1 FROM collab_group_members WHERE group_id=? AND owner_id=?",
                             (_clean_id(group_id, 80), _clean_id(owner_id, 80))).fetchone())


def request_grant(conn, token: str, peer_node: str, peer_owner: str, *,
                  group_id: str = "", room_ids=None, scopes=None,
                  allow_unsigned: bool = False) -> dict:
    ensure(conn)
    raw_token = str(token or "").strip()
    if len(raw_token) < 16:
        raise ValueError("token must be at least 16 chars")
    node = _clean_id(peer_node, 120)
    owner = _clean_id(peer_owner, 80)
    gid = _clean_id(group_id, 80)
    if not node or not owner:
        raise ValueError("peer_node and peer_owner required")
    if gid and not conn.execute("SELECT 1 FROM collab_groups WHERE group_id=?", (gid,)).fetchone():
        raise LookupError("group_not_found")
    if gid and not is_group_member(conn, gid, owner):
        raise PermissionError("owner_not_group_member")
    th = _hash(raw_token)
    existing = conn.execute("SELECT * FROM peer_grants WHERE token_hash=?", (th,)).fetchone()
    if existing:
        return _row(existing)
    grant_id = "grt-" + secrets.token_hex(6)
    rooms = _clean_rooms(room_ids)
    sc = _clean_scopes(scopes)
    conn.execute(
        "INSERT INTO peer_grants(grant_id,group_id,peer_node,peer_owner,token_hash,scopes,room_ids,"
        "allow_unsigned,status) VALUES(?,?,?,?,?,?,?,?, 'pending')",
        (grant_id, gid or None, node, owner, th, json.dumps(sc), json.dumps(rooms),
         1 if allow_unsigned else 0))
    # Pending requests are visible in /app/inbox for the local group owner.
    # Only create a notification if the owner exists as a local agent (FK safe).
    try:
        from . import community
        target = conn.execute("SELECT created_by FROM collab_groups WHERE group_id=?",
                              (gid,)).fetchone() if gid else None
        who = str((target["created_by"] if target else "") or "")
        if who and conn.execute("SELECT 1 FROM agents WHERE id=?", (who,)).fetchone():
            community.add_notification(conn, who, "peer_grant", grant_id,
                                       f"跨 Owner 授权请求：{owner} / {node}")
    except Exception:  # noqa: BLE001 — notification is best-effort
        pass
    conn.commit()
    return _row(conn.execute("SELECT * FROM peer_grants WHERE grant_id=?", (grant_id,)).fetchone())


def approve_grant(conn, grant_id: str, by: str, *, allow_unsigned: bool | None = None) -> dict:
    ensure(conn)
    row = conn.execute("SELECT * FROM peer_grants WHERE grant_id=?", (_clean_id(grant_id, 80),)).fetchone()
    if not row:
        raise LookupError("grant_not_found")
    if row["status"] == "approved" and not row["revoked_at"]:
        return _row(row)
    if row["status"] != "pending":
        raise ValueError("grant_not_pending")
    if row["group_id"]:
        g = conn.execute("SELECT created_by FROM collab_groups WHERE group_id=?", (row["group_id"],)).fetchone()
        if not g:
            raise LookupError("group_not_found")
        if _clean_id(by, 80) != g["created_by"]:
            raise PermissionError("only_group_owner_can_approve")
        if not is_group_member(conn, row["group_id"], row["peer_owner"]):
            raise PermissionError("peer_owner_not_group_member")
    if not _clean_id(by, 80):
        raise PermissionError("approver_required")
    if allow_unsigned is not None:
        conn.execute("UPDATE peer_grants SET allow_unsigned=? WHERE grant_id=?",
                     (1 if allow_unsigned else 0, row["grant_id"]))
    conn.execute("UPDATE peer_grants SET status='approved', decided_at=datetime('now','localtime'), "
                 "decided_by=? WHERE grant_id=?", (_clean_id(by, 80), row["grant_id"]))
    conn.commit()
    return _row(conn.execute("SELECT * FROM peer_grants WHERE grant_id=?", (row["grant_id"],)).fetchone())


def revoke_grant(conn, grant_id: str, by: str) -> dict:
    ensure(conn)
    row = conn.execute("SELECT * FROM peer_grants WHERE grant_id=?", (_clean_id(grant_id, 80),)).fetchone()
    if not row:
        raise LookupError("grant_not_found")
    conn.execute("UPDATE peer_grants SET revoked_at=datetime('now','localtime'), decided_by=? "
                 "WHERE grant_id=?", (_clean_id(by or "local", 80), row["grant_id"]))
    conn.commit()
    return _row(conn.execute("SELECT * FROM peer_grants WHERE grant_id=?", (row["grant_id"],)).fetchone())


def list_grants(conn) -> list[dict]:
    ensure(conn)
    rows = conn.execute("SELECT * FROM peer_grants ORDER BY requested_at DESC, grant_id").fetchall()
    return [_row(r) for r in rows]


def _legacy_token() -> str:
    return (os.environ.get("TAA_PEER_TOKEN") or "").strip()


def authorize(conn, token: str) -> dict | None:
    """Return an effective grant, or None. Env token is a local/test wildcard."""
    raw = str(token or "").strip()
    if not raw:
        return None
    legacy = _legacy_token()
    if legacy and hmac.compare_digest(raw, legacy):
        return {"grant_id": "legacy", "legacy": True, "scopes": ["*"], "room_ids": [],
                "allow_unsigned": (os.environ.get("TAA_PEER_ALLOW_LEGACY_UNSIGNED") or "").strip() in ("1", "true", "yes"),
                "peer_node": "", "peer_owner": "", "group_id": "", "status": "approved"}
    ensure(conn)
    row = conn.execute(
        "SELECT * FROM peer_grants WHERE token_hash=? AND status='approved' AND revoked_at IS NULL",
        (_hash(raw),)).fetchone()
    if not row:
        return None
    grant = _row(row)
    if grant.get("group_id") and not is_group_member(conn, grant["group_id"], grant["peer_owner"]):
        return None
    grant["legacy"] = False
    return grant


def can_blob(grant: dict | None) -> bool:
    return bool(grant and ("*" in grant.get("scopes", []) or "blob" in grant.get("scopes", [])))


def can_event(grant: dict | None, event: dict) -> bool:
    if not grant:
        return False
    scopes = set(grant.get("scopes") or [])
    if "*" in scopes:
        return True
    typ = str(event.get("type") or "")
    p = event.get("payload") or {}
    if typ == "room.message":
        if "rooms" not in scopes:
            return False
        rooms = grant.get("room_ids") or []
        return not rooms or str(p.get("room_id") or "") in rooms
    if typ in ("post.created", "reply.created"):
        return "posts" in scopes
    return False


def filter_events(grant: dict | None, events: list[dict]) -> list[dict]:
    return [e for e in events or [] if can_event(grant, e)]
