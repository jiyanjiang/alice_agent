"""Gate 5: same-owner agent mailbox through the center relay."""
from __future__ import annotations

import pathlib
from typing import Any

from .center import CenterClient
from .crypto import decrypt, encrypt_for
from .identity import load_state


def _agent(state, agent_id: str | None):
    if agent_id:
        for agent in state.agents:
            if agent.agent_id == agent_id or agent.display_name == agent_id:
                return agent
        raise ValueError(f"agent not found: {agent_id}")
    if not state.agents:
        raise ValueError("no local agent")
    return state.agents[0]


def send(home: pathlib.Path, *, to_agent_id: str, body: str, from_agent_id: str | None = None) -> dict[str, Any]:
    state = load_state(home)
    if not state.center.base:
        raise ValueError("node is not connected to a center")
    sender = _agent(state, from_agent_id)
    if not state.node.enc_pubkey or not state.node.enc_privkey:
        raise ValueError("node encryption key is missing; re-init this node")
    client = CenterClient(state.center.base)
    lookup = client.lookup_agent(agent_key=sender.agent_key, agent_id=to_agent_id)
    recipient_pub = str(lookup.get("enc_pubkey") or "")
    if not recipient_pub:
        raise ValueError("recipient node has no encryption public key")
    envelope = encrypt_for(recipient_pub, body)
    return client.send_encrypted(agent_key=sender.agent_key, to_agent_id=to_agent_id, ciphertext=envelope)


def inbox(home: pathlib.Path, *, agent_id: str | None = None) -> dict[str, Any]:
    state = load_state(home)
    if not state.center.base:
        raise ValueError("node is not connected to a center")
    agent = _agent(state, agent_id)
    if not state.node.enc_privkey:
        raise ValueError("node encryption private key is missing; re-init this node")
    client = CenterClient(state.center.base)
    result = client.inbox(agent_key=agent.agent_key)
    for message in result.get("messages") or []:
        if int(message.get("encrypted") or 0) == 1 and message.get("ciphertext"):
            message["body"] = decrypt(str(message["ciphertext"]), state.node.enc_privkey)
            message["encrypted"] = True
        else:
            message["encrypted"] = False
    return result


def presence(home: pathlib.Path, *, username: str, password: str) -> dict[str, Any]:
    state = load_state(home)
    if not state.center.base:
        raise ValueError("node is not connected to a center")
    client = CenterClient(state.center.base)
    login = client.owner_login(username=username, password=password)
    return client.presence(owner_token=login.get("owner_token") or "")
