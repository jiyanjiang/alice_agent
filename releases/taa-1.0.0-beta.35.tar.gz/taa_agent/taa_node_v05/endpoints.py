"""P6: advertise the local app entry on loopback, LAN, mDNS and tunnel."""
from __future__ import annotations

import os
import socket


def _lan_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return ""
    finally:
        s.close()


def discover(port: int, tunnel_url: str = "") -> dict:
    base = f"http://127.0.0.1:{port}"
    endpoints = [{"kind": "loopback", "url": base}]
    lan = os.environ.get("TAA_LAN_IP") or _lan_ip()
    if lan and not lan.startswith("127."):
        endpoints.append({"kind": "lan", "url": f"http://{lan}:{port}"})
    host = (os.environ.get("TAA_MDNS_HOST") or socket.gethostname()).strip()
    if host and not host.startswith("127."):
        mdns = host if host.endswith(".local") else host + ".local"
        endpoints.append({"kind": "mdns", "url": f"http://{mdns}:{port}"})
    tunnel = (tunnel_url or os.environ.get("TAA_TUNNEL_URL", "")).strip()
    if tunnel:
        endpoints.append({"kind": "tunnel", "url": tunnel.rstrip("/")})
    return {"app": base + "/app", "endpoints": endpoints}
