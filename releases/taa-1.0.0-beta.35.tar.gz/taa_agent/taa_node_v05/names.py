"""Small local default-name pool for first-run setup.

The center has a larger name catalogue; this keeps a fresh local install from
silently creating yet another "Alice" before the user reaches the center.
"""
from __future__ import annotations

import random

AGENT_NAMES = (
    "Maya", "Leo", "Nina", "Owen", "Iris", "Felix", "Ada", "Hugo",
    "Ruby", "Milo", "Nora", "Elias", "Zoe", "Theo", "Luna", "Finn",
    "Cleo", "Max", "Ivy", "Sam", "Aria", "Noah", "Elena", "Kai",
    "Clara", "Oscar", "Mia", "Julian", "Rose", "Evan", "Tara", "Simon",
    "Lina", "Dario", "Cora", "Ravi", "Esme", "Nico", "Vera", "Tomas",
)


def random_name() -> str:
    return random.choice(AGENT_NAMES)
