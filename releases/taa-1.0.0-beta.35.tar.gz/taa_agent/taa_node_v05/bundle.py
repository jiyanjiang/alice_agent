"""Portable TAA node bundle export/import.

The bundle is intentionally a simple archive with a versioned manifest and
sha256 checksums. It is a backup/migration primitive, not a live merge protocol.
"""
from __future__ import annotations

import hashlib
import json
import pathlib
import shutil
import tarfile
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from .identity import (
    CenterBinding,
    IdentityState,
    IDENTITY_FILE,
    load_state,
    new_key,
    new_id,
    save_state,
    NODE_KEY_PREFIX,
    SCHEMA_VERSION,
)

BUNDLE_SCHEMA_VERSION = 1
BUNDLE_ROOT = "taa-node"
BUNDLE_MANIFEST = "manifest.json"
DEFAULT_INCLUDE = ("identity.json", "agents", "tasks", "tools", "assets", "config")


@dataclass
class ExportResult:
    path: pathlib.Path
    manifest: dict[str, Any]


@dataclass
class ImportResult:
    state: IdentityState
    manifest: dict[str, Any]
    destination: pathlib.Path


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _safe_rel(rel: pathlib.PurePosixPath) -> bool:
    return bool(rel.parts) and rel.parts[0] == BUNDLE_ROOT and ".." not in rel.parts


def _iter_files(home: pathlib.Path):
    for name in DEFAULT_INCLUDE:
        path = home / name
        if path.is_symlink():
            continue
        if path.is_file():
            yield path
        elif path.is_dir():
            for child in path.rglob("*"):
                if any(part in {"__pycache__", ".git", ".venv"} for part in child.parts):
                    continue
                if child.is_symlink():
                    continue
                if child.is_file():
                    yield child


def read_bundle_manifest(bundle_path: pathlib.Path) -> dict[str, Any]:
    with tarfile.open(pathlib.Path(bundle_path).expanduser(), "r:gz") as tar:
        _verify_member_paths(tar)
        return _read_manifest(tar)


def export_bundle(
    home: pathlib.Path,
    out_path: pathlib.Path,
    *,
    include_secrets: bool = True,
) -> ExportResult:
    home = pathlib.Path(home).expanduser()
    state = load_state(home)
    out_path = pathlib.Path(out_path).expanduser()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    files = [
        path for path in _iter_files(home)
        if include_secrets or path.relative_to(home).as_posix() != "identity.json"
    ]
    entries: list[dict[str, Any]] = []
    if not include_secrets and (home / "config").exists():
        raise ValueError("config is considered secret; use include_secrets=True for a full backup")
    with tempfile.TemporaryDirectory(prefix="taa-bundle-") as tmp:
        tmp_root = pathlib.Path(tmp) / BUNDLE_ROOT
        tmp_root.mkdir(parents=True)
        for source in files:
            rel = source.relative_to(home)
            target = tmp_root / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            data = source.read_bytes()
            entries.append({
                "path": rel.as_posix(),
                "size": len(data),
                "sha256": sha256_bytes(data),
            })
        manifest = {
            "schema_version": BUNDLE_SCHEMA_VERSION,
            "created_at": _now(),
            "owner_id": state.center.owner_id,
            "owner_username": state.center.username,
            "source_node_id": state.node.node_id,
            "node_alias": state.node.alias,
            "agent_ids": [agent.agent_id for agent in state.agents],
            "contains_secrets": include_secrets,
            "files": entries,
        }
        (tmp_root / BUNDLE_MANIFEST).write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        with tarfile.open(out_path, "w:gz") as tar:
            for item in sorted(tmp_root.rglob("*")):
                if item.is_file():
                    arc = f"{BUNDLE_ROOT}/{item.relative_to(tmp_root).as_posix()}"
                    tar.add(item, arcname=arc, recursive=False)
    return ExportResult(path=out_path, manifest=manifest)


def _read_manifest(tar: tarfile.TarFile) -> dict[str, Any]:
    try:
        member = tar.getmember(f"{BUNDLE_ROOT}/{BUNDLE_MANIFEST}")
    except KeyError as exc:
        raise ValueError("bundle manifest missing") from exc
    if not member.isfile():
        raise ValueError("bundle manifest is not a file")
    raw = tar.extractfile(member)
    if raw is None:
        raise ValueError("cannot read bundle manifest")
    try:
        manifest = json.loads(raw.read().decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("invalid bundle manifest") from exc
    if int(manifest.get("schema_version") or 0) != BUNDLE_SCHEMA_VERSION:
        raise ValueError("unsupported bundle schema")
    return manifest


def _verify_member_paths(tar: tarfile.TarFile) -> None:
    for member in tar.getmembers():
        pure = pathlib.PurePosixPath(member.name)
        if not _safe_rel(pure):
            raise ValueError(f"unsafe bundle path: {member.name}")
        if member.issym() or member.islnk():
            raise ValueError(f"bundle links are not allowed: {member.name}")


def _verify_checksums(tar: tarfile.TarFile, manifest: dict[str, Any]) -> None:
    expected = {item["path"]: item for item in manifest.get("files") or []}
    actual = set()
    for member in tar.getmembers():
        if not member.isfile():
            continue
        pure = pathlib.PurePosixPath(member.name)
        rel = pathlib.PurePosixPath(*pure.parts[1:]).as_posix()
        if rel == BUNDLE_MANIFEST:
            continue
        actual.add(rel)
        if rel not in expected:
            raise ValueError(f"unexpected bundle file: {rel}")
        raw = tar.extractfile(member)
        if raw is None:
            raise ValueError(f"cannot read bundle file: {rel}")
        data = raw.read()
        if sha256_bytes(data) != expected[rel]["sha256"]:
            raise ValueError(f"bundle checksum mismatch: {rel}")
    missing = set(expected) - actual
    if missing:
        raise ValueError(f"bundle files missing: {sorted(missing)[:3]}")


def import_bundle(
    bundle_path: pathlib.Path,
    destination: pathlib.Path,
    *,
    keep_node_id: bool = False,
    rotate_agent_keys: bool = False,
    alias: str | None = None,
) -> ImportResult:
    bundle_path = pathlib.Path(bundle_path).expanduser()
    destination = pathlib.Path(destination).expanduser()
    if destination.exists() and any(destination.iterdir()):
        raise FileExistsError(f"destination is not empty: {destination}")
    with tempfile.TemporaryDirectory(prefix="taa-import-") as tmp:
        tmp_path = pathlib.Path(tmp)
        with tarfile.open(bundle_path, "r:gz") as tar:
            _verify_member_paths(tar)
            manifest = _read_manifest(tar)
            _verify_checksums(tar, manifest)
            for member in tar.getmembers():
                target = tmp_path / member.name
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                elif member.isfile():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    raw = tar.extractfile(member)
                    if raw is None:
                        raise ValueError(f"cannot extract: {member.name}")
                    target.write_bytes(raw.read())
        state = load_state(tmp_path / BUNDLE_ROOT)
        state = _rebind_state(state, keep_node_id=keep_node_id,
                             rotate_agent_keys=rotate_agent_keys, alias=alias)
        destination.mkdir(parents=True, exist_ok=True)
        for child in (tmp_path / BUNDLE_ROOT).iterdir():
            target = destination / child.name
            if child.is_dir():
                shutil.copytree(child, target, dirs_exist_ok=True)
            else:
                shutil.copy2(child, target)
        save_state(destination, state)
    return ImportResult(state=state, manifest=manifest, destination=destination)


def _rebind_state(
    state: IdentityState,
    *,
    keep_node_id: bool,
    rotate_agent_keys: bool,
    alias: str | None,
) -> IdentityState:
    old_node_id = state.node.node_id
    new_node_id = old_node_id if keep_node_id else new_id("nod_")
    state.node.node_id = new_node_id
    state.node.node_key = new_key(NODE_KEY_PREFIX)
    state.node.status = "pending_owner"
    state.center = CenterBinding()
    if alias:
        state.node.alias = alias[:40]
    for agent in state.agents:
        agent.node_id = new_node_id
        if rotate_agent_keys:
            from .identity import AGENT_KEY_PREFIX
            agent.agent_key = new_key(AGENT_KEY_PREFIX)
    return state
