"""Gate 7: resource-aware bundle plan and safe merge into an existing home.

This is offline migration/sync, not live peer-to-peer replication.
"""
from __future__ import annotations

import hashlib
import pathlib
import tarfile
from dataclasses import dataclass
from typing import Any

from .bundle import (
    BUNDLE_ROOT,
    _read_manifest,
    _verify_checksums,
    _verify_member_paths,
    read_bundle_manifest,
)
from .identity import load_state


class SyncConflict(RuntimeError):
    def __init__(self, conflicts: list[dict[str, Any]]):
        self.conflicts = conflicts
        super().__init__(f"{len(conflicts)} conflict(s) require explicit overwrite")


@dataclass
class SyncResult:
    copied: list[str]
    skipped: list[str]
    conflicts: list[dict[str, Any]]
    manifest: dict[str, Any]


def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _resource_skip(rel: str, size: int, free_disk_gb: float | None,
                   budget_bytes: int | None, max_asset_mb: int) -> bool:
    if rel == "identity.json":
        return True
    if rel.startswith("assets/") and size > max_asset_mb * 1024 * 1024:
        return True
    if free_disk_gb is not None and free_disk_gb < 1.0 and size > 50 * 1024 * 1024:
        return True
    if budget_bytes is not None and size > budget_bytes:
        return True
    return False


def plan_sync(
    bundle_path: pathlib.Path,
    home: pathlib.Path | None = None,
    *,
    free_disk_gb: float | None = None,
    budget_bytes: int | None = None,
    max_asset_mb: int = 64,
) -> dict[str, Any]:
    manifest = read_bundle_manifest(bundle_path)
    home = pathlib.Path(home).expanduser() if home else None
    items = []
    for item in manifest.get("files") or []:
        rel = str(item.get("path") or "")
        size = int(item.get("size") or 0)
        if rel == "identity.json":
            action = "identity-skip"
        elif _resource_skip(rel, size, free_disk_gb, budget_bytes, max_asset_mb):
            action = "resource-skip"
        elif home is None:
            action = "create"
        else:
            local = home / rel
            if local.is_symlink():
                action = "unsafe"
            elif not local.exists():
                action = "create"
            elif sha256_file(local) == item.get("sha256"):
                action = "same"
            else:
                action = "conflict"
        items.append({"path": rel, "size": size, "sha256": item.get("sha256"), "action": action})
    return {
        "ok": True,
        "schema_version": manifest.get("schema_version"),
        "source_node_id": manifest.get("source_node_id"),
        "files": items,
        "counts": {
            "create": sum(1 for x in items if x["action"] == "create"),
            "same": sum(1 for x in items if x["action"] == "same"),
            "conflict": sum(1 for x in items if x["action"] == "conflict"),
            "resource_skip": sum(1 for x in items if x["action"] == "resource-skip"),
            "identity_skip": sum(1 for x in items if x["action"] == "identity-skip"),
            "unsafe": sum(1 for x in items if x["action"] == "unsafe"),
        },
    }


def sync_bundle(
    bundle_path: pathlib.Path,
    home: pathlib.Path,
    *,
    overwrite: bool = False,
    free_disk_gb: float | None = None,
    budget_bytes: int | None = None,
    max_asset_mb: int = 64,
) -> SyncResult:
    home = pathlib.Path(home).expanduser()
    load_state(home)  # existing identity required; identity is never overwritten
    plan = plan_sync(bundle_path, home, free_disk_gb=free_disk_gb,
                     budget_bytes=budget_bytes, max_asset_mb=max_asset_mb)
    conflicts = [x for x in plan["files"] if x["action"] == "conflict"]
    if conflicts and not overwrite:
        raise SyncConflict(conflicts)
    copied: list[str] = []
    skipped: list[str] = []
    with tarfile.open(pathlib.Path(bundle_path).expanduser(), "r:gz") as tar:
        _verify_member_paths(tar)
        manifest = _read_manifest(tar)
        _verify_checksums(tar, manifest)
        actions = {x["path"]: x["action"] for x in plan["files"]}
        for item in manifest.get("files") or []:
            rel = str(item["path"])
            action = actions.get(rel)
            if action in {"same", "identity-skip", "resource-skip"}:
                skipped.append(rel)
                continue
            if action == "unsafe":
                raise ValueError(f"refusing to overwrite symlink: {rel}")
            member = tar.getmember(f"{BUNDLE_ROOT}/{rel}")
            if not member.isfile():
                raise ValueError(f"not a file: {rel}")
            raw = tar.extractfile(member)
            if raw is None:
                raise ValueError(f"cannot read: {rel}")
            data = raw.read()
            if hashlib.sha256(data).hexdigest() != item["sha256"]:
                raise ValueError(f"checksum mismatch: {rel}")
            target = home / rel
            if target.exists() and target.is_symlink():
                raise ValueError(f"refusing to overwrite symlink: {rel}")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            copied.append(rel)
    return SyncResult(copied=copied, skipped=skipped, conflicts=conflicts, manifest=manifest)
