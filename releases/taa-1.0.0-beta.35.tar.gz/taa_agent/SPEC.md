# TAA Node v0.5 · Gate 1 Contract

## 1. Scope

```text
Owner 1:N Node
Node 1:N Agent
Owner: username/password, optional email
Node: node_id, node_key, fingerprint_hash
Agent: agent_id, agent_key
```

- Node key is for node lifecycle/transport.
- Agent key is for agent identity, collaboration, migration and audit.
- Fingerprint hash is auxiliary, not authentication.
- Passwords are stored as PBKDF2-SHA256 hashes, never plaintext.
- Initial temporary password is returned by init once; caller must show it to the user.

## 2. Local layout

```text
<home>/
  identity.json
  agents/       optional
  tasks/        optional
  tools/        optional
  assets/       optional
  config/       optional
```

`identity.json` is mode 0600; home is mode 0700.

## 3. IDs and keys

```text
own_<hex>     Owner
nod_<hex>     Node
agt_<hex>     Agent
nk_<token>    Node key
ak_<token>    Agent key
```

## 4. Bundle

```text
taa-node/
  manifest.json
  identity.json
  agents/...
  tasks/...
  tools/...
  assets/...
  config/...
```

Manifest:

```json
{
  "schema_version": 1,
  "created_at": "...",
  "owner_id": "own_...",
  "source_node_id": "nod_...",
  "agent_ids": ["agt_..."],
  "contains_secrets": true,
  "files": [{"path": "identity.json", "size": 123, "sha256": "..."}]
}
```

Import rules:

```text
reject absolute paths
reject .. traversal
reject symlink/hardlink
verify sha256 for every file
new node_id by default
new node_key always
preserve agent_id
preserve agent_key by default (opt-in rotation)
```

## 5. Message encryption

```text
Node: X25519 keypair
public key: registered at center
private key: local identity only
message: ephemeral X25519 + HKDF-SHA256 + AES-GCM
center: stores ciphertext envelope only
```

The sender looks up the recipient node public key, encrypts locally, and the
recipient decrypts with its local private key. Cross-owner group messaging is
not enabled yet.

## 6. Deliberately not implemented in Gate 1

```text
center API
browser claim
UI
cross-LAN relay
live sync
account password reset
windows/linux packaging
```
