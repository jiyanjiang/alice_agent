#!/usr/bin/env python3
"""redaction_scan —— 脱敏/代码标准静态自检（**不依赖服务**，随时可跑）。

标准依据：`SOP.md §3`（不写绝对路径 `/Users/`/`/home/`、不写内网 IP、不写 key、不写真名）
        + `scripts/package_release.sh`（打包前泄露扫描）+ `docs/02` 脱敏正则。

检查项（对 `git ls-files` 的文本文件逐行）：
  1) 密钥：sk-… / AIzaSy… / AKIA… / Bearer …
  2) 绝对路径：/Users/<名> · /home/<名> · /opt/<名> · C:\\Users\\<名>
     （白名单：系统包管理器目录 /opt/homebrew、/usr/local、/opt/local——非用户路径）
  3) 真实内网 IP（白名单：书面示例 192.168.1.5/6/7、夹具 10.1.2.3 / 10.9.9.9、回环）
  4) 明文密钥字段（api_key/auth_code/password/secret = "…"）
  5) 敏感路径入库（bootstrap/certs/runtime、.key、data.db、config.yaml、inbox/、uploads/、.pwprofile）
  6) 私有记忆入包（agents/*/memory.db|.key|persona.yaml|working.json|resume.md）
  7) 真名（可选）：环境变量 TEAM_REDACT_NAMES="甲,乙" 时生效

用法：../venv/bin/python scripts/redaction_scan.py [--quiet]
退出码 0=全绿，非 0=有命中。
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TXT = (".md", ".py", ".sh", ".js", ".css", ".html", ".yaml", ".yml", ".txt",
       ".json", ".example", ".sql", ".toml", ".cfg", ".ini", ".ps1")

RULES = [
    ("密钥 sk-", re.compile(r"sk-[A-Za-z0-9]{16,}")),
    ("密钥 Google", re.compile(r"AIzaSy[A-Za-z0-9_-]{20,}")),
    ("密钥 AWS", re.compile(r"AKIA[0-9A-Z]{16}")),
    ("Bearer 令牌", re.compile(r"(?i)bearer\s+[A-Za-z0-9._-]{20,}")),
    ("绝对路径 /Users/", re.compile(r"/Users/[A-Za-z]")),
    ("绝对路径 /home//opt/", re.compile(r"(?<![\w.-])/(home|opt)/[A-Za-z]")),
    ("绝对路径 C:\\Users\\", re.compile(r"[Cc]:\\Users\\[A-Za-z]")),
    ("真实内网 IP", re.compile(r"\b(?:192\.168|10)\.\d{1,3}\.\d{1,3}\.\d{1,3}")),
    ("明文密钥字段", re.compile(r"(?i)\b(api[_-]?key|auth_code|password|passwd|secret)\b\s*[:=]\s*['\"]?[A-Za-z0-9_\-]{12,}")),
]
ALLOW = re.compile(r"192\.168\.1\.[5-7](?!\d)|10\.1\.2\.3(?!\d)|10\.9\.9\.9(?!\d)|127\.0\.0\.1|0\.0\.0\.0")
# 系统包管理器目录（非用户绝对路径，不含身份信息）：放行 /opt/homebrew、/usr/local、/opt/local。
ALLOW_PATH = re.compile(r"/opt/homebrew(?![\w.-])|/opt/local(?![\w.-])|/usr/local/(?:bin|sbin|lib|opt)(?![\w.-])")
SENSITIVE_PATH = re.compile(r"(^|/)(bootstrap|certs|runtime)/|\.key$|data\.db|config\.yaml$|inbox/|/room/|static/uploads/|\.pwprofile|\.curse")
PRIVATE_AGENT = re.compile(r"agents/[^/]+/(memory\.db|\.key|persona\.yaml|working\.json|resume\.md|wardrobe\.[A-Za-z]+)$")


def _tracked() -> list[str]:
    try:
        return [f for f in subprocess.run(["git", "ls-files"], cwd=ROOT,
                                          capture_output=True, text=True).stdout.splitlines() if f.strip()]
    except Exception:
        return []


def main() -> int:
    quiet = "--quiet" in sys.argv
    files = _tracked()
    names = [n for n in (os.environ.get("TEAM_REDACT_NAMES") or "").split(",") if n.strip()]
    hits: dict[str, list[str]] = {n: [] for n, _ in RULES}
    if names:
        hits["真名"] = []

    for f in files:
        if f == "scripts/redaction_scan.py" or not f.endswith(TXT):
            continue
        try:
            body = (ROOT / f).read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for i, ln in enumerate(body.splitlines(), 1):
            for name, rx in RULES:
                if rx.search(ln) and not (name == "真实内网 IP" and ALLOW.search(ln)) \
                        and not (name.startswith("绝对路径") and ALLOW_PATH.search(ln)):
                    hits[name].append(f"{f}:{i}: {ln.strip()[:120]}")
            for n in names:
                if n and n in ln:
                    hits["真名"].append(f"{f}:{i}: {ln.strip()[:120]}")

    # runtime/*.py are source modules, not runtime data; bootstrap/dist_serial is
    # a build serial (3 bytes), not a secret store. Other sensitive paths remain
    # blocked.
    bad = [
        f for f in files
        if SENSITIVE_PATH.search(f)
        and not (f.startswith("runtime/") and f.endswith(".py"))
        and f != "bootstrap/dist_serial"
    ]
    priv = [f for f in files if PRIVATE_AGENT.search(f)]

    fail = 0
    print(f"== redaction_scan（tracked {len(files)} 文件）==")
    for name, _ in RULES:
        h = hits[name]
        print(f"  [{'PASS' if not h else 'FAIL'}] {name}：{len(h)} 处")
        if h and not quiet:
            for x in h[:6]:
                print("        ", x)
        fail += len(h)
    if names:
        h = hits["真名"]
        print(f"  [{'PASS' if not h else 'FAIL'}] 真名（TEAM_REDACT_NAMES）：{len(h)} 处")
        if h and not quiet:
            for x in h[:6]:
                print("        ", x)
        fail += len(h)
    print(f"  [{'PASS' if not bad else 'FAIL'}] 敏感路径入库：{len(bad)}")
    if bad and not quiet:
        for x in bad[:6]:
            print("        ", x)
    fail += len(bad)
    print(f"  [{'PASS' if not priv else 'FAIL'}] 私有记忆/密钥入包：{len(priv)}")
    if priv and not quiet:
        for x in priv[:6]:
            print("        ", x)
    fail += len(priv)

    print(f"== redaction_scan 汇总：{'全绿' if not fail else str(fail) + ' 处命中'} ==")
    return 0 if not fail else 1


if __name__ == "__main__":
    sys.exit(main())
