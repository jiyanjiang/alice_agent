#!/usr/bin/env python3
"""sync —— 时钟同步客户端（自包含，可经目录系统分发）。

用法：
    python runtime/sync.py --as alice [--url https://...] [--since "2026-01-01 00:00:00"]
从 agents/<id>/.key 读取密钥，签名请求 /v1/sync，打印夜校 digest。
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import secrets
import ssl
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path.cwd()


def _key(agent_id: str) -> dict:
    return json.loads((ROOT / "agents" / agent_id / ".key").read_text(encoding="utf-8"))


def _sign(key: str, method: str, path: str, body: bytes, ts: str, nonce: str) -> str:
    canon = f"{method.upper()}\n{path}\n{hashlib.sha256(body).hexdigest()}\n{ts}\n{nonce}"
    return hmac.new(key.encode(), canon.encode(), hashlib.sha256).hexdigest()


def get(base: str, path: str, agent_id: str, ctx) -> dict:
    k = _key(agent_id)
    ts, nonce = str(int(time.time())), secrets.token_hex(8)
    req = urllib.request.Request(base + path, method="GET")
    req.add_header("X-TeamAI-Key", k["key_id"])
    req.add_header("X-TeamAI-Timestamp", ts)
    req.add_header("X-TeamAI-Nonce", nonce)
    req.add_header("X-TeamAI-Signature", _sign(k["key"], "GET", path, b"", ts, nonce))
    _hub_tok = os.environ.get("TEAMAI_HUB_TOKEN") or os.environ.get("TEAMAI_TUNNEL_TOKEN")
    if _hub_tok and "/n/" in req.full_url: req.add_header("X-Hub-Token", _hub_tok)
    with urllib.request.urlopen(req, timeout=30, context=ctx) as r:
        return json.loads(r.read().decode())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--as", dest="agent", required=True)
    ap.add_argument("--url", default=os.environ.get("TEAMAI_URL", "http://127.0.0.1:6030"))
    ap.add_argument("--since")
    ap.add_argument("--insecure", action="store_true")
    a = ap.parse_args()
    ctx = None
    if a.url.startswith("https"):
        ctx = ssl.create_default_context()
        if a.insecure:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
    path = f"/v1/sync?agent={a.agent}" + (f"&since={a.since}" if a.since else "")
    d = get(a.url.rstrip("/"), path, a.agent, ctx)
    print(json.dumps(d.get("digest", {}), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
