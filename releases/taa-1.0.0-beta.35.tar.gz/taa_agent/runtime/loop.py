#!/usr/bin/env python3
"""loop —— agent 自主循环骨架（自包含，可经目录系统分发）。

设计：每个节拍（默认 30 分钟）
  1. sync      拉取全队进度与夜校 digest
  2. tasks     取按人设打分排序的可认领任务
  3. 若本 agent 是执行者且 WIP 未满：认领分数最高且过阈值的任务
  4. 具体执行由 agent 运行时（IDE / LLM）完成，本循环只负责调度与同步

用法：
    python runtime/loop.py --as bob --once          # 跑一拍
    python runtime/loop.py --as bob --interval 30   # 常驻
"""
from __future__ import annotations

# Windows 控制台常为 GBK：print emoji/非 GBK 字符会 UnicodeEncodeError 直接崩（Darwin 实测 loop.py:192）
try:  # noqa: SIM105
    import sys as _sys
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

import argparse
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path.cwd()
import sys as _sys
if str(ROOT) not in _sys.path:
    _sys.path.insert(0, str(ROOT))     # 让 `from core import ...` 可用（否则 curate/obedience 静默失败）
MIN_SCORE = 0.15
MAX_PARALLEL = int(os.environ.get("TEAMAI_MAX_PARALLEL", "2"))   # ★ 2026-10-09：并发上限可配（原硬编码 wip<2）


def _key(agent_id: str) -> dict:
    return json.loads((ROOT / "agents" / agent_id / ".key").read_text(encoding="utf-8"))


def _sign(key: str, method: str, path: str, body: bytes, ts: str, nonce: str) -> str:
    canon = f"{method.upper()}\n{path}\n{hashlib.sha256(body).hexdigest()}\n{ts}\n{nonce}"
    return hmac.new(key.encode(), canon.encode(), hashlib.sha256).hexdigest()


def call(base: str, method: str, path: str, agent_id: str, ctx, body: dict | None = None) -> dict:
    data = json.dumps(body, ensure_ascii=False).encode() if body is not None else b""
    k = _key(agent_id)
    ts, nonce = str(int(time.time())), secrets.token_hex(8)
    req = urllib.request.Request(base + path, data=data if body is not None else None, method=method)
    req.add_header("Content-Type", "application/json")
    req.add_header("X-TeamAI-Key", k["key_id"])
    req.add_header("X-TeamAI-Timestamp", ts)
    req.add_header("X-TeamAI-Nonce", nonce)
    req.add_header("X-TeamAI-Signature", _sign(k["key"], method, path, data, ts, nonce))
    _hub_tok = os.environ.get("TEAMAI_HUB_TOKEN") or os.environ.get("TEAMAI_TUNNEL_TOKEN")
    if _hub_tok and "/n/" in req.full_url: req.add_header("X-Hub-Token", _hub_tok)
    with urllib.request.urlopen(req, timeout=30, context=ctx) as r:
        return json.loads(r.read().decode())


def _memory_db(agent: str):
    p = ROOT / "agents" / agent / "memory.db"
    if not p.exists():
        return None
    con = sqlite3.connect(p)
    con.row_factory = sqlite3.Row
    return con


def read_values(agent: str) -> dict:
    con = _memory_db(agent)
    if not con:
        return {}
    try:
        return {r["key"]: r["value"] for r in con.execute("SELECT key, value FROM values_t")}
    except sqlite3.Error:
        return {}
    finally:
        con.close()


def read_context(agent: str, limit: int = 5) -> dict:
    """从热记忆取当前焦点/意图，供决策装载。"""
    con = _memory_db(agent)
    if not con:
        return {}
    try:
        rows = con.execute(
            "SELECT kind, content FROM working WHERE expires_at IS NULL OR expires_at >= datetime('now','localtime') "
            "ORDER BY priority DESC LIMIT ?", (limit,)).fetchall()
        focus = next((r["content"] for r in rows if r["kind"] == "focus"), None)
        intents = [r["content"] for r in rows if r["kind"] == "intent"]
        return {"focus": focus, "intents": intents}
    except sqlite3.Error:
        return {}
    finally:
        con.close()


def export_working(agent: str) -> None:
    """每节拍物化热记忆到 agents/<id>/working.json。"""
    con = _memory_db(agent)
    if not con:
        return
    try:
        rows = con.execute(
            "SELECT kind, content, priority FROM working "
            "WHERE expires_at IS NULL OR expires_at >= datetime('now','localtime') "
            "ORDER BY priority DESC").fetchall()
        vals = {r["key"]: r["value"] for r in con.execute("SELECT key, value FROM values_t")}
    except sqlite3.Error:
        return
    finally:
        con.close()
    pack = {
        "agent": agent,
        "focus": next((r["content"] for r in rows if r["kind"] == "focus"), None),
        "values": vals,
        "intents": [r["content"] for r in rows if r["kind"] == "intent"],
        "open_questions": [r["content"] for r in rows if r["kind"] == "open_question"],
        "recent": [r["content"] for r in rows if r["kind"] == "recent_event"][:8],
    }
    (ROOT / "agents" / agent / "working.json").write_text(
        json.dumps(pack, ensure_ascii=False, indent=2), encoding="utf-8")


def read_status(agent: str) -> str:
    p = ROOT / "agents" / agent / ".status"
    return p.read_text(encoding="utf-8").strip() if p.exists() else "idle"


def _evidence_ok(posts: list) -> tuple[bool, str]:
    """判据式质检：产出帖是否含可核验的证据。"""
    if not posts:
        return False, "无关联产出帖"
    for p in posts:
        body = p.get("body") or ""
        if len(body) >= 200:
            return True, "正文≥200字"
        if "```" in body:
            return True, "含代码块"
        if re.search(r"(python|curl|make|npm|pytest|测试|输出|证据|复现|数据|命令)", body):
            return True, "含证据线索"
    return False, "缺少验收证据（需命令/测试/数据/引用）"


def _ds_key() -> str | None:
    for e in ("DEEPSEEK_API_KEY", "DS_KEY"):
        if os.environ.get(e):
            return os.environ[e]
    p = ROOT / "bootstrap" / "deepseek.key"
    return p.read_text(encoding="utf-8").strip() if p.exists() else None


def _persona(agent: str) -> tuple[str, str]:
    p = ROOT / "agents" / agent / "persona.yaml"
    try:
        import yaml
        d = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        return (d.get("identity") or {}).get("motto", ""), d.get("role", "coordinator")
    except Exception:
        return "", "coordinator"


def respond_message(base: str, agent: str, msg: dict, ctx) -> None:
    key = _ds_key()
    if not key:
        return
    motto, role = _persona(agent)
    prompt = (f"你是团队 AI 的统筹 agent「{agent}」（{role}；{motto}）。\n"
              f"收到来自 {msg['from_id']} 的私信：\n{msg['body']}\n\n"
              f"请用中文、直接、简短（≤120 字）回复。")
    body = json.dumps({"model": os.environ.get("TEAMAI_REPLY_MODEL", "deepseek-chat"),
                       "messages": [{"role": "user", "content": prompt}],
                       "temperature": 0.4, "max_tokens": 400}).encode()
    req = urllib.request.Request("https://api.deepseek.com/v1/chat/completions", data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", f"Bearer {key}")
    with urllib.request.urlopen(req, timeout=60) as r:
        reply = json.loads(r.read().decode())["choices"][0]["message"]["content"].strip()
    call(base, "POST", "/v1/messages", agent, ctx, {"to": msg["from_id"], "body": reply})
    print(f"  [reply -> {msg['from_id']}] {reply[:70]}")


def poll_dm(base: str, agent: str, ctx) -> dict:
    """一拍处理私信（D1-补）：即使离线期间真人发来，未读仍在 → 恢复后照样回复（补捞）。"""
    try:
        from core import dm_runtime
    except Exception as e:  # noqa: BLE001
        print(f"  [dm] import err: {e}")
        return {}

    def _c(method, path, body=None):
        return call(base, method, path, agent, ctx, body)

    try:
        s = dm_runtime.poll_dm(_c, agent)
    except Exception as e:  # noqa: BLE001
        print(f"  [dm] poll err: {e}")
        return {}
    for line in dm_runtime.brief_lines(s):
        print(f"  [dm] · {line}")
    return s


def tick(base: str, agent: str, ctx, claim: bool, standup: bool = False) -> None:
    export_working(agent)
    sync = call(base, "GET", f"/v1/sync?agent={agent}", agent, ctx)
    print(f"[sync] {sync['digest']['headline']}  wip={sync['me']['wip']} role={sync['me']['role']}"
          + (f"  DM未读={sync.get('dm_unread', 0)}"
             if sync.get("dm_unread") else ""))
    poll_dm(base, agent, ctx)          # ★ 私信优先（真人↔agent 的命门）
    notif = call(base, "GET", "/v1/notifications?unread=1", agent, ctx).get("notifications", [])
    for n in notif:
        print(f"  [notify:{n['kind']}] {n['body']}")
    if any(n.get("kind") == "review" for n in notif):
        print("  → 有任务被打回，优先处理")
    memctx = read_context(agent)
    if memctx:
        print(f"[context] focus={memctx.get('focus')} intents={memctx.get('intents')}")
    values = read_values(agent)
    path = f"/v1/tasks?for_agent={agent}"
    if values:
        path += "&values=" + urllib.parse.quote(json.dumps(values))
    d = call(base, "GET", path, agent, ctx)
    for t in d["tasks"][:5]:
        print(f"  candidate score={t['score']:<7} {t['id']} p{t['priority']} {t['title']}")
    if standup:
        did = [x.get("title") for x in sync["digest"].get("recently_done", [])][:5]
        plan = [t["title"] for t in d["tasks"][:3]]
        body = "自动日报：" + ("；计划 " + "、".join(plan) if plan else "暂无计划")
        call(base, "POST", "/v1/posts", agent, ctx,
             {"channel_id": "#standup", "type": "standup", "title": "standup",
              "body": body, "standup": {"did": did, "plan": plan, "blockers": []}})
        print("[standup] posted")
    if claim and d["tasks"]:
        # claimed 是排队位，in_progress 是执行位；两者合计不能超过 MAX_PARALLEL。
        # 旧代码只看 in_progress，会导致 loop 每拍继续 claim，claimed 泄漏成十几条。
        wip = int(sync["me"].get("wip", 0))
        queued = int(sync["me"].get("queued", 0))
        lanes = sync["me"].get("lanes") or {"long": 0, "short": 0}
        max_long = int(os.environ.get("TEAMAI_MAX_LONG", "1"))
        max_short = int(os.environ.get("TEAMAI_MAX_SHORT", "1"))
        if (wip + queued) < MAX_PARALLEL:
            for top in d["tasks"]:
                lane = "long" if top.get("lane") == "long" else "short"
                used = int(lanes.get(lane, 0))
                cap = max_long if lane == "long" else max_short
                if used >= cap:
                    continue
                if top["score"] < MIN_SCORE:
                    continue
                res = call(base, "POST", f"/v1/tasks/{top['id']}/claim", agent, ctx,
                           {"score": top["score"], "reason": "loop auto-claim (top score)"})
                print(f"  claimed {top['id']} lane={lane} -> {res['task']['status']}")
                write_brief(agent, top, sync)
                break


def write_brief(agent: str, task: dict, sync: dict) -> None:
    """把认领的任务写成「派活简报」，供 dispatcher 交给 opencode 执行。"""
    inbox = ROOT / "agents" / agent / "inbox"
    inbox.mkdir(parents=True, exist_ok=True)
    brief = {
        "agent": agent,
        "task_id": task["id"],
        "title": task.get("title"),
        "description": task.get("description"),
        "acceptance_criteria": task.get("acceptance_criteria"),
        "tags": task.get("tags"),
        "priority": task.get("priority"),
        "lane": task.get("lane") or "short",
        "phase": (task.get("metadata") or {}).get("phase") or "run",
        "workspace": (task.get("metadata") or {}).get("workspace") or "root",
        "claimed_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "active_topic": (sync.get("active_topic") or {}).get("title"),
        # 心跳简报可见性（D1-补 判据③）：未读私信随简报一起下发，离线恢复不漏
        "unread_dm": int(sync.get("dm_unread", 0) or 0),
        "dm_requests": int(sync.get("dm_requests", 0) or 0),
        "howto": "用 teamai CLI 发帖并 submit；详见 dispatcher 生成的 prompt",
    }
    (inbox / f"{task['id']}.json").write_text(
        json.dumps(brief, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"  → inbox brief written: agents/{agent}/inbox/{task['id']}.json")


def tick_coordinator(base: str, agent: str, ctx, auto_qc: bool = True, respond: bool = True,
                     require_plan: bool = False) -> None:
    """统筹者一拍：同步 → 处理未读/私信 → 质检 review 队列。"""
    sync = call(base, "GET", f"/v1/sync?agent={agent}", agent, ctx)
    print(f"[coordinator] {sync['digest']['headline']}  unread={sync.get('unread',0)}  "
          f"msgs={sync.get('unread_messages',0)}  DM未读={sync.get('dm_unread',0)}  "
          f"topic={(sync.get('active_topic') or {}).get('title') or '-'}")
    poll_dm(base, agent, ctx)          # ★ 统筹也要看私信（真人↔agent 的命门）
    notif = call(base, "GET", "/v1/notifications?unread=1", agent, ctx)
    for n in notif.get("notifications", []):
        print(f"  · 未读[{n['kind']}] {n['body']}")
    if notif.get("notifications"):
        call(base, "POST", "/v1/notifications/read", agent, ctx, {})
    msgs = sync.get("messages", [])
    for m in msgs:
        print(f"  · 私信 ← {m['from_id']}: {m['body'][:80]}")
    if msgs and respond:
        for m in msgs:
            try:
                respond_message(base, agent, m, ctx)
            except Exception as e:
                print(f"  reply err: {e}")
        call(base, "POST", "/v1/messages/read", agent, ctx, {})
    review = call(base, "GET", "/v1/tasks?status=review", agent, ctx).get("tasks", [])
    for t in review:
        if not auto_qc:
            print(f"  · 待质检 {t['id']} {t['title']}（仅建议）")
            continue
        posts = call(base, "GET", f"/v1/posts?task_id={t['id']}", agent, ctx).get("posts", [])
        ok, why = _evidence_ok(posts)
        # 规划优先门禁：未过 approved 方案 → 打回（方案评审见 core/plan.py / docs/30）
        if ok and require_plan:
            try:
                from core import plan as plan_mod
                tags = t.get("tags") or []
                if isinstance(tags, str):
                    tags = [tags]
                topic = (tags[0] if tags else t["id"])
                target = t.get("assignee") or t.get("assignee_id") or "?"
                g = plan_mod.plan_gate(agent, topic, target)
                if not g.get("ok"):
                    ok, why = False, f"未过方案门禁：{g.get('reason')}"
            except Exception as e:  # noqa: BLE001
                print(f"  plan gate err: {e}")
        body = {"decision": "approved" if ok else "request_changes",
                "comments": f"统筹判据式质检：{why}"}
        if ok:
            body["quality_score"] = 0.85
        res = call(base, "POST", f"/v1/tasks/{t['id']}/review", agent, ctx, body)
        print(f"  · 质检 {t['id']} [{body['decision']}] {why} -> {res.get('task', {}).get('status')}")
    backlog = call(base, "GET", "/v1/tasks?status=backlog", agent, ctx).get("tasks", [])
    for t in backlog[:5]:
        print(f"  · 待认领 {t['id']} p{t['priority']} {t['title']}")
    # 节流计数（控本）：精选每 6 拍、服从度每 12 拍，且**仅在有 running 房时**才跑（空闲零开销）
    tick_coordinator._tick_n = getattr(tick_coordinator, "_tick_n", 0) + 1
    try:
        _rooms_now = call(base, "GET", "/v1/rooms", agent, ctx).get("rooms", [])
    except Exception:
        _rooms_now = []
    _live = any((r.get("status") == "running") for r in _rooms_now)
    # 精选与推荐（docs/33）：挑值得看的产出，发精选帖 + 群里带帖号
    if _live and tick_coordinator._tick_n % 6 == 1:
        try:
            from core import curate as _curate
            def _cc(method, path, body=None):
                return call(base, method, path, agent, ctx, body)
            _r = _curate.run(_cc, agent)
            if _r.get("published"):
                print(f"  · 精选推荐: {_r['published']} (room={_r.get('room')})")
        except Exception as e:  # noqa: BLE001
            print(f"  curate err: {e}")
    # 服从度监控（docs/34）：**只在出现"无视/不兑现"时报警到群**（避免刷屏）
    if _live and tick_coordinator._tick_n % 12 == 1:
        try:
            from core import obedience as _ob
            def _oc(method, path, body=None):
                return call(base, method, path, agent, ctx, body)
            _rep = _ob.run(_oc, agent, hours=1, limit_rooms=2)
            if any(j["verdict"] == "ignored" for j in _rep["items"]):
                _rid = _ob.notify(_oc, agent, _ob.report_text(_rep))
                print(f"  · 服从度告警（发现无视项）→ {_rid}")
        except Exception as e:  # noqa: BLE001
            print(f"  obedience err: {e}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--as", dest="agent", required=True)
    ap.add_argument("--role", choices=["executor", "coordinator"], default="executor")
    ap.add_argument("--url", default=os.environ.get("TEAMAI_URL", "http://127.0.0.1:6030"))
    ap.add_argument("--interval", type=int, default=None,
                    help="分钟；默认 executor=30、coordinator=5")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--no-claim", action="store_true")
    ap.add_argument("--no-qc", action="store_true", help="统筹：只建议、不自动质检")
    ap.add_argument("--require-plan", dest="require_plan", action="store_true",
                    help="统筹：质检时启用『未过方案不得开工』门禁")
    ap.add_argument("--no-respond", action="store_true", help="统筹：不自动回复私信")
    ap.add_argument("--standup", action="store_true", help="executor：每拍发日报")
    ap.add_argument("--ca", help="CA 证书路径（https）")
    ap.add_argument("--insecure", action="store_true")
    a = ap.parse_args()
    base = a.url.rstrip("/")
    interval = a.interval or (5 if a.role == "coordinator" else 30)
    ctx = None
    if base.startswith("https"):
        cafile = a.ca or os.environ.get("TEAMAI_CA")
        ctx = ssl.create_default_context(cafile=cafile) if cafile else ssl.create_default_context()
        if a.insecure:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
    print(f"[loop] role={a.role} agent={a.agent} interval={interval}min")
    ticks = 0
    while True:
        if read_status(a.agent) == "busy":
            print("[busy] 跳过本拍（不接触服务端）")
            if a.once:
                break
            time.sleep(interval * 60)
            continue
        try:
            if a.role == "coordinator":
                tick_coordinator(base, a.agent, ctx, auto_qc=not a.no_qc, respond=not a.no_respond,
                                 require_plan=getattr(a, "require_plan", False))
            else:
                tick(base, a.agent, ctx, claim=not a.no_claim, standup=a.standup)
            ticks += 1
            (ROOT / "runtime").mkdir(exist_ok=True)
            (ROOT / "runtime" / f".healthy.{a.agent}").write_text(
                json.dumps({"agent": a.agent, "pid": os.getpid(), "tick": ticks, "ts": time.time()}),
                encoding="utf-8")
        except urllib.error.URLError as e:
            print(f"[loop] server unreachable: {e.reason}")
        if a.once:
            break
        time.sleep(interval * 60)


if __name__ == "__main__":
    main()
