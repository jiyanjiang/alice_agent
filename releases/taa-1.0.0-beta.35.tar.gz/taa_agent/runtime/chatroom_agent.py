#!/usr/bin/env python3
"""chatroom_agent —— 聊天室读书会的 agent 自动运行时（M2）。

轮到时：prepare 阶段用 opencode 决定「发言或 SKIP」，open 阶段 commit。
用法：
    python dist/chatroom_agent.py --as alice [--url https://...] [--ca certs/server.crt] [--interval 2]
"""
from __future__ import annotations

# Windows 控制台常为 GBK：print emoji/非 GBK 字符会 UnicodeEncodeError 直接崩（Darwin 实测 loop.py:192）
try:  # noqa: SIM105
    import sys as _sys
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

import argparse
import atexit
import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import signal
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path.cwd()


def _key(agent: str) -> dict:
    return json.loads((ROOT / "agents" / agent / ".key").read_text(encoding="utf-8"))


def _sign(key: str, method: str, path: str, body: bytes, ts: str, nonce: str) -> str:
    canon = f"{method.upper()}\n{path}\n{hashlib.sha256(body).hexdigest()}\n{ts}\n{nonce}"
    return hmac.new(key.encode(), canon.encode(), hashlib.sha256).hexdigest()


class Client:
    def __init__(self, base: str, agent: str, ca: str | None):
        self.base = base.rstrip("/")
        self.agent = agent
        self.k = _key(agent)
        self.last_err = None
        self.ctx = None
        if self.base.startswith("https"):
            cafile = ca or os.environ.get("TEAMAI_CA")
            self.ctx = ssl.create_default_context(cafile=cafile) if cafile else ssl.create_default_context()

    def call(self, method: str, path: str, body: dict | None = None,
             timeout: float = 30.0) -> dict:
        data = json.dumps(body, ensure_ascii=False).encode() if body is not None else b""
        ts, nonce = str(int(time.time())), secrets.token_hex(8)
        req = urllib.request.Request(self.base + path, data=data if body is not None else None, method=method)
        req.add_header("Content-Type", "application/json")
        req.add_header("X-TeamAI-Key", self.k["key_id"])
        req.add_header("X-TeamAI-Timestamp", ts)
        req.add_header("X-TeamAI-Nonce", nonce)
        req.add_header("X-TeamAI-Signature", _sign(self.k["key"], method, path, data, ts, nonce))
        _hub_tok = os.environ.get("TEAMAI_HUB_TOKEN") or os.environ.get("TEAMAI_TUNNEL_TOKEN")
        if _hub_tok and "/n/" in req.full_url: req.add_header("X-Hub-Token", _hub_tok)
        try:
            with urllib.request.urlopen(req, timeout=max(5.0, float(timeout)), context=self.ctx) as r:
                self.last_err = None
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            self.last_err = f"HTTP {e.code}"
            return {"_http": e.code, "_body": e.read().decode()[:200]}
        except urllib.error.URLError as e:
            self.last_err = str(e)
            return {"_err": str(e)}


def _persona(agent: str) -> dict:
    p = ROOT / "agents" / agent / "persona.yaml"
    try:
        import yaml
        return yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}


def _vision_model(agent: str) -> str:
    """视觉模型：agents/<id>/vision_model > config.llm.vision_model > env > 默认。"""
    try:
        p = ROOT / "agents" / agent / "vision_model"
        if p.exists():
            m = p.read_text(encoding="utf-8").strip()
            if m:
                return m
    except Exception:
        pass
    try:
        import sys as _s
        if str(ROOT) not in _s.path:
            _s.path.insert(0, str(ROOT))
        from core import config
        m = config.get("llm.vision_model")
        if m:
            return str(m)
    except Exception:
        pass
    return os.environ.get("TEAMAI_VISION_MODEL", "deepseek/deepseek-flash")


def _recent_images(transcript: list, base: str | None = None, n: int = 2,
                   lookback: int = 3) -> list[str]:
    """取最近几条消息里的图片；本地没有的从服务端下载到本地缓存（跨机附件）。"""
    urls = [m.get("attachment") for m in transcript[-lookback:] if m.get("attachment")]
    out = []
    for u in urls[-n:]:
        p = ROOT / str(u).lstrip("/")
        if p.exists():
            out.append(str(p))
            continue
        if base and str(u).startswith("/"):     # 远端附件 → 下载到 runtime/cache
            try:
                import urllib.request
                cache = ROOT / "runtime" / "cache"
                cache.mkdir(parents=True, exist_ok=True)
                lp = cache / Path(str(u)).name
                urllib.request.urlretrieve(base + str(u), str(lp))
                out.append(str(lp))
            except Exception as e:  # noqa: BLE001
                print(f"  [vision] 附件下载失败 {u}: {e}")
    return out


MAX_CHATWORK_IMAGES = 4          # 指令管道随附图片上限：多了会把上下文撑大（成本/噪声）


def _msg_attachment_urls(m: dict) -> list[str]:
    """取一条消息的附件 URL 列表。

    兼容两种字段：房间消息用单数 `attachment`（一个 URL）；DM/帖子用复数 `attachments`
    （列表，或 JSON 串）。返回去空、去重前的原始顺序。
    """
    def _norm(v) -> list[str]:
        """把「URL 串 / {url,name} / JSON 串 / 列表」统一摊平成 URL 列表。"""
        if isinstance(v, str) and v.strip():
            s = v.strip()
            if s[:1] in ("[", "{"):
                try:
                    v = json.loads(s)
                except Exception:  # noqa: BLE001
                    return [s]
            else:
                return [s]
        if isinstance(v, dict):
            u = v.get("url")
            return [str(u)] if u else []
        if isinstance(v, (list, tuple)):
            out: list[str] = []
            for x in v:
                out += _norm(x)
            return out
        return [str(v)] if v else []

    out: list[str] = []
    out += _norm(m.get("attachment"))
    out += _norm(m.get("attachments"))
    seen, uniq = set(), []
    for u in out:
        u = u.strip()
        if u and u not in seen:
            seen.add(u)
            uniq.append(u)
    return uniq


def _resolve_attachment(u: str, base: str | None = None) -> str | None:
    """附件 URL → **本机文件路径**。

    规则：`/static/uploads/x.jpg` → `ROOT/static/uploads/x.jpg`（项目根相对）；
    已是存在的本机绝对路径则直接用；本地没有再给 `base` 就从服务端下载到 `runtime/cache`
    （跨机附件）。取不到一律返回 None（调用方降级为纯文本，不抛异常）。
    """
    u = str(u or "").strip()
    if not u:
        return None
    try:
        p = Path(u)
        if p.is_absolute() and p.is_file():
            return str(p)
        lp = ROOT / u.lstrip("/")
        if lp.is_file():
            return str(lp)
        if base and u.startswith("/"):
            import urllib.request
            cache = ROOT / "runtime" / "cache"
            cache.mkdir(parents=True, exist_ok=True)
            dst = cache / Path(u.lstrip("/")).name
            urllib.request.urlretrieve(base + u, str(dst))
            if dst.is_file() and dst.stat().st_size:
                return str(dst)
    except Exception as e:  # noqa: BLE001
        print(f"[chatwork] 附件解析失败 {u}: {e}")
    return None


def _chatwork_images(m: dict, base: str | None = None,
                     cap: int = MAX_CHATWORK_IMAGES) -> tuple[list[str], str]:
    """把一条消息的附件解析成本机图片路径，供 `chatwork.classify(files=…)` 交给视觉模型。

    返回 (files, note)：
    - files：真实存在的本机路径（最多 cap 张，按消息内顺序取前 cap 张）；
    - note：需要写进提示的一句说明（仅在「超量」或「有附件取不到」时非空）——
      保证附件缺失/超量时**不崩**，而是降级为纯文本并如实说明。
    """
    urls = _msg_attachment_urls(m)
    files, missing = [], 0
    for u in urls[:cap]:
        p = _resolve_attachment(u, base)
        if p:
            files.append(p)
        else:
            missing += 1
    notes = []
    if len(urls) > cap:
        notes.append(f"（本条消息共 {len(urls)} 个附件，只随附了前 {cap} 张）")
    if missing:
        notes.append(f"（有 {missing} 个附件取不到本地文件，未能随附，请按现有信息判断并说明）")
    return files, "".join(notes)


def _persona_note(agent: str) -> str:
    """把性别/外貌/节律等富人格注入语气（#66/#70）。"""
    try:
        import sys as _sys
        if str(ROOT) not in _sys.path:
            _sys.path.insert(0, str(ROOT))
        from core import persona as pm
        v = pm.persona_view(_persona(agent))
    except Exception:
        return ""
    parts = []
    if v.get("gender") and v["gender"] != "unspecified":
        parts.append(f"性别{v['gender']}")
    b = v.get("body") or {}
    if b.get("height_cm"):
        parts.append(f"身高{b['height_cm']}cm")
    if b.get("appearance"):
        parts.append(str(b["appearance"]))
    if v.get("cycle"):
        parts.append(f"今日处于{v['cycle']['phase']}（{v['cycle'].get('note', '')}）")
    bnd = v.get("boundaries") or {}
    if bnd.get("note") or bnd.get("hard_limits"):
        seg = bnd.get("note") or ""
        if bnd.get("hard_limits"):
            seg += f"（硬边界：{'、'.join(bnd['hard_limits'])}）"
        parts.append(seg)
    if v.get("soul_note"):
        parts.insert(0, "你的灵魂宣言（据此思想与说话）：\n" + str(v["soul_note"]))
    vo = v.get("voice") or {}
    if vo.get("anchor"):
        parts.insert(0, vo["anchor"])
    if vo.get("style"):
        parts.append(f"说话风格：{vo['style']}")
    if vo.get("catchphrases"):
        parts.append(f"口头禅：{'、'.join(vo['catchphrases'])}")
    if not parts:
        return ""
    return "\n（你的人格： " + "；".join(parts) + "。自然地体现在语气与状态里，别直接报这些数字。）"


def _extract_json(out: str) -> str | None:
    """从模型输出里稳健地取出含 "action" 的 JSON 对象（容忍前后废话与换行）。"""
    i = out.find('"action"')
    if i == -1:
        return None
    start = out.rfind("{", 0, i)
    if start == -1:
        return None
    depth, instr, esc = 0, False, False
    for j in range(start, len(out)):
        ch = out[j]
        if esc:
            esc = False
            continue
        if ch == "\\":
            esc = True
            continue
        if ch == '"':
            instr = not instr
            continue
        if instr:
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return out[start:j + 1]
    return None


def _local_tool(agent: str, name: str, args: dict):
    """本机 tools/<pkg>/tool.py 存在则**本地执行**（返回 result 或 None 表示无此工具）。"""
    import importlib.util
    pkg = (name or "").split(".")[0]
    f = ROOT / "tools" / pkg / "tool.py"
    if not f.exists():
        return None
    try:
        spec = importlib.util.spec_from_file_location(f"localtool_{pkg}", f)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod.run(agent, args or {})
    except Exception as e:  # noqa: BLE001
        return {"_error": f"{type(e).__name__}: {e}"}


def _upload_local(c: "Client", path: str, allow_risky: bool = False) -> dict:
    """把本机文件作为附件上传到宿主（签名 multipart），返回附件 URL。"""
    import urllib.request as _u
    p = Path(path) if os.path.isabs(path or "") else (ROOT / (path or ""))
    data = p.read_bytes()
    b = "----teamai" + secrets.token_hex(8)
    pre = (f"--{b}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{p.name}\"\r\n"
           "Content-Type: application/octet-stream\r\n\r\n").encode("utf-8")
    tail = (f"\r\n--{b}\r\nContent-Disposition: form-data; name=\"allow_risky\"\r\n\r\n"
            f"{'1' if allow_risky else '0'}\r\n--{b}--\r\n").encode("utf-8")
    body = pre + data + tail
    ts, nonce = str(int(time.time())), secrets.token_hex(8)
    sig = _sign(c.k["key"], "POST", "/v1/uploads", body, ts, nonce)
    req = _u.Request(c.base + "/v1/uploads", data=body, method="POST")
    req.add_header("Content-Type", f"multipart/form-data; boundary={b}")
    req.add_header("X-TeamAI-Key", c.k["key_id"])
    req.add_header("X-TeamAI-Timestamp", ts)
    req.add_header("X-TeamAI-Nonce", nonce)
    req.add_header("X-TeamAI-Signature", sig)
    _hub_tok = os.environ.get("TEAMAI_HUB_TOKEN") or os.environ.get("TEAMAI_TUNNEL_TOKEN")
    if _hub_tok and "/n/" in req.full_url: req.add_header("X-Hub-Token", _hub_tok)
    with _u.urlopen(req, timeout=120) as r:
        d = json.loads(r.read().decode("utf-8"))
    if not d.get("ok"):
        raise RuntimeError(d.get("error") or "upload failed")
    return {"attachment": d["url"],
            "text": f"[tool upload]\n已上传附件：{d['url']}（{d.get('size')}B，{d.get('name')}）"}


def _weather_text(res: dict) -> str:
    """把 weather 工具结果压成群里能直接读的文字（不暴露本地路径/ky）。"""
    if not isinstance(res, dict):
        return str(res)
    if not res.get("ok"):
        return f"[weather 失败] {res.get('error') or '未知错误'}"
    loc = res.get("place") or {}
    w = res.get("weather") or {}
    adv = res.get("advice") or {}
    tag = "·".join(str(x) for x in (loc.get("name"), loc.get("admin1"), loc.get("country")) if x)
    lines = []
    if tag:
        lines.append(tag)
    lines.append(
        f"天气：{w.get('desc') or '—'}｜当前 {w.get('temp')}℃（体感 {w.get('feels')}℃）"
        f"｜今日 {w.get('t_min')}~{w.get('t_max')}℃"
        f"｜降水概率 {w.get('precip_prob')}%｜风 {w.get('wind')}km/h")
    items = adv.get("outfit") or []
    if items:
        lines.append("穿搭建议：")
        for o in items:
            lines.append(f"· {o.get('name')}（{o.get('type')}／{o.get('color')}）")
    for g in adv.get("generic") or []:
        lines.append(f"· {g}")
    for n in adv.get("notes") or []:
        lines.append(f"⚠ {n}")
    img = (res.get("image") or {}).get("url")
    if img:
        lines.append(f"图片：{img}")
    return "\n".join(lines)


def _research_text(res: dict) -> str:
    if not isinstance(res, dict):
        return str(res)
    if res.get("ok") is False:
        return f"[research.ask 失败] {res.get('error') or 'unknown'}"
    text = str(res.get("text") or res.get("summary") or "").strip()
    if not text:
        return f"[research.ask 完成] ref={res.get('ref') or '-'} provider={res.get('provider') or '-'}"
    ref = res.get("ref") or res.get("code") or ""
    provider = res.get("provider") or ""
    head = "research.ask" + (f" · {ref}" if ref else "") + (f" · {provider}" if provider else "")
    gate = res.get("gate") or {}
    status = gate.get("status") or ("verified" if res.get("verified") else "unverified")
    lines = [head, "", text, "", f"来源门禁：{status}"]
    if gate.get("reasons"):
        lines.append("门禁原因：" + "；".join(str(x) for x in gate["reasons"][:4]))
    return "\n".join(lines)


def _publish_research(c: "Client", agent: str, res: dict, args: dict) -> str:
    """把 research.ask 结果发到论坛；未通过来源门禁的结论不存档为事实。"""
    if not res.get("verified"):
        gate = res.get("gate") or {}
        return ("未发论坛：来源门禁未过（"
                + "；".join(str(x) for x in (gate.get("reasons") or ["未核验"]))[:300] + "）")
    text = _research_text(res)
    title = str(args.get("title") or res.get("title")
                or f"research.ask · {res.get('ref') or '调研结果'}")[:160]
    channel = str(args.get("channel") or "#reading")
    body = (f"## research.ask\n\n{text}\n\n"
            f"- ref: {res.get('ref') or '-'}\n"
            f"- provider: {res.get('provider') or '-'}\n"
            f"- model: {res.get('model') or '-'}\n"
            f"- agent: {agent}\n")
    try:
        d = c.call("POST", "/v1/posts",
                   {"channel_id": channel, "type": "note", "title": title,
                    "body": body[:60000], "tags": ["research.ask", "论坛备份"]},
                   timeout=60)
        pid = (d or {}).get("post_id")
        if pid:
            return f"论坛存档：{pid}\n链接：/app/p/{pid}"
        return f"论坛存档失败：{(d or {}).get('error') or 'unknown'}"
    except Exception as e:  # noqa: BLE001
        return f"论坛存档失败：{type(e).__name__}: {e}"


def _run_tool(c: "Client", tool: dict) -> dict:
    """执行 agent 声明的工具，返回 {attachment: 图片URL, text: 页面文本}。"""
    t = (tool or {}).get("type") or (tool or {}).get("tool")   # 兼容 "type" / "tool" 两种键
    args = (tool or {}).get("args") or {}
    try:
        if t == "weather":
            srv = c.call("POST", "/v1/tools/weather/call", {"args": args}, timeout=120) or {}
            res = srv.get("result")
            if not isinstance(res, dict):
                return {"attachment": None, "_error": True,
                        "text": f"[tool weather 失败] {srv.get('error') or '服务端未返回结果'}"}
            txt = _weather_text(res)
            att = (res.get("image") or {}).get("url")
            return {"attachment": att, "text": txt}
        if t == "research.ask":
            srv = c.call("POST", "/v1/tools/research.ask/call", {"args": args}, timeout=900) or {}
            res = srv.get("result")
            if not isinstance(res, dict):
                return {"attachment": None, "_error": True,
                        "text": f"[tool research.ask 失败] {srv.get('error') or '服务端未返回结果'}"}
            txt = _research_text(res)
            if args.get("publish") or args.get("forum"):
                txt += "\n\n" + _publish_research(c, c.agent, res, args)
            return {"attachment": None, "text": txt}
        if t == "upload":
            args = tool.get("args") or {}
            return _upload_local(c, tool.get("path") or args.get("path") or "",
                                 bool(args.get("allow_risky")))
        if t == "gen":
            u = c.call("POST", "/v1/media/generate", {"prompt": tool.get("prompt", "")}).get("url")
            return {"attachment": u, "text": ""}
        if t == "search":
            d = c.call("POST", "/v1/media/search", {"query": tool.get("query", ""), "n": 1})
            urls = d.get("results") or []
            if urls:
                u = c.call("POST", "/v1/media/fetch", {"url": urls[0]}).get("url")
                return {"attachment": u, "text": f"（Bing 搜到一张相关图：{urls[0]}）"}
        if t == "screenshot":
            u = c.call("POST", "/v1/media/screenshot",
                       {"url": tool.get("url", ""), "full": bool(tool.get("full"))}).get("url")
            return {"attachment": u, "text": ""}
        if t == "browse":
            d = c.call("POST", "/v1/media/browse",
                       {"url": tool.get("url", ""), "actions": tool.get("actions", []),
                        "full": bool(tool.get("full"))})
            return {"attachment": d.get("screenshot"), "text": d.get("text") or ""}
        if t == "plan.review":
            from core import plan as plan_mod
            pa = tool.get("args") or {}
            r = plan_mod.review_plan(pa.get("topic", ""), pa.get("target", c.agent),
                                     pa.get("plan", ""), agent=c.agent)
            if r.get("error"):
                return {"attachment": None, "text": f"[plan.review 失败] {r['error']}",
                        "_error": True}
            txt = (f"方案评审：{'通过 ✓' if r.get('ok') else '不通过 ✗'}（cycle#{r.get('cycle')}）\n"
                   f"结论：{r.get('verdict')}\n"
                   f"缺口：{r.get('missing')}\n反馈：{r.get('feedback')}")
            return {"attachment": None, "text": txt}
        if t and t not in ("gen", "search", "screenshot", "browse"):
            args = tool.get("args") or {}
            err = None
            res = None
            local = _local_tool(c.agent, t, args)
            if isinstance(local, dict) and local.get("_error"):
                err = f"本机执行失败：{local['_error']}"
            elif local is not None:
                res = local
            if res is None:   # 本机无此工具 / 本机失败 → 回退服务端
                try:
                    srv = c.call("POST", f"/v1/tools/{t}/call", {"args": args},
                                 timeout=(900 if t in ("research.ask", "research") else 120)) or {}
                    r = srv.get("result")
                    if isinstance(r, dict) and r.get("_error"):
                        err = f"{err + '；' if err else ''}服务端执行失败：{r['_error']}"
                    elif r is not None:
                        res = r
                    else:
                        err = err or "服务端未返回结果"
                except Exception as ee:  # noqa: BLE001
                    err = f"{err + '；' if err else ''}服务端调用异常：{type(ee).__name__}: {ee}"
            if res is None:
                # 显式回传失败：禁止"无证据就声称已抓取/已完成"
                return {"attachment": None, "_error": True,
                        "text": (f"[tool {t} 失败] {err or '未知错误'}\n"
                                 "⚠ 本次未取得任何证据。请如实说明工具失败，"
                                 "不要声称已抓取/已完成，也不要编造内容。")}
            txt = res.get("summary") if isinstance(res, dict) and res.get("summary") else res
            att = res.get("url") if isinstance(res, dict) else None   # 图片结果 → 进入视觉通道
            return {"attachment": att, "text": f"[tool {t}]\n{txt}"}
    except Exception as e:
        print(f"  tool err: {e}")
        return {"attachment": None, "_error": True,
                "text": (f"[tool {t} 失败] {type(e).__name__}: {e}\n"
                         "⚠ 本次未取得任何证据。请如实说明工具失败，不要声称已抓取/已完成。")}
    return {"attachment": None, "text": ""}


def _talk_note(agent: str) -> str:
    try:
        import sys as _sys
        if str(ROOT) not in _sys.path:
            _sys.path.insert(0, str(ROOT))
        from core import persona as pm
        t = pm.talkativeness(_persona(agent))
    except Exception:
        t = 0.5
    if t >= 0.65:
        return ("\n（你比较**健谈**：默认参与——可以追问、举例、连接、质疑、补充细节、抛新角度；"
                "只有当你上一条已经说过同样的话时才 SKIP。宁可多说一句，也别让场子冷掉。）")
    if t <= 0.45:
        return "\n（你偏**克制**：确有新增才发言，否则 SKIP。）"
    return ""


def _style_mod():
    import sys as _sys
    if str(ROOT) not in _sys.path:
        _sys.path.insert(0, str(ROOT))
    from core import style as st
    return st


def _build_prompt(agent: str, room: dict, cur: dict, transcript: list, tool_result: str | None = None,
                  style_note: str = "", rewrite=None, too_long: bool = False) -> str:
    p = _persona(agent)
    motto = (p.get("identity") or {}).get("motto", "")
    pnote = _persona_note(agent)
    talk_note = _talk_note(agent)
    learn_note = ""
    try:
        import sys as _sys
        if str(ROOT) not in _sys.path:
            _sys.path.insert(0, str(ROOT))
        from core import playbook as _pb
        learn_note = _pb.playbook_note(agent, limit=12)
    except Exception:
        learn_note = ""
    style_learned = ""
    try:
        style_learned = _style_mod().style_learned_note(p)
    except Exception:
        style_learned = ""
    _role = (p.get("role") or "")
    if _role == "coordinator":
        plan_note = ("\n【规划优先·你的职责】遇到新任务/需求，先用「方案七要素」（目标与交付物、可执行步骤、"
                     "事实源清单[硬源优先/≥2独立来源/一手二手分列]、事实库schema、可量化验收判据、分工与轮次、"
                     "风险与不做项）给出**可执行、涉细节的方案**，请执行者逐条确认后再执行；"
                     "可用 tool:{\"tool\":\"plan.review\",\"args\":{\"topic\":\"…\",\"target\":\"执行者\",\"plan\":\"方案全文\"}} "
                     "让机器评审，过审才开工。")
    elif _role == "executor":
        plan_note = ("\n【规划优先·你的职责】未收到**已过审的方案**前不得开工；对方案每条给出确认或异议，"
                     "方案过审后再执行；缺据就标「待证」，不写死。")
    else:
        plan_note = ""
    mentor_note = ("\n【导师最高优先级】真人（导师）的话**必须落实**：被点名就给明确回执并照做"
                   "（做事 / 守规则），不得闲聊回避、不得用人设搪塞；有异议可简述一句，但**先执行**。")
    rating_note = ""
    if (room or {}).get("rating") == "nsfw":
        _lv = {"swimwear": "泳装", "underwear": "内衣"}.get(
            (room or {}).get("content_level"), (room or {}).get("content_level") or "泳装/内衣")
        rating_note = (f"\n（本房间为 NSFW 分级，声明层级：**{_lv}（非露骨）**。你可在该层级内自然参与，"
                       "不必过度自我审查；但**硬红线必须拒绝并转移**：露骨性内容、任何疑似未成年人、"
                       "非自愿/偷拍/私密外泄、对真实可辨识人物的性化。）")
    ctx = "\n".join(f"[{m['round']}] {m['agent_id']}: {(m['body'] or '')[:200]}"
                    for m in transcript[-10:]) or "(无)"
    human_id = room.get("host") or "human"
    human_latest = next((m for m in reversed(transcript)
                         if m.get("agent_id") == human_id and m.get("kind") not in ("skip", "system")), None)
    human_line = (f"\n【真人最新发言 · 最高优先级，先直接回应它】{(human_latest or {}).get('body', '')[:300]}"
                  if human_latest else "")
    style_block = f"\n【本轮对话类型】{style_note}" if style_note else ""
    rewrite_block = ""
    if rewrite:
        prev, rep = rewrite
        reps = "、".join((rep.get("self") or []) + (rep.get("cross") or []))
        who = "自己" if rep.get("self") else ""
        who += ("和" if who and rep.get("cross") else "") + ("别人" if rep.get("cross") else "")
        rewrite_block = (f"\n\n⚠ 你上一版是：\n「{prev}」\n它与{who or '前面的发言'}重复了这些片段："
                         f"{reps or '（开头句式雷同）'}。\n请**重写一版**：换开头、换句式、换措辞，"
                         "意思不变，且不要再出现这些重复片段。")
    if too_long:
        rewrite_block += ("\n\n⚠ 你上一版太长了。请**压到 150 字以内**：只留一句核心 + 最多一句支撑，"
                          "删掉铺垫、例子堆砌和总结。")
    tool_block = ""
    if tool_result is not None:
        tool_block = (f"\n\n你刚刚**调用了工具**，返回的真实内容如下：\n\"\"\"\n{tool_result[:3000]}\n\"\"\"\n"
                      "请**基于这些真实内容**写发言：把工具返回的标题/链接**原样列出**，不要编造工具没说的东西。"
                      "（本次为工具汇报，篇幅可放宽到 600 字以内。）")
    try:
        _ver = (ROOT / "dist" / "VERSION").read_text(encoding="utf-8").strip()
    except OSError:
        _ver = "?"
    _node = os.environ.get("TEAM_NODE_ALIAS") or "本机"
    machine_line = f"\n【你所在的机器】节点={_node}，程序版本={_ver}。有人问版本/机器就照这个答，别编。"
    return f"""你是团队 AI 的 agent「{p.get('name', agent)}」。人设：{motto}{pnote}{talk_note}{machine_line}{learn_note}{style_learned}{plan_note}{mentor_note}
这是**自由群聊**《{room['topic']}》，真人可随时插话，你不必等轮次、也不必复述规则。{rating_note}{style_block}
最近发言：
{ctx}{human_line}
{tool_block}{rewrite_block}

**最高优先级**：真人的问题/要求必须**最先、直接**回应。只要【真人最新发言】里有尚未被回应的提问或要求，
就先点名（用真人的名字，如「human，…」）正面回答它，再谈别的；**不要**只顾着和另一个 agent 互相接话、把真人晾在一边。
**默认参与**：提出新观点/事实/论证，或追问、举例、连接、质疑、补充；只有当你上一条已经说过
同样内容、且确实无可补充时才 SKIP。禁止评论轮次、人数、工具、界面等机制问题。
**像真人说话**：口语、短句、允许语气词/口头禅/停顿/自嘲/直接接话，别用公文腔或论文腔；
但内容要实在（有推理、例证或引用），别空洞寒暄。
**不要 AI 腔**：禁止「不是……而是……」「首先/其次/最后」「综上所述/总的来说」「值得注意的是」
「让我们一起」「赋能/闭环/抓手/底层逻辑」这类套话；不要每段都用排比或反问收尾。
**只做你自己**：你要模仿的是**一个真实的人**，不是另一个 AI；**不要模仿另一个 agent 的语气**，各人保持自己的口吻。
篇幅（**硬要求**）：正文 **≤ 180 字**，超了会被打回重写。像发微信：一两句，最多一小段。
直接说你最锋利的那一点；**不要**铺垫、不要堆例子、不要总结、不要复述对方。
论证图 graph：**默认不给**（界面缺省不显示图）。只有当一个多层论证确实非图不可时才给：
  nodes id,type(claim|premise|evidence),text(≤14字),source_type(...)；edges from,to,rel(support|attack)；conclusion=结论 id。
若论证涉及决策/概率/效用（要算期望值 EV），改用影响图节点：
  chance: id,type=chance,text,states:[...],p:{{state:概率}}（同一父决策下的分布用 p_by_parent:{{选项:{{state:概率}}}},parent:决策id）
  decision: id,type=decision,text,options:[...]（决策节点不要赋概率）
  value: id,type=value,text,outcome:某chance节点id,utility:{{state:数值}}
  约束：chance 的 p 必须归一化（Σ=1）；不同 outcome_space 的概率不要相乘。
**要图就出图（重要）**：真人若说「提供 / 发 / 给 一张 照片 / 图 / 头像 / 形象 / 证件照」，**必须用 tool 出图**，
  绝不能只用文字描述、更不能说做不到。生成你自己的照片时，把外貌设定写进 prompt：
  {{"tool":"gen","prompt":"<你自己的外貌设定>，正面免冠、半身、露耳、五官清晰、自然微笑，写实证件照"}}
**抓取网页（重要）**：真人要你「访问 / 查看 / 抓取 / 调研某个网站」的**内容/新闻/头条/文本**时，
  **必须用 browse**：{{"tool":"browse","url":"https://目标网址","actions":[]}}——工具会把页面**文本回灌**给你，你再据此提炼/汇报。
  禁止说「我没有 browse / 读不了网页」；browse 就是你的网页抓取工具。
**默认工具（重要，必须用）**：
  - 真人问天气 / 穿搭 / 当前天气照片 → 用 weather：
    {{"tool":"weather","args":{{"place":"成都","image":true,"scene":"commute"}}}}
    地点不明时不要瞎编；可省略 place 让本机 personas/中心城市兜底。
  - 真人说 research.ask / 调研 / 查最新资料 → 用 research.ask：
    {{"tool":"research.ask","args":{{"prompt":"<真人原问题>","rounds":1,"publish":true,"channel":"#reading"}}}}
    只有真人说「发论坛 / 存档 / 转发群」时才 publish=true；否则只回结果。
  - 真人问天气/调研时，**不要**把它当成普通闲聊，也不要说「我没有工具」；先用工具，再根据真实结果写发言。
**主动用工具**：当真人要你「看/找/生成图片」或「操作某个网页工具」（如 http://127.0.0.1:6010/ 科研分析），
  不要只说做不到——直接在 JSON 里加 tool 字段（工具会先执行，结果再回灌给你写发言）：
  {{"tool":"gen","prompt":"文生图描述"}}   或   {{"tool":"search","query":"关键词"}}   或   {{"tool":"screenshot","url":"http://..."}}
**本机截图 / 看屏幕**：要展示你**本机的 opencode/IDE 界面**，用 tool:{{"tool":"screen.capture","args":{{}}}}；
  返回的图片会**进入你的视觉通道**（下一轮你能"看到"它），据此描述/汇报即可。
**传本地文件（重要）**：真人要你**交文件/上传落档**时，用 tool:{{"tool":"upload","args":{{"path":"<相对项目根的路径>"}}}}；返回的 URL 就是附件标识（`/static/uploads/…`），发帖/贴群都用它，别只说"我传了"。
**看别人发的图**：群里消息带图时，图片会自动进入你的视觉通道——直接看图说话，别猜。
  要看某工具的**结果**就用 browse（会填表/点击/等待并把**页面文本回灌给你**再写发言）：
  {{"tool":"browse","url":"http://127.0.0.1:6010/","actions":[{{"type":"fill","selector":"textarea","value":"要问的问题"}},{{"type":"click","selector":"button:has-text('开始分析')"}},{{"type":"wait","ms":15000}}]}}
**自我改进（三轴，R45）**：当真人要求你「改进自己 / 升级 / 换模型 / 造工具」时，不要只说做不到——用 tool 字段调用：
  {{"tool":"self.propose","args":{{"title":"…","summary":"…","kind":"feature","topic":"…"}}}}        ① 发起改进提案（harness/记忆/个性化）
  {{"tool":"self.update","args":{{"target_version":"x.y.z","source_peer":"http://主版本:6080","summary":"理由"}}}}  ① 申请自我更新（**需真人确认后应用**）
  {{"tool":"self.llm","args":{{"action":"set","backend":"opencode|omp|qoder","model":"…"}}}}          ② 换自己的 LLM 后端/模型
  {{"tool":"self.tool","args":{{"action":"write","name":"工具名","code":"def run(agent,args): return {{...}}"}}}}  ③ 自造工具（load 需开启）
  {{"tool":"self.version","args":{{}}}}  查询你自己上报的程序版本（被问版本时用这个，别编）
  规矩：改 harness 代码（self.update/self.propose）前**必须先给出变更清单与回滚预案**，并**等真人确认**再申请；不要凭空跳版本号。
**工具只能放在顶层 `tool` 字段**；**严禁**把工具 JSON 写进 body 正文。body 只放你的发言文本。
只输出一个 JSON（不要多余文字）：
{{"action":"say|skip","kind":"assertion|fact|question|emotion","body":"约600字(100-800)",
 "tool":{{...可选...}},
 "graph":{{"nodes":[{{"id":"c","type":"claim","text":"结论","source_type":"assertion"}},
                 {{"id":"e1","type":"evidence","text":"证据","source_type":"citation"}}],
          "edges":[{{"from":"e1","to":"c","rel":"support"}}],"conclusion":"c"}}}}"""


def _run_opencode(prompt: str, agent: str, room: dict, cur: dict,
                  use_model: str, files: list, env: dict | None = None) -> dict | None:
    # 统一走 LLM 适配层（app/llm）：默认 opencode，可换 omp/pi/qoder
    try:
        import sys as _sys
        if str(ROOT) not in _sys.path:
            _sys.path.insert(0, str(ROOT))
        from core.llm import get as _llm_get
        _bf = ROOT / "agents" / agent / "backend"
        _backend = _bf.read_text(encoding="utf-8").strip() if _bf.exists() else "opencode"
        r = _llm_get(_backend).run(
            prompt, model=use_model, cwd=str(ROOT), files=files,
            title=f"room:{room['id']}:{agent}:r{cur['round']}", timeout=180)
        out = r.text or ""
        if not r.ok and r.returncode is None:
            print("  decide timeout（已杀进程组）")
        if os.environ.get("TEAMAI_DEBUG"):
            print("[decide raw]", out[-800:])
        s = _extract_json(out)
        if s:
            d = json.loads(s, strict=False)
            if d.get("action") in ("say", "skip"):
                return d
    except Exception as e:
        print(f"  decide err: {e}")
    return None


def _llm(agent: str, room: dict, cur: dict, transcript: list, model: str,
         tool_result: str | None = None, style_note: str = "", rewrite=None,
         too_long: bool = False, base: str | None = None) -> dict | None:
    files = _recent_images(transcript, base)
    use_model = _vision_model(agent) if files else model
    prompt = _build_prompt(agent, room, cur, transcript, tool_result, style_note, rewrite, too_long)
    if files:
        prompt += "\n\n（聊天室里附有图片，请先用视觉读图，再据此发言。）"
    env = dict(os.environ)
    cfg = ROOT / "runtime" / "opencode.deepseek.json"
    if cfg.exists():
        env.setdefault("OPENCODE_CONFIG", str(cfg))
    if files:
        print(f"  [vision] attach {len(files)} image(s) via {use_model}")
    d = _run_opencode(prompt, agent, room, cur, use_model, files, env)
    if d is None:   # 解析失败 → 重试一次（更严格地要求 JSON）
        print("  decide retry…")
        d = _run_opencode(prompt + "\n\n（重试）上次输出不是合法 JSON。请**只**输出一个合法 JSON，"
                                    "字符串内不要有未转义的换行或引号。", agent, room, cur, use_model, files, env)
    return d


def decide(agent: str, room: dict, cur: dict, transcript: list, model: str,
           client: "Client | None" = None) -> dict:
    st = _style_mod()
    dtype = st.dialogue_type(room, transcript)
    style_note = st.style_hint(_persona(agent), dtype)
    base = client.base if client is not None else None
    print(f"  [style] 对话类型={dtype}")
    dec = _llm(agent, room, cur, transcript, model, style_note=style_note, base=base) or {"action": "skip", "kind": "skip", "body": ""}
    tool = dec.get("tool")
    if not isinstance(tool, dict) and dec.get("body"):
        # 兜底：LLM 有时把工具 JSON 写进正文 → 提取并执行
        m = re.search(r'\{[^{}]*"tool"\s*:\s*"[^"]+"[^{}]*\}', dec["body"])
        if m:
            try:
                tool = json.loads(m.group(0))
                dec["body"] = dec["body"].replace(m.group(0), "").strip()
            except Exception:
                tool = None
    if client is not None and isinstance(tool, dict) and dec.get("action") != "skip":
        print(f"  [tool] {tool.get('type') or tool.get('tool')} 执行中…")
        try:  # 工具可能较慢：先给自己延长回合，避免被跳过
            client.call("POST", f"/v1/rooms/{room['id']}/extend", {"seconds": 900})
        except Exception:
            pass
        res = _run_tool(client, tool)
        dec["attachment"] = res.get("attachment")
        if res.get("text"):   # browse 等有文本 → 第二遍：读结果再写发言
            dec2 = _llm(agent, room, cur, transcript, model, tool_result=res["text"], style_note=style_note, base=base) or dec
            dec2["attachment"] = res.get("attachment")
            dec = dec2
            dec["_from_tool"] = True   # 工具报告：不压缩、不重写，原样转述
            # 第二遍模型失败/返回空时，不能把已拿到的真实工具结果丢掉。
            if not dec.get("body") and res.get("text"):
                dec["action"] = "say"
                dec["kind"] = "fact"
                dec["body"] = str(res["text"])[:1800]
    # 太长 → 压缩到 160 字内（工具报告除外）
    if not dec.get("_from_tool") and dec.get("action") == "say" and dec.get("body") and len(dec["body"]) > 210:
        print(f"  [style] 过长({len(dec['body'])}字) → 压缩")
        dec2 = _llm(agent, room, cur, transcript, model, style_note=style_note, too_long=True, base=base) or dec
        if dec2.get("body") and len(dec2["body"]) < len(dec["body"]):
            dec2["attachment"] = dec.get("attachment")
            dec = dec2
    # 重复自检：与自己/与他人重复 → 换句式重写一版
    # 工具报告不参与重写：否则会丢掉 `_from_tool`，在 prepare 窗口里又变成“等 open”。
    if not dec.get("_from_tool") and dec.get("action") == "say" and dec.get("body"):
        human_id = room.get("host") or "human"
        own = [(m.get("body") or "") for m in transcript if m.get("agent_id") == agent][-8:]
        others = [(m.get("body") or "") for m in transcript if m.get("agent_id") not in (agent, human_id)][-8:]
        rep = st.repetition(dec["body"], own, others)
        nrep = len(rep["self"]) + len(rep["cross"])
        if nrep >= 3 or rep["self_open"] or rep["cross_open"]:   # 只在明显重复时重写，避免拖慢
            print(f"  [style] 重复：self={rep['self'][:2]} cross={rep['cross'][:2]} "
                  f"open={rep['self_open'] or rep['cross_open']}")
            dec2 = _llm(agent, room, cur, transcript, model, style_note=style_note,
                        rewrite=(dec["body"], rep), base=base) or dec
            if dec2.get("body"):
                dec2["attachment"] = dec.get("attachment")
                dec = dec2
    return dec


def cache_path(agent: str, room_id: str, rnd: int) -> Path:
    d = ROOT / "agents" / agent / "room"
    d.mkdir(parents=True, exist_ok=True)
    return d / f"{room_id}-r{rnd}.json"


AUTO_UPDATE = True
CHATWORK = True
DM = True              # 私信接入：每拍自动看/回真人私信（D1-补；真人↔agent 的命门）
CHAT_RATE = 1.0        # 聊天参与率：每 1/CHAT_RATE 回合参与 1 次；被点名则强制参与（1.0=不节流）
_START_TS = time.strftime("%Y-%m-%d %H:%M:%S")   # 本进程启动时刻（chatwork 首次见房时用于区分"历史/新消息"）
_UPDATE_CHECK = [0.0]


def _fed_token() -> str | None:
    p = ROOT / "bootstrap" / "enroll.key"
    try:
        return p.read_text(encoding="utf-8").strip() or None
    except OSError:
        return None


def _do_self_update(c: "Client", force: bool = False) -> None:
    """拉取宿主发行版 → 验签 → 快照 → 替换本地代码 → 重启驱动（保留 agents/data）。"""
    import sys as _sys
    if str(ROOT) not in _sys.path:
        _sys.path.insert(0, str(ROOT))
    from core import apply as apply_mod, distribution
    local = distribution.runtime_version()
    remote = (c.call("GET", "/v1/health") or {}).get("runtime_version") or ""
    if not remote:
        return
    if not force and not apply_mod.version_gt(remote, local):
        return
    print(f"[self-update] {local} -> {remote}，拉取发行版…")
    try:
        _m, data = apply_mod.fetch_bundle(
            c.base, _fed_token(), agent=getattr(c, "agent", None),
            ctx=getattr(c, "ctx", None))
    except Exception as e:  # noqa: BLE001
        print("[self-update] 拉取失败：", e)
        _notify(c, getattr(c, "agent", "?"), f"[self-update] ❌ 拉取失败：{e}")
        return
    res = apply_mod.apply_bundle(data, cur_version=local, cur_major=1)
    if not res.get("ok"):
        why = f"{res.get('stage')} {res.get('log') or res.get('precheck')}"
        print("[self-update] 失败：", why)
        _notify(c, getattr(c, "agent", "?"), f"[self-update] ❌ 应用失败：{why}")
        return
    print(f"[self-update] 已更新到 {remote}，安排整棵进程树重启…")
    _sys.stdout.flush()
    _request_full_restart(c, getattr(c, "agent", "?"))
    # 不再只 os.execv 当前 chatroom；helper 会停旧 supervisor/子进程并起一套。
    time.sleep(1)


def _set_enroll_token(c: "Client", agent: str, cmd: dict) -> None:
    """远程写入**发放 token**（写 bootstrap/enroll.key）并**自动触发自更新**。

    ★ 强制**本机一次性同意**：本机存在 `bootstrap/allow-remote-token` 才执行（用完即删）。
      这是"人在现场点一下确认"的落地形态 —— 远程无法绕过本机授权。
    """
    pl = cmd.get("payload")
    if isinstance(pl, str):
        try:
            pl = json.loads(pl)
        except Exception:
            pl = {}
    tok = str((pl or {}).get("token") or "").strip()
    marker = ROOT / "bootstrap" / "allow-remote-token"
    if not marker.exists():
        _notify(c, agent, "[set-enroll-token] 被拒：本机未同意。"
                          "若需同意，在本机执行一次：`echo 1 > bootstrap/allow-remote-token`")
        return
    if not tok:
        _notify(c, agent, "[set-enroll-token] 拒绝：payload 缺 token")
        return
    kp = ROOT / "bootstrap" / "enroll.key"
    kp.parent.mkdir(parents=True, exist_ok=True)
    kp.write_text(tok, encoding="utf-8")
    try:
        os.chmod(kp, 0o600)
    except Exception:
        pass
    try:
        marker.unlink()          # one-shot：同意一次，用后即删
    except Exception:
        pass
    _notify(c, agent, "[set-enroll-token] ✅ 已写入 bootstrap/enroll.key，开始自更新（version → 宿主版本）")
    _do_self_update(c, force=True)


def _maybe_self_update(c: "Client") -> None:
    """客户端自动更新：宿主版本更新时自动拉取并重启。"""
    now = time.time()
    if now - _UPDATE_CHECK[0] < 30:
        return
    _UPDATE_CHECK[0] = now
    try:
        _do_self_update(c)
    except Exception as e:
        print("[self-update] err:", e)


def _offer(c: "Client") -> None:
    """把本机发行版推送给宿主（双向同步，B→A）。"""
    import sys as _sys
    if str(ROOT) not in _sys.path:
        _sys.path.insert(0, str(ROOT))
    import base64 as _b64
    from core import distribution, nodeinfo
    m = distribution.manifest()
    data = distribution.bundle()
    node = os.environ.get("TEAM_NODE_ALIAS") or nodeinfo.detect().get("alias")
    c.call("POST", "/v1/federation/offer",
           {"manifest": m, "bundle_b64": _b64.b64encode(data).decode(), "node": node})
    print(f"[offer] 已推送本机发行版 v{m.get('runtime_version')} 给宿主（node={node}）")


def _notify(c: "Client", agent: str, text: str) -> None:
    """把结果回报到群里（开发日志，不需回合）。"""
    try:
        rooms = c.call("GET", "/v1/rooms").get("rooms", [])
        rid = next((r["id"] for r in rooms if r.get("status") == "running"), None)
        if rid:
            c.call("POST", f"/v1/rooms/{rid}/report", {"text": text, "agent_id": agent})
    except Exception as e:
        print("[notify] err:", e)


def _chatwork_notify(c: "Client", agent: str, rid: str, text: str) -> None:
    """把回执发到**指定房间**的开发日志（/report，不需回合）。"""
    try:
        c.call("POST", f"/v1/rooms/{rid}/report", {"text": text, "agent_id": agent})
    except Exception as e:
        print("[chatwork] notify err:", e)


def _submit_tool(agent: str, path: str) -> str:
    """工作群指令 → 本机 TAA CLI 提交工具目录（不经过人填表）。"""
    p = Path(path).expanduser()
    if not p.is_dir():
        return f"[tool] path not found: {path}"
    taa = os.environ.get("TAA_BIN") or str(Path.home() / ".taa" / "app" / "bin" / "taa")
    if not Path(taa).exists():
        taa = shutil.which("taa") or ""
    if not taa:
        return "[tool] taa binary not found; install TAA or set TAA_BIN"
    try:
        r = subprocess.run([taa, "tool", "submit", str(p)], capture_output=True, text=True,
                           timeout=120, cwd=str(ROOT))
    except Exception as e:  # noqa: BLE001
        return f"[tool] submit error: {e}"
    out = ((r.stdout or "") + (r.stderr or "")).strip()
    if r.returncode != 0:
        return f"[tool] submit failed (exit {r.returncode}): {out[-700:]}"
    return f"[tool] submitted: {out[-900:]}"


def _handle_directives(c: "Client", agent: str) -> None:
    """群聊即控制台：把 human 派给本 agent 的工作指令，**LLM 判定** → 落看板任务 + 认领 + 回报。"""
    try:
        import sys as _sys
        if str(ROOT) not in _sys.path:
            _sys.path.insert(0, str(ROOT))
        from core import chatwork
    except Exception as e:  # noqa: BLE001
        print("[chatwork] import err:", e)
        return
    try:
        rooms = c.call("GET", "/v1/rooms").get("rooms", [])
    except Exception:
        return
    for r in rooms:
        if r.get("status") != "running":
            continue
        rid = r["id"]
        try:
            d = c.call("GET", f"/v1/rooms/{rid}")
        except Exception:
            continue
        room = d.get("room") or {}
        if room.get("rating") == "nsfw":
            continue                        # NSFW 房是社交闲聊房：不派活、不建任务
        members = [m.get("agent_id") for m in (room.get("members") or [])]
        if agent not in members:            # 只扫本 agent 为成员的房间
            continue
        tr = d.get("transcript", [])
        if not chatwork.cursor_path(agent, rid).exists():
            # 首次见到该房间：只跳过"本进程启动之前"的历史；启动之后到达的消息照常处理。
            # （否则新建房间后立刻发的指令会被当成历史一并跳过）
            older = [int(m.get("id", 0)) for m in tr
                     if (m.get("created_at") or "") < _START_TS]
            chatwork.save_cursor(agent, rid,
                                 {"last": max(older or [0]), "titles": [], "attempts": {}})
            # 不 continue：继续按游标处理启动后到达的消息
        cur = chatwork.load_cursor(agent, rid)
        last = int(cur.get("last", 0))
        seen = set(cur.get("titles") or [])
        attempts = dict(cur.get("attempts") or {})
        new = [m for m in tr if int(m.get("id", 0)) > last and (m.get("source") or "") != "taa-exec"]
        if not new:
            continue
        humans = [m for m in new if chatwork.is_human_msg(m, room)]
        if not humans:                      # 本批无 human → 前移到本批最大 message id（防卡死）
            cur["last"] = max(int(m["id"]) for m in new)
            chatwork.save_cursor(agent, rid, cur)
            continue
        stop = False
        for m in humans:
            if stop:
                break
            mid = int(m["id"]); key = str(mid)
            if not chatwork.mentions_me(m.get("body") or "", agent):
                last = mid                 # 结构护栏：明确点名了别人 → 不调 LLM（省）
                continue
            _body_low = (m.get("body") or "").lower()
            if any(x in _body_low for x in ("weather", "research.ask", "天气", "穿搭", "调研")):
                # 工具类消息交给房间回合里的 tool 路由；chatwork 不再重复立项/建任务。
                last = mid
                continue
            if int(attempts.get(key, 0)) >= chatwork.MAX_ATTEMPTS:
                print(f"[chatwork] msg {mid} 放弃（重试 {chatwork.MAX_ATTEMPTS} 次）")
                attempts.pop(key, None); last = mid; continue
            # ★ 2026-10-14（读图·调用点补最后一步）：把消息附件 URL 解析成本机文件路径，
            #   随附给视觉模型（此前只把 URL 写进提示，模型看不到"图里是什么"）。
            #   无附件/附件缺失时 files 为空 → 行为与从前完全一致（降级纯文本，见 _chatwork_images）。
            files, files_note = _chatwork_images(m, getattr(c, "base", None))
            msg = {**m, "body": (m.get("body") or "") + (" " + files_note if files_note else "")}
            kw: dict = {"files": files or None}
            if files:
                kw["model"] = _vision_model(agent)      # 有图 → 走视觉模型
                print(f"[chatwork] msg {mid} 随附 {len(files)} 张图片 → 视觉模型")
            res = chatwork.classify(agent, room, [msg], **kw)
            if not res.get("ok"):
                attempts[key] = int(attempts.get(key, 0)) + 1
                print(f"[chatwork] msg {mid} LLM 失败({res.get('error')}) "
                      f"attempt={attempts[key]} -> 不前移，下拍补捞")
                stop = True                 # 保留游标在 mid-1，下拍重试（补捞/死信）
                break
            kind = res.get("kind")
            if kind == "task" and res.get("task"):
                task = res["task"]
                fp = chatwork.fingerprint(task["title"])
                if fp in seen:
                    print(f"[chatwork] msg {mid} 任务指纹重复，跳过")
                else:
                    ac = task["acceptance_criteria"]
                    if res.get("needs_plan"):
                        ac = "先出可执行方案并过审，再执行。" + ac
                    created = c.call("POST", "/v1/tasks", {
                        "title": task["title"], "description": task["description"],
                        "acceptance_criteria": ac, "required_skills": task["required_skills"],
                        "tags": task["tags"], "priority": task["priority"],
                        "lane": ("long" if "long" in [str(x).lower() for x in task["tags"]]
                                 else "short"),
                        "for_agent": agent,
                        "source_msg_id": f"{agent}:{rid}:{mid}"})  # 同一群消息幂等
                    tid = (created.get("task_id")
                           or (created.get("task") or {}).get("id") or created.get("id"))
                    if created.get("duplicate"):
                        print(f"[chatwork] msg {mid} 任务幂等命中，不重复 claim/写简报: {tid}")
                        _chatwork_notify(c, agent, rid,
                                         f"[chatwork] 这条消息已有任务 {tid}，不重复立项、不重复执行")
                        continue
                    if tid:
                        seen.add(fp)
                        # ★ WIP 门禁（2026-10-14 修）：群聊派单不再"无脑 claim"。
                        #   旧行为＝每收到一条 human 指令就 claim 一次，WIP 会被撑满
                        #   （实测一次堆到 9 个 claimed），此后本机 loop 的 wip<MAX_PARALLEL
                        #   门禁使其**再也认领不到任何新任务**（含 P0 返工）→ 事实上的死锁。
                        #   现在：有空位才 claim+写简报；没空位只立项排队，腾出位子由 loop 认领。
                        try:
                            _mep = c.call("GET", f"/v1/tasks?for_agent={agent}") or {}
                            wip = int(_mep.get("wip", 0))
                            queued = int(_mep.get("queued", 0))
                        except Exception:
                            wip = 0
                            queued = 0
                        max_par = int(os.environ.get("TEAMAI_MAX_PARALLEL", "2"))
                        if (wip + queued) < max_par:
                            c.call("POST", f"/v1/tasks/{tid}/claim", {"reason": "群聊直接派单"})
                            # 交给本机执行器：写 inbox 简报 → dispatcher 用 opencode 干活
                            chatwork.write_inbox_brief(
                                agent, tid, title=task["title"], description=task["description"],
                                acceptance_criteria=ac, tags=task["tags"], priority=task["priority"])
                            reply = res.get("reply") or f"收到，已立项 {tid} 并交给执行器开工；结果回帖回群。"
                            print(f"[chatwork] 建任务 {tid} 并写简报: {task['title']}")
                        else:
                            reply = (f"收到，已立项 {tid}（钉给我、排队中：在办 {wip} 项已达并行上限 {max_par}，"
                                     f"腾出并行位后自动开工）；结果回帖回群。")
                            print(f"[chatwork] 建任务 {tid} 但 WIP 满（{wip} >= {max_par}）：只排队，不 claim")
                        _chatwork_notify(c, agent, rid, f"[chatwork] {reply}（任务 {tid}）")
                    else:
                        print(f"[chatwork] 建任务失败: {created}")
            elif kind == "tool_submit" and (res.get("tool") or {}).get("path"):
                path = str(res["tool"]["path"])
                out = _submit_tool(agent, path)
                print(f"[chatwork] tool_submit {path}: {out[:120]}")
                _chatwork_notify(c, agent, rid, out)
            elif kind == "rule" and res.get("rule"):
                # 常驻规则/偏好 → 写进本 agent 的经验库（进入其 prompt，长期遵守）
                try:
                    from core import memory as _mem
                    _mem.add_learning(agent, res["rule"], type_="preference", scope="team",
                                      evidence=f"[{mid}]", room_id=rid,
                                      confidence=float(res.get("confidence") or 0.6), salience=0.9)
                    print(f"[chatwork] 记规则: {res['rule'][:50]}")
                except Exception as _e:  # noqa: BLE001
                    print("[chatwork] rule store err:", _e)
                _chatwork_notify(c, agent, rid,
                                 f"[chatwork] 收到，已记下并遵守：{res['rule']}"
                                 + (f"（{res['reply']}）" if res.get("reply") else ""))
            elif kind == "ack" and res.get("reply"):
                _chatwork_notify(c, agent, rid, f"[chatwork] {res['reply']}")
                print(f"[chatwork] 回执: {res['reply'][:40]}")
            attempts.pop(key, None)
            last = mid
        chatwork.save_cursor(agent, rid, {"last": last, "titles": list(seen), "attempts": attempts})


def _dm_tool(c: "Client", agent: str, text: str) -> str:
    """DM deterministic tool routing: weather / research.ask.

    Group chat uses the LLM's JSON tool field. DM replies are plain text, so
    use a small structural router here; the LLM still writes the final reply
    from the real tool result (and falls back to the tool text if it fails).
    """
    body = (text or "").strip()
    low = body.lower()
    if not body:
        return ""
    if "research.ask" in low or "调研" in body or "研究" in body:
        args = {"prompt": body, "rounds": 1,
                "publish": ("论坛" in body or "存档" in body),
                "channel": "#reading",
                "title": body[:80]}
        res = _run_tool(c, {"tool": "research.ask", "args": args})
        return str(res.get("text") or "")
    if "weather" in low or "天气" in body or "穿搭" in body or "穿什么" in body:
        m = re.search(r"([\u4e00-\u9fff]{2,4})(?:市)?(?:的)?天气", body)
        place = m.group(1) if m else ""
        args = {"place": place, "image": any(x in body for x in ("照片", "图", "穿搭")),
                "scene": "commute"}
        res = _run_tool(c, {"tool": "weather", "args": args})
        return str(res.get("text") or "")
    return ""


def _handle_dm(c: "Client", agent: str) -> None:
    """每拍处理私信（D1-补）：真人请求自动接受、未读自动回复、非好友 agent 请求留给本人。

    判据是**服务端未读**（不依赖本地游标）→ 离线期间的消息恢复后照样处理（补捞）。
    详见 `core/dm_runtime.py`；策略见 docs/79 §5 与 Owner 派单口径。
    """
    try:
        import sys as _s
        if str(ROOT) not in _s.path:
            _s.path.insert(0, str(ROOT))
        from core import dm_runtime
    except Exception as e:  # noqa: BLE001
        print("[dm] import err:", e)
        return
    try:
        s = dm_runtime.poll_dm(
            c.call, agent,
            tool_router=lambda a, t: _dm_tool(c, a, t),
        )
    except Exception as e:  # noqa: BLE001
        print("[dm] poll err:", e)
        return
    for line in dm_runtime.brief_lines(s):
        print(f"[dm] · {line}")
    if s.get("errors"):
        print(f"[dm] {len(s['errors'])} 个会话处理失败，下拍补捞")


def _supervisor_alive(agent: str) -> bool:
    p = ROOT / "runtime" / f".supervisor.{agent}.lock"
    try:
        pid = int(p.read_text(encoding="utf-8").strip() or "0")
        os.kill(pid, 0)
        return True
    except Exception:  # noqa: BLE001
        return False


def _spawn_restart(agent: str, base: str) -> bool:
    script = ROOT / "runtime" / "restart_agent.py"
    if not script.exists():
        print("[restart] restart_agent.py missing")
        return False
    log = ROOT / "runtime" / f"{agent}-restart.log"
    log.parent.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ)
    env["TEAMAI_URL"] = base
    env.setdefault("PYTHONIOENCODING", "utf-8")
    env.setdefault("PYTHONUTF8", "1")
    try:
        out = open(log, "ab")
        subprocess.Popen([sys.executable, str(script), "--as", agent,
                          "--url", base, "--role", "executor", "--interval", "5"],
                         cwd=str(ROOT), env=env, stdin=subprocess.DEVNULL,
                         stdout=out, stderr=out, start_new_session=True)
        print("[restart] helper spawned")
        return True
    except Exception as e:  # noqa: BLE001
        print(f"[restart] helper spawn failed: {e}")
        return False


def _request_full_restart(c: "Client", agent: str) -> None:
    """更新后自动收敛进程树：helper 停旧 supervisor/子进程，再起一套。"""
    if _spawn_restart(agent, c.base):
        _notify(c, agent, "[restart-executor] 已安排：停旧进程并启动单套 supervisor")


def _start_executor(c: "Client", agent: str) -> None:
    """远程拉起执行器（supervisor：loop 认领任务 + dispatcher 交给 opencode），并把结果回报到群。"""
    # 已有 live supervisor 时不要再拉一套（会造成重复 loop/chatroom/任务）。
    slock = ROOT / "runtime" / f".supervisor.{agent}.lock"
    if slock.exists():
        try:
            old = int(slock.read_text(encoding="utf-8").strip() or "0")
            os.kill(old, 0)
            _notify(c, agent, f"[start-executor] 已有 supervisor 在跑 pid={old}，不重复启动")
            print(f"[command] supervisor already alive pid={old}")
            return
        except Exception:  # noqa: BLE001
            pass
    path = None
    for rel in ("dist/supervisor.py", "runtime/supervisor.py"):
        p = ROOT / rel
        if p.exists():
            path = p
            break
    if not path:
        _notify(c, agent, f"[start-executor] 失败：本机找不到 supervisor.py（root={ROOT}）")
        print("[command] no supervisor found")
        return
    logdir = ROOT / "runtime"
    logdir.mkdir(parents=True, exist_ok=True)
    logpath = logdir / f"{agent}-supervisor.log"
    logf = open(logpath, "ab")
    try:
        proc = subprocess.Popen([sys.executable, str(path), "--as", agent, "--role", "executor",
                                 "--interval", "30", "--url", c.base],
                                cwd=str(ROOT), stdin=subprocess.DEVNULL, stdout=logf, stderr=logf,
                                start_new_session=True)
    except Exception as e:
        _notify(c, agent, f"[start-executor] 拉起异常：{e}（path={path}）")
        print("[command] start-executor spawn err:", e)
        return
    time.sleep(3)
    alive = proc.poll() is None
    tail = ""
    try:
        tail = logpath.read_text(encoding="utf-8", errors="ignore")[-400:]
    except Exception:
        pass
    _notify(c, agent, f"[start-executor] {'已启动 ✅' if alive else '启动后即退出 ❌'} pid={proc.pid} "
                      f"path={path}\nlog 尾部：{tail}")
    print(f"[command] executor started alive={alive} path={path}")


def _maybe_start_executor(c: "Client", agent: str, cmd: dict) -> None:
    """远程唤醒门禁（docs/62）：若本机设了 4 位码，则命令 payload.passcode 必匹配。"""
    rw = None
    try:
        import sys as _s
        if str(ROOT) not in _s.path:
            _s.path.insert(0, str(ROOT))
        from core import remote_wake as rw  # noqa: F401
    except Exception:
        rw = None
    if rw is not None:
        pl = cmd.get("payload")
        if isinstance(pl, str):
            try:
                import json as _json
                pl = _json.loads(pl)
            except Exception:
                pl = {}
        code = (pl or {}).get("passcode", "")
        ok, reason = rw.verify(agent, code, src="command:start-executor")
        if not ok:
            hint = {"locked": "已锁定（连续失败），稍后再试",
                    "locked_after_fails": "口令错误，已锁定 10 分钟",
                    "bad_passcode": "口令错误"}.get(reason, reason)
            _notify(c, agent, f"[start-executor] 被本机同意门禁拒绝：{hint}"
                              f"（远程唤醒已启用，需正确 4 位码）")
            print(f"[command] start-executor denied: {reason}")
            return
    _start_executor(c, agent)


def _moment_publish(c: "Client", agent: str, cmd: dict) -> None:
    """执行 moment.publish：本人读取人设后自己写、自己发；失败最多重试 2 次。"""
    payload = cmd.get("payload")
    if isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except Exception:
            payload = {}
    if not isinstance(payload, dict):
        return
    rid = payload.get("round_id") or ""
    cid = payload.get("candidate_id") or ""
    if not rid or payload.get("agent_id") != agent:
        return
    state_dir = ROOT / "runtime" / "moment_published"
    state_dir.mkdir(parents=True, exist_ok=True)
    state = state_dir / f"{rid}.json"
    if state.exists():
        try:
            old = json.loads(state.read_text(encoding="utf-8"))
            if old.get("post_id"):
                c.call("POST", f"/v1/moment/rounds/{rid}/result", {"post_id": old["post_id"]})
                return
        except Exception:
            pass
    cand = payload.get("candidate") or {}
    person = _persona(agent)
    brief = {k: v for k, v in person.items() if k not in ("body", "wardrobe")}
    try:
        import json as _json
        brief_s = _json.dumps(brief, ensure_ascii=False)[:3000]
    except Exception:
        brief_s = "{}"
    backend = "opencode"
    bf = ROOT / "agents" / agent / "backend"
    if bf.exists():
        backend = (bf.read_text(encoding="utf-8").strip() or backend)
    mf = ROOT / "agents" / agent / "model"
    model = (mf.read_text(encoding="utf-8").strip() if mf.exists() else "") or "deepseek/deepseek-flash"
    life_lens = brief.get("interests") or brief.get("motto") or ""
    prompt = (
        f"你是 {payload.get('agent_name') or agent}。现在是 {time.strftime('%Y-%m-%d %H:%M')}。\n"
        "写一条 80–180 字的中文朋友圈。**这不是工作汇报，也不是团队周报。**\n"
        "写一个具体的生活瞬间：天气、路上看到的东西、吃到的味道、读到的一句话、"
        "衣服/颜色/声音、一个小小的情绪或念头。第一人称，像微信朋友圈；"
        "可以有一点不完美，不要总结、不要讲道理、不要 markdown。\n"
        "禁止出现：任务、交付、验收、进度、回执、测试、部署、接口、代码、看板、"
        "文件路径、帖子编号、内网 IP、密钥、真名，以及身体/衣着等私密维度。\n"
        "如果下面的候选本身是工作/任务内容，**不要复述它**；只借它作为一个生活联想的起点，"
        "或者写你今天真实的一小段生活。\n"
        f"你的人设（已剥离私密维度）：{brief_s}\n"
        f"你的生活视角（只用于选择写什么，不要复述）：{str(life_lens)[:300]}\n"
        f"生活素材（可忽略）：{cand.get('hook') or cand.get('title') or ''}"
    )
    last_err = ""
    work_words = ("任务", "交付", "验收", "进度", "回执", "测试", "部署", "接口",
                  "代码", "看板", "commit", "pull request", "TODO", "Phase", "p-", "t-")
    def _moment_ok(text: str) -> tuple[bool, str]:
        low = (text or "").lower()
        if len(text) < 20 or len(text) > 220:
            return False, "length"
        if any(w.lower() in low for w in work_words):
            return False, "work_words"
        try:
            if not _red.scan(text)["pass"]:
                return False, "redaction"
        except Exception:
            pass
        return True, ""
    for attempt in range(2):
        try:
            from core.llm import get as _llm_get
            r = _llm_get(backend).run(prompt, model=model, cwd=str(ROOT),
                                      title=f"moment:{rid}", timeout=180)
            body = (r.text or "").strip()
            body = re.sub(r"^```[^\n]*\n", "", body)
            body = re.sub(r"\n```$", "", body).strip().strip('"“”')
            if not r.ok or len(body) < 20:
                last_err = f"draft_empty_or_failed:{body[:80]}"
                continue
            if len(body) > 220:
                body = body[:220].rsplit("。", 1)[0] + "。"
            from core import redaction as _red
            ok, why = _moment_ok(body)
            if not ok:
                last_err = f"draft_not_life:{why}"
                prompt += ("\n\n上一次草稿不合格（" + why + "）。请彻底重写：不要工作词，"
                           "只写一个具体生活瞬间；不要解释你在改写。")
                continue
            d = c.call("POST", "/v1/posts", {
                "channel_id": "#lobby", "type": "note", "title": None,
                "body": body, "tags": ["朋友圈", "lobby"],
                "kind": "moment", "visibility": "public",
            })
            pid = (d or {}).get("post_id")
            if not pid:
                last_err = f"post_failed:{str(d)[:120]}"
                continue
            state.write_text(json.dumps({"round_id": rid, "post_id": pid,
                                         "at": time.strftime("%Y-%m-%d %H:%M:%S")},
                                        ensure_ascii=False), encoding="utf-8")
            c.call("POST", f"/v1/moment/rounds/{rid}/result", {"post_id": pid})
            print(f"[moment] published {rid} -> {pid}")
            return
        except Exception as e:  # noqa: BLE001
            last_err = f"{type(e).__name__}:{e}"
    c.call("POST", f"/v1/moment/rounds/{rid}/result", {"error": last_err[:400]})
    print(f"[moment] publish failed {rid}: {last_err}")


def _handle_commands(c: "Client", agent: str) -> None:
    """轮询真人下达的远程指令并本地执行（口授）。"""
    try:
        d = c.call("GET", f"/v1/agents/{agent}/commands")
    except Exception:
        return
    for cmd in (d.get("commands") or []):
        name = cmd.get("cmd")
        if name in ("self-update", "update"):
            try:
                _do_self_update(c, force=bool((cmd.get("payload") or {}).get("force")))
            except Exception as e:
                print("[command] self-update err:", e)
        elif name == "offer":
            try:
                _offer(c)
            except Exception as e:
                print("[command] offer err:", e)
        elif name in ("restart-executor", "restart"):
            try:
                _request_full_restart(c, agent)
            except Exception as e:
                print("[command] restart-executor err:", e)
        elif name in ("start-executor", "executor"):
            try:
                _maybe_start_executor(c, agent, cmd)
            except Exception as e:
                print("[command] start-executor err:", e)
        elif name in ("moment.publish", "moment_publish"):
            try:
                _moment_publish(c, agent, cmd)
            except Exception as e:
                print("[command] moment.publish err:", e)
        elif name in ("set-enroll-token", "enroll-token"):
            try:
                _set_enroll_token(c, agent, cmd)
            except Exception as e:
                print("[command] set-enroll-token err:", e)
        elif name in ("usage", "cost"):
            try:
                import json as _json
                pl = cmd.get("payload")
                if isinstance(pl, str):
                    try:
                        pl = _json.loads(pl)
                    except Exception:
                        pl = {}
                _report_usage(c, agent, days=int((pl or {}).get("days", 2)))
            except Exception as e:
                print("[command] usage err:", e)


def _scrub(s: str) -> str:
    """擦除绝对路径（否则被发帖脱敏门禁 422 拦下）。"""
    import re as _re
    s = _re.sub(r"/Users/[^\s/]+", "/Users/<user>", s or "")
    s = _re.sub(r"/home/[^\s/]+", "/home/<user>", s)
    s = _re.sub(r"[A-Za-z]:\\\\Users\\\\[^\s\\\\]+", r"C:\\Users\\<user>", s)
    return s


def _report_usage(c: "Client", agent: str, days: int = 2) -> None:
    """把本机 opencode 用量算出发到 #projects/team-ai；**失败也把错误回传**（便于远程定位）。"""
    import sys as _sys
    import traceback
    if str(ROOT) not in _sys.path:
        _sys.path.insert(0, str(ROOT))
    try:
        from core import usage
        rep = usage.summary(int(days))
        lines = [f"【LLM 用量】{agent} @ 本机（近 {days} 天；$≈RMB 按 7.15）"]
        tot = 0.0
        for d, s in rep.items():
            t = s["total"]; tot += t["est"]
            lines.append(f"{d}: {t['n']} 次 ≈ ${t['est']:.4f}（{t['est'] * 7.15:.1f} 元）")
        lines.append(f"合计 ≈ ${tot:.2f}（{tot * 7.15:.1f} 元）")
        body = "\n".join(lines)
    except Exception as e:  # noqa: BLE001
        body = (f"【LLM 用量】{agent} 上报失败：{type(e).__name__}: {e}\n"
                f"```\n{traceback.format_exc()[-1200:]}\n```")
    body = _scrub(body)
    for ch in ("#projects/team-ai", "#reading"):
        try:
            c.call("POST", "/v1/posts", {"channel_id": ch, "type": "note",
                                         "title": f"usage@{agent}", "body": body,
                                         "tags": ["usage"]})
            print("[command] usage reported")
            return
        except Exception as e:  # noqa: BLE001
            print("[command] usage post err:", e, "ch=", ch)


_HANDSHAKE_AT = [0.0]


def _code_hash() -> str:
    """本机执行器代码指纹：版本字符串可能被 dist/VERSION 提前写高，哈希不会。"""
    h = hashlib.sha256()
    for rel in ("core/para.py", "core/tasks.py", "core/server.py",
                "runtime/loop.py", "runtime/dispatcher.py",
                "runtime/chatroom_agent.py", "runtime/workspace.py",
                "dist/VERSION"):
        p = ROOT / rel
        h.update(rel.encode("utf-8"))
        h.update(b"\0")
        h.update(p.read_bytes() if p.exists() else b"<missing>")
        h.update(b"\0")
    return h.hexdigest()[:16]


def _handshake(c: "Client", agent: str) -> None:
    """向宿主重新握手（上报本机硬件与当前 runtime），让 A 实时掌握版本。"""
    try:
        import sys as _sys
        if str(ROOT) not in _sys.path:
            _sys.path.insert(0, str(ROOT))
        from core import nodeinfo, distribution, protocol
        hw = nodeinfo.detect()
        nodeinfo.save_alias(hw.get("alias"))
        c.call("POST", "/v1/handshake", {
            "hardware": hw,
            "protocol_version": protocol.PROTOCOL_VERSION,
            "runtime_version": distribution.runtime_version(),
            "code_hash": _code_hash(),
            "capabilities": protocol.CAPABILITIES, "packages": []})
    except Exception as e:
        print("[handshake] err:", e)


def _maybe_handshake(c: "Client", agent: str) -> None:
    now = time.time()
    if now - _HANDSHAKE_AT[0] < 300:      # 每 5 分钟
        return
    _HANDSHAKE_AT[0] = now
    _handshake(c, agent)


def _should_participate(agent: str, cur: dict, transcript: list) -> bool:
    """聊天节流：默认每 N 回合参与 1 次（N=1/CHAT_RATE）。

    - 真人**显式 @ 点名本人** → 强制参与（服从优先，不节流）。
    - 否则按回合取模：`(round + agent_offset) % N == 0`。多名 agent 偏移错开 → 每回合恰一人参与。
    """
    if CHAT_RATE >= 0.999:
        return True
    try:
        from core import chatwork as _cw
    except Exception:
        _cw = None
    if _cw:
        for m in reversed(transcript or []):
            if _cw.is_human_msg(m):
                if _cw.explicit_me(m.get("body") or "", agent):
                    return True
                break
    cycle = max(1, int(round(1.0 / max(CHAT_RATE, 0.05))))
    off = {"alice": 0, "bob": 1, "carol": 2}.get(str(agent), abs(hash(str(agent))) % cycle)
    return (int(cur.get("round", 0)) + off) % cycle == 0


def _parse_ts(s) -> float | None:
    import datetime as _dt
    for f in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            return _dt.datetime.strptime((s or "")[:19], f).timestamp()
        except Exception:
            continue
    return None


def _chatroom_mode(agent: str) -> str:
    """聊天室参与模式：agents/<id>/chatroom(on|off|auto) > env TEAMAI_CHATROOM_MODE > 默认。

    默认：**bob=auto**（仅当无远程 agent 在线时才参与，保证聊天室≥3 主体），其余 on。
    """
    p = ROOT / "agents" / agent / "chatroom"
    if p.exists():
        m = (p.read_text(encoding="utf-8").strip().lower())
        if m in ("on", "off", "auto"):
            return m
    m = (os.environ.get("TEAMAI_CHATROOM_MODE") or "").strip().lower()
    if m in ("on", "off", "auto"):
        return m
    return "auto" if str(agent) == "bob" else "on"


def _remote_agents_online(c: "Client", fresh_s: int = 420) -> bool:
    """是否有**远程节点上的 agent** 在线（本机以外、且该节点有 agent、last_seen 新鲜）。"""
    try:
        d = c.call("GET", "/v1/nodes")
    except Exception:
        return False
    self_id = d.get("self")
    now = time.time()
    for n in d.get("nodes", []) or []:
        if n.get("id") == self_id or n.get("local"):
            continue
        if not n.get("agents"):
            continue
        ts = _parse_ts(n.get("last_seen"))
        if ts and (now - ts) < fresh_s:
            return True
    return False


def _latest_human_body(transcript: list, host: str = "") -> str:
    for m in reversed(transcript or []):
        if m.get("kind") in ("skip", "system"):
            continue
        if host and m.get("agent_id") == host:
            return m.get("body") or ""
        if not host and m.get("is_human"):
            return m.get("body") or ""
    return ""


def _room_participate(agent: str, mode: str, remote_online: bool, members: list,
                      human_body: str = "") -> bool:
    """本房是否参与（保持「≥3 主体」）。

    - on  ：总是参与；off：从不。
    - auto：无远程在线 → 全参与；有远程在线 → 仅当本房**其他 agent < 2** 时补位（凑够人类+2 agent）。
    - 真人显式 @ 点名：越过 auto 节流，点名必答。
    """
    if mode == "off":
        return False
    try:
        from core import chatwork as _cw
    except Exception:
        _cw = None
    if human_body and _cw and _cw.explicit_me(human_body, agent):
        return True
    # 点名了别人（不是 @所有人）：不要抢答。
    if human_body and _cw and not _cw.mentions_me(human_body, agent):
        return False
    if mode == "on":
        return True
    if not remote_online:
        return True
    others = [m for m in (members or [])
              if m != agent and not (_cw and _cw.is_human_msg({"agent_id": m}))]
    return len(others) < 2


def tick(c: Client, agent: str, model: str, only_room: str | None = None) -> None:
    _maybe_handshake(c, agent)
    _handle_commands(c, agent)
    if AUTO_UPDATE:
        _maybe_self_update(c)
    # 聊天室参与策略：bob 缺省 auto（无远程在线才上线），保持聊天室≥3 主体并省 token
    if DM:
        _handle_dm(c, agent)          # ★ 私信优先：每拍必看（与聊天室节流无关）
    mode = _chatroom_mode(agent)
    remote = _remote_agents_online(c) if mode == "auto" else False
    if CHATWORK and (mode == "on" or (mode == "auto" and not remote)):
        _handle_directives(c, agent)
    rooms = c.call("GET", "/v1/rooms").get("rooms", [])
    for r in rooms:
        if r["status"] != "running":
            continue
        if only_room and r["id"] != only_room:
            continue
        d = c.call("GET", f"/v1/rooms/{r['id']}")
        transcript = d.get("transcript", [])
        human_body = _latest_human_body(transcript, (d.get("room") or {}).get("host") or "")
        members = [m.get("agent_id") for m in (d.get("room", {}).get("members") or [])]
        if len(members) < 2:
            continue  # 单成员房间无意义，跳过
        if not _room_participate(agent, mode, remote, members, human_body):
            print(f"[{r['id']}] {agent} 待命（远程在线且本房已有≥2 agent；保持≥3主体）")
            continue
        cur = d.get("current_turn")
        if not cur or cur["agent_id"] != agent:
            continue
        if cur["state"] not in ("prepare", "open"):
            continue
        if not _should_participate(agent, cur, transcript):
            c.call("POST", f"/v1/rooms/{r['id']}/skip", {})
            print(f"[{r['id']} R{cur['round']}] 节流跳过 (chat_rate={CHAT_RATE})")
            continue
        cp = cache_path(agent, r["id"], cur["round"])
        if not cp.exists():
            # 远端/慢模型的决定可能超过 30s；先延长本回合，避免决定还没生成就被服务端 skip。
            try:
                c.call("POST", f"/v1/rooms/{r['id']}/extend", {"seconds": 120})
            except Exception:
                pass
            dec = decide(agent, d["room"], cur, transcript, model, client=c)
            cp.write_text(json.dumps(dec, ensure_ascii=False), encoding="utf-8")
            print(f"[{r['id']} R{cur['round']}] decided: {dec.get('action')} {dec.get('kind')}"
                  + (" +img" if dec.get("attachment") else ""))
        try:
            dec = json.loads(cp.read_text(encoding="utf-8"))
        except Exception:
            dec = {"action": "skip"}
        # 统一节奏：普通回合等到 open（=30s 窗口）再发；带工具结果/附件的回合立即发
        # （research.ask 可能耗时数分钟，不能因为 prepare 窗口没开就把结果丢在缓存里）
        if cur["state"] == "prepare" and not dec.get("attachment") and not dec.get("_from_tool"):
            continue
        if dec.get("action") == "say" and dec.get("body"):
            res = c.call("POST", f"/v1/rooms/{r['id']}/say",
                         {"body": dec["body"], "kind": dec.get("kind", "assertion"),
                          "graph": dec.get("graph"), "attachment": dec.get("attachment")})
            print(f"[{r['id']} R{cur['round']}] said: {res.get('score')} "
                  f"ev={res.get('evidence')} rehash={res.get('rehash')}")
        else:
            c.call("POST", f"/v1/rooms/{r['id']}/skip", {})
            print(f"[{r['id']} R{cur['round']}] skipped")
        if cp.exists():
            cp.unlink()


def _single_instance(agent: str) -> bool:
    """同一 agent 只允许一个 chatroom 进程。

    没有这个锁时，start-executor 每被调用一次就会多一个 chatroom_agent；
    同一句群消息会被多个进程各判一次，生成重复任务。
    """
    lock = ROOT / "runtime" / f".chatroom.{agent}.lock"
    lock.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
    except FileExistsError:
        alive = False
        old = 0
        try:
            old = int(lock.read_text(encoding="utf-8").strip() or "0")
            os.kill(old, 0)
            alive = True
        except Exception:  # noqa: BLE001
            alive = False
        if alive:
            print(f"[chatroom] 已有实例在跑（{lock.name} pid={old}），本进程退出")
            return False
        lock.write_text(str(os.getpid()), encoding="utf-8")
    atexit.register(lambda: lock.unlink(missing_ok=True))
    return True


def main():
    # 确保 opencode 配置包含随包声明的模型（含视觉模型）
    try:
        import sys as _sys
        if str(ROOT) not in _sys.path:
            _sys.path.insert(0, str(ROOT))
        from core.llm.opencode import ensure_config
        ensure_config()
    except Exception as e:  # noqa: BLE001
        print("[opencode-config] ensure failed:", e)

    # 依赖自愈：确保 playwright Chromium（本地工具 / 网页截图依赖），best-effort、幂等
    try:
        from core.deps import ensure_chromium
        _d = ensure_chromium(quiet=False)
        if _d.get("action") == "install":
            print(f"[deps] chromium install ok={_d.get('ok')} {str(_d.get('detail',''))[:120]}")
    except Exception as e:  # noqa: BLE001
        print("[deps] ensure_chromium failed:", e)

    ap = argparse.ArgumentParser()
    ap.add_argument("--as", dest="agent", required=True)
    ap.add_argument("--url", default=None)
    ap.add_argument("--ca")
    ap.add_argument("--interval", type=float, default=2)
    ap.add_argument("--model", default=None)
    ap.add_argument("--room", help="只驱动指定房间")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--no-auto-update", action="store_true", help="关闭客户端自动更新")
    ap.add_argument("--no-chatwork", action="store_true", help="关闭『群聊即控制台』指令识别")
    ap.add_argument("--no-dm", action="store_true", help="关闭私信自动看/回（DM 接入）")
    ap.add_argument("--no-migrate", action="store_true",
                    help="不自动收敛旧 supervisor（仅排障用）")
    ap.add_argument("--chat-rate", type=float, default=None,
                    help="聊天参与率 0-1（每 1/rate 回合参与 1 次）；默认 TEAMAI_CHAT_RATE 或 1/5")
    ap.add_argument("--no-discovery", action="store_true", help="关闭 UDP 信标地址发现")
    a = ap.parse_args()
    if not _single_instance(a.agent):
        return
    if a.no_auto_update:
        globals()["AUTO_UPDATE"] = False
    if a.no_chatwork:
        globals()["CHATWORK"] = False
    if a.no_dm:
        globals()["DM"] = False
    globals()["CHAT_RATE"] = (a.chat_rate if a.chat_rate is not None
                              else float(os.environ.get("TEAMAI_CHAT_RATE", 1.0 / 5.0)))
    if not a.model:                      # 模型优先级：CLI > agents/<id>/model > env > 默认
        _mf = ROOT / "agents" / a.agent / "model"
        a.model = ((_mf.read_text(encoding="utf-8").strip() if _mf.exists() else "")
                   or os.environ.get("TEAMAI_OPENCODE_MODEL", "deepseek/deepseek-flash"))
    # 地址发现：显式 --url > TEAMAI_URL > bootstrap/host_url > 默认
    import sys as _s
    if str(ROOT) not in _s.path:
        _s.path.insert(0, str(ROOT))
    try:
        from core import discovery as _disc
    except Exception:
        _disc = None
    url = (a.url or os.environ.get("TEAMAI_URL")
           or (_disc.load_host_url() if _disc else None) or "http://127.0.0.1:6030")
    c = Client(url, a.agent, a.ca)
    print(f"[chatroom_agent] {a.agent} @ {c.base} interval={a.interval}s room={a.room or 'all'} chat_rate={globals()['CHAT_RATE']}")
    # 旧版 self-update 只 execv 当前 chatroom，不会重启 supervisor。
    # 新 chatroom 启动时若发现没有 live supervisor 锁，自动安排一次整树收敛。
    if not getattr(a, "no_migrate", False) and not _supervisor_alive(a.agent):
        print("[restart] no live supervisor; migrating to single supervisor")
        _spawn_restart(a.agent, c.base)
        return
    if _disc and not getattr(a, "no_discovery", False):
        import threading
        _stop = threading.Event()

        def _adopt(base, node, addr):
            if base.rstrip("/") == c.base:
                return
            tc = Client(base, a.agent, a.ca)
            try:
                d = tc.call("GET", "/v1/me")
            except Exception:
                return
            aid = ((d.get("agent") or {}).get("id") if isinstance(d, dict) else None) or \
                  (d.get("id") if isinstance(d, dict) else None)
            if aid == a.agent:                       # 验真：能返回本 agent 身份→是同一 TeamAI 宿主
                print(f"[discovery] 发现并验真宿主 {base}（node={node}）→ 采纳（原 {c.base}）")
                c.base = base
                _disc.save_host_url(base)
            else:
                print(f"[discovery] 候选 {base} 验真未过，忽略")
        threading.Thread(target=_disc.listen_beacons, args=(_adopt,),
                         kwargs={"stop": _stop}, daemon=True).start()
        print(f"[discovery] 已启动信标监听（UDP {_disc.BEACON_PORT}）")
    _fail = 0
    while True:
        try:
            tick(c, a.agent, a.model, a.room)
        except Exception as e:
            print(f"[chatroom_agent] tick err: {e}")
        if c.last_err:                               # 醒报告警：连不上不静默
            _fail += 1
            if _fail == 3:                           # ★ 端点自愈（S2）：连续 3 拍失败即换地址，别抱着旧 IP 空转到天荒地老
                try:
                    from core.endpoint import heal as _heal
                    _new, _tried = _heal(c.base)
                    if _new and _new != c.base:
                        print(f"[conn] 🔁 端点自愈：{c.base} → {_new}（试过 {_tried[:3]}）")
                        c.base = _new
                        _fail = 0
                    elif not _new:
                        print(f"[conn] ⚠️ 端点自愈失败：候选全不可达（{_tried}）——需人工/中心站点")
                except Exception as _e:  # noqa: BLE001
                    print(f"[conn] 端点自愈异常：{_e}")
            if _fail in (1, 5, 20) or _fail % 60 == 0:
                print(f"[conn] ⚠️ 连不上宿主 {c.base}｜本机IP={_disc.local_ips() if _disc else '?'}"
                      f"｜错误={c.last_err}｜已连续 {_fail} 拍")
        else:
            if _fail:
                print(f"[conn] ✅ 已恢复（宿主 {c.base}）")
            _fail = 0
        if a.once:
            break
        time.sleep(a.interval)


if __name__ == "__main__":
    main()
