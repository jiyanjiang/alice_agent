#!/usr/bin/env python3
"""workspace —— 长/短任务的目录隔离与互斥。

原则：
  - 一个 workspace 同一时间只允许一个 run；
  - 任务完成后只回收白名单产物，不把整棵目录搬回主仓；
  - 默认 root workspace 仍可串行使用，不强制改变已有任务行为。
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path


class WorkspaceError(RuntimeError):
    pass


def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except Exception:  # noqa: BLE001
        return False


def allocate(root: Path, task_id: str, lane: str = "short") -> Path:
    """为任务分配独立 workspace；不复制整仓，调用方按需 seed。"""
    safe = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in str(task_id))
    p = Path(root) / "runtime" / "workspaces" / f"{lane}-{safe}"
    p.mkdir(parents=True, exist_ok=True)
    return p


def lock(workspace: Path) -> Path:
    """原子获取 workspace 锁；有 live owner 时拒绝。"""
    p = Path(workspace) / ".workspace.lock"
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(p), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
        return p
    except FileExistsError:
        try:
            old = int(p.read_text(encoding="utf-8").strip() or "0")
            if _alive(old):
                raise WorkspaceError(f"workspace busy: pid={old}")
        except WorkspaceError:
            raise
        except Exception:  # noqa: BLE001
            pass
        p.write_text(str(os.getpid()), encoding="utf-8")
        return p


def unlock(lock_path: Path | None) -> None:
    if not lock_path:
        return
    try:
        Path(lock_path).unlink()
    except FileNotFoundError:
        pass


def collect(workspace: Path, dest_root: Path,
            rels: tuple[str, ...] = ("deliverables", "runtime/artifacts")) -> list[str]:
    """把 workspace 里的白名单产物回收到主目录；返回相对路径。"""
    out: list[str] = []
    workspace = Path(workspace)
    dest_root = Path(dest_root)
    for rel in rels:
        src = workspace / rel
        if not src.exists():
            continue
        for f in src.rglob("*"):
            if not f.is_file():
                continue
            relp = f.relative_to(workspace)
            dst = dest_root / relp
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, dst)
            out.append(str(relp))
    return out


def cleanup(workspace: Path, keep: bool = False) -> None:
    """清理临时 workspace；keep=True 时保留供审计。"""
    if keep:
        return
    shutil.rmtree(Path(workspace), ignore_errors=True)
