#!/usr/bin/env bash
# TAA 1.x integrated installer. No agent key; the Owner claim happens in the browser.
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
TAA_HOME="${TAA_HOME:-$HOME/.taa}"
DEST="$TAA_HOME/app"
PORT="${TAA_HTTP_PORT:-6080}"
NO_OPEN=0
SKIP_DEPS=0

while [ $# -gt 0 ]; do
  case "$1" in
    --no-browser) NO_OPEN=1; shift ;;
    --skip-deps) SKIP_DEPS=1; shift ;;
    --port) PORT="$2"; shift 2 ;;
    --home) TAA_HOME="$2"; DEST="$TAA_HOME/app"; shift 2 ;;
    -h|--help)
      cat <<EOF
TAA installer

Usage: $0 [--home DIR] [--port N] [--no-browser] [--skip-deps]

Install the local runtime into \$TAA_HOME/app, create a venv, then start
the local app. No agent key is required.
EOF
      exit 0
      ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
done

command -v python3 >/dev/null 2>&1 || { echo "x Python 3.10+ is required" >&2; exit 3; }
PY="${TAA_PYTHON:-python3}"
"$PY" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)' \
  || { echo "x Python 3.10+ is required" >&2; exit 3; }

# Existing install: use the atomic upgrade path, never rsync over live app.
if [ -f "$TAA_HOME/identity.json" ] && [ -d "$DEST" ]; then
  UPGRADE_PY="$PY"
  if [ -x "$TAA_HOME/venv/bin/python" ]; then
    UPGRADE_PY="$TAA_HOME/venv/bin/python"
  fi
  echo "[upgrade] existing install detected"
  UPGRADE_ARGS=(--source "$ROOT" --home "$TAA_HOME" --port "$PORT" --python "$UPGRADE_PY")
  [ "$NO_OPEN" = "1" ] && UPGRADE_ARGS+=(--no-open)
  "$UPGRADE_PY" "$ROOT/taa_upgrade.py" "${UPGRADE_ARGS[@]}"
  exit $?
fi

mkdir -p "$DEST" "$TAA_HOME"
if [ "$ROOT" != "$DEST" ]; then
  # Upgrade-safe copy. The live app intentionally contains symlinks for
  # agents/bootstrap/uploads; copying onto those symlinks fails on macOS.
  if command -v rsync >/dev/null 2>&1; then
    rsync -a --exclude=/agents --exclude=/bootstrap --exclude=/static/uploads       "$ROOT/" "$DEST/"
  else
    # Portable fallback: temporarily remove the three data links.
    for rel in agents bootstrap static/uploads; do
      [ -L "$DEST/$rel" ] && rm -f "$DEST/$rel"
    done
    cp -R "$ROOT/." "$DEST/"
  fi
  mkdir -p "$TAA_HOME/agents" "$TAA_HOME/bootstrap" "$TAA_HOME/static/uploads"
  if [ -d "$ROOT/agents" ]; then
    cp -R "$ROOT/agents/." "$TAA_HOME/agents/" 2>/dev/null || true
  fi
  for rel in agents bootstrap static/uploads; do
    if [ -L "$DEST/$rel" ]; then
      rm -f "$DEST/$rel"
    elif [ -d "$DEST/$rel" ]; then
      rm -rf "$DEST/$rel"
    fi
    mkdir -p "$(dirname "$DEST/$rel")"
    ln -s "$TAA_HOME/$rel" "$DEST/$rel"
  done
fi

if [ "$SKIP_DEPS" != "1" ]; then
  if [ ! -x "$TAA_HOME/venv/bin/python" ]; then
    "$PY" -m venv "$TAA_HOME/venv"
  fi
  "$TAA_HOME/venv/bin/python" -m pip install --upgrade pip >/dev/null
  "$TAA_HOME/venv/bin/python" -m pip install -r "$DEST/requirements-core.txt"
  PY="$TAA_HOME/venv/bin/python"
fi

export TAA_HOME TAA_PYTHON="$PY" TAA_HTTP_PORT="$PORT"
cd "$DEST"
if [ "$NO_OPEN" = "1" ]; then
  "$DEST/taa" start --no-open
else
  "$DEST/taa" start
fi
echo "TAA_HOME=$TAA_HOME"
echo "TAA_APP=$DEST"
echo "LOCAL_UI_URL=http://127.0.0.1:$PORT/app/bridge"
