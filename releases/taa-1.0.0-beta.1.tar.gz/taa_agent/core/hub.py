"""跨局域网协作 · 中心节点（store-and-forward relay）v1。

为什么需要它（与 `docs/72`、`docs/91`、`docs/405` 一致）：
- 局域网协作已由 `core/net/gossip.py` 覆盖：UDP 广播发现 + 局域网 HTTP 反熵；
- 一旦两台机器不在同一网段（NAT/公司网/家庭网），UDP 广播与内网 IP **都不可达**；
- 因此跨局域网需要一个**可公网到达的中心节点**做「信箱 + 目录」：
  各节点只**主动出站**连接中心（节点侧无入站要求，天然过 NAT），
  中心按 `hub_seq` 存转发事件，**不解释内容、不存私有记忆/人格**。

本模块只依赖 Flask + sqlite3，可单独部署在任何有公网地址的机器/VPS：
    ../venv/bin/python -m core.hub serve --port 6180 --db data/hub.db \
        --token <强随机串>=team-a

安全与边界：
- 所有读写接口需 `X-Hub-Token`；token → group 的映射在启动参数/环境变量里，token 不落库、不打日志；
- 事件以 group 隔离（同一中心可服务多个项目组）；
- 单条/单批有大小上限，避免被当成通用存储滥用；
- 中心只存协作事件（任务/帖子/房间消息等），**不存 memory.db / persona / 私有草稿**。
"""
from __future__ import annotations

import argparse
import hmac
import json
import os
import sqlite3
import threading
import time
from pathlib import Path

from flask import Flask, jsonify, request

SERVICE = "teamai-hub"
HUB_VERSION = "1"

MAX_BATCH = 500
MAX_EVENT_BYTES = 256 * 1024
MAX_PULL = 500

# 隧道转发到节点侧的请求头白名单（Host/Content-Length 由节点侧重算）
_FORWARD_HEADERS = {"content-type", "accept", "authorization", "user-agent", "cookie",
                    "x-teamai-key", "x-teamai-timestamp", "x-teamai-nonce",
                    "x-teamai-signature", "x-enroll-token", "x-forwarded-for"}

SCHEMA = """
CREATE TABLE IF NOT EXISTS hub_events (
  seq         INTEGER PRIMARY KEY AUTOINCREMENT,
  grp         TEXT NOT NULL,
  id          TEXT NOT NULL,
  node_id     TEXT NOT NULL,
  lamport     INTEGER NOT NULL,
  type        TEXT NOT NULL,
  payload     TEXT NOT NULL,
  ts          REAL NOT NULL,
  received_at REAL NOT NULL,
  UNIQUE (grp, id)
);
CREATE INDEX IF NOT EXISTS idx_hub_events_grp_seq ON hub_events(grp, seq);
CREATE TABLE IF NOT EXISTS hub_nodes (
  grp        TEXT NOT NULL,
  node_id    TEXT NOT NULL,
  addr       TEXT,
  meta       TEXT,
  first_seen REAL NOT NULL,
  last_seen  REAL NOT NULL,
  PRIMARY KEY (grp, node_id)
);
"""


def parse_tokens(raw: list[str] | None, default_group: str = "default") -> dict[str, str]:
    """把 `token=group` 列表解析成 {token: group}；缺 group 时归入默认组。"""
    out: dict[str, str] = {}
    for item in raw or []:
        item = (item or "").strip()
        if not item:
            continue
        if "=" in item:
            tok, grp = item.split("=", 1)
        else:
            tok, grp = item, default_group
        tok, grp = tok.strip(), (grp.strip() or default_group)
        if tok:
            out[tok] = grp
    return out


class HubStore:
    """轻量信箱：SQLite + 进程内锁（中心是 IO 很轻的中转，不做重计算）。"""

    def __init__(self, path: str | Path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        with self._lock:
            self.conn.executescript(SCHEMA)
            self.conn.commit()

    def close(self) -> None:
        with self._lock:
            self.conn.close()

    # ---------------- 目录 ----------------
    def register(self, grp: str, node_id: str, addr: str = "", meta: dict | None = None) -> list[dict]:
        now = time.time()
        payload = json.dumps(meta or {}, ensure_ascii=False)[:4096]
        with self._lock:
            self.conn.execute(
                "INSERT INTO hub_nodes(grp,node_id,addr,meta,first_seen,last_seen) "
                "VALUES (?,?,?,?,?,?) ON CONFLICT(grp,node_id) DO UPDATE SET "
                "addr=excluded.addr, meta=excluded.meta, last_seen=excluded.last_seen",
                (grp, node_id, (addr or "")[:256], payload, now, now))
            self.conn.commit()
            rows = self.conn.execute(
                "SELECT node_id, addr, meta, first_seen, last_seen FROM hub_nodes "
                "WHERE grp=? ORDER BY last_seen DESC LIMIT 100", (grp,)).fetchall()
        return [{"node_id": r["node_id"], "addr": r["addr"],
                 "meta": _loads(r["meta"], {}), "first_seen": r["first_seen"],
                 "last_seen": r["last_seen"]} for r in rows]

    # ---------------- 事件 ----------------
    def ingest(self, grp: str, events: list[dict]) -> tuple[int, int, int]:
        """去重写入；返回 (新增数, 跳过数, 本组最大 seq)。"""
        accepted = skipped = 0
        now = time.time()
        with self._lock:
            for e in events:
                cur = self.conn.execute(
                    "INSERT OR IGNORE INTO hub_events"
                    "(grp,id,node_id,lamport,type,payload,ts,received_at) VALUES (?,?,?,?,?,?,?,?)",
                    (grp, e["id"], e["node_id"], int(e["lamport"]), e["type"],
                     json.dumps(e["payload"], ensure_ascii=False), float(e["ts"]), now))
                if cur.rowcount:
                    accepted += 1
                else:
                    skipped += 1
            self.conn.commit()
            row = self.conn.execute(
                "SELECT COALESCE(MAX(seq),0) AS m FROM hub_events WHERE grp=?", (grp,)).fetchone()
        return accepted, skipped, int(row["m"])

    def pull(self, grp: str, since: int = 0, limit: int = 200) -> tuple[list[dict], int, bool]:
        """按 seq 升序取增量；`next_since` 只推进到**本次实际返回**的最后一个 seq。"""
        limit = max(1, min(int(limit or 200), MAX_PULL))
        with self._lock:
            rows = self.conn.execute(
                "SELECT seq,id,node_id,lamport,type,payload,ts FROM hub_events "
                "WHERE grp=? AND seq>? ORDER BY seq LIMIT ?",
                (grp, int(since or 0), limit + 1)).fetchall()
        more = len(rows) > limit
        rows = rows[:limit]
        events = [{"id": r["id"], "node_id": r["node_id"], "lamport": r["lamport"],
                   "type": r["type"], "payload": _loads(r["payload"], {}), "ts": r["ts"]}
                  for r in rows]
        next_since = int(rows[-1]["seq"]) if rows else int(since or 0)
        return events, next_since, more

    def stats(self, grp: str) -> dict:
        with self._lock:
            ev = self.conn.execute("SELECT COUNT(*) AS n, COALESCE(MAX(seq),0) AS m "
                                   "FROM hub_events WHERE grp=?", (grp,)).fetchone()
            nd = self.conn.execute("SELECT COUNT(*) AS n FROM hub_nodes WHERE grp=?",
                                   (grp,)).fetchone()
            cutoff = time.time() - 300
            live = self.conn.execute(
                "SELECT COUNT(*) AS n FROM hub_nodes WHERE grp=? AND last_seen>=?",
                (grp, cutoff)).fetchone()
        return {"events": int(ev["n"]), "max_seq": int(ev["m"]),
                "nodes": int(nd["n"]), "nodes_5m": int(live["n"])}


def _loads(raw, default):
    try:
        return json.loads(raw) if raw else default
    except Exception:
        return default


def _clean_event(e) -> dict | None:
    if not isinstance(e, dict):
        return None
    eid, node_id, type_ = e.get("id"), e.get("node_id"), e.get("type")
    if not all(isinstance(x, str) and x for x in (eid, node_id, type_)):
        return None
    try:
        lamport, ts = int(e.get("lamport")), float(e.get("ts"))
    except (TypeError, ValueError):
        return None
    payload = e.get("payload")
    if not isinstance(payload, dict):
        payload = {}
    ev = {"id": eid[:128], "node_id": node_id[:128], "lamport": lamport,
          "type": type_[:64], "payload": payload, "ts": ts}
    if len(json.dumps(ev, ensure_ascii=False).encode("utf-8")) > MAX_EVENT_BYTES:
        return None
    return ev


def create_app(store: HubStore, tokens: dict[str, str], tunnel=None) -> Flask:
    app = Flask(__name__)
    # 一批最多 500 条、单条 256KB；总请求体再兜一层，避免被当成通用存储。
    # 隧道转发可能有附件上传，放宽到 32MB。
    app.config["MAX_CONTENT_LENGTH"] = 32 * 1024 * 1024

    def _group() -> str | None:
        # 只认请求头：token 放 URL 会被反向代理/网关日志记下来。
        tok = request.headers.get("X-Hub-Token") or ""
        for known, grp in tokens.items():
            if tok and hmac.compare_digest(str(tok), str(known)):
                return grp
        return None

    def _deny():
        return jsonify({"ok": False, "error": "invalid hub token"}), 401

    @app.get("/v1/hub/health")
    def health():
        return jsonify({"ok": True, "service": SERVICE, "version": HUB_VERSION,
                        "tunnel": bool(tunnel)})

    @app.post("/v1/hub/register")
    def register():
        grp = _group()
        if not grp:
            return _deny()
        body = request.get_json(force=True, silent=True) or {}
        node_id = body.get("node_id")
        if not isinstance(node_id, str) or not node_id.strip():
            return jsonify({"ok": False, "error": "node_id required"}), 400
        peers = store.register(grp, node_id.strip(), str(body.get("addr") or ""),
                               body.get("meta") if isinstance(body.get("meta"), dict) else {})
        return jsonify({"ok": True, "group": grp, "service": SERVICE, "version": HUB_VERSION,
                        "peers": peers})

    @app.post("/v1/hub/events")
    def push():
        grp = _group()
        if not grp:
            return _deny()
        body = request.get_json(force=True, silent=True) or {}
        raw = body.get("events")
        if not isinstance(raw, list):
            return jsonify({"ok": False, "error": "events must be a list"}), 400
        if len(raw) > MAX_BATCH:
            return jsonify({"ok": False, "error": f"too many events (max {MAX_BATCH})"}), 413
        events = [e for e in (_clean_event(x) for x in raw) if e]
        accepted, skipped, max_seq = store.ingest(grp, events)
        return jsonify({"ok": True, "accepted": accepted, "skipped": skipped,
                        "invalid": len(raw) - len(events), "max_seq": max_seq})

    @app.get("/v1/hub/events")
    def pull():
        grp = _group()
        if not grp:
            return _deny()
        try:
            since = int(request.args.get("since", 0) or 0)
        except ValueError:
            return jsonify({"ok": False, "error": "since must be int"}), 400
        events, next_since, more = store.pull(grp, since, request.args.get("limit", 200))
        return jsonify({"ok": True, "events": events, "next_since": next_since, "more": more})

    @app.get("/v1/hub/stats")
    def stats():
        grp = _group()
        if not grp:
            return _deny()
        return jsonify({"ok": True, "group": grp, **store.stats(grp)})

    # ---------------- 反向隧道（节点只出站；外部经中心访问） ----------------
    @app.get("/v1/tunnel/<node_id>/pull")
    def tunnel_pull(node_id):
        if not tunnel:
            return jsonify({"ok": False, "error": "tunnel disabled"}), 503
        grp = _group()
        if not grp:
            return _deny()
        wait = request.args.get("wait")
        try:
            waitf = float(wait) if wait is not None else None
        except ValueError:
            waitf = None
        try:
            req = tunnel.pull(node_id, grp, waitf)
        except RuntimeError as e:
            return jsonify({"ok": False, "error": str(e)}), 409
        if not req:
            return "", 204
        return jsonify(req)

    @app.post("/v1/tunnel/<node_id>/respond")
    def tunnel_respond(node_id):
        if not tunnel:
            return jsonify({"ok": False, "error": "tunnel disabled"}), 503
        grp = _group()
        if not grp:
            return _deny()
        body = request.get_json(force=True, silent=True) or {}
        import base64
        try:
            raw = base64.b64decode(body.get("body") or "")
        except Exception:
            raw = b""
        ok = tunnel.respond(node_id, grp, str(body.get("rid") or ""),
                            int(body.get("status") or 502),
                            [(str(k), str(v)) for k, v in (body.get("headers") or [])], raw)
        return jsonify({"ok": ok}), (200 if ok else 410)

    @app.get("/v1/tunnel/stats")
    def tunnel_stats():
        if not tunnel:
            return jsonify({"ok": False, "error": "tunnel disabled"}), 503
        if not _group():
            return _deny()
        return jsonify({"ok": True, **tunnel.stats()})

    @app.route("/n/<node_id>/", defaults={"sub": ""},
               methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
    @app.route("/n/<node_id>/<path:sub>",
               methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
    def tunnel_proxy(node_id, sub):
        """外部入口：`/n/<node>/<原路径>`；剥前缀后签名与节点侧一致。"""
        if not tunnel:
            return jsonify({"ok": False, "error": "tunnel disabled"}), 503
        grp = _group()
        if not grp:
            return _deny()
        if tunnel.group_of(node_id) != grp:
            return jsonify({"ok": False, "error": "unknown node"}), 404
        path = "/" + sub
        if request.query_string:
            path += "?" + request.query_string.decode("utf-8", "ignore")
        raw = request.get_data() or b""
        fwd = [(k, v) for k, v in request.headers.items()
               if k.lower() in _FORWARD_HEADERS]
        status, headers, body = tunnel.forward(node_id, grp, request.method, path, fwd, raw)
        from flask import make_response
        resp = make_response(body, status)
        for k, v in headers:
            if k.lower() == "set-cookie":
                resp.headers.add(k, v)
            else:
                resp.headers[k] = v
        return resp

    return app


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="teamai-hub", description="跨局域网协作中心节点（信箱 + 目录）")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("serve", help="启动中心节点")
    s.add_argument("--host", default=os.environ.get("TEAMAI_HUB_HOST", "0.0.0.0"))
    s.add_argument("--port", type=int, default=int(os.environ.get("TEAMAI_HUB_PORT", "6180")))
    s.add_argument("--db", default=os.environ.get("TEAMAI_HUB_DB", "data/hub.db"))
    s.add_argument("--token", action="append", default=None,
                   help="访问令牌，格式 token=group（可重复）；也可用 TEAMAI_HUB_TOKENS（逗号分隔）")
    s.add_argument("--group", default="default", help="仅给 token 不带 =group 时使用的默认组")
    s.add_argument("--tls-cert", default="")
    s.add_argument("--tls-key", default="")
    s.add_argument("--no-tunnel", action="store_true", help="只做事件信箱，不开放反向隧道")
    s.add_argument("--tunnel-timeout", type=float, default=30.0,
                   help="外部请求等待节点回传的秒数（默认 30）")
    args = ap.parse_args(argv)

    raw = args.token
    if raw is None and os.environ.get("TEAMAI_HUB_TOKENS"):
        raw = os.environ["TEAMAI_HUB_TOKENS"].split(",")
    tokens = parse_tokens(raw, args.group)
    if not tokens:
        ap.error("至少需要一个 --token（或设置 TEAMAI_HUB_TOKENS）")

    store = HubStore(args.db)
    tunnel = None
    if not args.no_tunnel:
        from .tunnel import TunnelHub
        tunnel = TunnelHub(timeout=args.tunnel_timeout)
    app = create_app(store, tokens, tunnel=tunnel)
    ssl_context = (args.tls_cert, args.tls_key) if (args.tls_cert and args.tls_key) else None
    scheme = "https" if ssl_context else "http"
    print(f"[hub] {scheme}://{args.host}:{args.port}  db={args.db}  "
          f"groups={sorted(set(tokens.values()))}  tunnel={'on' if tunnel else 'off'}")
    app.run(host=args.host, port=args.port, debug=False, use_reloader=False,
            threaded=True, ssl_context=ssl_context)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
