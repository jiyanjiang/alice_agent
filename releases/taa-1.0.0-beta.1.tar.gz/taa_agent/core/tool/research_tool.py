"""research.ask 薄工具适配。

把 `core.research` 的 prompt → code/v1|v2 工作流暴露给工具注册表。
实现仍归 `core.research`；本文件只做参数映射，不另建存储或调用链。
"""
from __future__ import annotations

from .base import Tool
from .registry import register


def _research_ask(agent: str, a: dict) -> dict:
    """Thin adapter: prompt → modern code/v1|v2 → DeepSeek/Ali ask."""
    from .. import research
    prompt = str(a.get("prompt") or "").strip()
    if not prompt:
        raise ValueError("research.ask 需要 prompt")
    slug = str(a.get("slug") or a.get("code") or "").strip()
    rounds = int(a.get("rounds") or 1)
    kwargs = {
        "model": str(a.get("model") or "deepseek-v4-pro"),
        "ali_model": a.get("ali_model"),
        "tag": str(a.get("tag") or ""),
    }
    if slug:
        if rounds > 1:
            return research.ask_deep(slug, prompt, rounds=rounds,
                                     version=a.get("version"), **kwargs)
        return research.ask(slug, prompt, version=a.get("version"), **kwargs)
    return research.ask_prompt(prompt, title=a.get("title"), reuse=bool(a.get("reuse")),
                               rounds=rounds, **kwargs)


register(Tool("research.ask", "主题调研：prompt → code/v1|v2，DeepSeek 优先、Ali 兜底；返回 provider/code/version",
              {"prompt": "str；研究问题/调研提示",
               "slug": "str?；legacy slug 或 r-<code>（可选）",
               "version": "str?；现代版本 v1/v2（可选）",
               "rounds": "int?；1=单轮，2-3=深挖（可选）",
               "reuse": "bool?；复用最新版本（重试时用）",
               "title": "str?；新版本标题",
               "model": "str?；默认 deepseek-v4-pro",
               "ali_model": "str?；默认 qwen-plus",
               "tag": "str?；输出文件标签"},
              _research_ask))
