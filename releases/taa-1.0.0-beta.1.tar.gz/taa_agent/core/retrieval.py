"""检索层：给 `research.ask` 提供**可核验的来源**（而不是让模型凭空给 URL）。

设计目标（与 docs/37 七步对齐）：
  · 只做**取回**：Bing / 维基 / OpenAlex 三条免费通道，无需 API key；
  · 每条结果保留 URL、标题、摘要、正文摘录（尽量抓原页）；
  · 来源分级保守：官方/一手 > 权威二手 > 弱二手；拿不准就降级；
  · 全部落盘缓存，便于复核与离线重跑。

用法：
    from core.retrieval import gather
    docs = gather("扬中 太平洲 圩 历史", limit=8)
    # -> [{"id":"S1","title":...,"url":...,"text":...,"grade":"official",...}]

注意：本模块**不调用 LLM**，也不写任何密钥。
"""
from __future__ import annotations

import base64
import hashlib
import html
import json
import re
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CACHE = ROOT / "research" / "_retrieval_cache"

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36")
HEADERS = {"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"}

# 来源分级（保守）
OFFICIAL_HOSTS = (
    ".gov.cn", "gov.cn", ".edu.cn", "edu.cn", "archives.", "da.gov.cn",
    "loc.gov", "archives.gov", "nationalarchives.gov", "europa.eu",
)
PRIMARY_HOSTS = ("doi.org", "nature.com", "science.org", "aps.org", "arxiv.org",
                 "jstor.org", "tandfonline.com", "sagepub.com", "springer.com",
                 "cambridge.org", "oxford.com", "ac.cn")
SECONDARY_HOSTS = ("wikipedia.org", "baike.baidu.com", "britannica.com",
                   "openalex.org", "crossref.org", "zhihu.com", "cnki.net")
WEAK_HOSTS = ("sohu.com", "163.com", "sina.com.cn", "qq.com", "toutiao.com",
              "baijiahao.baidu.com", "weixin.qq.com", "douban.com")


def grade_for(url: str) -> str:
    host = (urllib.parse.urlparse(url or "").hostname or "").lower()
    if any(host == h or host.endswith("." + h.lstrip(".")) or h in host for h in OFFICIAL_HOSTS):
        return "official"
    if any(h in host for h in PRIMARY_HOSTS):
        return "primary"
    if any(h in host for h in WEAK_HOSTS):
        return "weak"
    if any(h in host for h in SECONDARY_HOSTS):
        return "secondary"
    return "weak"


def _get(url: str, timeout: int = 25, max_bytes: int = 2_500_000) -> tuple[str, str]:
    last = None
    for attempt in range(3):
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                ctype = r.headers.get("Content-Type", "")
                raw = r.read(max_bytes)
            return ctype, raw.decode("utf-8", "ignore")
        except Exception as e:  # noqa: BLE001
            last = e
            code = getattr(e, "code", 0)
            if code not in (429, 500, 502, 503, 504) or attempt == 2:
                raise
            time.sleep((2, 6)[attempt])
    raise last  # type: ignore[misc]


def _clean(s: str) -> str:
    s = re.sub(r"<(script|style|noscript|svg)[^>]*>.*?</\1>", " ", s or "", flags=re.S | re.I)
    s = re.sub(r"<br\s*/?>|</p>|</div>|</h[1-6]>|</li>", "\n", s, flags=re.I)
    s = re.sub(r"<[^>]+>", " ", s)
    s = html.unescape(s)
    s = re.sub(r"[ \t\u00a0]+", " ", s)
    s = re.sub(r"\n\s*\n\s*\n+", "\n\n", s)
    return s.strip()


def fetch_text(url: str, timeout: int = 25) -> str:
    """抓原页并抽正文；失败返回空串（不抛异常，便于批量）。"""
    try:
        ctype, body = _get(url, timeout=timeout)
    except Exception:
        return ""
    if "pdf" in ctype.lower() or url.lower().endswith(".pdf"):
        return ""
    if "html" not in ctype.lower() and "text" not in ctype.lower():
        return ""
    # 优先 article/main，退化到整页
    m = re.search(r"<(article|main)[^>]*>(.*?)</\1>", body, re.S | re.I)
    core = m.group(2) if m else body
    txt = _clean(core)
    # 去掉导航/页脚常见的短行
    lines = [ln.strip() for ln in txt.splitlines() if len(ln.strip()) >= 20]
    return "\n".join(lines)[:20000]


# ---------------------------------------------------------------- Bing
def _decode_bing(u: str) -> str:
    if not u:
        return ""
    if "bing.com/ck/a" in u:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(u).query)
        v = (q.get("u") or [""])[0]
        if v.startswith("a1"):
            v = v[2:]
        try:
            pad = "=" * (-len(v) % 4)
            return base64.urlsafe_b64decode(v + pad).decode("utf-8", "ignore")
        except Exception:
            return u
    return u


def bing(q: str, limit: int = 8, timeout: int = 25) -> list[dict]:
    url = "https://www.bing.com/search?" + urllib.parse.urlencode({"q": q, "count": max(limit, 10), "setlang": "zh-Hans"})
    try:
        _, t = _get(url, timeout=timeout)
    except Exception:
        return []
    starts = [m.start() for m in re.finditer(r'<li class="b_algo"', t)]
    out = []
    for i, s in enumerate(starts[:limit * 2]):
        e = starts[i + 1] if i + 1 < len(starts) else min(len(t), s + 8000)
        b = t[s:e]
        m = re.search(r'<h2[^>]*>\s*<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', b, re.S)
        if not m:
            continue
        link = _decode_bing(html.unescape(m.group(1)))
        title = _clean(m.group(2))
        sm = re.search(r'<p[^>]*>(.*?)</p>', b, re.S)
        snippet = _clean(sm.group(1)) if sm else ""
        if not link.startswith("http") or not title:
            continue
        out.append({"provider": "bing", "title": title[:160], "url": link,
                    "snippet": snippet[:600], "text": "", "grade": grade_for(link)})
        if len(out) >= limit:
            break
    return out


# ---------------------------------------------------------------- Wikipedia
def wikipedia(q: str, limit: int = 3, lang: str = "zh", timeout: int = 25) -> list[dict]:
    api = f"https://{lang}.wikipedia.org/w/api.php"
    su = api + "?" + urllib.parse.urlencode({
        "action": "query", "list": "search", "srsearch": q, "format": "json",
        "srlimit": limit, "utf8": 1,
    })
    try:
        _, t = _get(su, timeout=timeout)
        data = json.loads(t)
    except Exception:
        return []
    out = []
    for it in (data.get("query", {}).get("search") or [])[:limit]:
        title = it.get("title", "")
        page = f"https://{lang}.wikipedia.org/wiki/" + urllib.parse.quote(title.replace(" ", "_"))
        try:
            eu = api + "?" + urllib.parse.urlencode({
                "action": "query", "prop": "extracts", "explaintext": 1,
                "titles": title, "format": "json", "redirects": 1,
            })
            _, et = _get(eu, timeout=timeout)
            pages = json.loads(et).get("query", {}).get("pages", {})
            text = next(iter(pages.values()), {}).get("extract", "") if pages else ""
        except Exception:
            text = ""
        out.append({"provider": f"wikipedia-{lang}", "title": title, "url": page,
                    "snippet": _clean(it.get("snippet", ""))[:600], "text": (text or "")[:20000],
                    "grade": "secondary"})
    return out


# ---------------------------------------------------------------- OpenAlex
def _abstract(inv: dict | None) -> str:
    if not inv:
        return ""
    pos = []
    for w, ps in inv.items():
        for p in ps:
            pos.append((p, w))
    return " ".join(w for _, w in sorted(pos))[:4000]


def openalex(q: str, limit: int = 5, timeout: int = 25) -> list[dict]:
    url = "https://api.openalex.org/works?" + urllib.parse.urlencode({
        "search": q, "per-page": limit, "mailto": "teamai@example.org",
    })
    try:
        _, t = _get(url, timeout=timeout)
        data = json.loads(t)
    except Exception:
        return []
    out = []
    for w in (data.get("results") or [])[:limit]:
        title = w.get("title") or w.get("display_name") or ""
        doi = w.get("doi") or ""
        loc = (w.get("primary_location") or {}).get("landing_page_url") or ""
        link = doi or loc or (w.get("id") or "")
        if not link:
            continue
        out.append({"provider": "openalex", "title": title[:200], "url": link,
                    "snippet": _abstract(w.get("abstract_inverted_index"))[:1000],
                    "text": _abstract(w.get("abstract_inverted_index"))[:20000],
                    "grade": "secondary",
                    "year": w.get("publication_year")})
    return out


# ---------------------------------------------------------------- curated pages
# 搜索对冷门史学题目并不稳定；每章配一组「已知相关」的百科条目作底料，
# 再由检索结果补充。它们只是**线索**，事实仍须逐字回原文校验。
CURATED_PAGES = {
    "0": ["流民", "游民", "帮会", "中国户籍制度", "里甲", "黄册", "灾荒", "中国人口史", "编户齐民", "保甲制度"],
    "1": ["长江三角洲", "冲积平原", "河口沙洲", "崇明岛", "扬中市", "靖江市", "张家港市",
          "常阴沙", "长兴岛", "横沙岛", "九段沙", "圩田", "鱼鳞图册", "里甲", "黄册", "保甲制度"],
    "2": ["疍民", "水上人", "船民", "崇明岛", "启东市", "海门区", "如东县", "靖江市",
          "扬中市", "张家港市", "吴语", "沙地话", "张謇", "盐垦"],
    "3": ["圩田", "圩", "鱼鳞图册", "永佃制", "田面权", "宗族", "械斗", "保甲制度",
          "里甲", "黄册", "乡绅", "团练"],
    "4": ["团练", "保甲制度", "乡绅", "崇明岛", "圩田", "太平天国", "湘军", "淮军"],
    "5": ["陈友谅", "朱元璋", "张士诚", "鄱阳湖之战", "元末民变", "太平天国", "湘军", "淮军", "水师", "水寨"],
    "6": ["波利尼西亚人", "南岛民族", "客家围屋", "福建土楼", "台湾垦殖", "洞庭湖",
          "珠江三角洲", "沙田", "圩田", "宗族", "垦殖"],
    "7": ["乡绅", "圩田", "基层治理", "保甲制度"],
}


def wiki_page(title: str, lang: str = "zh", timeout: int = 25) -> dict | None:
    """按条目标题直接取维基正文（比搜索更稳）。"""
    api = f"https://{lang}.wikipedia.org/w/api.php?" + urllib.parse.urlencode({
        "action": "query", "prop": "extracts", "explaintext": 1,
        "titles": title, "format": "json", "redirects": 1,
    })
    try:
        _, t = _get(api, timeout=timeout)
        pages = json.loads(t).get("query", {}).get("pages", {})
        page = next(iter(pages.values()), {}) if pages else {}
        text = page.get("extract") or ""
        if not text:
            return None
        real = page.get("title") or title
        url = f"https://{lang}.wikipedia.org/wiki/" + urllib.parse.quote(real.replace(" ", "_"))
        return {"provider": f"curated-wiki-{lang}", "title": real, "url": url,
                "snippet": text[:600], "text": text[:20000], "grade": "secondary"}
    except Exception:
        return None


def curated(chapter_no: str, limit: int = 3, lang: str = "zh", offset: int = 0) -> list[dict]:
    pages = CURATED_PAGES.get(str(chapter_no), [])
    if not pages:
        return []
    offset = offset % len(pages)
    titles = (pages[offset:] + pages[:offset])[:limit]
    CACHE.mkdir(parents=True, exist_ok=True)
    cp = CACHE / f"curated_{lang}_{chapter_no}_{limit}_{offset}.json"
    if cp.exists():
        try:
            data = json.loads(cp.read_text(encoding="utf-8"))
            if len(data) >= min(2, len(titles)):
                return data
        except Exception:
            pass
    out = []
    for t in titles:                       # 顺序取，避免维基并发限流
        d = wiki_page(t, lang=lang)
        if d:
            out.append(d)
        time.sleep(0.2)
    if out:
        try:
            cp.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
    return out


# ---------------------------------------------------------------- gather
def _key(q: str, limit: int, fetch_n: int) -> str:
    return hashlib.sha1(f"{q}|{limit}|{fetch_n}".encode("utf-8")).hexdigest()[:16]


def _dedupe(items: list[dict]) -> list[dict]:
    seen, out = set(), []
    for it in items:
        u = (it.get("url") or "").split("#")[0].rstrip("/")
        if not u or u in seen:
            continue
        seen.add(u)
        out.append(it)
    return out


_STOP = set("""的 了 在 是 有 和 与 及 或 为 以 于 而 对 从 到 把 被 将 我们 他们 这个 那个
一个 一种 如何 什么 为什么 怎么 历史 研究 资料 综述 背景 问题 概念 界定 机制 模型 视角
框架 创新 缺陷 空白 意义 启示 结论 不足 方向 对照 对比 异同 史料 档案 县志 文书 中国
传统 文化 社会 制度 地方 古代 近代 现代 当代""".split())


def _terms(q: str) -> list[str]:
    """粗分词：中文 2–6 字片段 + 拉丁词；不做词典分词，只用于相关性排序。"""
    q = (q or "").lower()
    out: list[str] = []
    for w in re.findall(r"[a-z][a-z0-9\-]{2,}", q):
        if w not in _STOP:
            out.append(w)
    for seg in re.findall(r"[\u4e00-\u9fff]{2,}", q):
        if len(seg) <= 6:
            if seg not in _STOP:
                out.append(seg)
        else:
            for n in (4, 3, 2):
                for i in range(0, len(seg) - n + 1):
                    w = seg[i:i + n]
                    if w not in _STOP:
                        out.append(w)
    # 去重保序、限制数量
    seen, out2 = set(), []
    for w in out:
        if w not in seen:
            seen.add(w)
            out2.append(w)
    return out2[:24]


def _relevance(it: dict, terms: list[str]) -> float:
    title = (it.get("title") or "").lower()
    snip = (it.get("snippet") or "").lower()
    text = (it.get("text") or "")[:6000].lower()
    s = 0.0
    for w in terms:
        if w in title:
            s += 3.0
        if w in snip:
            s += 1.0
        if w in text:
            s += 0.25
    # 首页/门户降权（不是资料页）
    path = urllib.parse.urlparse(it.get("url") or "").path
    if path in ("", "/") or re.search(r"/index\.(s?html?|php)$", path):
        s -= 4.0
    if re.search(r"(地图|登录|攻略|旅游|招聘|房产|天气|新闻中心)", title):
        s -= 3.0
    return s


def _relevance_head(it: dict, terms: list[str]) -> float:
    """只看标题+摘要的相关度：搜索阶段用它挡掉“正文里偶然出现关键词”的跑题页。"""
    title = (it.get("title") or "").lower()
    snip = (it.get("snippet") or "").lower()
    return sum((3.0 if w in title else 0.0) + (1.0 if w in snip else 0.0) for w in terms)


def _rank(it: dict) -> tuple:
    g = {"primary": 0, "official": 1, "secondary": 2, "weak": 3}.get(it.get("grade", "weak"), 4)
    p = {"curated-wiki-zh": 0, "curated-wiki-en": 0, "bing": 1, "wikipedia-zh": 2,
         "wikipedia-en": 2, "openalex": 3, "semantic-scholar": 3, "crossref": 3,
         "archive-org": 2}.get(it.get("provider", ""), 4)
    return (0 if it.get("curated") else 1, -float(it.get("score", 0)), g, p)


def gather(question: str, *, queries: list[str] | None = None, limit: int = 8, fetch_n: int = 5,
           lang: str = "zh", use_cache: bool = True, cache_dir: Path | None = None,
           curated_docs: list[dict] | None = None) -> list[dict]:
    """并发取回多源结果，抓取前 fetch_n 个原页正文，返回 S1..Sn。

    queries: 可给多条检索式（同义词/学术词/英文词）；默认只用 question。
    """
    cache_dir = cache_dir or CACHE
    cache_dir.mkdir(parents=True, exist_ok=True)
    qs = [q for q in (queries or [question]) if q and q.strip()]
    cache_key = question + "|" + "|".join(qs) + "|" + "|".join(
        sorted((d.get("title") or "") for d in (curated_docs or [])))
    cp = cache_dir / (_key(cache_key, limit, fetch_n) + ".json")
    if use_cache and cp.exists():
        try:
            return json.loads(cp.read_text(encoding="utf-8"))
        except Exception:
            pass
    q = qs[0]
    tasks = {
        "bing": lambda: bing(q, limit=limit),
        "wiki_zh": lambda: wikipedia(q, limit=min(4, limit), lang="zh"),
        "openalex": lambda: openalex(q, limit=min(4, limit)),
    }
    for i, qq in enumerate(qs[1:4], 1):
        tasks[f"bing{i}"] = (lambda qq=qq: bing(qq, limit=limit))
        if i <= 2:
            tasks[f"wiki{i}"] = (lambda qq=qq: wikipedia(qq, limit=min(2, limit), lang="zh"))
    if lang != "zh":
        tasks["wiki_en"] = lambda: wikipedia(q, limit=min(2, limit), lang="en")
    items: list[dict] = []
    with ThreadPoolExecutor(max_workers=6) as ex:
        futs = {ex.submit(fn): name for name, fn in tasks.items()}
        for f in as_completed(futs):
            try:
                items.extend(f.result() or [])
            except Exception:
                pass
    if curated_docs:
        items.extend(curated_docs)
    items = _dedupe(items)
    terms = _terms(" ".join(qs))
    for it in items:
        it["score"] = round(_relevance(it, terms), 2)
        it["score_head"] = round(_relevance_head(it, terms), 2)
        if str(it.get("provider", "")).startswith("curated"):
            it["curated"] = True
    # 标题/摘要层面必须与问题有实际词面关系（curated 底料除外）
    items = [it for it in items if it["score_head"] > 0.5 or it.get("curated")]
    items.sort(key=_rank)
    items = items[:max(limit, fetch_n)]

    # 抓原页（已有正文的维基/OpenAlex 不重复抓）
    need = [it for it in items if not it.get("text")][:fetch_n]
    if need:
        with ThreadPoolExecutor(max_workers=4) as ex:
            futs = {ex.submit(fetch_text, it["url"]): it for it in need}
            for f in as_completed(futs):
                it = futs[f]
                try:
                    it["text"] = f.result() or it.get("snippet", "")
                except Exception:
                    it["text"] = it.get("snippet", "")
    for it in items:
        if not it.get("text"):
            it["text"] = it.get("snippet", "")
    # 抓回正文后再按词面相关度重排一次（正文里命中才算数）
    for it in items:
        it["score"] = round(_relevance(it, terms), 2)
    items.sort(key=_rank)
    for i, it in enumerate(items, 1):
        it["id"] = f"S{i}"
    if use_cache:
        try:
            cp.write_text(json.dumps(items, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception:
            pass
    return items


def to_jsonl(docs: list[dict]) -> str:
    return "\n".join(json.dumps(d, ensure_ascii=False) for d in docs) + ("\n" if docs else "")


if __name__ == "__main__":  # 手工自测：python -m core.retrieval "问题"
    import sys
    q = " ".join(sys.argv[1:]) or "扬中 太平洲 圩 历史"
    for d in gather(q, limit=6, fetch_n=3):
        print(f"[{d['id']}] {d['grade']:<9} {d['title'][:60]}\n    {d['url']}\n    {d['text'][:160]}")
