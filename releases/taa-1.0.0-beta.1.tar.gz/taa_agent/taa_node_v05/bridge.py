"""P3: map a v0.5 local identity onto the main TAA core database.

The v0.5 identity remains the center-facing identity. The main core keeps its
existing agents/keys schema; this module creates idempotent mirror rows so the
local /app can use the same agent id.
"""
from __future__ import annotations

import datetime as _dt
import json
import sqlite3
from typing import Any

from .identity import IdentityState


def _now() -> str:
    return _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def ensure_core_identity(state: IdentityState, conn: sqlite3.Connection) -> dict[str, Any]:
    """Create/update core nodes, agents and keys for the v0.5 identity.

    It never writes the v0.5 key to disk outside the existing identity store;
    the key is encrypted with the core master key in the core keys table.
    """
    from core import security  # local import: keeps standalone v0.5 usable

    node_id = state.node.node_id
    alias = f"v05-{node_id[-10:]}"
    node_row = conn.execute("SELECT id FROM nodes WHERE id=?", (node_id,)).fetchone()
    if node_row is None:
        conn.execute(
            "INSERT INTO nodes(id, hostname, alias, node_code, os, arch, is_main, last_seen) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (node_id, state.node.alias, alias, state.node.fingerprint_hash[:16],
             "", "", 0, _now()),
        )
    else:
        conn.execute(
            "UPDATE nodes SET hostname=?, last_seen=? WHERE id=?",
            (state.node.alias, _now(), node_id),
        )

    mapped: list[dict[str, Any]] = []
    for agent in state.agents:
        full_name = f"{agent.display_name}@{alias}"
        row = conn.execute("SELECT id FROM agents WHERE id=?", (agent.agent_id,)).fetchone()
        persona = {
            "id": agent.agent_id,
            "name": agent.display_name,
            "kind": "ai",
            "identity": {"avatar": "🤖"},
            "v05": {
                "owner_id": state.owner.owner_id,
                "node_id": node_id,
                "center_owner_id": state.center.owner_id,
            },
        }
        if row is None:
            conn.execute(
                "INSERT INTO agents(id, name, kind, node_id, full_name, role, persona_json, status, last_seen) "
                "VALUES (?,?, 'ai', ?,?, 'executor', ?, 'active', ?)",
                (agent.agent_id, agent.display_name, node_id, full_name,
                 json.dumps(persona, ensure_ascii=False), _now()),
            )
        else:
            conn.execute(
                "UPDATE agents SET name=?, node_id=?, full_name=?, persona_json=?, status='active', last_seen=? "
                "WHERE id=?",
                (agent.display_name, node_id, full_name,
                 json.dumps(persona, ensure_ascii=False), _now(), agent.agent_id),
            )

        key_row = conn.execute(
            "SELECT key_id FROM keys WHERE agent_id=? AND revoked_at IS NULL",
            (agent.agent_id,),
        ).fetchone()
        if key_row is None:
            conn.execute(
                "INSERT INTO keys(key_id, agent_id, key_hash, key_enc, label) VALUES (?,?,?,?,?)",
                (security.gen_key_id(), agent.agent_id,
                 security.hash_secret(agent.agent_key),
                 security.encrypt(agent.agent_key), "v05-bridge"),
            )
        mapped.append({"agent_id": agent.agent_id, "display_name": agent.display_name})

    conn.commit()
    return {
        "ok": True,
        "owner_id": state.owner.owner_id,
        "center_owner_id": state.center.owner_id,
        "node_id": node_id,
        "agents": mapped,
    }
