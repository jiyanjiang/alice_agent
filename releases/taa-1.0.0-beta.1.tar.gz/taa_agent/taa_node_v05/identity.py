"""TAA Node Identity v0.5 · local identity primitives.

This module is deliberately center-agnostic. It creates and stores:
  - Owner identity (username/password hash; optional email)
  - Node identity (node_id, node_key, fingerprint hash)
  - Agent identity (agent_id, agent_key)

No network calls. No plaintext password storage. No raw hardware fingerprint
is written to disk.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import pathlib
import platform
import secrets
import socket
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any

from .crypto import generate_keypair

SCHEMA_VERSION = 1
IDENTITY_FILE = "identity.json"
PBKDF2_ITERATIONS = 200_000

OWNER_PREFIX = "own_"
NODE_PREFIX = "nod_"
AGENT_PREFIX = "agt_"
NODE_KEY_PREFIX = "nk_"
AGENT_KEY_PREFIX = "ak_"


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def new_id(prefix: str) -> str:
    return prefix + secrets.token_hex(8)


def new_key(prefix: str) -> str:
    return prefix + secrets.token_urlsafe(32)


def default_alias() -> str:
    host = socket.gethostname().split(".")[0].strip()
    if host:
        return host[:40]
    return f"{platform.system() or 'TAA'}-node"[:40]


def _machine_id() -> str:
    if platform.system() == "Darwin":
        # Deliberately avoid shelling out for the primitive; host + model info
        # still makes a stable local fingerprint hash without storing raw data.
        return platform.mac_ver()[0] or ""
    for path in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            value = pathlib.Path(path).read_text(encoding="utf-8").strip()
            if value:
                return value
        except OSError:
            pass
    return ""


def machine_fingerprint() -> str:
    """Return a local fingerprint string; callers must not persist it raw."""
    parts = [
        platform.system(),
        platform.release(),
        platform.machine(),
        _machine_id(),
        socket.gethostname(),
        platform.processor(),
    ]
    return "|".join(parts)


def fingerprint_hash(salt_hex: str | None = None) -> tuple[str, str]:
    """Return (hmac_sha256_hex, salt_hex). Raw fingerprint is never returned."""
    salt = salt_hex or secrets.token_hex(16)
    digest = hmac.new(
        bytes.fromhex(salt),
        machine_fingerprint().encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return digest, salt


def hash_password(password: str, salt_hex: str | None = None) -> str:
    salt = salt_hex or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), bytes.fromhex(salt), PBKDF2_ITERATIONS
    ).hex()
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${salt}${digest}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algorithm, iterations, salt, expected = encoded.split("$", 3)
        if algorithm != "pbkdf2_sha256":
            return False
        digest = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), bytes.fromhex(salt), int(iterations)
        ).hex()
        return hmac.compare_digest(digest, expected)
    except (TypeError, ValueError):
        return False


@dataclass
class Owner:
    owner_id: str
    username: str
    password_hash: str
    email: str = ""
    status: str = "provisional"
    created_at: str = field(default_factory=now_iso)


@dataclass
class Node:
    node_id: str
    owner_id: str
    alias: str
    node_key: str
    fingerprint_hash: str
    fingerprint_salt: str
    status: str = "pending_owner"
    enc_pubkey: str = ""
    enc_privkey: str = ""
    created_at: str = field(default_factory=now_iso)


@dataclass
class Agent:
    agent_id: str
    node_id: str
    display_name: str
    agent_key: str
    status: str = "active"
    created_at: str = field(default_factory=now_iso)


@dataclass
class CenterBinding:
    base: str = ""
    owner_id: str = ""
    claimed_at: str = ""


@dataclass
class IdentityState:
    owner: Owner
    node: Node
    agents: list[Agent] = field(default_factory=list)
    center: CenterBinding = field(default_factory=CenterBinding)
    schema_version: int = SCHEMA_VERSION

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "owner": asdict(self.owner),
            "node": asdict(self.node),
            "agents": [asdict(agent) for agent in self.agents],
            "center": asdict(self.center),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "IdentityState":
        if int(data.get("schema_version") or 0) != SCHEMA_VERSION:
            raise ValueError("unsupported identity schema")
        try:
            owner = Owner(**data["owner"])
            node = Node(**data["node"])
            agents = [Agent(**item) for item in data.get("agents") or []]
            center = CenterBinding(**(data.get("center") or {}))
        except (KeyError, TypeError) as exc:
            raise ValueError(f"invalid identity data: {exc}") from exc
        _validate(owner, node, agents)
        return cls(owner=owner, node=node, agents=agents, center=center)

    def agent_by_id(self, agent_id: str) -> Agent | None:
        return next((agent for agent in self.agents if agent.agent_id == agent_id), None)


@dataclass
class InitResult:
    state: IdentityState
    temporary_password: str
    generated_password: bool


def _validate(owner: Owner, node: Node, agents: list[Agent]) -> None:
    if not owner.owner_id.startswith(OWNER_PREFIX):
        raise ValueError("invalid owner id")
    if not node.node_id.startswith(NODE_PREFIX):
        raise ValueError("invalid node id")
    if not node.node_key.startswith(NODE_KEY_PREFIX):
        raise ValueError("invalid node key")
    if node.owner_id != owner.owner_id:
        raise ValueError("node owner mismatch")
    ids = set()
    for agent in agents:
        if not agent.agent_id.startswith(AGENT_PREFIX):
            raise ValueError("invalid agent id")
        if not agent.agent_key.startswith(AGENT_KEY_PREFIX):
            raise ValueError("invalid agent key")
        if agent.node_id != node.node_id:
            raise ValueError("agent node mismatch")
        if agent.agent_id in ids:
            raise ValueError("duplicate agent id")
        ids.add(agent.agent_id)


def identity_path(home: pathlib.Path) -> pathlib.Path:
    return pathlib.Path(home) / IDENTITY_FILE


def ensure_home(home: pathlib.Path) -> pathlib.Path:
    home = pathlib.Path(home).expanduser()
    home.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        os.chmod(home, 0o700)
    except OSError:
        pass
    return home


def save_state(home: pathlib.Path, state: IdentityState) -> pathlib.Path:
    home = ensure_home(home)
    path = identity_path(home)
    tmp = home / (IDENTITY_FILE + ".tmp")
    payload = json.dumps(state.as_dict(), ensure_ascii=False, indent=2) + "\n"
    tmp.write_text(payload, encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)
    os.chmod(path, 0o600)
    return path


def load_state(home: pathlib.Path) -> IdentityState:
    path = identity_path(pathlib.Path(home).expanduser())
    if not path.exists():
        raise FileNotFoundError(f"identity not found: {path}")
    return IdentityState.from_dict(json.loads(path.read_text(encoding="utf-8")))


def init_identity(
    home: pathlib.Path,
    *,
    alias: str | None = None,
    username: str | None = None,
    password: str | None = None,
    email: str = "",
    create_agent: bool = True,
    agent_name: str = "alice",
) -> InitResult:
    home = pathlib.Path(home).expanduser()
    if identity_path(home).exists():
        raise FileExistsError(f"identity already exists: {home}")
    generated = password is None
    temporary_password = password or secrets.token_urlsafe(14)
    owner = Owner(
        owner_id=new_id(OWNER_PREFIX),
        username=username or ("owner_" + secrets.token_hex(4)),
        password_hash=hash_password(temporary_password),
        email=email.strip(),
        status="provisional",
    )
    fp_hash, fp_salt = fingerprint_hash()
    enc_privkey, enc_pubkey = generate_keypair()
    node = Node(
        node_id=new_id(NODE_PREFIX),
        owner_id=owner.owner_id,
        alias=(alias or default_alias())[:40],
        node_key=new_key(NODE_KEY_PREFIX),
        fingerprint_hash=fp_hash,
        fingerprint_salt=fp_salt,
        status="pending_owner",
        enc_pubkey=enc_pubkey,
        enc_privkey=enc_privkey,
    )
    agents: list[Agent] = []
    if create_agent:
        agents.append(
            Agent(
                agent_id=new_id(AGENT_PREFIX),
                node_id=node.node_id,
                display_name=(agent_name or "alice")[:40],
                agent_key=new_key(AGENT_KEY_PREFIX),
            )
        )
    state = IdentityState(owner=owner, node=node, agents=agents)
    save_state(home, state)
    return InitResult(state=state, temporary_password=temporary_password, generated_password=generated)


def add_agent(
    home: pathlib.Path,
    display_name: str,
    *,
    state: IdentityState | None = None,
) -> tuple[IdentityState, Agent]:
    state = state or load_state(home)
    name = (display_name or "").strip()[:40]
    if not name:
        raise ValueError("agent display name is required")
    agent = Agent(
        agent_id=new_id(AGENT_PREFIX),
        node_id=state.node.node_id,
        display_name=name,
        agent_key=new_key(AGENT_KEY_PREFIX),
    )
    state.agents.append(agent)
    save_state(home, state)
    return state, agent


def verify_owner_password(state: IdentityState, password: str) -> bool:
    return verify_password(password, state.owner.password_hash)


def set_owner_password(home: pathlib.Path, new_password: str) -> IdentityState:
    if len(new_password) < 8:
        raise ValueError("password must be at least 8 characters")
    state = load_state(home)
    state.owner.password_hash = hash_password(new_password)
    save_state(home, state)
    return state


def public_summary(state: IdentityState) -> dict[str, Any]:
    return {
        "owner_id": state.owner.owner_id,
        "owner_username": state.owner.username,
        "node_id": state.node.node_id,
        "node_alias": state.node.alias,
        "node_status": state.node.status,
        "enc_pubkey": state.node.enc_pubkey,
        "center": {
            "base": state.center.base,
            "owner_id": state.center.owner_id,
            "claimed_at": state.center.claimed_at,
        },
        "agents": [
            {"agent_id": agent.agent_id, "name": agent.display_name, "status": agent.status}
            for agent in state.agents
        ],
    }
