#!/usr/bin/env node
// S4-② 自检：LAN 直连（点对点，数据不过中心）——同机起两个 daemon 模拟两台机器
// 判据：① 已批准好友：直连成功且对方信息由**对方节点**返回 ② 直连后**中心房间日志为 0**（数据面零中心）
//      ③ 未批准：信令阶段即被拒（拿不到 endpoint）④ 本节点 direct_hits 计数递增
import { spawn } from "node:child_process";
import fs from "node:fs"; import os from "node:os"; import path from "node:path";
const C = process.env.BASE || "https://dev.alice.loomsci.com";
const tag = Math.random().toString(36).slice(2, 6);
const A_ID = `lan-${tag}/a`, B_ID = `lan-${tag}/b`, C_ID = `lan-${tag}/c`;
let PASS = 0, FAIL = 0;
const ck = (n, c, d = "") => { console.log(`  [${c ? "PASS" : "FAIL"}] ${n}${d ? `  (${d})` : ""}`); c ? PASS++ : FAIL++; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const post = async (p, b) => (await fetch(C + p, { method: "POST", headers: { "content-type": "application/json", "user-agent": "alice-selftest/0.1" }, body: JSON.stringify(b) })).json();
const get = async (p) => (await fetch(C + p, { headers: { "user-agent": "alice-selftest/0.1" } })).json();

function startDaemon(port, id) {
  return new Promise((res, rej) => {
    const home = fs.mkdtempSync(path.join(os.tmpdir(), "alice-lan-"));
    const p = spawn(process.execPath, ["client/daemon.mjs", "--center", C, "--port", String(port), "--home", home, "--id", id], { stdio: ["ignore", "pipe", "pipe"] });
    let out = ""; p.stdout.on("data", (b) => { out += b; const m = out.match(/token=([0-9a-f-]{36})/); if (m) res({ p, port, token: m[1] }); });
    p.stderr.on("data", (b) => { out += b; }); setTimeout(() => rej(new Error("超时 " + out.slice(-150))), 15000);
  });
}
// ★ 第二个参数是 **cookie**（首请求用 token 换 cookie；此后一律带 cookie）
const jpost = async (port, cookie, p, b) => {
  const h = { "content-type": "application/json" };
  if (cookie && cookie.startsWith("alice_session=")) h.cookie = cookie;
  const url = cookie && cookie.startsWith("alice_session=") === false
    ? `http://127.0.0.1:${port}${p}?token=${cookie}` : `http://127.0.0.1:${port}${p}`;
  const r = await fetch(url, { method: "POST", headers: h, body: JSON.stringify(b ?? {}) });
  let j = null; try { j = await r.json(); } catch {}
  return { status: r.status, j, cookie: (r.headers.get("set-cookie") ?? "").split(";")[0] };
};
const jget = async (port, p, cookie) => {
  const r = await fetch(`http://127.0.0.1:${port}${p}`, { headers: cookie ? { cookie } : {} });
  let j = null; try { j = await r.json(); } catch {}
  return { status: r.status, j };
};

console.log("[0] 造数据（dev 钩子）：两队 + 成员 + 好友（A↔B 批准；C 不加）");
await post("/team/create", { id: `lan-${tag}-1`, name: "LAN-1", owner_human: `lan-${tag}-1/human` });
await post("/team/create", { id: `lan-${tag}-2`, name: "LAN-2", owner_human: `lan-${tag}-2/human` });
// ★ 批准权归"目标队的真人" → 必须把两队真人**也建成成员**（此前漏了，导致批准无效）
await post("/member/add", { id: `lan-${tag}-1/human`, team_id: `lan-${tag}-1`, kind: "human" });
await post("/member/add", { id: `lan-${tag}-2/human`, team_id: `lan-${tag}-2`, kind: "human" });
for (const [id, team] of [[A_ID, `lan-${tag}-1`], [B_ID, `lan-${tag}-2`], [C_ID, `lan-${tag}-2`]]) {
  await post("/member/add", { id, team_id: team, kind: "agent", endpoint: "" });
}
console.log("[1] 起两个 daemon（随机端口，**局域网监听默认开启**）");
const PA = 8900 + Math.floor(Math.random() * 200), PB = PA + 1;   // 随机端口，避免残留占用
const da = await startDaemon(PA, A_ID), db = await startDaemon(PB, B_ID);
await sleep(800);
const meA = await jget(PA, "/api/me", "");   // 探活（无 token 应 401）
ck("A 未授权访问被拒", meA.status === 401);
const hiA = await jpost(PA, da.token, "/api/hello", {}); const ckA = hiA.cookie;
const hiB = await jpost(PB, db.token, "/api/hello", {}); const ckB = hiB.cookie;
ck("两节点均向中心握手成功", hiA.j?.ok === true && hiB.j?.ok === true);
const infoB = await jget(PB, "/peer/info", ckB);
ck("B 暴露自身直连身份", infoB.j?.direct === true && infoB.j?.id === B_ID, infoB.j?.local);

console.log("[2] 未批准 → 信令阶段即被拒（拿不到 endpoint）");
const bad = await jpost(PA, ckA, "/peer/connect", { peer_id: C_ID });
ck("未批准好友：直连被拒（stage=signal）", bad.j?.ok === false && bad.j?.stage === "signal", `status=${bad.status} ${bad.j?.error}`);
console.log("[2b] ★ 局域网监听开关验证：--no-lan 时局域网 IP 不可达");
const homeNL = fs.mkdtempSync(path.join(os.tmpdir(), "alice-nolan-"));
const PNL = PB + 2;
const pnl = spawn(process.execPath, ["client/daemon.mjs", "--center", C, "--port", String(PNL), "--home", homeNL, "--id", `${tag}/nolan`, "--no-lan"], { stdio: ["ignore", "pipe", "pipe"] });
let outNL = ""; pnl.stdout.on("data", (b) => { outNL += b; });
await sleep(1500);
let lanBlocked = false;
try { await fetch(`http://${infoB.j.local}/peer/info`, { headers: { "user-agent": "alice-selftest/0.1" } }); }
catch { lanBlocked = false; }
const infoNL = await (async () => { try { const r = await fetch(`http://127.0.0.1:${PNL}/peer/info`); return await r.json(); } catch { return null; } })();
ck("--no-lan：仅本机可访问（局域网应不可达）", !!infoNL && outNL.includes("已关闭"), outNL.split("\n").filter((x) => x.includes("绑定"))[0] ?? "");
pnl.kill("SIGKILL");

console.log("[3] 真人批准 A↔B 后 → 直连成功（数据不过中心）");
const rq = await post("/friend/request", { from: A_ID, to: B_ID });
await post("/friend/decide", { id: rq.id, by: `lan-${tag}-2/human`, approve: true });
const sigB = await get(`/signal?id=${encodeURIComponent(A_ID)}&to=${encodeURIComponent(B_ID)}`);
console.log(`  [diag] 信令: HTTP? ok=${sigB.ok} endpoint=${sigB.endpoint} error=${sigB.error}`);
const conn = await jpost(PA, ckA, "/peer/connect", { peer_id: B_ID });
console.log(`  [diag] 直连响应: HTTP ${conn.status} body=${JSON.stringify(conn.j).slice(0, 160)}`);
ck("直连成功", conn.j?.ok === true && conn.j?.via === "direct", `stage=${conn.j?.stage ?? "-"} endpoint=${conn.j?.endpoint} err=${conn.j?.err ?? "-"}`);
ck("★ 对方信息由**对方节点**返回（非中心）", conn.j?.peer?.direct === true && conn.j?.peer?.id === B_ID, JSON.stringify(conn.j?.peer ?? null).slice(0, 60));
const dm = await post("/conversations/dm", { me: A_ID, peer: B_ID });
const pk = await get(`/rooms/${dm.room_id}/peek`);
ck("★ 中心房间日志为 0（数据面零中心）", (pk.log ?? []).length === 0, `n=${(pk.log ?? []).length}`);
const st = await jget(PA, "/local/stats", ckA);
ck("本节点 direct_hits 递增", (st.j?.direct_hits ?? 0) >= 1, `hits=${st.j?.direct_hits}`);
da.p.kill("SIGKILL"); db.p.kill("SIGKILL");
console.log(`  ---- PASS=${PASS} FAIL=${FAIL} ----`);
console.log(FAIL === 0 ? "  ✅ S4-② LAN 直连自检通过" : "  ❌ S4-② 自检失败");
process.exit(FAIL === 0 ? 0 : 1);
