#!/usr/bin/env node
// S2 自检：本地 daemon（127.0.0.1 + 一次性 token + 私钥本地持久化 + 中心握手）
// 判据：① 无 token → 401 ② 带 token → 200 且拿到自己的 id/公钥 ③ **token 一次性**（复用即 401）
//      ④ 轮换后的 cookie 可用 ⑤ 中心握手成功且目录可见 ⑥ 私钥文件 0600 且**中心侧无任何私钥材料**
//      ⑦ 重启后 **id/公钥不变**（持久化） ⑧ 只监听 127.0.0.1（局域网卡不监听）
import { spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const CENTER = process.env.BASE || "https://dev.alice.loomsci.com";
const PORT = 8797 + Math.floor(Math.random() * 200);
const HOME = fs.mkdtempSync(path.join(os.tmpdir(), "alice-daemon-"));
const ID = `selftest/daemon-${Math.random().toString(36).slice(2, 7)}`;
let PASS = 0, FAIL = 0;
const ck = (n, c, d = "") => { console.log(`  [${c ? "PASS" : "FAIL"}] ${n}${d ? `  (${d})` : ""}`); c ? PASS++ : FAIL++; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function startDaemon() {
  return new Promise((resolve, reject) => {
    const p = spawn(process.execPath, ["client/daemon.mjs", "--center", CENTER, "--port", String(PORT), "--home", HOME, "--id", ID],
      { cwd: path.resolve("."), stdio: ["ignore", "pipe", "pipe"] });
    let out = "";
    const onData = (b) => {
      out += b.toString();
      const m = out.match(/token=([0-9a-f-]{36})/);
      if (m) resolve({ proc: p, token: m[1], out: () => out });
    };
    p.stdout.on("data", onData);
    p.stderr.on("data", (b) => { out += b.toString(); });
    p.on("exit", (c) => reject(new Error(`daemon exited ${c}: ${out.slice(-200)}`)));
    setTimeout(() => reject(new Error("daemon 启动超时: " + out.slice(-200))), 15000);
  });
}
const get = async (p, cookie) => {
  const r = await fetch(`http://127.0.0.1:${PORT}${p}`, { headers: cookie ? { cookie } : {} });
  let j = null; try { j = await r.json(); } catch { j = null; }
  return { status: r.status, j, setCookie: r.headers.get("set-cookie") };
};

console.log("[1] 启动 daemon（本机 127.0.0.1）");
const d1 = await startDaemon();
await sleep(400);
ck("终端打印了一次性 token 入口", /token=[0-9a-f-]{36}/.test(d1.out()));

console.log("[2] 无 token → 401；带 token → 200");
const noTok = await get("/api/me");
ck("无 token 被拒（401）", noTok.status === 401, `status=${noTok.status}`);
const withTok = await get(`/api/me?token=${d1.token}`);
ck("带 token 通过（200）", withTok.status === 200, `status=${withTok.status}`);
ck("返回自己的 id", withTok.j?.id === ID);
const pub = withTok.j?.pubkey ?? "";
ck("返回自己的公钥（非空）", typeof pub === "string" && pub.length > 20);
ck("响应里不含私钥材料（jwk 的 d 字段）", !JSON.stringify(withTok.j ?? {}).includes('"d"'));

console.log("[3] token 一次性：复用同一个 token 必须失败；cookie 可用");
const reuse = await get(`/api/me?token=${d1.token}`);
ck("旧 token 复用 → 401（已轮换）", reuse.status === 401, `status=${reuse.status}`);
const cookie = (withTok.setCookie ?? "").split(";")[0];
const byCookie = await get("/api/me", cookie);
ck("轮换后的 cookie 可用", byCookie.status === 200, `status=${byCookie.status}`);

console.log("[4] 中心握手 + 在线目录");
const hi = await get("/api/hello", cookie);
ck("向中心握手成功", hi.j?.ok === true, JSON.stringify(hi.j).slice(0, 80));
// ★ 目录语义＝**排除自己**，所以用另一个"探针"来验证可见性（此前我误断言"看到自己"，是我的用例错）
const probePub = "PROBE-" + Math.random().toString(36).slice(2, 10);
await fetch(`${CENTER}/hello`, { method: "POST", headers: { "content-type": "application/json", "user-agent": "alice-selftest/0.1" },
  body: JSON.stringify({ id: `selftest/probe-${Math.random().toString(36).slice(2, 7)}`, kind: "agent", pubkey: probePub }) });
const peers = await get("/api/peers", cookie);
ck("目录里能看到另一个在线节点", (peers.j?.peers ?? []).some((p) => p.pubkey === probePub), `n=${(peers.j?.peers ?? []).length}`);
ck("目录里不含自己（语义正确）", !(peers.j?.peers ?? []).some((p) => p.pubkey === pub));

console.log("[5] 私钥本地化：文件 0600，且中心侧只有公钥");
const f = path.join(HOME, "device.json");
const mode = (fs.statSync(f).mode & 0o777).toString(8);
ck("私钥文件存在且权限 0600", mode === "600", `mode=${mode}`);
const centerPeers = await (await fetch(`${CENTER}/peers?id=x`)).json();
const mine = (centerPeers.peers ?? []).find((p) => p.id === ID);
ck("中心侧有我的公钥", mine?.pubkey === pub);
ck("中心侧响应不含私钥材料", !JSON.stringify(centerPeers).includes('"d"'));

console.log("[6] 重启后 id/公钥不变（持久化）");
d1.proc.kill("SIGKILL");
await sleep(400);
const d2 = await startDaemon();
await sleep(400);
const me2 = await get(`/api/me?token=${d2.token}`);
ck("重启后 id 不变", me2.j?.id === ID);
ck("重启后公钥不变（同一设备身份）", me2.j?.pubkey === pub);
d2.proc.kill("SIGKILL");

console.log(`  ---- PASS=${PASS} FAIL=${FAIL} ----`);
console.log(FAIL === 0 ? "  ✅ S2 daemon 自检通过" : "  ❌ S2 daemon 自检失败");
process.exit(FAIL === 0 ? 0 : 1);
