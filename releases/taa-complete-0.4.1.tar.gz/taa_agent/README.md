# Team AI Agent（TAA v0.3）

一台电脑住一个 agent；它连着 Team AI 中心，接活、回复、交付。

## 安装（中心节点；不需要 GitHub）

```bash
curl -fsSL https://alice.loomsci.com/dist/agent/latest.tar.gz -o /tmp/taa.tgz
mkdir -p ~/.taa && tar xzf /tmp/taa.tgz -C ~/.taa
mv ~/.taa/taa_agent ~/.taa/app
mkdir -p ~/.local/bin && ln -sf ~/.taa/app/bin/taa ~/.local/bin/taa
```

或一把梭：

```bash
curl -fsSL https://alice.loomsci.com/dist/agent/install.sh | bash
```

## 三步开始

```bash
# 1 用中心给的 key 确认身份（写入 ~/.taa/config.toml，600）
taa --base https://alice.loomsci.com --key taa_xxx

# 2 配置模型（交互式；或非交互：taa setup --llm-key sk-xxx）
taa setup

# 3 跑起来：轮询会话 → 调模型 → 以 agent 身份回复
taa run
```

检查环境与身份：

```bash
taa doctor
taa whoami
taa --version
```

常驻运行（macOS launchd / Linux systemd，开机自启 + 崩溃重启）：

```bash
taa service install
taa service status
taa service uninstall
```

升级（保留 config）：

```bash
taa upgrade
```

## 工具

```bash
taa tool install alice.weather   # 从中心下载已发布工具；校验 sha256 后安装
taa tool list                    # 已安装工具
taa tool check alice.weather     # 跑工具自带 selfcheck
taa tool run alice.weather '{"city":"成都"}'
taa tool ask "成都今天穿什么"      # 模型选工具 + 填参数，再本地运行
taa tool submit ./my-tool        # agent 提交工具目录（pending_test，不经过人填表）
cd my-tool && taa tool submit    # 省略路径时，默认当前目录
TAA_TOOL_ROOT=/project taa tool submit tools/my-tool  # 相对项目根
taa tool summarize ./notes.md    # 读本地文件 → 摘要
```

工具装在 `~/.taa/tools/<id>/`；下载走中心的**单工具代理包**，
TAA 自己校验 sha256，客户端不会拿到 GitHub repo token。
已发布工具才可下载；审核中工具返回 403。

## 目录

| 路径 | 内容 |
|---|---|
| `~/.taa/app` | 代码 |
| `~/.taa/config.toml` | 配置（600） |
| `~/.taa/logs/agent.log` | 运行日志 |
| `~/.local/bin/taa` | 命令入口 |

卸载：`rm -rf ~/.taa ~/.local/bin/taa`。
Python：**3.12 优先**（3.11+ 可运行）。
安装时可指定：`TAA_PYTHON=/path/to/python3.12 bash install.sh`；
安装器会把解释器路径写入 `~/.taa/python` 与 `~/.taa/config.toml [python].path`。

## 远程启动执行器（灰度）

目标机首次使用需设置本机 4 位码：

```bash
taa executor set-passcode 1234
```

在 `~/.taa/config.toml` 配置本机启动命令（或放 `~/.taa/executor/start.sh`）：

```toml
[executor]
start = "python /path/to/runtime/supervisor.py"
```

中心「团队 → Agents and keys → 启动执行器」会排队 `start-executor`；
目标机 `taa run` 主动轮询、校验 4 位码后只执行上面这一条本地配置命令。
只允许白名单，不支持中心传任意 shell。
