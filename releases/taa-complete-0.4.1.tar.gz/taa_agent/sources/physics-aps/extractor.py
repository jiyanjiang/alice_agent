"""physics.aps.org 抽取器（**每站定制**：选择器链 + 清洗）。

已知坑（实测，见 `spec.md`）：
  ① 页面尾部/侧栏有独立的 `<time>`（"最新文章"）→ **`article time` 优先**，否则取错日期；
  ② 正文有"摘要 + 正文"两段 → 取 article 内全部段落，逐段保留；
  ③ 相关推荐在 `<aside>` 里 → 文本抽取时整体跳过 aside。

2026-10-14 重写：改用 `core/extractor_kit` + `core/simple_dom`（真 DOM）。
"""
from __future__ import annotations

import sys
from pathlib import Path

try:
    from core.extractor_kit import extract_article
except ImportError:                                   # 被按文件路径加载且 ROOT 不在 sys.path 时
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from core.extractor_kit import extract_article

VERSION = "aps-3"

TITLE_CHAIN = ["h1.article-title", "h1.title", "article h1", "h1"]
DATE_CHAIN = ["meta[property=article:published_time]", "meta[name=date]", "article time", ".article-metadata time", "time"]
BYLINE_CHAIN = [".article-authors", ".authors", ".byline"]
BODY_CHAIN = ["article .entry-content", "article .article-body", "article .content", ".entry-content", "article", "main"]


def extract(html: str, url: str = "") -> dict:
    return extract_article(html, url, source_id="physics-aps", version=VERSION,
                           title_chain=TITLE_CHAIN, date_chain=DATE_CHAIN,
                           byline_chain=BYLINE_CHAIN, body_chain=BODY_CHAIN)
