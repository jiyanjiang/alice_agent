# physics.aps.org 抽取规格（aps-1）

| 字段 | 选择器回退链 | 清洗 |
|---|---|---|
| title | `h1.article-title` → `h1.title` → `article h1` → `h1` | 去标签、合并空白 |
| published_at | `article time` → `.article-metadata time` → `time` | **优先 `time[datetime]` 属性** |
| byline | `meta[name=author]` → `.article-authors` → `.authors` | 逗号/分号/and 切分 |
| body | `article .article-body` → `article .content` → `article` → `main` | **剔除 `<aside>`（相关推荐）** + 丢弃 read more/related/subscribe… 的句子 |

**已知坑**（实测）：① 页面尾部/侧栏有独立的 `<time>`（"最新文章"）→ **必须用 `article time` 优先**，否则创刊/文章日期取错；
② APS 有"摘要+正文"两段，本实现取 article 内全部段落；
③ 相关推荐在 `<aside>` 里 → 先删 aside 再切句。
