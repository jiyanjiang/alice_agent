# physicsworld.com 抽取规格（v1）

| 字段 | 选择器回退链 | 清洗 |
|---|---|---|
| title | `h1.article-title` → `h1.title` → `article h1` → `h1` | 去标签、合并空白 |
| published_at | `article time` → `.meta time` → `time` → `.article-date` | 保留原样（含 4 位年即可过完整性门禁） |
| byline | `meta[name=author]` → `.byline` → `.author` | 逗号/分号/and 切分 |
| body | `article .article-body` → `article` → `main` → `.content` | **丢弃含 read more/related/subscribe/sign up/newsletter/share this 的句子** |

已知坑：① 全局 `time` 可能取到侧栏"最新文章"的时间 → 优先用 `article time`；
② 正文里混入推荐位 → 用 DROP 规则剔除；③ 付费墙 → 由 `core/capture_gate.py` 的 paywall 判据拦下（不在此处处理）。
