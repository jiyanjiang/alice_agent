"""physicsworld.com 抽取器（**每站定制**：选择器链 + 清洗）。

实物依据：`working/physics_scraper` 的做法。已知坑：
  ① 正文里混推荐位（"Read more about…"）→ 按句丢弃；
  ② 付费墙文本 → 由 `core/capture_gate.py` 拦（本抽取器不负责判定）；
  ③ 侧栏/文末有独立 `<time>` → **必须 `article time` 优先**，否则取到"最新文章"日期。

2026-10-14 重写：改用 `core/extractor_kit` + `core/simple_dom`（真 DOM），
修掉正则时代的三处系统性缺陷（嵌套标签/自闭合标签被吞、段落结构被抹平）。
"""
from __future__ import annotations

import sys
from pathlib import Path

try:
    from core.extractor_kit import extract_article
except ImportError:                                   # 被按文件路径加载且 ROOT 不在 sys.path 时
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from core.extractor_kit import extract_article

VERSION = "pw-3"   # 2026-10-14 按**真页**实测类名重定（原先拿自造样例调的，真站全不匹配）

# ★ 以下类名取自**真实页面**样本 sources/physicsworld/samples/real-desalination.html
TITLE_CHAIN = ["h1.single-header__heading", "h1.hero__title", "h1.article-title", "article h1", "h1"]
DATE_CHAIN = ["meta[property=article:published_time]", "meta[name=date]", "article time", "time"]
BYLINE_CHAIN = [".author-byline", ".byline", ".article-authors", ".author"]
BODY_CHAIN = ["article .entry-content", ".entry-content", "article .article-body", "article", "main"]


def extract(html: str, url: str = "") -> dict:
    return extract_article(html, url, source_id="physicsworld", version=VERSION,
                           title_chain=TITLE_CHAIN, date_chain=DATE_CHAIN,
                           byline_chain=BYLINE_CHAIN, body_chain=BODY_CHAIN)
