// 设备身份（本地持久化）——私钥只存本机文件（0600），只把公钥交给中心
// 说明：为能"持久化"，这里的私钥必须可导出（extractable=true）；但**导出只写入本机文件**，
//       从不随任何请求外发（`selftest_daemon.mjs` 断言中心侧响应中不含私钥材料）。
import fs from "node:fs";
import path from "node:path";
import { b64u } from "./e2e.mjs";

const FILE = "device.json";

export async function loadOrCreateDevice(home, id) {
  const dir = home;
  const file = path.join(dir, FILE);
  if (fs.existsSync(file)) {
    const saved = JSON.parse(fs.readFileSync(file, "utf8"));
    const priv = await crypto.subtle.importKey("jwk", saved.jwk, { name: "X25519" }, true, ["deriveBits"]);
    return { id: saved.id, priv, pubB64: saved.pubB64 };
  }
  const kp = await crypto.subtle.generateKey({ name: "X25519" }, true, ["deriveBits"]);
  const pub = new Uint8Array(await crypto.subtle.exportKey("raw", kp.publicKey));
  const jwk = await crypto.subtle.exportKey("jwk", kp.privateKey);
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  fs.writeFileSync(file, JSON.stringify({ id, pubB64: b64u.enc(pub), jwk }, null, 2), { mode: 0o600 });
  fs.chmodSync(file, 0o600);
  return { id, priv: kp.privateKey, pubB64: b64u.enc(pub) };
}

export const DEVICE_FILE = FILE;
