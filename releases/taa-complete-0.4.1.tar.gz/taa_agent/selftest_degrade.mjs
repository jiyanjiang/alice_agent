#!/usr/bin/env node
// S4-④ / C6 自检：中心不可用 → ① 退避重试（不打死循环）② 返回**本地缓存**且标 degraded
//                    ③ 节点**仍可用**（局域网/本地端点照常）④ 观测字段暴露
import { spawn } from "node:child_process";
import fs from "node:fs"; import os from "node:os"; import path from "node:path";
const tag = Math.random().toString(36).slice(2, 6);
const PORT = 9400 + Math.floor(Math.random() * 200);
let PASS = 0, FAIL = 0;
const ck = (n, c, d = "") => { console.log(`  [${c ? "PASS" : "FAIL"}] ${n}${d ? `  (${d})` : ""}`); c ? PASS++ : FAIL++; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

console.log("[1] 起 daemon，中心指向**死地址**（127.0.0.1:9）");
const home = fs.mkdtempSync(path.join(os.tmpdir(), "alice-dg-"));
const p = spawn(process.execPath, ["client/daemon.mjs", "--center", "http://127.0.0.1:9", "--port", String(PORT), "--home", home, "--id", `dg-${tag}/a`], { stdio: ["ignore", "pipe", "pipe"] });
const tok = await new Promise((res, rej) => { let o = ""; p.stdout.on("data", (b) => { o += b; const m = o.match(/token=([0-9a-f-]{36})/); if (m) res(m[1]); }); p.stderr.on("data", (b) => { o += b; }); setTimeout(() => rej(new Error("超时 " + o.slice(-120))), 15000); });
await sleep(500);
const U = (x) => `http://127.0.0.1:${PORT}${x}`;
let cookie = ""; const req = async (x) => { const r = await fetch(U(x), { headers: cookie ? { cookie } : {} }); const sc = r.headers.get("set-cookie"); if (sc) cookie = sc.split(";")[0]; let j = null; try { j = await r.json(); } catch {} return { status: r.status, j }; };

console.log("[2] 首次带 token 取 cookie + 触发一次中心调用");
const first = await req(`/api/peers?token=${tok}`);
ck("降级仍返回 200（不报错）", first.status === 200);
ck("★ 标记 degraded=true", first.j?.degraded === true, JSON.stringify(first.j).slice(0, 90));
ck("返回本地缓存数组（可为空）", Array.isArray(first.j?.peers), `peers=${(first.j?.peers ?? []).length}`);

console.log("[3] ★ 退避：一次降级调用耗时应 ≥ 退避总和（150+450+900≈1.5s，非打死循环）");
const t0 = Date.now(); await req("/api/peers"); const dt = Date.now() - t0;
ck("耗时符合退避（≥1s 且 <5s）", dt >= 1000 && dt < 5000, `${dt}ms`);

console.log("[4] 节点仍可用：本地端点照常");
const info = await req("/peer/info");
ck("局域网身份仍可访问（200）", info.status === 200 && info.j?.direct === true);
const cfg = await req("/api/config");
ck("观测字段暴露（degraded / center_failures）", cfg.j?.degraded === true && (cfg.j?.center_failures ?? 0) >= 1, JSON.stringify(cfg.j).slice(0, 120));

p.kill("SIGKILL");
console.log(`  ---- PASS=${PASS} FAIL=${FAIL} ----`);
console.log(FAIL === 0 ? "  ✅ C6 降级自检通过" : "  ❌ C6 降级自检失败");
process.exit(FAIL === 0 ? 0 : 1);
