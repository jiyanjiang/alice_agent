"""工具层：内核只定接口 + 注册表；具体工具可插拔。

用法：
    from app import tool
    tool.get("media.search").call("bob", {"query": "..."})
    tool.catalog()      # 供 LLM 选择
"""
from __future__ import annotations

from .base import Tool
from .registry import catalog, get, names, register
from . import builtin  # noqa: F401  （注册内置能力）
from . import user_tools  # noqa: F401  （加载 tools/<name>/tool.py 工具包）

__all__ = ["Tool", "register", "get", "names", "catalog", "user_tools"]
