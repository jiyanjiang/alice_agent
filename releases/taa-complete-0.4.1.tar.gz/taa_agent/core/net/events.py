"""事件溯源（S4）：append-only 事件日志 + 确定性折叠。

对等、无选主：
- 每个节点本地 append 事件（带 Lamport 逻辑时钟 + node_id）。
- 状态 = 对"合并后事件集"按 (lamport, id) 排序后**确定性折叠**。
- 冲突（如两个 agent 同时认领同一任务）= **最小 (lamport, id) 先到者胜**，结果可复现。
"""
from __future__ import annotations

import functools
import hashlib
import json
import sqlite3
import threading
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
  id      TEXT PRIMARY KEY,        -- 全局唯一：sha1(node|seq|type|payload|ts)
  lamport INTEGER NOT NULL,
  node_id TEXT NOT NULL,
  type    TEXT NOT NULL,
  payload TEXT NOT NULL,
  ts      REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_lamport ON events(lamport, id);
CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
"""


def _eid(node_id: str, seq: int, type_: str, payload: dict, ts: float) -> str:
    raw = f"{node_id}|{seq}|{type_}|{json.dumps(payload, sort_keys=True, ensure_ascii=False)}|{ts}"
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:20]


def _synchronized(fn):
    """串行化同一 EventLog 连接上的所有访问。

    Flask 工作线程与 gossip 后台线程共用同一个 `_NODE_LOG` 单例（见 `server._node_log`
    与 `net.gossip.Gossip._sync`），而 sqlite 连接本身非线程安全。用 RLock 串行化，
    避免间歇性的
    `SQLite objects created in a thread can only be used in that same thread` / 500。
    """
    @functools.wraps(fn)
    def wrapper(self, *args, **kwargs):
        with self._lock:
            return fn(self, *args, **kwargs)
    return wrapper


class EventLog:
    def __init__(self, path: str | Path, node_id: str):
        self.path = Path(path)
        self.node_id = node_id
        # 多线程共享同一连接（server._node_log 单例 + gossip 后台线程）：
        # 放开 sqlite 线程检查，并用 RLock 串行化（见 _synchronized）。
        self.conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._lock = threading.RLock()
        with self._lock:
            self.conn.executescript(SCHEMA)
            self.conn.commit()
        self._seq = 0

    # ---------------- 本地写 ----------------
    @_synchronized
    def _lamport(self) -> int:
        row = self.conn.execute("SELECT v FROM meta WHERE k='lamport'").fetchone()
        return int(row["v"]) if row else 0

    @_synchronized
    def _set_lamport(self, v: int) -> None:
        self.conn.execute("INSERT INTO meta(k,v) VALUES('lamport',?) "
                          "ON CONFLICT(k) DO UPDATE SET v=excluded.v", (str(v),))

    @_synchronized
    def append(self, type_: str, payload: dict, lamport: int | None = None) -> dict:
        """本地追加一条事件；lamport 取 max(本地, 外部)+1。"""
        self._seq += 1
        lam = (max(self._lamport(), lamport or 0) + 1)
        ts = time.time()
        eid = _eid(self.node_id, self._seq, type_, payload, ts)
        self.conn.execute("INSERT OR IGNORE INTO events(id,lamport,node_id,type,payload,ts) "
                          "VALUES (?,?,?,?,?,?)",
                          (eid, lam, self.node_id, type_, json.dumps(payload, ensure_ascii=False), ts))
        self._set_lamport(lam)
        self.conn.commit()
        return {"id": eid, "lamport": lam, "node_id": self.node_id, "type": type_,
                "payload": payload, "ts": ts}

    # ---------------- 合并（来自 gossip）----------------
    @_synchronized
    def merge(self, events: list[dict]) -> int:
        """并入外部事件；按 id 去重；推进本地 lamport。返回新增数。"""
        n, hi = 0, self._lamport()
        for e in events:
            cur = self.conn.execute("INSERT OR IGNORE INTO events(id,lamport,node_id,type,payload,ts) "
                                    "VALUES (?,?,?,?,?,?)",
                                    (e["id"], e["lamport"], e["node_id"], e["type"],
                                     json.dumps(e["payload"], ensure_ascii=False), e["ts"]))
            if cur.rowcount:
                n += 1
            hi = max(hi, int(e["lamport"]))
        if n:
            self._set_lamport(hi)
            self.conn.commit()
        return n

    # ---------------- 读 ----------------
    @_synchronized
    def all(self) -> list[dict]:
        rows = self.conn.execute("SELECT * FROM events ORDER BY lamport, id").fetchall()
        return [{"id": r["id"], "lamport": r["lamport"], "node_id": r["node_id"], "type": r["type"],
                 "payload": json.loads(r["payload"]), "ts": r["ts"]} for r in rows]

    @_synchronized
    def since(self, lamport: int = 0) -> list[dict]:
        rows = self.conn.execute("SELECT * FROM events WHERE lamport>? ORDER BY lamport, id",
                                 (int(lamport),)).fetchall()
        return [{"id": r["id"], "lamport": r["lamport"], "node_id": r["node_id"], "type": r["type"],
                 "payload": json.loads(r["payload"]), "ts": r["ts"]} for r in rows]

    @_synchronized
    def lamport(self) -> int:
        return self._lamport()


# ------------------------------------------------------------------ 折叠（确定性状态）
def _apply(state: dict, e: dict) -> None:
    t, p = e["type"], e["payload"]
    tasks = state["tasks"]
    if t == "task.created":
        tasks.setdefault(p["id"], {"id": p["id"], "title": p.get("title", ""),
                                   "status": "backlog", "assigned_to": None})
    elif t == "task.claimed":
        task = tasks.setdefault(p["task_id"], {"id": p["task_id"], "status": "backlog", "assigned_to": None})
        if task.get("assigned_to") is None:          # 最小 (lamport,id) 先到者胜
            task["assigned_to"] = p["agent"]
            task["status"] = "claimed"
    elif t == "task.started":
        task = tasks.get(p["task_id"])
        if task and task.get("assigned_to") == p["agent"]:
            task["status"] = "in_progress"
    elif t == "task.submitted":
        task = tasks.get(p["task_id"])
        if task and task.get("assigned_to") == p["agent"]:
            task["status"] = "review"
    elif t == "task.done":
        task = tasks.get(p["task_id"])
        if task:
            task["status"] = "done"
    elif t == "post.created":
        state["posts"].append({"id": p["id"], "author": p.get("author"), "channel": p.get("channel"),
                               "body": p.get("body", "")})
    elif t == "room.message":
        state["messages"].append({"room_id": p["room_id"], "agent": p.get("agent"),
                                  "body": p.get("body", ""), "round": p.get("round")})
    elif t == "agent.enrolled":
        state["agents"][p["id"]] = {"id": p["id"], "name": p.get("name", p["id"])}
    elif t == "node.heartbeat":
        state["nodes"][p["node_id"]] = {"node_id": p["node_id"], "addr": p.get("addr"),
                                        "lamport": e["lamport"]}


def fold(events: list[dict]) -> dict:
    """对事件集做确定性折叠（先按 (lamport, id) 排序）。"""
    state = {"tasks": {}, "posts": [], "messages": [], "agents": {}, "nodes": {}}
    for e in sorted(events, key=lambda x: (x["lamport"], x["id"])):
        _apply(state, e)
    return state
