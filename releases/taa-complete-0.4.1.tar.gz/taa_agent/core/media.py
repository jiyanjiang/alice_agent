"""媒体工具：Bing 搜图 / 火山方舟文生图 / 本地图库 / 网页截图。

密钥来源（优先级）：环境变量（ARK_API_KEY / DASHSCOPE_API_KEY）> 项目 `config.yaml`
的 `providers.ark_api_key` / `providers.dashscope_api_key` > 本地 `~/Downloads/working/api-key.txt`
（+ Loom_City/config.yaml 兜底）。`ark_model` / `ark_endpoint` 同样走 config。
生成/下载的图片落到 static/uploads，返回可放进聊天室的 URL。
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import re
import tarfile
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

from . import redaction

ROOT = Path(__file__).resolve().parent.parent
UPLOAD_DIR = ROOT / "static" / "uploads"

# 可上传附件类型（图片 + 文档/数据/压缩包；db 允许，但须过隐私扫描）
UPLOAD_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg",
               ".mp4", ".webm", ".mov", ".m4v",
               ".md", ".txt", ".csv", ".tsv", ".json", ".yaml", ".yml", ".log",
               ".pdf", ".zip", ".tar", ".gz", ".tgz", ".db", ".sqlite", ".sqlite3",
               ".docx", ".xlsx", ".pptx"}
TEXT_EXTS = {".md", ".txt", ".csv", ".tsv", ".json", ".yaml", ".yml", ".log", ".svg"}
UPLOAD_MAX = 50 * 1024 * 1024          # 50MB
KEY_FILE = Path.home() / "Downloads" / "working" / "api-key.txt"
LOOM_CFG = Path.home() / "Downloads" / "Loom_City" / "config.yaml"
LOCAL_IMAGE_DIRS = [Path.home() / "Downloads" / "reddit" / "images",
                    Path.home() / "Downloads" / "reddit" / "downloads"]

ARK_ENDPOINT = "https://ark.cn-beijing.volces.com/api/v3/images/generations"
ARK_MODEL = "doubao-seedream-4-5-251128"
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")


def _read_key_file() -> dict:
    out = {}
    if not KEY_FILE.exists():
        return out
    txt = KEY_FILE.read_text(errors="ignore")
    for line in txt.splitlines():
        s = line.strip()
        m = re.search(r"(sk-[A-Za-z0-9]{16,})", s)
        if m and "阿里" in s or (m and ("Tongyi" in s)):
            out.setdefault("dashscope", m.group(1))
        if m and "DeepSeek" in s:
            out["deepseek"] = m.group(1)
        if s.startswith("api-key-"):
            for c in [x.strip().strip('"').strip("'") for x in s.split("|")]:
                if re.match(r"^[0-9a-fA-F-]{32,}$", c) and c.count("-") == 4:
                    out["ark"] = c
        if "AIzaSy" in s:
            mm = re.search(r"(AIzaSy[A-Za-z0-9_\-]{20,})", s)
            if mm:
                out["google"] = mm.group(1)
    # 兜底：Loom_City/config.yaml 的 deepseek
    if "deepseek" not in out and LOOM_CFG.exists():
        mm = re.search(r'deepseek_api_key:\s*"([^"]+)"', LOOM_CFG.read_text(errors="ignore"))
        if mm:
            out["deepseek"] = mm.group(1)
    return out


def _cfg_provider(field: str, env: str, default=None):
    """读项目 config.yaml 的 `providers.<field>`；环境变量优先（config.get 已处理）。

    只读 config.yaml / 环境变量，不碰本地 api-key 文件（那由 `_read_key_file` 兜底）。
    """
    try:
        from . import config as _config
        return _config.get(f"providers.{field}", default, env=env)
    except Exception:
        return default


def _resolve_keys() -> dict:
    """优先级：环境变量 > config.yaml `providers.*` > 本地 api-key 文件。"""
    out = _read_key_file()
    for name, field, env in (("ark", "ark_api_key", "ARK_API_KEY"),
                             ("dashscope", "dashscope_api_key", "DASHSCOPE_API_KEY")):
        v = _cfg_provider(field, env)
        if v:
            out[name] = str(v).strip()
    # 设置页写入 ~/.taa/config.toml 的 [llm] Key 也要生效。
    try:
        from . import config as _config
        if not out.get("ark") and _config.volcano_key():
            out["ark"] = _config.volcano_key()
        if not out.get("dashscope") and _config.alibaba_key():
            out["dashscope"] = _config.alibaba_key()
    except Exception:
        pass
    return out


KEYS = _resolve_keys()


def has_key(name: str) -> bool:
    return bool(_resolve_keys().get(name))


def _save_bytes(data: bytes, ext: str = ".png") -> str:
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    name = hashlib.sha256(data).hexdigest()[:16] + ext
    (UPLOAD_DIR / name).write_bytes(data)
    return f"/static/uploads/{name}"


def _scan_upload(data: bytes, ext: str) -> dict:
    """对上传内容做隐私扫描：文本直扫；zip/tar 扫成员名+抽检文本；二进制扫原始字节。"""
    findings: list[dict] = []
    if ext in TEXT_EXTS:
        findings += redaction.scan(data[:400000].decode("utf-8", "ignore"))["findings"]
    elif ext == ".zip":
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                for n in z.namelist()[:200]:
                    findings += redaction.scan(n)["findings"]
                    try:
                        chunk = z.read(n)[:200000]
                    except Exception:
                        continue
                    enc = "utf-8" if os.path.splitext(n)[1].lower() in TEXT_EXTS else "latin-1"
                    findings += redaction.scan(chunk.decode(enc, "ignore"))["findings"]
        except Exception:
            pass
    elif ext in (".tar", ".gz", ".tgz"):
        try:
            with tarfile.open(fileobj=io.BytesIO(data)) as t:
                for m in t.getmembers()[:200]:
                    findings += redaction.scan(m.name)["findings"]
                    if m.isfile():
                        f = t.extractfile(m)
                        if f:
                            enc = "utf-8" if os.path.splitext(m.name)[1].lower() in TEXT_EXTS else "latin-1"
                            findings += redaction.scan(f.read(200000).decode(enc, "ignore"))["findings"]
        except Exception:
            pass
    else:  # 二进制（db/pdf/docx…）：原始字节扫高危模式
        findings += redaction.scan(data[:400000].decode("latin-1", "ignore"))["findings"]
    counts = {"high": 0, "medium": 0, "low": 0}
    for f in findings:
        counts[f["level"]] += 1
    return {"counts": counts, "findings": findings}


def save_upload(data: bytes, filename: str, *, allow_risky: bool = False) -> dict:
    """保存一个通用附件（图片/文档/数据/压缩包）。含类型/大小/隐私门禁。

    allow_risky=True 时，即使命中 high 风险也放行（但会在返回值里标记 risky，供审计/质检）。
    """
    ext = os.path.splitext(filename or "")[1].lower()
    if ext not in UPLOAD_EXTS:
        raise ValueError(f"unsupported type: {ext or '(none)'}")
    if len(data) > UPLOAD_MAX:
        raise ValueError(f"too large ({len(data)} > {UPLOAD_MAX})")
    rep = _scan_upload(data, ext)
    if rep["counts"]["high"] > 0 and not allow_risky:
        raise ValueError(f"redaction: {rep['counts']['high']} high-risk hit in file (denied)")
    url = _save_bytes(data, ext)
    return {"url": url, "name": filename, "ext": ext, "size": len(data),
            "high": rep["counts"]["high"], "medium": rep["counts"]["medium"],
            "risky": rep["counts"]["high"] > 0}


def _fetch(url: str, timeout: int = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": url})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def download_image(url: str) -> str:
    """下载网络图片到 static/uploads，返回本地 URL。"""
    data = _fetch(url, timeout=60)
    ext = os.path.splitext(urllib.parse.urlparse(url).path)[1].lower()
    if ext not in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
        ext = ".jpg"
    return _save_bytes(data, ext)


# ------------------------------------------------------------------ 火山方舟文生图
def _ark_model() -> str:
    return str(_cfg_provider("ark_model", "ARK_MODEL", ARK_MODEL) or ARK_MODEL)


def _ark_endpoint() -> str:
    return str(_cfg_provider("ark_endpoint", "ARK_ENDPOINT", ARK_ENDPOINT) or ARK_ENDPOINT)


def ark_generate(prompt: str, size: str = "2K") -> str:
    key = _resolve_keys().get("ark")
    if not key:
        raise RuntimeError("未找到火山方舟密钥：请设环境变量 ARK_API_KEY，或 config.yaml "
                           "providers.ark_api_key，或写入 ~/Downloads/working/api-key.txt")
    body = json.dumps({
        "model": _ark_model(), "prompt": prompt, "response_format": "url",
        "size": size, "watermark": False, "sequential_image_generation": "disabled",
        "stream": False,
    }).encode("utf-8")
    req = urllib.request.Request(_ark_endpoint(), data=body, method="POST", headers={
        "Content-Type": "application/json", "Authorization": f"Bearer {key}"})
    with urllib.request.urlopen(req, timeout=180) as r:
        d = json.loads(r.read().decode())
    items = d.get("data") or []
    if not items:
        raise RuntimeError(f"Ark 未返回图片：{str(d)[:200]}")
    return download_image(items[0]["url"])


# ------------------------------------------------------------------ Bing 搜图
def bing_images(query: str, n: int = 8) -> list[str]:
    url = "https://www.bing.com/images/search?q=" + urllib.parse.quote(query) + "&form=HDRSC2&first=1"
    html = _fetch(url, timeout=30).decode("utf-8", "ignore")
    urls = re.findall(r'murl&quot;:&quot;(.*?)&quot;', html)
    if not urls:
        urls = re.findall(r'"murl":"(.*?)"', html)
    out, seen = [], set()
    for u in urls:
        u = u.replace("\\/", "/")
        if u.startswith("http") and u not in seen:
            seen.add(u)
            out.append(u)
        if len(out) >= n:
            break
    return out


# ------------------------------------------------------------------ 本地图库
def local_library(limit: int = 60) -> list[str]:
    files = []
    for d in LOCAL_IMAGE_DIRS:
        if d.exists():
            for p in sorted(d.rglob("*")):
                if p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp", ".gif"):
                    files.append(p)
    return [str(p) for p in files[:limit]]


def local_copy(path: str) -> str:
    p = Path(path)
    if not p.exists() or p.suffix.lower() not in (".jpg", ".jpeg", ".png", ".webp", ".gif"):
        raise ValueError("invalid local image")
    return _save_bytes(p.read_bytes(), p.suffix.lower())


# ------------------------------------------------------------------ 网页截图 / 操作（把网址当工具）
def screenshot(url: str, full: bool = False, wait_ms: int = 2500) -> str:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        pg = b.new_page(viewport={"width": 1440, "height": 1000})
        pg.goto(url, wait_until="domcontentloaded", timeout=45000)
        pg.wait_for_timeout(wait_ms)
        png = pg.screenshot(full_page=full)
        b.close()
    return _save_bytes(png, ".png")


def browse(url: str, actions: list | None = None, full: bool = False, wait_ms: int = 2500) -> dict:
    """打开网址并执行操作序列（fill/click/press/wait），返回截图 + 页面文本。

    actions 例：[{"type":"fill","selector":"textarea","value":"..."},
                 {"type":"click","selector":"button:has-text('开始分析')"},
                 {"type":"wait","ms":8000}]
    """
    actions = actions or []
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        pg = b.new_page(viewport={"width": 1440, "height": 1000})
        pg.goto(url, wait_until="domcontentloaded", timeout=45000)
        for a in actions:
            t = a.get("type")
            try:
                if t == "fill":
                    pg.fill(a["selector"], a.get("value", ""))
                elif t == "click":
                    pg.click(a["selector"], timeout=15000)
                elif t == "press":
                    pg.press(a.get("selector", "body"), a.get("key", "Enter"))
                elif t == "wait":
                    pg.wait_for_timeout(int(a.get("ms", 1000)))
            except Exception as e:
                print(f"[browse] action {t} failed: {e}")
        pg.wait_for_timeout(wait_ms)
        png = pg.screenshot(full_page=full)
        try:
            text = pg.inner_text("body")[:6000]
        except Exception:
            text = ""
        try:  # 附上页面链接（标题 -> URL），供引用
            links = pg.eval_on_selector_all(
                "a[href]", "els => els.slice(0,80).map(e => "
                "((e.innerText||'').trim().replace(/\\s+/g,' ').slice(0,70) + ' -> ' + e.href))")
            links = [x for x in links if x and not x.startswith(" -> ") and x.split(" -> ")[0]]
            if links:
                text += "\n\n[页面链接（标题 -> URL）]\n" + "\n".join(links[:40])
        except Exception:
            pass
        b.close()
    return {"screenshot": _save_bytes(png, ".png"), "text": text}
