"""人设加载与默认值（D9/D18）。"""
from __future__ import annotations

import datetime
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
AGENTS_DIR = ROOT / "agents"

# 富人格（#66/#70）：身份/身体/节律
DEFAULT_IDENTITY = {"avatar": "🙂", "color": "#6366f1", "gender": "unspecified",
                    "pronouns": "", "avatar_url": None}
CYCLE_PHASES = [("menstrual", 5), ("follicular", 9), ("ovulation", 3), ("luteal", 11)]
PHASE_NOTE = {"menstrual": "经期：精力偏低，宜做收敛与复盘",
              "follicular": "卵泡期：精力回升，适合开启新任务",
              "ovulation": "排卵期：状态峰值，适合攻坚与对外沟通",
              "luteal": "黄体期：偏敏感，宜聚焦细节、避免多线"}


def cycle_phase(rhythm: dict | None, today: datetime.date | None = None) -> dict | None:
    """按 cycle_length/last_period 推算今天的生理阶段。"""
    lp = (rhythm or {}).get("last_period")
    if not lp:
        return None
    try:
        d0 = datetime.date.fromisoformat(str(lp))
    except (ValueError, TypeError):
        return None
    cl = int((rhythm or {}).get("cycle_length") or 28)
    today = today or datetime.date.today()
    day = ((today - d0).days % cl) + 1
    acc = 0
    phase = "luteal"
    for name, span in CYCLE_PHASES:
        acc += span
        if day <= acc:
            phase = name
            break
    return {"day": day, "phase": phase, "cycle_length": cl, "note": PHASE_NOTE.get(phase, "")}


# 话题边界（#68）：个性来自 agent 自己划界，而非被全局放开
BOUNDARY_TOPICS = ["亲密关系", "政治", "暴力", "死亡", "宗教", "成瘾", "外貌", "金钱"]


def boundary_view(persona: dict) -> dict:
    b = persona.get("boundaries") or {}
    return {"comfort": {k: float(v) for k, v in (b.get("comfort") or {}).items()},
            "hard_limits": list(b.get("hard_limits") or []),
            "note": b.get("note") or "", "topics": BOUNDARY_TOPICS}


def boundary_check(persona: dict, text: str, threshold: float = 0.5) -> dict:
    """agent 自己的边界判定：命中硬限制→拒绝；否则按已声明话题的舒适度。"""
    v = boundary_view(persona)
    text = text or ""
    for h in v["hard_limits"]:
        if h and h in text:
            return {"engage": False, "comfort": 0.0, "reason": f"触及硬边界：{h}"}
    hits = [t for t in v["topics"] if t in text]
    if not hits:
        return {"engage": True, "comfort": None, "reason": "未触及已声明话题，默认参与"}
    comfort = sum(v["comfort"].get(t, 0.5) for t in hits) / len(hits)
    return {"engage": comfort >= threshold, "comfort": round(comfort, 3),
            "reason": f"话题「{'、'.join(hits)}」舒适度 {round(comfort, 2)}"}


# AI 腔套话（要禁止，避免两个 agent 越聊越像、沦为 AI slop）
DEFAULT_AVOID = ["不是……而是……", "首先", "其次", "再次", "综上所述", "总的来说", "总而言之",
                 "值得注意的是", "让我们一起", "不妨", "赋能", "闭环", "抓手", "底层逻辑",
                 "颗粒度", "说白了", "本质上", "某种意义上", "我们可以看到", "这不仅", "在这个时代"]


def voice_view(persona: dict) -> dict:
    v = persona.get("voice") or {}
    return {"style": v.get("style") or "", "catchphrases": list(v.get("catchphrases") or []),
            "tone": v.get("tone") or "", "avoid": list(v.get("avoid") or DEFAULT_AVOID),
            "anchor": v.get("anchor") or "", "styles": v.get("styles") or {},
            "learned": v.get("learned") or {}, "updated_at": v.get("updated_at")}


def parse_nl(text: str) -> dict:
    """自然语言 → 人设字段（启发式；整段文字存为 soul 风格种子）。"""
    import re
    t = (text or "").strip()
    out = {"soul": t}
    m = re.search(r"(?:我叫|我是|名字是|叫)\s*([A-Za-z0-9\u4e00-\u9fff]{1,16})", t)
    if m:
        out["name"] = m.group(1)
    if re.search(r"(女|女生|女性|她|女士)", t):
        out["gender"] = "female"
    elif re.search(r"(男|男生|男性|他|先生)", t):
        out["gender"] = "male"
    m = re.search(r"(\d{1,2})\s*岁", t)
    if m:
        out["age"] = int(m.group(1))
    m = re.search(r"身高\s*(\d{3})", t)
    if m:
        out["height_cm"] = int(m.group(1))
    return out


def soul_view(persona: dict) -> dict:
    """归一化 soul：兼容旧字符串，或返回结构化 dict。"""
    s = persona.get("soul")
    if isinstance(s, str):
        return {"identity": s, "raw": s, "sections": [], "beliefs": [],
                "method": [], "voice": {}, "taboos": [], "scenarios": [], "evolution": []}
    if isinstance(s, dict):
        return s
    return {}


def _subsections(body: str) -> list[dict]:
    import re
    heads = list(re.finditer(r"^#{3,4}\s+(.+)$", body, re.M))
    out = []
    for i, h in enumerate(heads):
        s = h.end()
        e = heads[i + 1].start() if i + 1 < len(heads) else len(body)
        out.append({"name": h.group(1).strip(), "body": body[s:e].strip()})
    return out


def parse_soul(text: str) -> dict:
    """解析一段文字或 SOUL.md → 结构化 soul（分节 + 抽取理念/方法/风格/禁忌）。"""
    import re
    t = (text or "").strip()
    out = {"raw": t, "sections": [], "beliefs": [], "method": [],
           "voice": {}, "taboos": [], "scenarios": [], "evolution": []}
    if not t:
        return out
    heads = list(re.finditer(r"^#{1,2}\s+(.+)$", t, re.M))
    if not heads:
        out["identity"] = t
        return out
    for i, h in enumerate(heads):
        title = h.group(1).strip()
        start = h.end()
        end = heads[i + 1].start() if i + 1 < len(heads) else len(t)
        out["sections"].append({"title": title, "body": t[start:end].strip()})
    for sec in out["sections"]:
        title, body = sec["title"], sec["body"]
        if re.search(r"身份|定位", title) and not out.get("identity"):
            out["identity"] = body
        elif re.search(r"理念|信念|原则", title):
            out["beliefs"] += _subsections(body) or [{"name": title, "body": body}]
        elif re.search(r"方法|方法论|流程", title):
            out["method"] += _subsections(body) or [{"name": title, "body": body}]
        elif re.search(r"风格|语言|表达|语气", title):
            lines = [ln.strip("-•* ").strip() for ln in body.splitlines() if ln.strip()]
            out["voice"] = {"rules": lines[:12]}
        elif re.search(r"禁忌|边界|红线|不", title):
            out["taboos"] = [ln.strip("-•* ").strip() for ln in body.splitlines() if ln.strip()][:12]
        elif re.search(r"场景|应用", title):
            out["scenarios"] += _subsections(body) or [{"name": title, "body": body}]
    if not out.get("identity") and out["sections"]:
        out["identity"] = out["sections"][0]["body"]
    return out


def soul_note(persona: dict, limit: int = 1400) -> str:
    """把 soul 渲染成注入 prompt 的紧凑文本。"""
    s = soul_view(persona)
    if not s:
        return ""
    parts = []
    if s.get("identity"):
        parts.append("【身份】" + str(s["identity"])[:300])
    for b in (s.get("beliefs") or [])[:8]:
        parts.append("【理念·" + str(b.get("name", "")) + "】" + str(b.get("body") or b.get("principle", ""))[:220])
    for m in (s.get("method") or [])[:8]:
        parts.append("【方法·" + str(m.get("name", "")) + "】" + str(m.get("body") or m.get("rule", ""))[:220])
    vo = s.get("voice") or {}
    if isinstance(vo, dict) and vo.get("rules"):
        parts.append("【语言】" + "；".join(str(x) for x in vo["rules"])[:300])
    if s.get("taboos"):
        def _t(x):
            if isinstance(x, dict):
                return f"{x.get('name','')}：{x.get('body','')}" if x.get("name") else str(x.get("body", ""))
            return str(x)
        parts.append("【禁忌】" + "；".join(_t(x) for x in s["taboos"])[:300])
    evo = s.get("evolution") or []
    if evo:
        parts.append("【演化】" + " | ".join(str(e.get("change", "")) for e in evo[-3:])[:200])
    return "\n".join(parts)[:limit]


def soul_evolve(persona: dict, change: str, reason: str = "") -> dict:
    """自我演化：向 soul.evolution 追加一条（含原因）。"""
    from datetime import datetime
    s = soul_view(persona)
    if not isinstance(s, dict):
        s = {"identity": str(s)}
    s.setdefault("evolution", [])
    s["evolution"].append({"at": datetime.now().strftime("%Y-%m-%d %H:%M"),
                           "change": change, "reason": reason})
    persona["soul"] = s
    return persona


# ---------------------------------------------------------------- 人格维度（系统化方法论）
#: 统一人格维度表（"我是谁"的完整维度）。**维度定义=方法论（可随母版演化）；
#: 每个 agent 的具体取值=其私有内容，只能由本人演化**（见 docs/64、AGENTS.md）。
DIMENSIONS: dict[str, str] = {
    "identity": "身份：姓名/称号/角色/头像/自称/座右铭/主色",
    "body": "长相与体态：年龄/身高/体型/面容发型/神态细节",
    "wardrobe": "衣柜：日常/正式/居家/运动/场合搭配 + 随身信物",
    "traits": "性格（大五）：openness/conscientiousness/extraversion/agreeableness/neuroticism",
    "values": "价值观权重：rigor/safety/speed/visibility/collaboration/autonomy/novelty",
    "voice": "表达：语气/句长/口头禅/风格池/场合分支",
    "aesthetic": "审美：代码/文档/界面风格/风险偏好",
    "boundaries": "边界：舒适度/硬底线",
    "career_strategy": "职业策略：目标/期限/偏好",
    "collaboration": "协作：沟通/冲突/并行/严格度",
    "skills": "技能：名称/当前/目标/策略",
    "interests": "兴趣",
    "soul": "灵魂宣言：信念/方法/禁忌/场景/演化",
}
EVOLUTION_KEY = "evolution"

#: **私密维度**：只属于本人，**不得下发给他人 / 不得外传**（视 agent 为"人"，人格私密）。
#: body=身体长相；wardrobe=衣柜（含贴身/私密单品）。对外视图一律剥离；本人自看/自编辑除外。
PRIVATE_DIMS: tuple[str, ...] = ("body", "wardrobe")


def strip_private(persona: dict) -> dict:
    """返回**对外（他人）**可见的人格（去掉私密维度）。"""
    if not isinstance(persona, dict):
        return {}
    return {k: v for k, v in persona.items() if k not in PRIVATE_DIMS}


def dimension_view(persona: dict) -> dict:
    """逐维度「是否已定义 + 摘要」，供自省/UI/派单参考。"""
    out: dict[str, dict] = {}
    for dim, desc in DIMENSIONS.items():
        v = persona.get(dim)
        if isinstance(v, dict):
            summary = "、".join(list(v)[:6])
        elif isinstance(v, list):
            summary = f"{len(v)} 项"
        else:
            summary = str(v)[:60] if v else ""
        out[dim] = {"defined": bool(v), "desc": desc, "summary": summary}
    return out


def persona_evolve(agent_id: str, dimension: str, change: str, reason: str = "",
                   by: str = "", persona: dict | None = None) -> dict:
    """**本人**的维度演化：向 `persona.evolution` 追加一条（含变更/原因/依据）。

    · 只写"演化留痕"；具体取值由 `set_dimension` 写入。
    · 调用方**必须**鉴权为本人——**别人的记忆只能别人自己保存**（本函数不校验，由上层把关）。
    """
    if dimension not in DIMENSIONS and dimension != "general":
        raise ValueError(f"unknown dimension: {dimension}")
    from datetime import datetime
    p = persona if persona is not None else load_persona(agent_id)
    entry = {"at": datetime.now().strftime("%Y-%m-%d %H:%M"),
             "dimension": dimension, "change": (change or "").strip(),
             "reason": (reason or "").strip(), "by": by or agent_id}
    p.setdefault(EVOLUTION_KEY, []).append(entry)
    save_persona(agent_id, p)
    return entry


def set_dimension(agent_id: str, dimension: str, value, *, reason: str = "",
                  by: str = "") -> dict:
    """写入某维度的**具体取值** + 留痕。**仅限本人**。"""
    if dimension not in DIMENSIONS:
        raise ValueError(f"unknown dimension: {dimension}")
    p = load_persona(agent_id)
    p[dimension] = value
    persona_evolve(agent_id, dimension, f"设定维度 `{dimension}`", reason=reason, by=by, persona=p)
    return p


def talkativeness(persona: dict) -> float:
    """健谈度：显式 voice.talkativeness 优先，否则由开放性/外向性推导。"""
    v = persona.get("voice") or {}
    if "talkativeness" in v:
        try:
            return max(0.0, min(1.0, float(v["talkativeness"])))
        except (TypeError, ValueError):
            pass
    tr = persona.get("traits") or {}
    o = float(tr.get("openness", 0.5))
    e = float(tr.get("extraversion", 0.5))
    return round(0.6 * o + 0.4 * e, 3)


def persona_view(persona: dict, today: datetime.date | None = None) -> dict:
    """给 UI/驱动的富人格视图（含推算出的节律）。"""
    ident = dict(DEFAULT_IDENTITY)
    ident.update(persona.get("identity") or {})
    rhythm = persona.get("rhythm") or {}
    return {"avatar": ident.get("avatar") or "🙂", "avatar_url": ident.get("avatar_url"),
            "color": ident.get("color") or "#6366f1", "gender": ident.get("gender"),
            "pronouns": ident.get("pronouns"), "motto": ident.get("motto"),
            "bio": ident.get("bio"), "body": persona.get("body") or {},
            "rhythm": rhythm, "cycle": cycle_phase(rhythm, today),
            "boundaries": boundary_view(persona), "voice": voice_view(persona),
            "soul": soul_view(persona), "soul_note": soul_note(persona)}

DEFAULT_WEIGHTS = {
    "skill_fit": 0.20,
    "career_gain": 0.20,
    "strategy_align": 0.12,
    "priority_bias": 0.08,
    "interest_novelty": 0.08,
    "resource_fit": 0.12,
    "load_penalty": 0.15,
    "risk_penalty": 0.05,
}


def agent_dir(agent_id: str) -> Path:
    return AGENTS_DIR / agent_id


def load_persona(agent_id: str) -> dict:
    """读取 agents/<id>/persona.yaml，缺省字段补默认值。"""
    path = agent_dir(agent_id) / "persona.yaml"
    if not path.exists():
        raise FileNotFoundError(f"persona not found: {path}")
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    data.setdefault("id", agent_id)
    data.setdefault("name", agent_id.capitalize())
    data.setdefault("role", "executor")
    data.setdefault("skills", [])
    data.setdefault("interests", [])
    data.setdefault("identity", {})
    data.setdefault("body", {})
    data.setdefault("wardrobe", {})
    data.setdefault("rhythm", {})
    data.setdefault("boundaries", {})
    data.setdefault("traits", {})
    data.setdefault("aesthetic", {})
    data.setdefault("career_strategy", {})
    data.setdefault("collaboration", {})
    data.setdefault(EVOLUTION_KEY, [])
    data.setdefault("scoring_weights", dict(DEFAULT_WEIGHTS))
    return data


def list_persona_ids() -> list[str]:
    if not AGENTS_DIR.exists():
        return []
    return sorted(p.parent.name for p in AGENTS_DIR.glob("*/persona.yaml")
                  if not p.parent.name.startswith("_"))     # 跳过 _templates 等


def load_template(name: str) -> dict:
    """加载起始档案模板（agents/_templates/<name>.yaml）。"""
    path = AGENTS_DIR / "_templates" / f"{name}.yaml"
    if not path.exists():
        raise FileNotFoundError(f"template not found: {name}")
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


def list_templates() -> list[str]:
    d = AGENTS_DIR / "_templates"
    return sorted(p.stem for p in d.glob("*.yaml")) if d.exists() else []


def save_persona(agent_id: str, persona: dict) -> None:
    path = agent_dir(agent_id) / "persona.yaml"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(persona, allow_unicode=True, sort_keys=False), encoding="utf-8")
