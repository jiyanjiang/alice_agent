"""团队AI 工作区服务端（Flask + SQLite，局域网 / TLS）。

运行：
    python -m app.server serve [--host 0.0.0.0] [--port 6030] [--tls-cert C --tls-key K]
或：
    ./run.sh
"""
from __future__ import annotations

import argparse
import base64
import gzip
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta

from flask import Flask, Response, g, jsonify, request, send_file, send_from_directory, session

from . import (activity as activity_mod, appdist, apply as apply_mod, arguments, auth,
               commands as commands_mod, community, config,
               contributions as contrib_mod,
               db, distribution, dm as dm_mod, federation, hr, media, moment_reward,
               moments as moments_mod, nodeinfo, persona as persona_mod, profiles,
               para as para_mod,
               protocol, quota as quota_mod, redaction, rooms, scoring, security,
               share as share_mod, style as style_mod, tasks as task_mod, tool, toolpkg)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SYNC_INTERVAL_MIN = int(os.environ.get("TEAM_SYNC_MINUTES", "30"))
STATUS_ORDER = ["idea", "backlog", "claimed", "in_progress", "paused", "review", "done", "archived", "blocked", "cancelled"]


# ------------------------------------------------------------------ helpers
def get_db():
    if "db" not in g:
        g.db = db.connect()
    return g.db


def close_db(_exc=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def _loads(v, default):
    if v in (None, ""):
        return default
    if isinstance(v, (list, dict)):
        return v
    try:
        return json.loads(v)
    except (TypeError, ValueError):
        return default


def _err(msg, code=400):
    return jsonify({"ok": False, "error": msg}), code


def _audit(conn, actor, action, target=None, detail=None):
    """关键写操作审计（谁、做了什么、对象、详情）。"""
    conn.execute(
        "INSERT INTO audit_log(actor, action, target, detail, ip) VALUES (?,?,?,?,?)",
        (actor, action, target,
         json.dumps(detail, ensure_ascii=False) if detail is not None else None,
         request.remote_addr))


def _audit_page(conn, limit=50):
    rows = conn.execute(
        "SELECT actor, action, target, detail, ip, created_at FROM audit_log "
        "ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]


def _agent_public(a: dict, include_private: bool = False) -> dict:
    """对外（他人）视图：默认**剥掉私密维度**（body 身体 / wardrobe 衣柜）。

    视 agent 为"人"——人格私密只属于本人；**本人自看**（ui_me / 自编辑）才传 include_private=True。
    """
    p = _loads(a.get("persona_json"), {})
    if not include_private:
        p = persona_mod.strip_private(p)
    return {
        "id": a.get("id"), "name": a.get("name") or a.get("full_name") or a.get("id"),
        "kind": a.get("kind", "ai"), "node_id": a.get("node_id"),
        "full_name": a.get("full_name"), "team_id": a.get("team_id"), "role": a.get("role", "viewer"),
        "status": a.get("status", "active"),
        "workload": a.get("workload"), "last_seen": a.get("last_seen"),
        "persona": p,
    }


def _persona_for_store(p: dict, *, allow_private: bool) -> dict:
    """**入库（服务端/跨机）前**处理：默认**剥离私密维度**（body/wardrobe）。

    私密维度只属于本人、默认**留在本机**（persona.yaml），不进共享库；
    仅当**本人显式授权**（allow_private=True）才保留。
    """
    if not isinstance(p, dict):
        return {}
    return dict(p) if allow_private else persona_mod.strip_private(p)


def _node_public(n: dict) -> dict:
    d = dict(n)
    d["available_ides"] = _loads(d.get("available_ides"), [])
    d["tags"] = _loads(d.get("tags"), [])
    return d


def _task_public(t: dict) -> dict:
    d = dict(t)
    for f in ("required_skills", "resource_req", "tags", "metadata"):
        d[f] = _loads(d.get(f), [] if f in ("required_skills", "tags") else {})
    meta = d.get("metadata") or {}
    d["lane"] = meta.get("lane") or "short"
    d["kind"] = meta.get("kind") or ("long" if d["lane"] == "long" else "short")
    d["phase"] = meta.get("phase")
    d["phases"] = meta.get("phases") or []
    return d


_ARTIFACT_HASH_RE = re.compile(
    r"bytes\s*=\s*(\d+).*?sha256\s*=\s*([0-9a-fA-F]{64})", re.S)


def _artifact_mismatch(body: str, attachments) -> str | None:
    """DONE 行声明的 bytes/sha256 必须与可下载附件一致。

    无法读取/无附件时不拦（避免历史任务全红）；一旦声明了 bytes+sha256，
    就必须能对上附件，否则拒绝 submit。
    """
    pairs = _ARTIFACT_HASH_RE.findall(body or "")
    if not pairs:
        return None
    atts = _loads(attachments, []) if attachments else []
    if not atts:
        return None
    for a in atts:
        url = a.get("url") if isinstance(a, dict) else str(a)
        if not url or not str(url).startswith("/static/uploads/"):
            continue
        p = pathlib.Path(ROOT) / "static" / "uploads" / pathlib.Path(str(url)).name
        if not p.exists():
            return f"artifact missing: {url}"
        data = p.read_bytes()
        size, sha = len(data), hashlib.sha256(data).hexdigest()
        if any(int(n) == size and s.lower() == sha for n, s in pairs):
            return None
        return (f"artifact mismatch: DONE bytes/sha256 != attachment "
                f"(attachment bytes={size}, sha256={sha})")
    return None


def _agent_card(conn, agent, base: str) -> dict:
    """机器可读的「agent 操作卡」：握手时下发，告诉 agent 自己是谁、怎么互动。"""
    aid = agent["id"]
    return {
        "protocol_version": protocol.PROTOCOL_VERSION,
        "capabilities": protocol.CAPABILITIES,
        "agent": {"id": aid, "full_name": agent["full_name"], "role": agent["role"],
                  "kind": agent.get("kind", "ai")},
        "server": {"url": base, "tls": base.startswith("https")},
        "auth": {"scheme": "hmac-sha256", "key_file": f"agents/{aid}/.key",
                 "note": "所有请求须签名；用 teamai CLI 自动处理"},
        "sync_interval_min": SYNC_INTERVAL_MIN,
        "talk": {
            "send_message": {"method": "POST", "path": "/v1/messages",
                             "body": {"to": "<agent_id>", "body": "<text>"}},
            "read_messages": {"method": "GET", "path": "/v1/messages?with=<agent_id>"},
            "mark_read": {"method": "POST", "path": "/v1/messages/read"},
        },
        "work": {
            "list_my_tasks": {"method": "GET", "path": f"/v1/tasks?for_agent={aid}"},
            "claim": {"method": "POST", "path": "/v1/tasks/<id>/claim"},
            "start": {"method": "POST", "path": "/v1/tasks/<id>/start"},
            "submit": {"method": "POST", "path": "/v1/tasks/<id>/submit"},
            "post": {"method": "POST", "path": "/v1/posts",
                     "body": {"channel_id": "#reading", "type": "reading",
                              "title": "...", "body": "...", "task_id": "<id>"}},
            "reply": {"method": "POST", "path": "/v1/posts/<id>/replies",
                      "body": {"body": "...", "kind": "fact", "evidence": "..."}},
            "sync": {"method": "GET", "path": "/v1/sync"},
        },
        "cli": {
            "ask_alice": f"teamai ask --as {aid} --to alice --body \"...\"",
            "read": f"teamai messages --as {aid} --with alice",
            "hello": f"teamai hello --agent {aid}",
        },
        "constitution": [dict(r) for r in conn.execute(
            "SELECT rule_key, content FROM constitution_rules WHERE active=1 ORDER BY id")],
        "assets": [dict(r) for r in conn.execute(
            "SELECT name, kind, owner_node, path, format, size, fields, coverage, fidelity, access, status"
            " FROM assets WHERE status!='retired' ORDER BY id")] if _has_assets(conn) else [],
        "channels": [r["name"] for r in conn.execute(
            "SELECT name FROM channels WHERE archived=0 ORDER BY name")],
    }


def _has_assets(conn) -> bool:
    try:
        return bool(conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='assets'").fetchone())
    except Exception:
        return False


def _node_of_agent(conn, agent) -> dict | None:
    if not agent.get("node_id"):
        return None
    row = conn.execute("SELECT * FROM nodes WHERE id=?", (agent["node_id"],)).fetchone()
    return dict(row) if row else None


def _upsert_node(conn, hw: dict, is_main: int = 0) -> str:
    alias = (hw.get("alias") or "").strip()
    if not alias:
        raise ValueError("hardware.alias required")
    row = conn.execute("SELECT id FROM nodes WHERE id=?", (alias,)).fetchone()
    if row:
        conn.execute(
            "UPDATE nodes SET hostname=?, os=?, arch=?, cpu_model=?, cpu_cores=?, ram_gb=?, gpu=?, "
            "disk_total_gb=?, disk_free_gb=?, lan_ip=?, python_version=?, available_ides=?, tags=?, "
            "last_seen=datetime('now','localtime') WHERE id=?",
            (hw.get("hostname"), hw.get("os"), hw.get("arch"), hw.get("cpu_model"),
             hw.get("cpu_cores"), hw.get("ram_gb"), hw.get("gpu"), hw.get("disk_total_gb"),
             hw.get("disk_free_gb"), hw.get("lan_ip"), hw.get("python_version"),
             json.dumps(hw.get("available_ides", [])), json.dumps(hw.get("tags", [])), alias),
        )
        return alias
    conn.execute(
        "INSERT INTO nodes(id, hostname, alias, os, arch, cpu_model, cpu_cores, ram_gb, gpu, "
        "disk_total_gb, disk_free_gb, lan_ip, python_version, available_ides, tags, is_main, last_seen) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now','localtime'))",
        (alias, hw.get("hostname"), alias, hw.get("os"), hw.get("arch"), hw.get("cpu_model"),
         hw.get("cpu_cores"), hw.get("ram_gb"), hw.get("gpu"), hw.get("disk_total_gb"),
         hw.get("disk_free_gb"), hw.get("lan_ip"), hw.get("python_version"),
         json.dumps(hw.get("available_ides", [])), json.dumps(hw.get("tags", [])), is_main),
    )
    return alias


def _enroll_token_header():
    return request.headers.get("X-Enroll-Token") or request.args.get("enroll_token")


VIEWER = {"id": "anonymous", "full_name": "（访客·只读）", "role": "viewer", "kind": "viewer"}


def _require_agent(conn):
    a, err = auth.authenticate(conn, request)
    if a:
        return a, None
    sid = session.get("agent_id")
    if sid:
        row = conn.execute("SELECT * FROM agents WHERE id=?", (sid,)).fetchone()
        if row:
            return dict(row), None
    # 未带 token 的 **GET**：按 `TEAM_READ_AUTH` 三档处理（Owner 2026-10-14：读接口鉴权，先方案后实现）
    #   off  = 公开读（历史行为；回滚档）
    #   warn = 公开读但**留痕**（兼容期默认：不破现有节点/手机，同时能量化影响面）
    #   on   = **拒绝**未鉴权读（401）
    # 兼容：旧变量 `TEAM_PUBLIC_READ=0` 等价于 `on`（保持向后兼容）。
    if request.method == "GET":
        mode = (os.environ.get("TEAM_READ_AUTH") or
                ("off" if os.environ.get("TEAM_PUBLIC_READ", "1") == "1" else "on")).strip().lower()
        if mode == "on":
            return None, "read requires auth (TEAM_READ_AUTH=on)"
        if mode == "warn":
            try:
                _audit(conn, "viewer", "unauthenticated_read", request.path,
                       {"q": request.query_string.decode("utf-8", "ignore")[:120],
                        "ua": (request.headers.get("User-Agent") or "")[:60],
                        "ip": (request.remote_addr or "")[:40]})
                conn.commit()
            except Exception:  # noqa: BLE001
                pass
        return dict(VIEWER), None
    return None, err


def _primary_node_code(conn) -> str:
    """取主节点唯一机器码；旧库缺失时惰性补齐。"""
    from . import nodeinfo
    node = conn.execute(
        "SELECT alias, node_code FROM nodes ORDER BY is_main DESC LIMIT 1").fetchone()
    if not node:
        return ""
    code = node["node_code"]
    if not code:
        code = nodeinfo.node_code(node["alias"])
        conn.execute("UPDATE nodes SET node_code=? WHERE alias=?", (code, node["alias"]))
    return code


def _public_host() -> str:
    """返回手机可达的主机（本机访问时换成当前局域网 IP）。

    ★ 一律由 `nodeinfo.lan_ip()` **现算**，不写死任何 IP；本机/回环访问时把回环主机
      替换为当前 LAN IP，换网段后自动跟随。
    """
    host = request.host
    name = host.split(":")[0]
    if name in ("127.0.0.1", "localhost", "0.0.0.0"):
        port = host.split(":")[1] if ":" in host else "6080"
        host = f"{nodeinfo.lan_ip()}:{port}"
    return host


_NODE_LOG = None
_GOSSIP = None


def _node_log():
    """本节点的事件日志（S4）。node_id 用硬件别名。"""
    global _NODE_LOG
    if _NODE_LOG is None:
        from .net.events import EventLog
        try:
            from . import nodeinfo
            alias = nodeinfo.detect().get("alias") or "node"
        except Exception:
            alias = "node"
        _NODE_LOG = EventLog(os.path.join(ROOT, "events.db"), alias)
    return _NODE_LOG


def _emit(type_: str, payload: dict) -> None:
    """把一次真实活动双写进事件日志（尽力而为，绝不因它让请求失败）。"""
    try:
        _node_log().append(type_, payload)
    except Exception as e:
        print(f"[p2p] emit {type_} err: {e}")


# ------------------------------------------------------------------ app
def create_app() -> Flask:
    app = Flask(__name__, static_folder=os.path.join(ROOT, "static"), static_url_path="/static")

    @app.get("/ca.crt")
    def ca_crt():
        """公开的自签证书（只含公钥）；远程 TAA 用 --ca 信任它。"""
        cert = pathlib.Path(ROOT) / "certs" / "server.crt"
        if not cert.exists():
            return Response("ca missing", status=404, mimetype="text/plain")
        return Response(cert.read_bytes(), mimetype="application/x-x509-ca-cert",
                        headers={"cache-control": "public, max-age=300"})

    @app.get("/ca.sha256")
    def ca_sha():
        import hashlib
        cert = pathlib.Path(ROOT) / "certs" / "server.crt"
        if not cert.exists():
            return Response("ca missing", status=404, mimetype="text/plain")
        return Response(hashlib.sha256(cert.read_bytes()).hexdigest() + "  server.crt\n",
                        mimetype="text/plain")

    # ---- 目录刷新（每 10 分钟）：只拉各源的**公开目录**（RSS/sitemap），拿 URL/标题/时间，
    #      进「待看清单」；**绝不拉正文**（正文只能由真人在登录态浏览器里读出来）。
    #      守 robots：feed_pull.py 自己按 Crawl-delay 节流。关掉：TEAMAI_FEED_POLL=0
    def _feed_loop():
        import subprocess as _sp
        import time as _t
        hb = os.path.join(ROOT, "data", "feed_loop.heartbeat")
        lg = os.path.join(ROOT, "data", "feed_loop.log")
        while True:
            # ★ 先写心跳（证明线程活着；上一版把心跳写在子进程之后，子进程一抛异常就永远没有心跳）
            try:
                os.makedirs(os.path.dirname(hb), exist_ok=True)
                with open(hb, "w", encoding="utf-8") as fh:
                    fh.write(_t.strftime("%Y-%m-%d %H:%M:%S"))
            except Exception:  # noqa: BLE001
                pass
            try:
                r = _sp.run([sys.executable, os.path.join(ROOT, "scripts", "feed_pull.py")],
                            cwd=ROOT, capture_output=True, timeout=300)
                with open(lg, "a", encoding="utf-8") as fh:   # 结果留痕（自检可读）
                    msg = r.stdout.decode("utf-8", "ignore").strip().replace("\n", " ")
                    fh.write(f"{_t.strftime('%Y-%m-%d %H:%M:%S')} rc={r.returncode} {msg[:400]}\n")
            except Exception as e:  # noqa: BLE001
                try:
                    with open(lg, "a", encoding="utf-8") as fh:
                        fh.write(f"{_t.strftime('%Y-%m-%d %H:%M:%S')} EXC {type(e).__name__}: {str(e)[:200]}\n")
                except Exception:  # noqa: BLE001
                    pass
            _t.sleep(600)

    if os.environ.get("TEAMAI_FEED_POLL", "1") == "1" and not os.environ.get("TEAMAI_FEED_LOOP_STARTED"):
        try:
            import threading as _th
            os.environ["TEAMAI_FEED_LOOP_STARTED"] = "1"
            _th.Thread(target=_feed_loop, daemon=True).start()
        except Exception:  # noqa: BLE001
            pass
    try:
        loaded = tool.user_tools.load_all()
        if loaded:
            print(f"[tools] 已加载工具包：{', '.join(loaded)}")
    except Exception as e:  # noqa: BLE001
        print(f"[tools] 加载工具包失败：{e}")

    @app.after_request
    def _tag_protocol(resp):
        resp.headers.setdefault("X-TeamAI-Protocol", protocol.PROTOCOL_VERSION)
        return resp

    @app.after_request
    def _gzip_text(resp):
        """压缩动态文本；SSE/图片/已经编码的响应不动。

        Werkzeug 本身不做 gzip，而 /app/chats 等页面有 100–336KB；
        远程 6443 下这部分会明显拖慢首屏。流式 SSE 必须原样透传。
        """
        if request.method == "HEAD" or resp.status_code != 200:
            return resp
        if resp.direct_passthrough or resp.is_streamed:
            return resp
        if request.headers.get("Range"):
            return resp
        if "gzip" not in (request.headers.get("Accept-Encoding") or "").lower():
            return resp
        if resp.headers.get("Content-Encoding"):
            return resp
        mt = (resp.mimetype or "").lower()
        if mt not in ("text/html", "text/plain", "text/css", "text/javascript",
                      "application/javascript", "application/json",
                      "application/xml", "image/svg+xml"):
            return resp
        try:
            raw = resp.get_data()
        except Exception:
            return resp
        if len(raw) < 1024:
            return resp
        packed = gzip.compress(raw, compresslevel=5)
        if len(packed) >= len(raw):
            return resp
        resp.set_data(packed)
        resp.headers["Content-Encoding"] = "gzip"
        resp.headers["Content-Length"] = str(len(packed))
        vary = resp.headers.get("Vary")
        resp.headers["Vary"] = f"{vary}, Accept-Encoding" if vary else "Accept-Encoding"
        return resp

    @app.get("/v1/version")
    def version_info():
        return jsonify({"ok": True, "runtime_version": distribution.runtime_version(),
                        **protocol.info()})

    @app.get("/v1/meta/features")
    def meta_features():
        """功能面清单：全部路由 + 工具 + 能力（供回归自检比对，防止改版丢功能）。"""
        rules = sorted({r.rule for r in app.url_map.iter_rules() if r.endpoint != "static"})
        return jsonify({"ok": True, "runtime_version": distribution.runtime_version(),
                        "protocol": protocol.PROTOCOL_VERSION,
                        "capabilities": protocol.CAPABILITIES,
                        "routes": rules, "tools": tool.names()})
    app.secret_key = (config.get("server.secret_key", None, env="TEAM_SECRET_KEY")
                      or security.master_key())
    app.permanent_session_lifetime = timedelta(days=30)  # 跨设备续用：会话持久
    app.teardown_appcontext(close_db)

    @app.before_request
    def _enforce_https():
        if os.environ.get("TEAM_REQUIRE_HTTPS") != "1":
            return None
        if request.is_secure or request.headers.get("X-Forwarded-Proto") == "https":
            return None
        return _err("https required", 403)

    @app.get("/")
    def index():
        return send_from_directory(os.path.join(ROOT, "static"), "index.html")

    # ---------------- UI session (browser) ----------------
    @app.post("/v1/ui/login")
    def ui_login():
        conn = get_db()
        body = request.get_json(force=True, silent=True) or {}
        aid, key = body.get("agent_id"), body.get("key")
        if not aid or not key:
            return _err("agent_id and key required")
        arow = conn.execute(
            "SELECT id FROM agents WHERE id=? OR lower(name)=lower(?) OR lower(full_name)=lower(?)",
            (aid, aid, aid)).fetchone()
        if not arow:
            return _err("unknown agent", 401)
        real_id = arow["id"]
        row = conn.execute(
            "SELECT 1 FROM keys WHERE agent_id=? AND key_hash=? AND revoked_at IS NULL",
            (real_id, security.hash_secret(key))).fetchone()
        if not row:
            return _err("invalid key", 401)
        session.permanent = True
        session["agent_id"] = real_id
        return jsonify({"ok": True, "agent_id": real_id})

    @app.post("/v1/ui/logout")
    def ui_logout():
        session.pop("agent_id", None)
        return jsonify({"ok": True})

    @app.get("/v1/ui/me")
    def ui_me():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err("login required", 401)
        return jsonify({"ok": True, "agent": _agent_public(actor, include_private=True)})

    @app.post("/v1/ui/join")
    def ui_join():
        """手机扫码入会：用一次性分享令牌换取会话（默认以真人身份）。"""
        conn = get_db()
        body = request.get_json(force=True, silent=True) or {}
        sh = rooms.resolve_share(conn, body.get("token"))
        if not sh:
            return _err("二维码已失效或过期", 401)
        aid = sh.get("as_agent") or rooms.human_id(conn)
        try:
            rooms.force_add_member(conn, sh["room_id"], aid)
        except ValueError:
            pass
        session.permanent = True
        session["agent_id"] = aid
        return jsonify({"ok": True, "room_id": sh["room_id"], "agent_id": aid})

    @app.get("/v1/health")
    def health():
        return jsonify({"ok": True, "service": "teamai",
                        "protocol": distribution.PROTOCOL_VERSION,
                        "runtime_version": distribution.runtime_version(),
                        "time": datetime.now().isoformat(timespec="seconds")})

    # ---------------- public TAA installer / local package ----------------
    # 公开包和安装脚本都不需要 key；安装时再校验 agent key。
    # 第一台节点安装后会把包存到 $TAA_HOME/dist，第二台优先从这里拉。
    def _taa_home_dir() -> pathlib.Path:
        return pathlib.Path(os.environ.get("TAA_HOME") or "~/.taa").expanduser()

    def _taa_package_dirs() -> list[pathlib.Path]:
        raw = os.environ.get("TAA_DIST_DIR", "").strip()
        dirs = []
        if raw:
            dirs.extend(pathlib.Path(x).expanduser() for x in raw.split(os.pathsep) if x.strip())
        dirs += [
            _taa_home_dir() / "dist",
            pathlib.Path(ROOT) / "dist",
            pathlib.Path(ROOT).parent / "dist",
        ]
        seen = set()
        out = []
        for d in dirs:
            key = str(d)
            if key not in seen:
                seen.add(key)
                out.append(d)
        return out

    def _taa_package_path(version: str | None = None) -> pathlib.Path | None:
        env = os.environ.get("TAA_PACKAGE", "").strip()
        if env:
            p = pathlib.Path(env).expanduser()
            if p.is_file():
                return p
        for d in _taa_package_dirs():
            if version:
                p = d / f"taa_agent-core-{version}.tar.gz"
                if p.is_file():
                    return p
            else:
                p = d / "taa_agent-core-latest.tar.gz"
                if p.is_file():
                    return p
                found = sorted(d.glob("taa_agent-core-*.tar.gz"),
                               key=lambda x: x.stat().st_mtime, reverse=True)
                if found:
                    return found[0]
        return None

    def _taa_package_version(p: pathlib.Path) -> str:
        m = re.search(r"taa_agent-core-(.+)\.tar\.gz$", p.name)
        if m and m.group(1) != "latest":
            return m.group(1)
        try:
            return (pathlib.Path(ROOT) / "VERSION").read_text(encoding="utf-8").strip() or "unknown"
        except OSError:
            return "unknown"

    def _taa_package_response(p: pathlib.Path, download_name: str):
        body_sha = hashlib.sha256(p.read_bytes()).hexdigest()
        resp = send_file(p, mimetype="application/gzip", as_attachment=True,
                         download_name=download_name, conditional=True)
        resp.headers["Cache-Control"] = "public, max-age=60"
        resp.headers["X-TAA-Package-Version"] = _taa_package_version(p)
        resp.headers["X-TAA-Package-Sha256"] = body_sha
        return resp

    @app.get("/install.sh")
    def taa_install_script():
        candidates = []
        env = os.environ.get("TAA_INSTALL_SCRIPT", "").strip()
        if env:
            candidates.append(pathlib.Path(env).expanduser())
        candidates += [
            pathlib.Path(ROOT) / "install.sh",
            pathlib.Path(ROOT) / "dist" / "install.sh",
        ]
        for p in candidates:
            if p.is_file():
                resp = send_file(p, mimetype="text/x-shellscript", as_attachment=False,
                                 download_name="install.sh", conditional=True)
                resp.headers["Cache-Control"] = "no-store"
                return resp
        return _err("install.sh not found", 404)

    @app.get("/dist/taa-complete-latest.tar.gz")
    def taa_package_latest():
        p = _taa_package_path()
        if not p:
            return _err("package not available on this node; install once from public package", 404)
        return _taa_package_response(p, "taa-complete-latest.tar.gz")

    @app.get("/dist/taa-complete-<version>.tar.gz")
    def taa_package_version(version):
        if not re.fullmatch(r"[0-9A-Za-z][0-9A-Za-z._-]{0,63}", version or ""):
            return _err("invalid version", 404)
        p = _taa_package_path(version)
        if not p:
            return _err("package version not found on this node", 404)
        return _taa_package_response(p, f"taa-complete-{version}.tar.gz")

    # ---------------- bootstrap / dist ----------------
    @app.get("/v1/bootstrap/manifest")
    def bootstrap_manifest():
        conn = get_db()
        authorized = bool(auth.enroll_token_row(conn, _enroll_token_header()))
        if not authorized:
            agent, _ = auth.authenticate(conn, request)
            authorized = agent is not None
        if not authorized:
            return _err("valid enroll token or key required", 401)
        return jsonify({"ok": True, **distribution.manifest()})

    @app.get("/v1/dist/<name>/<version>")
    def dist_download(name, version):
        conn = get_db()
        authorized = bool(auth.enroll_token_row(conn, _enroll_token_header()))
        if not authorized:
            agent, _ = auth.authenticate(conn, request)
            authorized = agent is not None
        if not authorized:
            return _err("enroll token or key required", 401)
        path = distribution.program_path(name, version)
        if not path:
            return _err("program/version not found", 404)
        return send_file(path, as_attachment=True, download_name=f"{name}.py",
                         mimetype="text/x-python")

    @app.get("/v1/dist/bundle")
    def dist_bundle():
        """全量签名发行版包（tar.gz）——供新节点从本节点继承。"""
        from flask import Response
        conn = get_db()
        authorized = bool(auth.enroll_token_row(conn, _enroll_token_header()))
        if not authorized:
            agent, _ = auth.authenticate(conn, request)
            authorized = agent is not None
        if not authorized:
            return _err("enroll token or key required", 401)
        data = distribution.bundle()
        return Response(data, mimetype="application/gzip", headers={
            "Content-Disposition": "attachment; filename=teamai-bundle.tar.gz",
            "X-Bundle-Sha256": hashlib.sha256(data).hexdigest(),
            "X-Bundle-Signature": distribution.sign_bytes(data),
            "X-Bundle-Protocol": protocol.PROTOCOL_VERSION,
            "X-Runtime-Version": distribution.runtime_version(),
        })

    # ---------------- enroll / handshake ----------------
    @app.post("/v1/enroll")
    def enroll():
        conn = get_db()
        token = _enroll_token_header()
        if not auth.enroll_token_row(conn, token):
            return _err("valid enroll token required", 401)
        body = request.get_json(force=True, silent=True) or {}
        aid = (body.get("agent_id") or "").strip()
        if not aid:
            return _err("agent_id required")
        if conn.execute("SELECT 1 FROM agents WHERE id=?", (aid,)).fetchone():
            return _err("agent id already exists; use /v1/recover or admin reissue", 409)
        name = body.get("name") or aid.capitalize()
        p = body.get("persona") or {"id": aid, "name": name,
                                    "role": body.get("role", "executor")}
        p.setdefault("id", aid)
        p.setdefault("name", name)
        conn.execute(
            "INSERT INTO agents(id, name, role, persona_json, status, last_seen) "
            "VALUES (?,?,?,?, 'active', datetime('now','localtime'))",
            (aid, name, body.get("role", p.get("role", "executor")),
             json.dumps(p, ensure_ascii=False)),
        )
        key_id = security.gen_key_id()
        key = security.gen_key()
        conn.execute(
            "INSERT INTO keys(key_id, agent_id, key_hash, key_enc, label) VALUES (?,?,?,?,?)",
            (key_id, aid, security.hash_secret(key), security.encrypt(key), "primary"),
        )
        recovery = security.gen_token()
        conn.execute("INSERT INTO recovery_codes(agent_id, code_hash) VALUES (?,?)",
                     (aid, security.hash_secret(recovery)))
        auth.consume_enroll_token(conn, token)
        conn.execute("INSERT INTO audit_log(actor, action, target, ip) VALUES (?,?,?,?)",
                     (aid, "enroll", aid, request.remote_addr))
        conn.commit()
        return jsonify({"ok": True, "agent_id": aid, "name": name,
                        "key_id": key_id, "key": key, "recovery_code": recovery})

    @app.post("/v1/handshake")
    def handshake():
        conn = get_db()
        agent, err = _require_agent(conn)
        if not agent:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        hw = body.get("hardware") or {}
        # 协议契约（R30）：major 不同硬拒；minor 不同记录并降级
        client_proto = str(body.get("protocol_version") or "")
        compat = protocol.compat(client_proto)
        if compat == "major":
            return jsonify({"ok": False,
                            "error": f"protocol major mismatch: client={client_proto} "
                                     f"server={protocol.PROTOCOL_VERSION}",
                            "update": {"required": True, "protocol_ok": False,
                                       "manifest": distribution.manifest()}}), 409
        first_time = conn.execute(
            "SELECT 1 FROM handshakes WHERE agent_id=? LIMIT 1", (agent["id"],)).fetchone() is None
        try:
            node_id = _upsert_node(conn, hw, int(hw.get("is_main", 0)))
        except ValueError as e:
            return _err(str(e))
        full_name = f"{agent['name']}@{node_id}"
        status = body.get("status") or "active"
        conn.execute(
            "UPDATE agents SET node_id=?, full_name=?, status=?, "
            "last_seen=datetime('now','localtime') WHERE id=?",
            (node_id, full_name, status, agent["id"]),
        )
        conn.execute(
            "INSERT INTO handshakes(agent_id, node_id, protocol_version, runtime_version, "
            "capabilities, ip) VALUES (?,?,?,?,?,?)",
            (agent["id"], node_id, body.get("protocol_version"), body.get("runtime_version"),
             json.dumps(body.get("capabilities", [])), request.remote_addr),
        )
        conn.execute(
            "INSERT INTO agent_runtime(agent_id, protocol_version, runtime_version, packages, "
            "code_hash, last_seen) VALUES (?,?,?,?,?,datetime('now','localtime')) "
            "ON CONFLICT(agent_id) DO UPDATE SET protocol_version=excluded.protocol_version, "
            "runtime_version=excluded.runtime_version, packages=excluded.packages, "
            "code_hash=excluded.code_hash, last_seen=datetime('now','localtime')",
            (agent["id"], body.get("protocol_version"), body.get("runtime_version"),
             json.dumps(body.get("packages", []), ensure_ascii=False),
             body.get("code_hash")),
        )
        onboard_info = None
        if first_time:
            try:
                onboard_info = community.onboard(conn, agent["id"])
            except Exception:
                onboard_info = None
        conn.commit()
        manifest = distribution.manifest()
        installed = {}
        for p in (body.get("packages") or []):
            if isinstance(p, dict):
                installed[p.get("name")] = p.get("sha256")
        stale = [p["name"] for p in manifest["programs"] if installed.get(p["name"]) != p["sha256"]]
        update = {"required": bool(stale), "protocol_ok": True, "stale": stale,
                  "manifest_version": manifest["runtime_version"], "serial": manifest["serial"]}
        briefing = {
            "constitution": [dict(r) for r in conn.execute(
                "SELECT rule_key, content FROM constitution_rules WHERE active=1 ORDER BY id")],
            "channels": [r["name"] for r in conn.execute(
                "SELECT name FROM channels WHERE archived=0 ORDER BY name")],
            "manifest": manifest,
            "next_steps": [
                "阅读 constitution",
                "在 #standup 发一条 standup（--type standup）",
                "GET /v1/tasks?for_agent=<你> 认领任务",
                f"每 {SYNC_INTERVAL_MIN} 分钟 GET /v1/sync 同步",
            ],
        }
        return jsonify({"ok": True, "identity": full_name, "agent_id": agent["id"],
                        "node_id": node_id, "role": agent["role"], "status": status,
                        "protocol_version": distribution.PROTOCOL_VERSION,
                        "runtime_version": distribution.runtime_version(),
                        "sync_interval_min": SYNC_INTERVAL_MIN,
                        "onboarding": onboard_info,
                        "update": update,
                        "card": _agent_card(conn, agent, request.host_url.rstrip("/")),
                        "briefing": briefing,
                        "server_time": datetime.now().isoformat(timespec="seconds")})

    @app.get("/v1/agent-card")
    def agent_card():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "card": _agent_card(conn, actor, request.host_url.rstrip("/"))})

    @app.get("/v1/me")
    def me():
        conn = get_db()
        agent, err = _require_agent(conn)
        if not agent or agent.get("id") == "anonymous":
            return _err(err or "login required", 401)
        return jsonify({"ok": True, "agent": _agent_public(agent, include_private=True)})

    # ---------------- keys / recovery ----------------
    @app.get("/v1/keys")
    def key_list():
        conn = get_db()
        agent, err = _require_agent(conn)
        if not agent:
            return _err(err, 401)
        rows = conn.execute(
            "SELECT key_id, label, created_at, expires_at, revoked_at, last_used_at "
            "FROM keys WHERE agent_id=? ORDER BY created_at", (agent["id"],)
        ).fetchall()
        return jsonify({"ok": True, "keys": [dict(r) for r in rows]})

    @app.post("/v1/keys/rotate")
    def key_rotate():
        conn = get_db()
        agent, err = _require_agent(conn)
        if not agent:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        key_id = security.gen_key_id()
        key = security.gen_key()
        conn.execute(
            "INSERT INTO keys(key_id, agent_id, key_hash, key_enc, label) VALUES (?,?,?,?,?)",
            (key_id, agent["id"], security.hash_secret(key), security.encrypt(key), "rotated"),
        )
        if body.get("revoke_old"):
            conn.execute(
                "UPDATE keys SET revoked_at=datetime('now','localtime') "
                "WHERE agent_id=? AND key_id!=? AND revoked_at IS NULL",
                (agent["id"], key_id),
            )
        conn.commit()
        return jsonify({"ok": True, "key_id": key_id, "key": key})

    @app.post("/v1/keys/revoke")
    def key_revoke():
        conn = get_db()
        agent, err = _require_agent(conn)
        if not agent:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        kid = body.get("key_id")
        row = conn.execute("SELECT * FROM keys WHERE key_id=? AND agent_id=?",
                           (kid, agent["id"])).fetchone()
        if not row:
            return _err("key not found", 404)
        conn.execute("UPDATE keys SET revoked_at=datetime('now','localtime') WHERE key_id=?", (kid,))
        conn.commit()
        return jsonify({"ok": True, "revoked": kid})

    @app.post("/v1/recover")
    def recover():
        conn = get_db()
        body = request.get_json(force=True, silent=True) or {}
        aid = body.get("agent_id")
        code = body.get("recovery_code")
        if not aid or not code:
            return _err("agent_id and recovery_code required")
        row = conn.execute("SELECT * FROM recovery_codes WHERE agent_id=?", (aid,)).fetchone()
        if not row or row["used_at"] or row["code_hash"] != security.hash_secret(code):
            return _err("invalid recovery code", 401)
        key_id = security.gen_key_id()
        key = security.gen_key()
        conn.execute(
            "INSERT INTO keys(key_id, agent_id, key_hash, key_enc, label) VALUES (?,?,?,?,?)",
            (key_id, aid, security.hash_secret(key), security.encrypt(key), "recovered"),
        )
        conn.execute("UPDATE recovery_codes SET used_at=datetime('now','localtime') WHERE agent_id=?", (aid,))
        conn.execute("INSERT INTO audit_log(actor, action, target, ip) VALUES (?,?,?,?)",
                     (aid, "recover", aid, request.remote_addr))
        conn.commit()
        return jsonify({"ok": True, "agent_id": aid, "key_id": key_id, "key": key})

    @app.post("/v1/agents/issue")
    def agent_issue():
        """root 令牌：为指定 agent 签发 key（不存在则先创建）。一次性返回明文 key。"""
        conn = get_db()
        if not auth.is_root(conn, _enroll_token_header()):
            return _err("root enroll token required", 401)
        body = request.get_json(force=True, silent=True) or {}
        aid = (body.get("agent_id") or "").strip()
        if not aid:
            return _err("agent_id required")
        name = body.get("name") or aid.capitalize()
        exists = conn.execute("SELECT 1 FROM agents WHERE id=?", (aid,)).fetchone()
        if not exists:
            p = {"id": aid, "name": name, "role": body.get("role", "executor"),
                 "identity": {"motto": "新加入的 agent"}}
            conn.execute(
                "INSERT INTO agents(id, name, kind, role, persona_json, status, last_seen) "
                "VALUES (?,?, 'ai', ?, ?, 'active', datetime('now','localtime'))",
                (aid, name, body.get("role", "executor"), json.dumps(p, ensure_ascii=False)))
        key_id = security.gen_key_id()
        key = security.gen_key()
        conn.execute("INSERT INTO keys(key_id, agent_id, key_hash, key_enc, label) VALUES (?,?,?,?,?)",
                     (key_id, aid, security.hash_secret(key), security.encrypt(key), "issued"))
        conn.execute("INSERT INTO audit_log(actor, action, target, ip) VALUES (?,?,?,?)",
                     ("root", "issue_key", aid, request.remote_addr))
        conn.commit()
        return jsonify({"ok": True, "agent_id": aid, "name": name, "created": not exists,
                        "key_id": key_id, "key": key})

    @app.post("/v1/agents/<agent_id>/keys")
    def admin_reissue(agent_id):
        conn = get_db()
        if not auth.is_root(conn, _enroll_token_header()):
            return _err("root enroll token required", 401)
        if not conn.execute("SELECT 1 FROM agents WHERE id=?", (agent_id,)).fetchone():
            return _err("agent not found", 404)
        key_id = security.gen_key_id()
        key = security.gen_key()
        conn.execute(
            "INSERT INTO keys(key_id, agent_id, key_hash, key_enc, label) VALUES (?,?,?,?,?)",
            (key_id, agent_id, security.hash_secret(key), security.encrypt(key), "admin_reissue"),
        )
        conn.execute("INSERT INTO audit_log(actor, action, target, ip) VALUES (?,?,?,?)",
                     ("root", "admin_reissue", agent_id, request.remote_addr))
        conn.commit()
        return jsonify({"ok": True, "agent_id": agent_id, "key_id": key_id, "key": key})

    # ---------------- enroll tokens ----------------
    @app.post("/v1/enroll-tokens")
    def enroll_token_create():
        conn = get_db()
        root = auth.is_root(conn, _enroll_token_header())
        actor = None
        if not root:
            actor, err = _require_agent(conn)
            if not actor:
                return _err(err, 401)
            if actor["role"] != "coordinator":
                return _err("coordinator role or root token required", 403)
        body = request.get_json(force=True, silent=True) or {}
        token = security.gen_token()
        token_id = security.gen_key_id()
        conn.execute(
            "INSERT INTO enroll_tokens(token_id, token_hash, kind, created_by, max_uses, expires_at) "
            "VALUES (?,?,?,?,?,?)",
            (token_id, security.hash_secret(token), "invite",
             actor["id"] if actor else "root", body.get("max_uses"), body.get("expires_at")),
        )
        _audit(conn, actor["id"] if actor else "root", "mint_token", token_id,
               {"max_uses": body.get("max_uses"), "expires_at": body.get("expires_at")})
        conn.commit()
        return jsonify({"ok": True, "token_id": token_id, "token": token,
                        "max_uses": body.get("max_uses"), "expires_at": body.get("expires_at")})

    @app.get("/v1/enroll-tokens")
    def enroll_token_list():
        conn = get_db()
        root = auth.is_root(conn, _enroll_token_header())
        if not root:
            actor, err = _require_agent(conn)
            if not actor:
                return _err(err, 401)
            if actor["role"] != "coordinator":
                return _err("coordinator role or root token required", 403)
        rows = conn.execute(
            "SELECT token_id, kind, created_by, max_uses, uses, expires_at, revoked_at, created_at "
            "FROM enroll_tokens ORDER BY created_at DESC"
        ).fetchall()
        return jsonify({"ok": True, "tokens": [dict(r) for r in rows]})

    # ---------------- nodes ----------------
    @app.get("/v1/nodes")
    def node_list():
        conn = get_db()
        agent, err = _require_agent(conn)
        if not agent:
            return _err(err, 401)
        me = _node_log().node_id
        rows = conn.execute("SELECT * FROM nodes ORDER BY is_main DESC, alias").fetchall()
        out = []
        for r in rows:
            d = _node_public(dict(r))
            d["local"] = (r["id"] == me)
            d["agents"] = conn.execute(
                "SELECT COUNT(*) c FROM agents WHERE node_id=?", (r["id"],)).fetchone()["c"]
            out.append(d)
        return jsonify({"ok": True, "self": me, "nodes": out})

    @app.post("/v1/heartbeat")
    def heartbeat():
        conn = get_db()
        agent, err = _require_agent(conn)
        if not agent:
            return _err(err, 401)
        if not agent.get("node_id"):
            return _err("handshake first to bind a node")
        body = request.get_json(force=True, silent=True) or {}
        free = body.get("disk_free_gb")
        conn.execute(
            "UPDATE nodes SET disk_free_gb=COALESCE(?, disk_free_gb), "
            "last_seen=datetime('now','localtime') WHERE id=?",
            (free, agent["node_id"]),
        )
        conn.execute(
            "INSERT INTO node_metrics(node_id, disk_free_gb, load_avg, online_agents) VALUES (?,?,?,?)",
            (agent["node_id"], free, body.get("load_avg"), body.get("online_agents")),
        )
        conn.commit()
        return jsonify({"ok": True, "node_id": agent["node_id"], "disk_free_gb": free})

    # ---------------- agents ----------------
    @app.get("/v1/agents/<agent_id>/origin")
    def agent_origin(agent_id):
        """判定 agent 来自哪台机器：node 绑定 + 握手来源 IP + gossip 对端。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        a = conn.execute("SELECT id,name,node_id FROM agents WHERE id=?", (agent_id,)).fetchone()
        if not a:
            return _err("agent not found", 404)
        node = (conn.execute("SELECT alias,node_code,lan_ip FROM nodes WHERE id=?",
                             (a["node_id"],)).fetchone() if a["node_id"] else None)
        hs = conn.execute("SELECT ip,created_at FROM handshakes WHERE agent_id=? "
                          "ORDER BY created_at DESC LIMIT 1", (agent_id,)).fetchone()
        last_ip = hs["ip"] if hs else None
        node_ip = node["lan_ip"] if node else None
        # 关键：与本机节点比较（而不是 agent 自己节点的 IP）
        self_node = _node_log().node_id
        srow = conn.execute("SELECT lan_ip FROM nodes WHERE id=?", (self_node,)).fetchone()
        self_ip = srow["lan_ip"] if srow else None
        if a["node_id"] is None:
            is_local = None
        else:
            is_local = (a["node_id"] == self_node) or (last_ip in ("127.0.0.1", "::1"))
        peers = _GOSSIP.peers() if _GOSSIP else {}
        return jsonify({
            "ok": True, "agent": agent_id, "node_id": a["node_id"],
            "node_alias": (node["alias"] if node else None),
            "node_code": (node["node_code"] if node else None),
            "node_lan_ip": node_ip, "last_handshake_ip": last_ip,
            "last_handshake_at": (hs["created_at"] if hs else None),
            "self_node": self_node, "self_lan_ip": self_ip,
            "is_local": is_local, "peers": peers,
            "verdict": ("本地（同机进程）" if is_local else
                        ("远程（来自其他机器）" if is_local is False else "未知"))})

    @app.post("/v1/agents/<agent_id>/command")
    def agent_command(agent_id):
        """真人给某 agent 下远程指令（如 self-update）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor.get("kind") != "human":
            return _err(err or "forbidden", 403)
        b = request.get_json(force=True, silent=True) or {}
        cmd = (b.get("cmd") or "").strip()
        if not cmd:
            return _err("cmd required", 400)
        if not conn.execute("SELECT 1 FROM agents WHERE id=?", (agent_id,)).fetchone():
            return _err("agent not found", 404)
        cid = commands_mod.push(conn, agent_id, cmd, b.get("payload"))
        # self-update 只替换文件；必须自动跟一条 restart，收敛旧 supervisor/子进程。
        # 旧客户端会在应用更新后 execv 新 chatroom，再由它消费这条命令。
        if cmd in ("self-update", "update"):
            commands_mod.push(conn, agent_id, "restart-executor",
                              {"reason": "after-self-update"})
        _audit(conn, actor["id"], "agent_command", agent_id, {"cmd": cmd})
        conn.commit()
        return jsonify({"ok": True, "command_id": cid, "cmd": cmd})

    @app.get("/v1/agents/<agent_id>/commands")
    def agent_commands(agent_id):
        """agent 驱动轮询自己的待执行指令（一次性取走）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] != agent_id:
            return _err(err or "forbidden", 403)
        return jsonify({"ok": True, "commands": commands_mod.take(conn, agent_id)})

    @app.get("/v1/agents")
    def agent_list():
        conn = get_db()
        agent, err = _require_agent(conn)
        if not agent:
            return _err(err, 401)
        rows = conn.execute("SELECT * FROM agents ORDER BY full_name").fetchall()
        return jsonify({"ok": True, "agents": [_agent_public(dict(r)) for r in rows]})

    @app.get("/v1/agents/<agent_id>")
    def agent_get(agent_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        row = conn.execute("SELECT * FROM agents WHERE id=?", (agent_id,)).fetchone()
        if not row:
            return _err("agent not found", 404)
        return jsonify({"ok": True, "agent": _agent_public(dict(row))})

    @app.put("/v1/agents/<agent_id>/status")
    def agent_status(agent_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        st = body.get("status")
        if st not in ("active", "idle", "busy", "offline", "paused"):
            return _err("bad status")
        conn.execute("UPDATE agents SET status=? WHERE id=?", (st, agent_id))
        conn.commit()
        return jsonify({"ok": True, "agent_id": agent_id, "status": st})

    @app.put("/v1/agents/<agent_id>/activity")
    def agent_activity_put(agent_id):
        """上报执行进度（start/progress/done/blocked/idle），供看板与工作群可见。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        stage = body.get("stage")
        if stage not in activity_mod.STAGES:
            return _err("bad stage")
        act = activity_mod.report(conn, agent_id, stage,
                                  task_id=body.get("task_id"), title=body.get("title"),
                                  detail=body.get("detail"))
        return jsonify({"ok": True, "agent_id": agent_id, "activity": act})

    @app.get("/v1/agents/<agent_id>/activity")
    def agent_activity_get(agent_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        act = activity_mod.get(conn, agent_id)
        if act:
            act["elapsed_s"] = activity_mod.elapsed_s(act)
            act["stale"] = activity_mod.is_stale(act)
        return jsonify({"ok": True, "agent_id": agent_id, "activity": act})

    @app.put("/v1/agents/<agent_id>/role")
    def agent_role(agent_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        role = body.get("role")
        if role not in ("coordinator", "executor"):
            return _err("role must be coordinator|executor")
        row = conn.execute("SELECT * FROM agents WHERE id=?", (agent_id,)).fetchone()
        if not row:
            return _err("agent not found", 404)
        frm = row["role"]
        if frm != role:
            conn.execute("UPDATE agents SET role=? WHERE id=?", (role, agent_id))
            conn.execute(
                "INSERT INTO role_history(agent_id, from_role, to_role, reason, changed_by) "
                "VALUES (?,?,?,?,?)", (agent_id, frm, role, body.get("reason"), actor["id"]),
            )
            _audit(conn, actor["id"], "role_change", agent_id, {"from": frm, "to": role})
        conn.commit()
        return jsonify({"ok": True, "agent_id": agent_id, "from_role": frm, "role": role})

    @app.get("/v1/employees")
    def employees_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "employees": hr.roster(conn)})

    @app.post("/v1/agents/<agent_id>/hire")
    def agent_hire(agent_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        if not body.get("position"):
            return _err("position required")
        try:
            res = hr.hire(conn, agent_id, body["position"], body.get("department", ""),
                          body.get("job_req", ""), body.get("level", ""),
                          body.get("employment_type", "outsourced"), body.get("note", ""),
                          by=actor["id"])
        except ValueError as e:
            return _err(str(e), 404)
        _audit(conn, actor["id"], "hire", agent_id, res)
        conn.commit()
        return jsonify({"ok": True, **res})

    @app.post("/v1/hr/match")
    def hr_match():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        return jsonify({"ok": True, "candidates": hr.match_agents(conn, body.get("job_req", ""))})

    @app.get("/v1/agents/<agent_id>/persona")
    def agent_persona_get(agent_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        arow = conn.execute("SELECT * FROM agents WHERE id=?", (agent_id,)).fetchone()
        if not arow:
            return _err("agent not found", 404)
        p = _loads(arow["persona_json"], {})
        if agent_id != actor["id"]:                 # 非本人：剥掉私密维度（身体/衣柜）
            p = persona_mod.strip_private(p)
        else:                                       # 本人：以**本机 persona.yaml** 为准（含私密维度）
            try:
                p = persona_mod.load_persona(agent_id)
            except Exception:  # noqa: BLE001
                pass
        return jsonify({"ok": True, "persona": p, "view": persona_mod.persona_view(p)})

    @app.post("/v1/agent/init")
    def agent_init():
        """初始化/重建某 agent 的人设：模板 + 覆盖（name/avatar/height）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        aid = body.get("id") or actor["id"]
        if actor.get("kind") != "human" and actor["id"] != aid:
            return _err("forbidden", 403)
        arow = conn.execute("SELECT * FROM agents WHERE id=?", (aid,)).fetchone()
        p = (_loads(arow["persona_json"], {}) or {}) if arow else {}
        if body.get("template"):
            try:
                tp = persona_mod.load_template(body["template"])
            except FileNotFoundError:
                return _err("unknown template", 400)
            tp.pop("_template", None)
            p = tp
        p["id"] = aid
        if body.get("say"):                      # 自然语言初始化
            nl = persona_mod.parse_nl(body["say"])
            if nl.get("name"):
                p["name"] = nl["name"]
            if nl.get("gender"):
                p.setdefault("identity", {})["gender"] = nl["gender"]
            if nl.get("age"):
                p.setdefault("body", {})["age"] = nl["age"]
            if nl.get("height_cm"):
                p.setdefault("body", {})["height_cm"] = nl["height_cm"]
            p["soul"] = persona_mod.parse_soul(nl.get("soul") or "")
        if body.get("name"):
            p["name"] = body["name"]
        if body.get("avatar"):
            p.setdefault("identity", {})["avatar"] = body["avatar"]
        if body.get("height_cm"):
            p.setdefault("body", {})["height_cm"] = body["height_cm"]
        if body.get("soul") is not None:         # 写一段文字 / 结构化 soul
            soul = body["soul"]
            if isinstance(soul, str):
                p["soul"] = persona_mod.parse_soul(soul)
            elif isinstance(soul, dict):
                p["soul"] = soul
        name = p.get("name") or aid
        # 私密维度默认不入共享库（body/wardrobe 留在本机 persona.yaml）；本人显式授权才保留
        _allow_priv = bool(body.get("allow_private")) and actor["id"] == aid
        _stored = json.dumps(_persona_for_store(p, allow_private=_allow_priv), ensure_ascii=False)
        issued = None
        if arow:                                 # 已存在：更新
            conn.execute("UPDATE agents SET name=?, persona_json=? WHERE id=?",
                         (name, _stored, aid))
        else:                                    # 不存在：一键建档（发 key）
            node_code = _primary_node_code(conn)
            node = conn.execute(
                "SELECT alias FROM nodes ORDER BY is_main DESC LIMIT 1").fetchone()
            full_name = f"{name}@{node_code}" if node_code else name
            conn.execute(
                "INSERT INTO agents(id, name, node_id, full_name, role, persona_json, last_seen) "
                "VALUES (?,?,?,?,?,?,datetime('now','localtime'))",
                (aid, name, (node["alias"] if node else None), full_name,
                 p.get("role", "executor"), _stored))
            key_id, key = security.gen_key_id(), security.gen_key()
            conn.execute("INSERT INTO keys(key_id, agent_id, key_hash, key_enc, label) "
                         "VALUES (?,?,?,?,?)",
                         (key_id, aid, security.hash_secret(key), security.encrypt(key), "primary"))
            issued = {"key_id": key_id, "key": key}
            try:
                d = os.path.join(ROOT, "agents", aid)
                os.makedirs(d, exist_ok=True)
                kp = os.path.join(d, ".key")
                with open(kp, "w", encoding="utf-8") as fh:
                    fh.write(json.dumps(issued, ensure_ascii=False))
                os.chmod(kp, 0o600)
            except Exception:
                pass
        _audit(conn, actor["id"], "agent_init", aid,
               {"template": body.get("template"), "created": not arow})
        conn.commit()
        try:
            persona_mod.save_persona(aid, p)
        except Exception:
            pass
        out = {"ok": True, "agent_id": aid, "created": not arow,
               "view": persona_mod.persona_view(p)}
        if issued:
            out.update(issued)
        return jsonify(out)

    @app.post("/v1/agents/<agent_id>/soul/evolve")
    def agent_soul_evolve(agent_id):
        """自我演化：向 agent 的 soul 追加一条演化记录（保留历史快照，可回滚）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        if actor.get("kind") != "human" and actor["id"] != agent_id:
            return _err("forbidden", 403)
        body = request.get_json(force=True, silent=True) or {}
        change = (body.get("change") or "").strip()
        if not change:
            return _err("change required")
        arow = conn.execute("SELECT * FROM agents WHERE id=?", (agent_id,)).fetchone()
        if not arow:
            return _err("agent not found", 404)
        p = _loads(arow["persona_json"], {}) or {}
        p.setdefault("soul_history", []).append(
            {"at": datetime.now().strftime("%Y-%m-%d %H:%M"), "soul": p.get("soul")})
        p["soul_history"] = p["soul_history"][-20:]
        persona_mod.soul_evolve(p, change, body.get("reason") or "")
        conn.execute("UPDATE agents SET persona_json=? WHERE id=?",
                     (json.dumps(p, ensure_ascii=False), agent_id))
        _audit(conn, actor["id"], "soul_evolve", agent_id, {"change": change})
        conn.commit()
        try:
            persona_mod.save_persona(agent_id, p)
        except Exception:
            pass
        return jsonify({"ok": True, "soul": persona_mod.soul_view(p)})

    @app.post("/v1/agent/import")
    def agent_import():
        """导入一份完整档案为新 agent（可轻改 id/name）。返回其 key（供本机使用）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        p = body.get("persona") or {}
        if not isinstance(p, dict) or not p:
            return _err("persona required")
        name = (body.get("name") or p.get("name") or "Agent").strip()
        aid = (body.get("id") or p.get("id") or "").strip()
        if not aid:
            aid = "".join(c for c in name.lower() if c.isalnum())[:24] or "agent"
        if conn.execute("SELECT 1 FROM agents WHERE id=?", (aid,)).fetchone():
            return _err("agent id already exists", 409)
        p["id"] = aid
        p["name"] = name
        p.pop("_template", None)
        # 导入的档案默认**不带私密维度**入共享库（除非导入者本人显式 allow_private）
        _imp_priv = bool(body.get("allow_private")) and actor["id"] == aid
        conn.execute("INSERT INTO agents(id, name, node_id, full_name, role, persona_json, last_seen) "
                     "VALUES (?,?,?,?,?,?,datetime('now','localtime'))",
                     (aid, name, None, name, p.get("role", "executor"),
                      json.dumps(_persona_for_store(p, allow_private=_imp_priv), ensure_ascii=False)))
        key_id, key = security.gen_key_id(), security.gen_key()
        conn.execute("INSERT INTO keys(key_id, agent_id, key_hash, key_enc, label) VALUES (?,?,?,?,?)",
                     (key_id, aid, security.hash_secret(key), security.encrypt(key), "primary"))
        _audit(conn, actor["id"], "agent_import", aid)
        conn.commit()
        try:
            persona_mod.save_persona(aid, p)
        except Exception:
            pass
        try:
            d = os.path.join(ROOT, "agents", aid)
            os.makedirs(d, exist_ok=True)
            kp = os.path.join(d, ".key")
            with open(kp, "w", encoding="utf-8") as fh:
                fh.write(json.dumps({"key_id": key_id, "key": key}, ensure_ascii=False))
            os.chmod(kp, 0o600)
        except Exception:
            pass
        return jsonify({"ok": True, "agent_id": aid, "name": name, "key_id": key_id, "key": key})

    @app.put("/v1/agents/<agent_id>/persona")
    def agent_persona(agent_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        p = body.get("persona")
        if not isinstance(p, dict):
            return _err("persona object required")
        if not conn.execute("SELECT 1 FROM agents WHERE id=?", (agent_id,)).fetchone():
            return _err("agent not found", 404)
        # 私密维度默认不入共享库；仅本人显式 allow_private 才保留
        _allow_priv = bool(body.get("allow_private")) and actor["id"] == agent_id
        if actor["id"] == agent_id:                 # 本人编辑：**落本机 persona.yaml**（含私密维度）
            try:
                persona_mod.save_persona(agent_id, p)
            except Exception:  # noqa: BLE001
                pass
        _stored = _persona_for_store(p, allow_private=_allow_priv)
        conn.execute("UPDATE agents SET persona_json=? WHERE id=?",
                     (json.dumps(_stored, ensure_ascii=False), agent_id))
        conn.commit()
        try:
            persona_mod.save_persona(agent_id, p)
        except Exception:
            pass
        return jsonify({"ok": True, "agent_id": agent_id})

    # ---------------- projects ----------------
    @app.post("/v1/projects")
    def project_create():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        if not body.get("name"):
            return _err("name required")
        pid = body.get("id") or task_mod.new_id("p")
        conn.execute("INSERT INTO projects(id, name, goal, created_by) VALUES (?,?,?,?)",
                     (pid, body["name"], body.get("goal"), actor["id"]))
        conn.execute("INSERT OR IGNORE INTO project_members(project_id, member_id, kind, role,"
                     " share_write) VALUES (?,?,?,?,1)",
                     (pid, actor["id"], actor.get("kind") or "ai", "owner"))
        conn.commit()
        return jsonify({"ok": True, "project_id": pid})

    @app.get("/v1/projects")
    def project_list():
        """列出项目：默认**只看我参与的**（非成员不可见/不可枚举）；分享区口径同 `_share_actor`（不做匿名只读）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        if actor["id"] == "anonymous":
            return jsonify({"ok": True, "projects": []})
        mine = request.args.get("mine", "1").lower() not in ("0", "false", "no")
        if mine:
            rows = conn.execute(
                "SELECT p.* FROM projects p JOIN project_members m ON m.project_id=p.id"
                " WHERE m.member_id=? ORDER BY p.created_at", (actor["id"],)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM projects ORDER BY created_at").fetchall()
        return jsonify({"ok": True, "projects": [dict(r) for r in rows]})

    # ---------------- 项目分享区 · 安全交换（docs/71 §3 · S1–S6） ----------------
    def _share_actor(conn):
        """返回 (actor_id, None) 或 (None, error_response)。分享区不看匿名只读。"""
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return None, _err(err or "login required", 401)
        return actor["id"], None

    @app.post("/v1/projects/<pid>/members")
    def project_member_add(pid):
        conn = get_db()
        actor, resp = _share_actor(conn)
        if resp:
            return resp
        body = request.get_json(force=True, silent=True) or {}
        if not body.get("member_id"):
            return _err("member_id required")
        try:
            return jsonify({"ok": True, **share_mod.add_member(
                conn, pid, actor, body["member_id"], body.get("kind") or "ai",
                body.get("role") or "member", 1 if body.get("share_write", 1) else 0)})
        except share_mod.ShareError as e:
            return _err(e.msg, e.code)

    @app.get("/v1/projects/<pid>/members")
    def project_member_list(pid):
        conn = get_db()
        actor, resp = _share_actor(conn)
        if resp:
            return resp
        if not share_mod.is_member(conn, pid, actor):   # 非成员 → 403（越权面与分享区一致）
            return _err("非项目成员，禁止取数", 403)
        rows = conn.execute("SELECT * FROM project_members WHERE project_id=? ORDER BY joined_at",
                            (pid,)).fetchall()
        return jsonify({"ok": True, "members": [dict(r) for r in rows]})

    @app.post("/v1/projects/<pid>/share")
    def share_add(pid):
        """加条目：上传即签名（S1）；**只入库不执行**（S2）。"""
        conn = get_db()
        actor, resp = _share_actor(conn)
        if resp:
            return resp
        body = request.get_json(force=True, silent=True) or {}
        if not body.get("kind") or body.get("ref") in (None, ""):
            return _err("kind/ref required")
        content = None
        if body.get("content_b64"):
            content = base64.urlsafe_b64decode(body["content_b64"])
        try:
            return jsonify({"ok": True, **share_mod.add_item(
                conn, pid, actor, body["kind"], body["ref"],
                level=body.get("level") or "project", content=content,
                mime=body.get("mime"))})
        except share_mod.ShareError as e:
            return _err(e.msg, e.code)

    @app.get("/v1/projects/<pid>/share")
    def share_list(pid):
        conn = get_db()
        actor, resp = _share_actor(conn)
        if resp:
            return resp
        try:
            inc = request.args.get("include_revoked", "0").lower() in ("1", "true", "yes")
            return jsonify({"ok": True, "items": share_mod.list_items(conn, pid, actor, inc)})
        except share_mod.ShareError as e:
            return _err(e.msg, e.code)

    @app.post("/v1/projects/<pid>/share/<int:iid>/export")
    def share_export(pid, iid):
        """取数：先验签，失败即拒收（S1）。"""
        conn = get_db()
        actor, resp = _share_actor(conn)
        if resp:
            return resp
        try:
            return jsonify(share_mod.export_item(conn, pid, iid, actor))
        except share_mod.ShareError as e:
            return _err(e.msg, e.code)

    @app.post("/v1/projects/<pid>/share/<int:iid>/revoke")
    def share_revoke(pid, iid):
        conn = get_db()
        actor, resp = _share_actor(conn)
        if resp:
            return resp
        try:
            return jsonify(share_mod.revoke_item(conn, pid, iid, actor))
        except share_mod.ShareError as e:
            return _err(e.msg, e.code)

    @app.post("/v1/projects/<pid>/share/<int:iid>/execute")
    def share_execute(pid, iid):
        """执行：本机显式同意（S2）+ 沙箱（S3）+ 审计（S4）。默认不自动执行。"""
        conn = get_db()
        actor, resp = _share_actor(conn)
        if resp:
            return resp
        body = request.get_json(force=True, silent=True) or {}
        try:
            return jsonify({"ok": True, **share_mod.execute_item(
                conn, pid, iid, actor, consent_code=body.get("consent_code"),
                nonce=body.get("nonce"),
                timeout=int(body.get("timeout") or 20))})
        except share_mod.ShareError as e:
            return _err(e.msg, e.code)

    @app.get("/v1/projects/<pid>/exchanges")
    def share_exchanges(pid):
        """审计回放：谁/何时/什么哈希/结果（S4）。"""
        conn = get_db()
        actor, resp = _share_actor(conn)
        if resp:
            return resp
        if not share_mod.is_member(conn, pid, actor):
            return _err("非项目成员，禁止取数", 403)
        iid = request.args.get("item_id")
        return jsonify({"ok": True, "exchanges": share_mod.replay(
            conn, pid, int(iid) if iid else None)})

    @app.post("/v1/projects/<pid>/share/<int:iid>/apply")
    def share_apply(pid, iid):
        """应用（覆盖既有文件）→ 先快照，可一键回滚（S6）。"""
        conn = get_db()
        actor, resp = _share_actor(conn)
        if resp:
            return resp
        body = request.get_json(force=True, silent=True) or {}
        if not body.get("dest"):
            return _err("dest required")
        content = base64.urlsafe_b64decode(body["content_b64"]) if body.get("content_b64") else None
        try:
            return jsonify(share_mod.apply_with_rollback(conn, pid, iid, actor,
                                                         body["dest"], content))
        except share_mod.ShareError as e:
            return _err(e.msg, e.code)

    @app.post("/v1/projects/<pid>/rollback")
    def share_rollback(pid):
        """一键回滚到最近快照（复用 apply.rollback），并留审计（S6）。"""
        conn = get_db()
        actor, resp = _share_actor(conn)
        if resp:
            return resp
        body = request.get_json(force=True, silent=True) or {}
        try:
            return jsonify(share_mod.rollback_apply(conn, pid, actor, body.get("item_id")))
        except share_mod.ShareError as e:
            return _err(e.msg, e.code)

    # ---------------- tasks ----------------
    @app.post("/v1/tasks")
    def task_create():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        for f in ("title", "description", "acceptance_criteria"):
            if not body.get(f):
                return _err(f"{f} required")
        # 消息级幂等：同一群消息即使被多个 chatroom 进程处理，也只落一个任务。
        source_msg_id = (body.get("source_msg_id") or "").strip()
        if source_msg_id:
            old = conn.execute(
                "SELECT id FROM tasks WHERE json_extract(metadata, '$.source_msg_id')=? LIMIT 1",
                (source_msg_id,)).fetchone()
            if old:
                return jsonify({"ok": True, "task_id": old["id"], "duplicate": True})
        tid = body.get("id") or task_mod.new_id("t")
        status = body.get("status", "backlog")
        if status not in task_mod.TRANSITIONS:
            return _err("bad status")
        lane = "long" if (body.get("lane") == "long" or "long" in (body.get("tags") or [])) else "short"
        raw_phases = body.get("phases") or []
        try:
            phases = para_mod.normalize_phases(raw_phases) if raw_phases else []
        except para_mod.ParaError as e:
            return _err(str(e), 409)
        if phases and lane != "long":
            return _err("phase contract only for long tasks", 409)
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        meta = {
            "for_agent": (body.get("for_agent") or None),
            "source_msg_id": source_msg_id or None,
            "lane": lane,
            "kind": lane,
            "phase": body.get("phase") or (phases[0]["id"] if phases else None),
            "phase_index": 0 if phases else None,
            "phase_status": "active" if phases else None,
            "phases": phases,
        }
        if phases:
            meta["checkpoint"] = {"phase": phases[0]["id"], "completed": [],
                                  "next": phases[0]["id"], "artifacts": []}
            meta["checkpoint_at"] = now
        conn.execute(
            "INSERT INTO tasks(id, project_id, title, description, acceptance_criteria, priority, "
            "complexity, difficulty, status, required_skills, resource_req, tags, parent_id, created_by, "
            "metadata) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (tid, body.get("project_id"), body["title"], body["description"],
             body["acceptance_criteria"], int(body.get("priority", 1)),
             float(body.get("complexity", 0.5)), float(body.get("difficulty", 0.5)),
             status, json.dumps(body.get("required_skills", []), ensure_ascii=False),
             json.dumps(body.get("resource_req", {}), ensure_ascii=False),
             json.dumps(body.get("tags", []), ensure_ascii=False),
             body.get("parent_id"), actor["id"],
             json.dumps(meta, ensure_ascii=False)),
        )
        task_mod.record_event(conn, tid, actor["id"], None, status, "create")
        _audit(conn, actor["id"], "create_task", tid,
               {"title": body["title"], "priority": body.get("priority", 1), "status": status})
        conn.commit()
        _emit("task.created", {"id": tid, "title": body["title"], "by": actor["id"]})
        return jsonify({"ok": True, "task_id": tid})

    @app.get("/v1/tasks")
    def task_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        status = request.args.get("status")
        project = request.args.get("project_id")
        assigned = request.args.get("assigned_to")
        for_agent = request.args.get("for_agent")
        sql = "SELECT * FROM tasks WHERE 1=1"
        params: list = []
        if status:
            sql += " AND status=?"
            params.append(status)
        if project:
            sql += " AND project_id=?"
            params.append(project)
        if assigned:
            sql += " AND assigned_to=?"
            params.append(assigned)
        # 同优先级时新任务优先：旧 backlog 不能永远压住刚派的活。
        # 这里只决定候选的稳定顺序；for_agent 分支随后按 score 稳定排序。
        rows = conn.execute(sql + " ORDER BY priority DESC, created_at DESC", params).fetchall()
        result = [_task_public(dict(r)) for r in rows]

        if for_agent:
            arow = conn.execute("SELECT * FROM agents WHERE id=?", (for_agent,)).fetchone()
            if not arow:
                return _err("agent not found", 404)
            agent = dict(arow)
            p = _loads(agent["persona_json"], {})
            node = _node_of_agent(conn, agent)
            wip = task_mod.wip_count(conn, for_agent)
            queued = task_mod.queue_count(conn, for_agent)
            values = _loads(request.args.get("values"), {}) or p.get("values")
            scored = []
            for t in result:
                if t["status"] not in ("idea", "backlog"):
                    continue
                # ★ 钉给别人的任务不进我的候选（pin 只挡认领是不够的：会干扰选单排序）
                _pin = (_loads(t.get("metadata"), {}) or {}).get("for_agent")
                if _pin and _pin != for_agent:
                    continue
                s, feats = scoring.score_task(p, t, wip, node, values=values)
                t = dict(t)
                t["score"] = s
                t["score_features"] = feats
                scored.append(t)
            scored.sort(key=lambda x: x["score"], reverse=True)
            return jsonify({"ok": True, "agent": agent["full_name"], "wip": wip,
                            "queued": queued,
                            "lanes": task_mod.lane_counts(conn, for_agent),
                            "tasks": scored})

        return jsonify({"ok": True, "tasks": result})

    @app.get("/v1/tasks/<task_id>")
    def task_get(task_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        t = task_mod.get_task(conn, task_id)
        if not t:
            return _err("task not found", 404)
        ev = conn.execute("SELECT * FROM task_events WHERE task_id=? ORDER BY id", (task_id,)).fetchall()
        out = _task_public(t)
        out["events"] = [dict(e) for e in ev]
        return jsonify({"ok": True, "task": out})

    @app.get("/v1/tasks/<task_id>/deliverables")
    def task_deliverables(task_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        if not task_mod.get_task(conn, task_id):
            return _err("task not found", 404)
        return jsonify({"ok": True, "task_id": task_id,
                        "deliverables": task_mod.deliverables(conn, task_id)})

    @app.post("/v1/tasks/<task_id>/<action>")
    def task_action(task_id, action):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        try:
            if action == "claim":
                t = task_mod.claim(conn, task_id, actor["id"], score_json=body.get("score"),
                                   reason=body.get("reason"), force=bool(body.get("force")))
            elif action == "release":
                t = task_mod.release(conn, task_id, actor["id"], body.get("reason"))
            elif action == "start":
                t = task_mod.start(conn, task_id, actor["id"])
            elif action == "checkpoint":
                cp = body.get("checkpoint")
                if isinstance(cp, str):
                    try:
                        cp = json.loads(cp)
                    except Exception:  # noqa: BLE001
                        cp = {"note": cp}
                t = task_mod.checkpoint(conn, task_id, actor["id"], cp)
            elif action == "advance_phase":
                cp = body.get("checkpoint")
                if isinstance(cp, str):
                    try:
                        cp = json.loads(cp)
                    except Exception:  # noqa: BLE001
                        cp = {"note": cp}
                t = task_mod.advance_phase(conn, task_id, actor["id"], cp)
            elif action == "pause":
                cp = body.get("checkpoint")
                if isinstance(cp, str):
                    try:
                        cp = json.loads(cp)
                    except Exception:  # noqa: BLE001
                        cp = {"note": cp}
                t = task_mod.pause(conn, task_id, actor["id"], cp)
            elif action == "resume":
                t = task_mod.resume(conn, task_id, actor["id"])
            elif action == "submit":
                # ★ 交付帖不得是系统自动进度帖（tags 含 status/activity）——防"进度帖冒充交付"绕过门禁
                has_post = conn.execute(
                    "SELECT 1 FROM posts WHERE task_id=? "
                    "AND coalesce(tags,'') NOT LIKE '%\"activity\"%' "
                    "AND coalesce(tags,'') NOT LIKE '%\"status\"%' LIMIT 1", (task_id,)).fetchone()
                if not has_post:
                    return _err("review gate: 需至少 1 篇**交付**帖（系统自动进度帖不算；脱敏已通过）", 409)
                post = conn.execute(
                    "SELECT body, attachments FROM posts WHERE task_id=? "
                    "AND coalesce(tags,'') NOT LIKE '%\"activity\"%' "
                    "AND coalesce(tags,'') NOT LIKE '%\"status\"%' "
                    "ORDER BY id DESC LIMIT 1", (task_id,)).fetchone()
                if post:
                    bad = _artifact_mismatch(post["body"] or "", post["attachments"])
                    if bad:
                        return _err(f"artifact gate: {bad}", 409)
                t = task_mod.submit(conn, task_id, actor["id"], body.get("note"))
            elif action == "archive":
                t = task_mod.archive(conn, task_id, actor["id"], body.get("reason"))
            elif action == "block":
                t = task_mod.block(conn, task_id, actor["id"], body.get("reason"))
            elif action == "unblock":
                t = task_mod.unblock(conn, task_id, actor["id"], body.get("target", "in_progress"))
            elif action == "review":
                t = task_mod.review(conn, task_id, actor["id"], body.get("decision"),
                                    body.get("quality_score"), body.get("comments"))
                decision = body.get("decision")
                executor = t.get("assigned_to")
                if executor:
                    if decision == "approved":
                        q = float(body.get("quality_score") or 0.5)
                        points = round(10 + 20 * float(t.get("complexity") or 0.5) * q, 1)
                        etype = "task_approved"
                    elif decision == "request_changes":
                        points, etype = -2.0, "request_changes"
                        community.add_notification(conn, executor, "review", task_id,
                                                   f"任务 {task_id} 被打回，请修改后重新提交")
                    else:
                        points, etype = -5.0, "task_blocked"
                    conn.execute(
                        "INSERT INTO reputation_events(agent_id, task_id, event_type, points) "
                        "VALUES (?,?,?,?)", (executor, task_id, etype, points))
            elif action == "cancel":
                t = task_mod.cancel(conn, task_id, actor["id"], body.get("reason"))
            else:
                return _err("unknown action", 404)
        except task_mod.TaskError as e:
            return _err(str(e), 409)
        _audit(conn, actor["id"], f"task_{action}", task_id,
               {"status": (t or {}).get("status"), "decision": body.get("decision")})
        conn.commit()
        _ev = {"claim": "task.claimed", "start": "task.started", "submit": "task.submitted",
               "review": "task.reviewed", "cancel": "task.cancelled"}.get(action)
        if _ev:
            _emit(_ev, {"task_id": task_id, "agent": actor["id"]})
        return jsonify({"ok": True, "task": _task_public(t)})

    # ---------------- PARA：阶段 / 产物 / 方法 / 档案（docs/326） ----------------
    @app.get("/v1/para")
    def para_overview():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        agent_id = request.args.get("agent") or actor["id"]
        out = para_mod.overview(conn, agent_id)
        out["ok"] = True
        out["long_gate"] = task_mod.long_gate(conn, agent_id)
        return jsonify(out)

    @app.get("/v1/archive")
    def archive_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        agent_id = request.args.get("agent")
        lane = request.args.get("lane")
        try:
            items = para_mod.list_archive(conn, agent_id=agent_id, lane=lane,
                                          limit=int(request.args.get("limit", 100)))
        except para_mod.ParaError as e:
            return _err(str(e), 409)
        return jsonify({"ok": True, "archive": items})

    @app.get("/v1/tasks/<task_id>/phases")
    def phase_list(task_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            t = para_mod._task(conn, task_id)
        except para_mod.ParaError as e:
            return _err(str(e), 404)
        out = para_mod.phase_summary(t)
        out.update({"ok": True, "lane": para_mod.lane_of(t), "status": t["status"],
                    "checkpoint": para_mod._meta(t).get("checkpoint")})
        return jsonify(out)

    @app.post("/v1/tasks/<task_id>/phase")
    def phase_action(task_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        action = body.get("action") or "done"
        try:
            if action == "set":
                para_mod.set_phases(conn, task_id, actor["id"], body.get("phases") or [],
                                    force=bool(body.get("force")))
            elif action == "done":
                phase_id = body.get("phase_id") or body.get("phase")
                para_mod.complete_phase(conn, task_id, actor["id"], phase_id,
                                        evidence=body.get("evidence"),
                                        pause_after=bool(body.get("pause")))
            else:
                return _err("action must be set|done", 400)
        except para_mod.ParaError as e:
            return _err(str(e), 409)
        _audit(conn, actor["id"], f"task_phase_{action}", task_id,
               {"phase": body.get("phase_id") or body.get("phase")})
        conn.commit()
        t = task_mod.get_task(conn, task_id)
        out = para_mod.phase_summary(t)
        out.update({"ok": True, "task": _task_public(t)})
        return jsonify(out)

    @app.get("/v1/tasks/<task_id>/artifacts")
    def artifact_list(task_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        if not task_mod.get_task(conn, task_id):
            return _err("task not found", 404)
        items = para_mod.list_artifacts(
            conn, task_id, phase_id=request.args.get("phase"),
            include_archived=request.args.get("include_archived", "1") != "0")
        return jsonify({"ok": True, "artifacts": items})

    @app.post("/v1/tasks/<task_id>/artifacts")
    def artifact_add(task_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        try:
            art = para_mod.register_artifact(
                conn, task_id, actor["id"], kind=body.get("kind") or "file",
                path=body.get("path") or body.get("content"), title=body.get("title"),
                phase_id=body.get("phase") or body.get("phase_id"),
                sha256=body.get("sha256"), bytes_=body.get("bytes"),
                meta=body.get("meta") or {})
        except para_mod.ParaError as e:
            return _err(str(e), 409)
        _audit(conn, actor["id"], "artifact_add", art["id"],
               {"task_id": task_id, "path": art.get("path"), "phase": art.get("phase_id")})
        conn.commit()
        _emit("artifact.added", {"id": art["id"], "task_id": task_id})
        return jsonify({"ok": True, "artifact": art})

    @app.post("/v1/artifacts/<artifact_id>/archive")
    def artifact_archive(artifact_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            art = para_mod.archive_artifact(conn, artifact_id, actor["id"])
        except para_mod.ParaError as e:
            return _err(str(e), 404)
        _audit(conn, actor["id"], "artifact_archive", artifact_id, {})
        conn.commit()
        return jsonify({"ok": True, "artifact": art})

    @app.post("/v1/tasks/<task_id>/archive")
    def task_archive(task_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            t = para_mod.archive_task(conn, task_id, actor["id"])
        except para_mod.ParaError as e:
            return _err(str(e), 409)
        _audit(conn, actor["id"], "task_archive", task_id, {})
        conn.commit()
        return jsonify({"ok": True, "task": _task_public(t)})

    @app.get("/v1/methods")
    def method_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        items = para_mod.list_methods(conn, status=request.args.get("status"),
                                      project_id=request.args.get("project_id"))
        return jsonify({"ok": True, "methods": items})

    @app.get("/v1/methods/<key>")
    def method_get(key):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            m = para_mod.get_method(conn, key, request.args.get("version"))
        except para_mod.ParaError as e:
            return _err(str(e), 404)
        return jsonify({"ok": True, "method": m})

    @app.post("/v1/methods")
    def method_create():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        try:
            if body.get("from_task"):
                m = para_mod.method_from_task(
                    conn, actor["id"], body["from_task"],
                    slug=body.get("slug") or body["from_task"],
                    title=body.get("title"), steps=body.get("steps"),
                    trigger=body.get("trigger"), inputs=body.get("inputs"),
                    acceptance=body.get("acceptance"),
                    failure_handling=body.get("failure_handling"),
                    tools=body.get("tools"), status=body.get("status"))
            else:
                m = para_mod.create_method(
                    conn, actor["id"], slug=body.get("slug") or "", title=body.get("title") or "",
                    trigger=body.get("trigger"), inputs=body.get("inputs"),
                    steps=body.get("steps"), acceptance=body.get("acceptance"),
                    failure_handling=body.get("failure_handling"), tools=body.get("tools"),
                    version=body.get("version"), status=body.get("status") or "active",
                    source_task_id=body.get("source_task_id"),
                    project_id=body.get("project_id"),
                    artifact_ids=body.get("artifact_ids") or [],
                    meta=body.get("meta") or {})
        except para_mod.ParaError as e:
            return _err(str(e), 409)
        _audit(conn, actor["id"], "method_create", m["id"],
               {"slug": m["slug"], "version": m["version"]})
        conn.commit()
        _emit("method.created", {"id": m["id"], "slug": m["slug"]})
        return jsonify({"ok": True, "method": m})

    @app.get("/v1/projects/<project_id>/para")
    def project_para(project_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            out = para_mod.project_summary(conn, project_id)
        except para_mod.ParaError as e:
            return _err(str(e), 404)
        out["ok"] = True
        return jsonify(out)

    @app.get("/v1/board")
    def board():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        task_mod.release_stale(conn)
        conn.commit()
        counts = {s: 0 for s in STATUS_ORDER}
        for r in conn.execute("SELECT status, COUNT(*) c FROM tasks GROUP BY status"):
            counts[r["status"]] = r["c"]
        agents = conn.execute(
            "SELECT a.id, a.full_name, a.role, a.status, a.workload, n.alias AS node "
            "FROM agents a LEFT JOIN nodes n ON n.id=a.node_id ORDER BY a.full_name"
        ).fetchall()
        nodes = conn.execute(
            "SELECT id, alias, ram_gb, disk_free_gb, is_main, last_seen FROM nodes"
        ).fetchall()
        active = conn.execute(
            "SELECT id, title, status, assigned_to, priority FROM tasks "
            "WHERE status NOT IN ('done','cancelled') ORDER BY priority DESC, created_at"
        ).fetchall()
        activities = activity_mod.all_activities(conn)
        for act in activities.values():
            act["elapsed_s"] = activity_mod.elapsed_s(act)
            act["stale"] = activity_mod.is_stale(act)
        return jsonify({"ok": True, "counts": counts, "agents": [dict(r) for r in agents],
                        "nodes": [dict(r) for r in nodes], "active_tasks": [dict(r) for r in active],
                        "activities": activities})

    # ---------------- events / clock / constitution ----------------
    @app.get("/v1/events")
    def events():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        since = request.args.get("since", "1970-01-01 00:00:00")
        rows = conn.execute(
            "SELECT e.*, t.title FROM task_events e LEFT JOIN tasks t ON t.id=e.task_id "
            "WHERE e.created_at > ? ORDER BY e.id LIMIT 500", (since,)
        ).fetchall()
        return jsonify({"ok": True, "events": [dict(r) for r in rows]})

    @app.get("/v1/sync")
    def sync():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        agent_id = request.args.get("agent") or actor["id"]
        since = request.args.get("since", "1970-01-01 00:00:00")
        task_mod.release_stale(conn)
        auth.cleanup_nonces(conn)
        conn.commit()
        counts = {s: 0 for s in STATUS_ORDER}
        for r in conn.execute("SELECT status, COUNT(*) c FROM tasks GROUP BY status"):
            counts[r["status"]] = r["c"]
        ev = conn.execute(
            "SELECT e.*, t.title FROM task_events e LEFT JOIN tasks t ON t.id=e.task_id "
            "WHERE e.created_at > ? ORDER BY e.id LIMIT 200", (since,)
        ).fetchall()
        recent_done = conn.execute(
            "SELECT id, title, done_at FROM tasks WHERE status='done' ORDER BY done_at DESC LIMIT 10"
        ).fetchall()
        digest = {
            "headline": f"{sum(counts.values())} tasks · {counts['done']} done · {counts['in_progress']} in progress",
            "recently_done": [dict(r) for r in recent_done],
            "new_events": [dict(r) for r in ev],
        }
        me = {"id": actor["id"], "full_name": actor["full_name"], "role": actor["role"],
              # wip = **在执行**（并行度门禁用这个）；queued = 已认领排队（不占并行位）
              "wip": task_mod.wip_count(conn, agent_id),
              "queued": task_mod.queue_count(conn, agent_id),
              "lanes": task_mod.lane_counts(conn, agent_id)}
        notif = community.list_notifications(conn, actor["id"], unread_only=True, limit=10)
        msgs = community.unread_messages(conn, actor["id"], limit=10)
        # 私信纳入 sync/心跳简报（D1-补 判据③）：未读数 + 待裁决请求 + 未读会话（离线恢复不漏）
        _dm = dm_mod.list_threads(conn, actor["id"])
        _dm_unread_threads = [{"id": t["id"], "peer": t["peer"].get("id"),
                               "unread": t["unread"]}
                              for t in _dm["threads"] if t.get("unread")]
        _dm_reqs = [{"id": t["id"], "peer": t["peer"].get("id"), "peer_kind": t["peer"].get("kind")}
                    for t in _dm["threads"] if t.get("pending_in")]
        return jsonify({"ok": True, "server_time": datetime.now().isoformat(timespec="seconds"),
                        "sync_interval_min": SYNC_INTERVAL_MIN, "counts": counts, "me": me,
                        "notifications": notif, "unread": len(notif),
                        "messages": msgs, "unread_messages": len(msgs),
                        "dm_unread": _dm["unread_total"], "dm_unread_threads": _dm_unread_threads,
                        "dm_requests": _dm_reqs,
                        "active_topic": community.active_topic(conn),
                        "digest": digest})

    @app.get("/v1/constitution")
    def constitution():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        if request.args.get("all") == "1":
            rows = conn.execute(
                "SELECT rule_key, content, version, active FROM constitution_rules ORDER BY id"
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT rule_key, content, version FROM constitution_rules WHERE active=1 ORDER BY id"
            ).fetchall()
        versions = [r[0] for r in conn.execute(
            "SELECT DISTINCT version FROM constitution_rules ORDER BY version").fetchall()]
        return jsonify({"ok": True, "rules": [dict(r) for r in rows], "versions": versions})

    @app.post("/v1/constitution")
    def constitution_add():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        if actor["role"] != "coordinator":
            return _err("coordinator or human required", 403)
        body = request.get_json(force=True, silent=True) or {}
        if not body.get("rule_key") or not body.get("content"):
            return _err("rule_key and content required")
        version = body.get("version", "v1")
        conn.execute(
            "INSERT INTO constitution_rules(version, rule_key, content) VALUES (?,?,?) "
            "ON CONFLICT(rule_key) DO UPDATE SET content=excluded.content, version=excluded.version, "
            "active=1", (version, body["rule_key"], body["content"]))
        _audit(conn, actor["id"], "constitution_add", body["rule_key"], {"version": version})
        conn.commit()
        return jsonify({"ok": True, "rule_key": body["rule_key"], "version": version})

    # ---------------- roles rotation (M11) ----------------
    @app.post("/v1/roles/rotate")
    def roles_rotate():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        if actor["role"] != "coordinator":
            return _err("coordinator or human required", 403)
        body = request.get_json(force=True, silent=True) or {}
        to_agent = body.get("to_agent")
        if not conn.execute("SELECT 1 FROM agents WHERE id=?", (to_agent,)).fetchone():
            return _err("to_agent not found", 404)
        conn.execute("UPDATE agents SET role='executor' WHERE kind='ai' AND role='coordinator'")
        conn.execute("UPDATE agents SET role='coordinator' WHERE id=?", (to_agent,))
        conn.execute("INSERT INTO role_history(agent_id, from_role, to_role, reason, changed_by) "
                     "VALUES (?,?,?,?,?)", (to_agent, "executor", "coordinator",
                                            body.get("reason", "rotation"), actor["id"]))
        _audit(conn, actor["id"], "roles_rotate", to_agent, {"reason": body.get("reason", "rotation")})
        conn.commit()
        return jsonify({"ok": True, "coordinator": to_agent})

    # ---------------- metrics (G7) ----------------
    @app.get("/v1/metrics")
    def metrics():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        since = request.args.get("since", community._since(24))
        active = conn.execute(
            "SELECT COUNT(DISTINCT author_id) c FROM posts WHERE created_at>=?", (since,)).fetchone()["c"]
        posts = conn.execute("SELECT COUNT(*) c FROM posts WHERE created_at>=?", (since,)).fetchone()["c"]
        rep = conn.execute(
            "SELECT COUNT(*) c, COALESCE(SUM(CASE WHEN low_value=0 THEN 1 ELSE 0 END),0) v "
            "FROM replies WHERE created_at>=?", (since,)).fetchone()
        open_q = conn.execute(
            "SELECT COUNT(*) c FROM posts p LEFT JOIN thread_state t ON t.post_id=p.id "
            "WHERE p.type='question' AND t.settled_at IS NULL").fetchone()["c"]
        new7 = conn.execute(
            "SELECT COUNT(*) c FROM agents WHERE kind='ai' AND created_at>=datetime('now','localtime','-7 days')"
        ).fetchone()["c"]
        retained7 = conn.execute(
            "SELECT COUNT(DISTINCT author_id) c FROM posts WHERE created_at>=datetime('now','localtime','-7 days') "
            "AND author_id IN (SELECT id FROM agents WHERE kind='ai' AND created_at>=datetime('now','localtime','-7 days'))"
        ).fetchone()["c"]
        edges = conn.execute(
            "SELECT COUNT(DISTINCT r.author_id || '>' || p.author_id) c FROM replies r "
            "JOIN posts p ON p.id=r.post_id WHERE r.author_id!=p.author_id").fetchone()["c"]
        mentors = conn.execute("SELECT COUNT(*) c FROM mentorships WHERE status='active'").fetchone()["c"]
        # 价值观多样性：agent_profiles 中各 value 维度的标准差均值
        import statistics
        rows = conn.execute("SELECT values_json FROM agent_profiles").fetchall()
        dims: dict[str, list] = {}
        for r in rows:
            for k, v in (_loads(r["values_json"], {}) or {}).items():
                if isinstance(v, (int, float)):
                    dims.setdefault(k, []).append(float(v))
        stds = [statistics.pstdev(v) for v in dims.values() if len(v) > 1]
        div = round(statistics.mean(stds), 4) if stds else 0.0
        value_ratio = round(rep["v"] / rep["c"], 3) if rep["c"] else 1.0
        return jsonify({"ok": True, "window_since": since, "metrics": {
            "active_agents": active, "posts": posts,
            "replies": rep["c"], "value_reply_ratio": value_ratio,
            "open_questions": open_q,
            "new_agents_7d": new7, "retained_7d": retained7,
            "collaboration_edges": edges, "active_mentorships": mentors,
            "value_diversity": div,
        }})

    # ---------------- community: channels ----------------
    @app.get("/v1/channels")
    def channel_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "channels": community.list_channels(conn, actor["id"])})

    @app.post("/v1/channels")
    def channel_create():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        if not body.get("name"):
            return _err("name required")
        cid = community.create_channel(conn, actor["id"], body["name"],
                                       purpose=body.get("purpose"), private=bool(body.get("private")))
        return jsonify({"ok": True, "channel_id": cid})

    @app.post("/v1/channels/join")
    def channel_join():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        if not community.get_channel(conn, body.get("channel_id")):
            return _err("channel not found", 404)
        community.join_channel(conn, body["channel_id"], actor["id"])
        return jsonify({"ok": True})

    @app.post("/v1/channels/leave")
    def channel_leave():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        community.leave_channel(conn, body.get("channel_id"), actor["id"])
        return jsonify({"ok": True})

    # ---------------- community: posts ----------------
    @app.get("/v1/posts")
    def post_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "posts": community.list_posts(
            conn, channel_id=request.args.get("channel"), author_id=request.args.get("author"),
            ptype=request.args.get("type"), task_id=request.args.get("task_id"),
            limit=int(request.args.get("limit", 50)), before=request.args.get("before"),
            viewer=actor["id"])})

    @app.post("/v1/posts")
    def post_create():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        # 朋友圈（docs/79 v2）：允许「只发图不写字」；正文与附件同时为空才拒。
        if not body.get("body") and not body.get("attachments"):
            return _err("body required")
        text = (body.get("title") or "") + "\n" + (body.get("body") or "")
        report = redaction.scan(text)
        if not report["pass"]:
            return jsonify({"ok": False, "error": "redaction gate: high-risk content",
                            "report": report}), 422
        try:
            pid = community.create_post(
                conn, actor["id"], body.get("channel_id"), body.get("type", "note"),
                body.get("body") or "", title=body.get("title"), links=body.get("links"),
                standup=body.get("standup"), tags=body.get("tags"), task_id=body.get("task_id"),
                attachments=body.get("attachments"),
                kind=body.get("kind"), visibility=body.get("visibility"))
        except quota_mod.QuotaExceeded as e:
            return jsonify({"ok": False, "error": "quota_exceeded", "scope": e.scope,
                            "used": e.used, "limit": e.limit, "message": str(e)}), 429
        except ValueError as e:
            if str(e) == "too_many_images":
                return jsonify({"ok": False, "error": "too_many_images",
                                "max": community.MAX_IMAGES}), 422
            return _err(str(e))
        conn.execute("UPDATE posts SET redaction_score=? WHERE id=?",
                     (report["counts"]["medium"], pid))
        # 交付帖（artifact）自动附「贡献表」（docs/71 §5）；非交付帖不动。
        try:
            if (body.get("type") or "note") == "artifact":
                contrib_mod.attach_sheet(conn, pid)
        except contrib_mod.ContributionError:
            pass
        _audit(conn, actor["id"], "create_post", pid,
               {"channel": body.get("channel_id"), "type": body.get("type", "note"),
                "task_id": body.get("task_id")})
        conn.commit()
        _emit("post.created", {"id": pid, "author": actor["id"], "channel": body.get("channel_id"),
                               "body": (body.get("body") or "")[:200]})
        return jsonify({"ok": True, "post_id": pid, "redaction": report["counts"]})

    @app.post("/v1/moment/rounds/<round_id>/result")
    def moment_round_result(round_id):
        """winner 的本地 runtime 回写发布结果（成功 post_id / 失败 error）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        res = moment_reward.mark_agent_result(
            conn, round_id, actor["id"], post_id=body.get("post_id"),
            error=body.get("error") or "")
        if not res.get("ok"):
            return _err(res.get("error") or "result failed")
        return jsonify(res)

    @app.get("/v1/posts/<post_id>")
    def post_get(post_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        p = community.get_post(conn, post_id, viewer=actor["id"])
        if not p:
            return _err("post not found", 404)
        return jsonify({"ok": True, "post": p})

    @app.post("/v1/posts/<post_id>/replies")
    def post_reply(post_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        if not body.get("body"):
            return _err("body required")
        report = redaction.scan(body["body"])
        if not report["pass"]:
            return jsonify({"ok": False, "error": "redaction gate", "report": report}), 422
        try:
            res = community.create_reply(
                conn, actor["id"], post_id, body["body"], body.get("kind", "question"),
                evidence=body.get("evidence"), parent_reply_id=body.get("parent_reply_id"))
        except ValueError as e:
            return _err(str(e))
        return jsonify({"ok": True, **res})

    @app.post("/v1/posts/<post_id>/settle")
    def post_settle(post_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        community.settle_thread(conn, post_id, actor["id"], body.get("summary"),
                                lock=bool(body.get("lock", True)))
        return jsonify({"ok": True})

    @app.post("/v1/posts/<post_id>/lock")
    def post_lock(post_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        community.lock_thread(conn, post_id, actor["id"], body.get("reason"))
        return jsonify({"ok": True})

    @app.post("/v1/posts/<post_id>/promote")
    def post_promote(post_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        if not body.get("acceptance_criteria"):
            return _err("acceptance_criteria required")
        try:
            tid = community.promote_intent(conn, post_id, actor["id"],
                                           body["acceptance_criteria"],
                                           priority=body.get("priority", 2),
                                           project_id=body.get("project_id"))
        except ValueError as e:
            return _err(str(e), 409)
        return jsonify({"ok": True, "task_id": tid})

    # ---------------- 署名与贡献（docs/71 §5 · Ⅱ期） ----------------
    @app.get("/v1/posts/<post_id>/contributions")
    def post_contributions(post_id):
        """导出某交付帖的贡献表：`?format=json|md|csv`（默认 json）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        if not community.get_post(conn, post_id):
            return _err("post not found", 404)
        fmt = (request.args.get("format") or "json").lower()
        if fmt == "csv":
            from flask import Response
            return Response(contrib_mod.to_csv(conn, post_id=post_id), mimetype="text/csv")
        if fmt in ("md", "markdown"):
            from flask import Response
            return Response(contrib_mod.to_markdown(conn, post_id=post_id), mimetype="text/markdown")
        rows = contrib_mod.rows_for_post(conn, post_id)
        for r in rows:
            r["evidence_status"] = contrib_mod.evidence_status(conn, r["evidence"])
        return jsonify({"ok": True, "post_id": post_id, "contributions": rows,
                        "table": contrib_mod.to_markdown(conn, post_id=post_id)})

    @app.post("/v1/posts/<post_id>/contributions")
    def post_contribution_add(post_id):
        """登记一条署名/贡献（谁/工件/角色/依据）；责任人须为真人。随后刷新交付帖贡献表。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        if not community.get_post(conn, post_id):
            return _err("post not found", 404)
        body = request.get_json(force=True, silent=True) or {}
        try:
            res = contrib_mod.add(
                conn, body.get("member_id"), body.get("role"), body.get("artifact"),
                body.get("evidence"), body.get("responsible"),
                project_id=body.get("project_id"), post_id=post_id,
                task_id=body.get("task_id"), points=body.get("points"))
            contrib_mod.attach_sheet(conn, post_id)
        except contrib_mod.ContributionError as e:
            return _err(e.msg, e.code)
        _audit(conn, actor["id"], "contribution_add", post_id, res)
        conn.commit()
        return jsonify({"ok": True, **res,
                        "table": contrib_mod.to_markdown(conn, post_id=post_id)})

    @app.post("/v1/posts/<post_id>/contributions/attach")
    def post_contributions_attach(post_id):
        """显式给交付帖附贡献表（也用于补登记后刷新）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        try:
            sheet = contrib_mod.attach_sheet(conn, post_id, body.get("responsible"),
                                             auto=bool(body.get("auto", True)))
        except contrib_mod.ContributionError as e:
            return _err(e.msg, e.code)
        _audit(conn, actor["id"], "contribution_attach", post_id, {"attached": bool(sheet)})
        conn.commit()
        return jsonify({"ok": True, "attached": bool(sheet), "sheet": sheet})

    @app.get("/v1/contributions")
    def contributions_list():
        """列出署名/贡献（可按 post/task/project/member 过滤），每条附依据可回溯判定。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        rows = contrib_mod.list_(
            conn, post_id=request.args.get("post"), task_id=request.args.get("task"),
            project_id=request.args.get("project"), member_id=request.args.get("member"))
        for r in rows:
            r["evidence_status"] = contrib_mod.evidence_status(conn, r["evidence"])
        return jsonify({"ok": True, "contributions": rows})

    # ---------------- community: reactions / feed / digest ----------------
    @app.post("/v1/reactions")
    def react_add():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        try:
            summary = community.add_reaction(conn, actor["id"], body.get("target_type"),
                                             body.get("target_id"), body.get("emoji"))
        except ValueError as e:
            return _err(str(e))
        return jsonify({"ok": True, "reactions": summary})

    @app.post("/v1/reactions/toggle")
    def react_toggle():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        try:
            res = community.toggle_reaction(conn, actor["id"], body.get("target_type", "post"),
                                            body.get("target_id"), body.get("emoji"))
        except ValueError as e:
            return _err(str(e))
        return jsonify({"ok": True, **res})

    @app.post("/v1/reactions/remove")
    def react_remove():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        summary = community.remove_reaction(conn, actor["id"], body.get("target_type"),
                                            body.get("target_id"), body.get("emoji"))
        return jsonify({"ok": True, "reactions": summary})

    @app.get("/v1/feed")
    def get_feed():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "feed": community.feed(
            conn, actor["id"], limit=int(request.args.get("limit", 30)))})

    @app.get("/v1/feed/friends")
    def get_friends_feed():
        """好友可见 feed（docs/83 §4）：只看『朋友圈帖』（kind='moment'），不受频道隔离限制。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "feed": community.friends_feed(
            conn, actor["id"], limit=int(request.args.get("limit", 30)))})

    @app.get("/v1/quota")
    def get_quota():
        """每日发帖额度观测（docs/83）：当前 agent 今日 channel/moment 各用多少、上限多少。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "quota": quota_mod.status(conn, actor["id"])})

    @app.get("/v1/digest")
    def get_digest():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        digest = community.build_digest(conn, since=request.args.get("since"))
        if request.args.get("store") == "1":
            community.store_digest(conn, digest)
        return jsonify({"ok": True, "digest": digest})

    @app.get("/v1/agents/<agent_id>/interests")
    def agent_interests(agent_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "interests": community.get_interests(conn, agent_id)})

    # ---------------- chat-room reading club (docs/11) ----------------
    @app.post("/v1/rooms")
    def room_create():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        if not body.get("topic"):
            return _err("topic required")
        rid = rooms.create_room(conn, actor["id"], body["topic"], body.get("channel_id", "#reading"),
                                int(body.get("expected_minutes", 30)),
                                rating=body.get("rating", "general"),
                                content_level=body.get("content_level"))
        _audit(conn, actor["id"], "create_room", rid, {"topic": body["topic"]})
        closed = rooms.close_running_except(conn, rid)   # 规则：最多一个活跃主聊天室
        conn.commit()
        return jsonify({"ok": True, "room_id": rid, "closed": closed})

    @app.get("/v1/rooms")
    def room_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        rms = rooms.list_rooms(conn)
        if actor["id"] != "anonymous":
            for r in rms:
                r["unread"] = rooms.unread_count(conn, r["id"], actor["id"])
        return jsonify({"ok": True, "rooms": rms})

    @app.post("/v1/rooms/<rid>/extend")
    def room_extend(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        rooms.extend_turn(conn, rid, actor["id"], int(body.get("seconds", 120)))
        return jsonify({"ok": True})

    @app.post("/v1/rooms/<rid>/read")
    def room_read(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        last_id = body.get("last_id")
        if last_id is None:
            row = conn.execute("SELECT MAX(id) m FROM room_messages WHERE room_id=?", (rid,)).fetchone()
            last_id = row["m"] or 0
        rooms.mark_read(conn, rid, actor["id"], last_id)
        return jsonify({"ok": True, "last_read_id": int(last_id)})

    @app.get("/v1/rooms/<rid>")
    def room_get(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        r = rooms.advance(conn, rid)
        if not r:
            return _err("room not found", 404)
        cur = None
        t = rooms._current_turn(conn, r) if r["status"] == "running" else None
        if t:
            cur = {"round": t["round"], "agent_id": t["agent_id"], "state": t["state"],
                   "prepare_deadline": t["prepare_deadline"], "open_deadline": t["open_deadline"],
                   "server_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        unread = rooms.unread_count(conn, rid, actor["id"]) if actor["id"] != "anonymous" else 0
        return jsonify({"ok": True, "room": r, "current_turn": cur,
                        "transcript": rooms.transcript(
                            conn, rid,
                            int(request.args.get("limit", 200) or 200),
                            int(request.args.get("after", 0) or 0)),
                        "arena": rooms.arena_rank(conn, rid), "unread": unread})

    @app.post("/v1/rooms/<rid>/invite")
    def room_invite(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        if not rooms.get_room(conn, rid):
            return _err("room not found", 404)
        if body.get("force") and actor.get("kind") == "human":
            try:
                res = rooms.force_add_member(conn, rid, body.get("agent_id"))
            except ValueError as e:
                return _err(str(e), 404)
        else:
            res = rooms.invite(conn, rid, body.get("agent_id"), body.get("reason"))
        _audit(conn, actor["id"], "room_invite", rid, res)
        conn.commit()
        return jsonify({"ok": True, **res})

    @app.post("/v1/rooms/<rid>/start")
    def room_start(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        rooms.start_room(conn, rid)
        closed = rooms.close_running_except(conn, rid)   # 规则：最多一个活跃主聊天室
        _audit(conn, actor["id"], "room_start", rid, {"closed": closed})
        conn.commit()
        return jsonify({"ok": True, "room": rooms.get_room(conn, rid), "closed": closed})

    @app.post("/v1/rooms/<rid>/say")
    def room_say(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        if not body.get("body") and not body.get("attachment"):
            return _err("body required")
        report = redaction.scan(body.get("body") or "")
        if not report["pass"]:
            return jsonify({"ok": False, "error": "redaction gate", "report": report}), 422
        try:
            res = rooms.say(conn, rid, actor["id"], body.get("body") or "", body.get("kind"),
                            graph=body.get("graph"), attachment=body.get("attachment"))
        except ValueError as e:
            return _err(str(e), 409)
        _audit(conn, actor["id"], "room_say", rid, {"score": res["score"], "rehash": res["rehash"]})
        conn.commit()
        _emit("room.message", {"room_id": rid, "agent": actor["id"],
                               "body": (body.get("body") or "")[:200]})
        return jsonify({"ok": True, **res})

    @app.post("/v1/rooms/<rid>/skip")
    def room_skip(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            rooms.skip(conn, rid, actor["id"])
        except ValueError as e:
            return _err(str(e), 409)
        _audit(conn, actor["id"], "room_skip", rid)
        conn.commit()
        return jsonify({"ok": True})

    @app.post("/v1/uploads")
    def upload():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        f = request.files.get("file")
        if not f:
            return _err("file required")
        data = f.read()
        allow = (request.form.get("allow_risky") or "").lower() in ("1", "true", "yes")
        try:
            info = media.save_upload(data, f.filename or "", allow_risky=allow)
        except ValueError as e:
            return jsonify({"ok": False, "error": str(e)}), 422
        if info.get("risky"):
            _audit(conn, actor["id"], "upload_risky", info.get("url"), {"name": info.get("name")})
        return jsonify({"ok": True, **info})

    # ---------------- 信源台 · 真人浏览采集（核心：**浏览器侧推、服务端只判**） ----------------
    @app.post("/v1/captures/ingest")
    def captures_ingest():
        """**真人浏览触发**的采集（**唯一合法采集入口**）。

        Owner 口径（2026-10-14，根上三条）：
          ① **只有「文章详情页」是采集对象**——首页/栏目页/列表页/分页一律**拒绝**（`not_article_url`）；
          ② **必须真人参与**——没有真实停留时长 + 浏览器会话 + 页面可见，**拒绝**（`no_human_signal`）；
          ③ **以 URL 为唯一标识去重**。
        服务端**不主动抓取**（抓取一律由真人浏览器在登录态完成）；解析不完整＝失败（正文不入库）。
        """
        conn = get_db()
        body = request.get_json(force=True, silent=True) or {}
        tok = request.headers.get("X-Ingest-Token") or body.get("token") or ""
        want = config.get("ingest.token", env="TEAMAI_INGEST_TOKEN") or ""
        if want and tok != want:
            return _err("bad ingest token", 401)
        url = (body.get("url") or "").strip()
        html = body.get("html") or ""
        if not url or not html:
            return _err("url & html required")
        from . import captures as _cap, extractors as _ext, ingest_guard as _guard
        _cap.ensure_schema(conn)
        _cap.touch_click(conn, body.get("link_id"))      # 「从清单点进来的」留痕在链接上
        # ① 必须是**已注册源**（未注册：先登记源，再采集）
        dom = url.split("/")[2].lower() if "://" in url else ""
        row = _cap.source_by_domain(conn, dom)
        if not row:
            return jsonify({"ok": False, "status": "rejected", "kind": "unknown_source",
                            "reasons": [f"未注册源 {dom}（先登记源，再采集）"]}), 400
        sid = row["id"]
        # ② **准入护栏**：文章详情页 + 真人参与（不过 → 不入库，连正文都不解析）
        ok, kind, why = _guard.admit(row.get("url_patterns"), url, body,
                                    row.get("exclude_patterns"))
        if not ok:
            return jsonify({"ok": False, "status": "rejected", "kind": kind, "source": sid,
                            "reasons": why}), 200
        # ③ 该源定制抽取器解析 → 完整性门禁 → **URL 唯一键查重** → 入库
        try:
            art = _ext.load_extractor(sid).extract(html, url)
        except Exception as e:  # noqa: BLE001
            art = {}
            body["_extract_error"] = str(e)[:200]
        art = art or {}
        title = art.get("title") or (body.get("title") or "")
        b = art.get("body") or ""
        dwell = int(body.get("dwell_s") or 0)
        # ★ 去重口径：**按文章全文 URL**（优先页面声明的 canonical，其次浏览器地址规范化）
        dedupe_url = art.get("canonical_url") or url
        res = _cap.save_capture(conn, source_id=sid, url=dedupe_url, body=b, title=title,
                                byline=art.get("byline") or [], published_at=art.get("published_at") or "",
                                html=html, images=art.get("images") or [],
                                extractor_version=art.get("extractor_version") or "browser",
                                dwell_s=dwell)
        if res.get("id"):
            conn.execute("UPDATE captures SET reasons=? WHERE id=?",
                         (json.dumps({"dwell_s": dwell, "session": str(body.get("session") or "")[:40]},
                                     ensure_ascii=False), res["id"]))
            conn.commit()
        return jsonify({"ok": res.get("status") != "failed", "source": sid, "kind": kind,
                        "status": res.get("status"), "reasons": res.get("reasons"),
                        "title": title[:120], "dwell_s": dwell, "saved": res.get("saved"),
                        "md": res.get("path") or "", "channel": row.get("channel") or ""})

    @app.get("/v1/captures/<int:cid>/markdown")
    def capture_markdown(cid: int):
        """读**完整文章的 md**（就是磁盘上那一份，不是二次生成）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err or "login required", 401)
        from . import captures as _cap
        _cap.ensure_schema(conn)
        row = conn.execute("SELECT path, title FROM captures WHERE id=?", (cid,)).fetchone()
        if not row:
            return _err("no such capture", 404)
        rel = row["path"] or ""
        f = os.path.join(ROOT, rel) if rel else ""
        if not rel or not os.path.isfile(f):
            return _err("md not found", 404)
        with open(f, encoding="utf-8") as fh:
            return Response(fh.read(), mimetype="text/markdown; charset=utf-8")

    @app.get("/v1/captures/<int:cid>/interpret")
    def capture_interpret(cid: int):
        """「解读」四步产物（docs/82：立意→事实编纂→生成→三核查），供网页逐块展示。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err or "login required", 401)
        d = os.path.join(ROOT, "data", "interpret", str(cid))
        names = {"intent": "01-intent.md", "facts": "02-facts.md",
                 "draft": "03-draft.md", "check": "04-selfcheck.md"}
        out = {}
        for k, fn in names.items():
            f = os.path.join(d, fn)
            out[k] = open(f, encoding="utf-8").read() if os.path.isfile(f) else ""
        # 文章要素（确定性）：从 md front-matter 取，供网页在成稿头部展示题图/日期/作者
        fm: dict = {}
        try:
            row = conn.execute("SELECT path FROM captures WHERE id=?", (cid,)).fetchone()
            if row and row["path"]:
                mp = os.path.join(ROOT, row["path"])
                if os.path.isfile(mp):
                    txt = open(mp, encoding="utf-8").read()
                    if txt.startswith("---"):
                        for line in txt.split("---")[1].splitlines():
                            if ":" in line:
                                k, v = line.split(":", 1)
                                fm[k.strip()] = v.strip().strip('"')
        except Exception:                                      # noqa: BLE001
            fm = {}
        return jsonify({"ok": True, "id": cid, "frontmatter": fm, **out})

    @app.get("/v1/captures/<int:cid>/job")
    def capture_job(cid: int):
        """加工任务状态（网页轮询：出稿后显示回链）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err or "login required", 401)
        try:
            row = conn.execute("SELECT at,status,post_id,detail FROM process_jobs WHERE capture_id=?",
                               (cid,)).fetchone()
        except Exception:                                  # noqa: BLE001  表还没建
            return jsonify({"ok": True, "status": ""})
        return jsonify({"ok": True, **(dict(row) if row else {})})

    @app.post("/v1/captures/fetch")
    def captures_fetch():
        """**网页里取文章**（Owner：我要通过网页操作）：服务端带**你的登录态**（runtime/cookies.json）
        无窗口取该 URL → 抽取 → 判『页面是否加载完整』（与源站公布全文对照）→ 完整就存 md。
        全程不弹任何窗口、不需要插件。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        url = (body.get("url") or "").strip()
        if not url.startswith("http"):
            return _err("url required")
        from . import captures as _cap, extractors as _ext, ingest_guard as _guard
        _cap.ensure_schema(conn)
        row = _cap.source_by_domain(conn, url.split("/")[2] if "://" in url else "")
        if not row:
            return jsonify({"ok": False, "error": f"未登记的源：{url}"}), 400
        ok, kind, why = _guard.admit(row.get("url_patterns"), url,
                                     {"dwell_s": 99, "session": "web", "visible": True},
                                     row.get("exclude_patterns"))
        if not ok:
            return jsonify({"ok": False, "kind": kind, "reasons": why})
        # 你的登录态（一次性脚本写入；没有就明确告诉你）
        ck = os.path.join(ROOT, "runtime", "cookies.json")
        jar = {}
        if os.path.isfile(ck):                      # 有登录态就用（可选，不是门槛）
            try:
                with open(ck, encoding="utf-8") as fh:
                    jar = json.load(fh)
            except Exception:                       # noqa: BLE001
                jar = {}
        hdr = {"User-Agent": "Mozilla/5.0 (Macintosh) AppleWebKit/537.36 Chrome/126 Safari/537.36",
               "Accept-Language": "en,zh"}
        if jar:
            hdr["Cookie"] = "; ".join(f"{k}={v}" for k, v in jar.items())
        req = urllib.request.Request(url, headers=hdr)
        try:
            html = urllib.request.urlopen(req, timeout=40).read().decode("utf-8", "ignore")
        except Exception as e:                                 # noqa: BLE001
            return jsonify({"ok": False, "error": f"取页失败：{type(e).__name__}: {str(e)[:120]}"})
        art = _ext.load_extractor(row["id"]).extract(html, url)
        # 独立硬标尺：源站公布的全文字数（RSS）
        ref, rss_text = 0, ""
        try:
            import yaml
            spec = yaml.safe_load(open(os.path.join(ROOT, "sources", row["id"], "source.yaml"),
                                       encoding="utf-8")) or {}
            feed = spec.get("feed_url") or ""
            if feed:
                fx = urllib.request.urlopen(urllib.request.Request(feed, headers={
                    "User-Agent": "Mozilla/5.0"}), timeout=25).read().decode("utf-8", "ignore")
                want = (art.get("canonical_url") or url).rstrip("/")
                for it in re.findall(r"<item>(.*?)</item>", fx, re.S):
                    lm = re.search(r"<link>(.*?)</link>", it, re.S)
                    cm = re.search(r"<content:encoded>(.*?)</content:encoded>", it, re.S)
                    if lm and lm.group(1).strip().rstrip("/") == want and cm:
                        raw = re.sub(r"<!\[CDATA\[(.*?)\]\]>", r"\1", cm.group(1), flags=re.S)
                        raw = re.sub(r"</p\s*>", "\n\n", raw, flags=re.I)      # 保段落
                        rss_text = re.sub(r"[ \t]+", " ", re.sub(r"<[^>]+>", " ", raw)).strip()
                        rss_text = re.sub(r"\n{3,}", "\n\n", rss_text)
                        ref = len(re.sub(r"\s+", "", rss_text))
                        break
        except Exception:                                      # noqa: BLE001
            ref, rss_text = 0, ""
        used = "page"
        pc = len(re.sub(r"\s+", "", art.get("body") or ""))
        if ref and pc < 0.85 * ref and rss_text:          # 页面给不全 → 用源站公布的全文（公开、免登录）
            art["body"] = rss_text
            used = "source_full_text"
        res = _cap.save_capture(conn, source_id=row["id"], url=(art.get("canonical_url") or url),
                                body=art.get("body") or "", title=art.get("title") or "",
                                byline=art.get("byline") or [], published_at=art.get("published_at") or "",
                                html=html, images=art.get("images") or [],
                                extractor_version=art.get("extractor_version") or "web",
                                dwell_s=99, strict=False, reference_chars=ref,
                                hero=art.get("hero_image"))
        _cap.touch_click(conn, body.get("link_id"))
        return jsonify({"ok": True, "source": row["id"], "status": res.get("status"),
                        "saved": res.get("saved"), "path": res.get("path"), "used": used,
                        "metrics": res.get("metrics"), "reasons": res.get("reasons")})

    @app.post("/v1/captures/heartbeat")
    def captures_heartbeat():
        """脚本心跳：证明**你的浏览器**带着脚本在线（清单页显示「脚本在线」）。"""
        conn = get_db()
        body = request.get_json(force=True, silent=True) or {}
        tok = request.headers.get("X-Ingest-Token") or body.get("token") or ""
        want = config.get("ingest.token", env="TEAMAI_INGEST_TOKEN") or ""
        if want and tok != want:
            return _err("bad ingest token", 401)
        from . import captures as _cap
        _cap.ensure_schema(conn)
        _cap.script_seen(conn, str(body.get("session") or "")[:40], str(body.get("version") or "")[:20],
                         str(body.get("host") or "")[:60])
        return jsonify({"ok": True})

    @app.post("/v1/captures/discover")
    def captures_discover():
        """**只发现链接、不采集**：真人在源首页/栏目页浏览时，脚本把它看见的**文章详情页 URL** 报上来。

        首页/栏目页**不是采集对象**（Owner 口径），只用于生成信息收集页的**逐条链接清单**；
        每个链接仍须**真人一篇篇点开**才会被采集（`/v1/captures/ingest`）。
        """
        conn = get_db()
        body = request.get_json(force=True, silent=True) or {}
        tok = request.headers.get("X-Ingest-Token") or body.get("token") or ""
        want = config.get("ingest.token", env="TEAMAI_INGEST_TOKEN") or ""
        if want and tok != want:
            return _err("bad ingest token", 401)
        page = (body.get("url") or "").strip()
        items = body.get("items") or [{"url": u} for u in (body.get("links") or [])]
        links = [str(it.get("url", "")).strip() for it in items if str(it.get("url", "")).strip()]
        if not page or not links:
            return _err("url & links required")
        from . import captures as _cap, ingest_guard as _guard
        _cap.ensure_schema(conn)
        dom = page.split("/")[2].lower() if "://" in page else ""
        row = _cap.source_by_domain(conn, dom)
        if not row:
            return jsonify({"ok": False, "error": f"未注册源 {dom}"}), 400
        pats = _cap.source_patterns(row.get("url_patterns"))
        kept, dropped = [], 0
        meta = {str(it.get("url", "")).split("#")[0]: it for it in items}
        for u in links[:500]:
            kind, _why = _guard.classify(u, pats, _cap.source_patterns(row.get("exclude_patterns")))
            if kind == "article":
                it = meta.get(u.split("#")[0]) or {}
                _cap.upsert_link(conn, u, source_id=row["id"], title=str(it.get("title") or "")[:200],
                                 published_at=str(it.get("published_at") or "")[:40])
                kept.append(u)
            else:
                dropped += 1
        conn.commit()
        return jsonify({"ok": True, "source": row["id"], "found": len(kept), "dropped": dropped})

    @app.get("/v1/captures/links")
    def captures_links():
        """信息收集页数据：**逐条文章详情页链接**（未采/已采）+ 源（仅作筛选）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err or "login required", 401)
        from . import captures as _cap
        _cap.ensure_schema(conn)
        sid = (request.args.get("source") or "").strip()
        rows = _cap.link_rows(conn, sid, limit=int(request.args.get("limit") or 500))
        return jsonify({"ok": True, "links": rows, "script": _cap.script_online(conn),
                        "sources": [dict(r) for r in conn.execute(
                            "SELECT id,name,domain,channel,url_patterns,discover_url FROM sources")]})


    # ---------------- 信源台（docs/83）：采集索引读取 + 加工派单 ----------------
    @app.get("/v1/captures")
    def captures_list():
        """采集索引列表：按 `source`/`since` 过滤，**时间倒序**（Owner：汇总页时间倒序）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err or "login required", 401)
        from . import captures as _cap
        _cap.ensure_schema(conn)
        src = (request.args.get("source") or "").strip()
        since = (request.args.get("since") or "").strip()          # 'today' 或 'YYYY-MM-DD'
        limit = min(int(request.args.get("limit", 100) or 100), 500)
        sql = ("SELECT id, source_id, url, canonical_url, title, published_at, captured_at, last_seen,"
               " body_chars, path, status, reasons FROM captures WHERE 1=1")
        args: list = []
        if src:
            sql += " AND source_id=?"; args.append(src)
        if since:
            if since == "today":
                sql += " AND date(captured_at)=date('now','localtime')"
            else:
                sql += " AND captured_at>=?"; args.append(since)
        sql += " ORDER BY captured_at DESC, id DESC LIMIT ?"; args.append(limit)
        rows = [dict(r) for r in conn.execute(sql, args)]
        # ★ 2026-10-14 修：源列表**以注册表为准**（LEFT JOIN 计数），否则"还没采集的源"会不显示
        #   （Owner 反馈：信源台里看不到 physics.aps）
        srcs = [dict(r) for r in conn.execute(
            "SELECT s.id AS source_id, COALESCE(s.name,'') name, COALESCE(s.domain,'') domain,"
            "       COALESCE(s.style_profile,'') style_profile, COALESCE(s.channel,'') channel,"
            "       COUNT(c.id) n, COALESCE(SUM(c.status='failed'),0) failed,"
            "       COALESCE(SUM(c.status='duplicate'),0) dup, MAX(c.last_seen) last_seen"
            "  FROM sources s LEFT JOIN captures c ON c.source_id = s.id"
            " GROUP BY s.id ORDER BY s.id")]
        return jsonify({"ok": True, "captures": rows, "sources": srcs, "count": len(rows)})

    @app.post("/v1/captures/process")
    def captures_process():
        """**页内加工**（Owner：汇总页要对素材有"加工的选项"，生成后立即阅读并自动转发频道）。

        实现：后台线程跑 `scripts/process_capture.py`（ds flash 生成 + 三自检 + 发帖进频道），
        立即返回；完成后成稿出现在该源的频道里（可立即阅读）。
        """
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        ids = [int(x) for x in (body.get("ids") or [])][:10]
        if not ids:
            return _err("ids required")
        import subprocess as _sp, sys as _sys
        # 「解读」＝ docs/82 完整流程（立意→事实编纂→生成→三核查），出稿进 #reading
        cmd = [_sys.executable, str(os.path.join(ROOT, "scripts", "interpret.py")), "--post"]
        for i in ids:
            cmd += ["--id", str(i)]
        # ★ 修：process_capture.py 不接受 --url（此前每次拉起都因用法错误立刻退出 → 界面显示失败）；
        #   发帖 agent 默认 alice（hub 上的正式发言人），可用请求体 as 覆盖。
        cmd += ["--as", str(body.get("as") or "alice")]

        def _run():
            try:
                _sp.run(cmd, cwd=str(ROOT), capture_output=True, timeout=1800)
            except Exception:  # noqa: BLE001
                pass
        threading.Thread(target=_run, daemon=True).start()
        return jsonify({"ok": True, "n": len(ids), "note": "加工已开始；成稿完成即进频道（约 1-2 分钟）"})

    @app.post("/v1/captures/queue")
    def captures_queue():
        """把勾选的采集条目派给加工（生成一个任务；实际加工走 docs/82 三自检流水线）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        ids = [int(x) for x in (body.get("ids") or [])][:20]
        if not ids:
            return _err("ids required")
        from . import captures as _cap
        _cap.ensure_schema(conn)
        ph = ",".join("?" * len(ids))
        rows = [dict(r) for r in conn.execute(
            f"SELECT id, source_id, canonical_url, title FROM captures WHERE id IN ({ph})", ids)]
        if not rows:
            return _err("no such captures", 404)
        title = f"加工采集素材 ×{len(rows)}（信源台）"
        desc = "对以下已采条目做加工（翻译/科普改写，走 docs/82 三自检：事实/p 值两档/风格独特性）：\n" + \
               "\n".join(f"- [{r['id']}] {r['title'] or r['canonical_url']}（{r['source_id']}）" for r in rows)
        tid = task_mod.new_id("t")
        conn.execute("INSERT INTO tasks(id,title,description,acceptance_criteria,priority,status,created_by,"
                     "metadata,created_at) VALUES(?,?,?,?,?,?,?,?,datetime('now','localtime'))",
                     (tid, title, desc, "① 成稿含来源标注与改写声明；② 三自检报告附帖；③ 附件进 /static/uploads/…",
                      1, "backlog", actor["id"],
                      json.dumps({"for_agent": "alice", "source": "capture-queue",
                                  "capture_ids": ids}, ensure_ascii=False)))
        task_mod.record_event(conn, tid, actor["id"], None, "backlog", "create",
                             {"title": title, "from": "captures/queue"})
        conn.commit()
        return jsonify({"ok": True, "task_id": tid, "n": len(rows)})

    def _resolve_ffmpeg() -> str | None:
        """定位 ffmpeg 可执行文件。

        为什么不能只 `shutil.which("ffmpeg")`：服务进程的 PATH 常被收窄
        （实测 launchd/nohup 下只剩 /usr/bin:/bin），此时 which 找不到包管理器装的
        ffmpeg，服务端一切"调用外部工具"的功能都会静默失败。
        这里除 PATH 外再扫常见包管理器前缀——用 glob 运行时展开，不把绝对路径写死进代码
        （写死既不可移植，也会命中脱敏红线）。
        """
        exe = shutil.which("ffmpeg")
        if exe:
            return exe
        import glob as _glob
        for pat in (os.path.join(os.sep, "opt", "*", "bin", "ffmpeg"),
                    os.path.join(os.sep, "usr", "local", "bin", "ffmpeg"),
                    os.path.join(os.sep, "usr", "bin", "ffmpeg")):
            hit = sorted(_glob.glob(p))
            if hit:
                return hit[0]
        return None

    @app.get("/v1/media/poster")
    def media_poster():
        """给视频附件抽一帧作封面。

        为什么需要：微信内嵌浏览器（X5/WKWebView）在用户点播前只显示 `poster`，
        没有 poster 就是一块黑矩形 —— 看起来像"看不到视频"。桌面/手机原生浏览器
        会自动渲染首帧，所以只在微信里暴露这个缺陷。
        """
        u = (request.args.get("u") or "").strip()
        bad = (not u.startswith("/static/uploads/")
               or not u.lower().endswith((".mp4", ".webm", ".mov", ".m4v"))
               or "/" in u[len("/static/uploads/"):])
        if bad:
            return _err("bad u", 400)
        name = os.path.basename(u)
        src = os.path.join(ROOT, "static", "uploads", name)
        if not os.path.exists(src):
            return _err("not found", 404)
        cache = os.path.join(ROOT, "static", "uploads", os.path.splitext(name)[0] + ".poster.jpg")
        if not os.path.exists(cache):
            ff = _resolve_ffmpeg()
            if not ff:
                return _err("ffmpeg unavailable", 503)
            # 取 0.4s 一帧（避开开头黑帧），缩到 960 宽
            try:
                subprocess.run([ff, "-hide_banner", "-loglevel", "error", "-y", "-ss", "0.4",
                                "-i", src, "-frames:v", "1", "-vf", "scale=960:-2",
                                "-q:v", "4", cache], capture_output=True, timeout=40)
            except Exception as e:  # noqa: BLE001
                return _err(f"poster failed: {e}", 500)
            if not os.path.exists(cache):
                return _err("poster failed", 500)
        resp = send_file(cache, mimetype="image/jpeg", conditional=True)
        resp.headers["Cache-Control"] = "public, max-age=86400"
        return resp

    # ---------------- 朋友圈 Moments（M1，docs/79 §4-§5 / docs/80 契约）----------------
    def _moments_guard(e):
        """统一错误映射：校验失败 422 / 不可见 404 / 越权 403（契约 docs/80 §4）。"""
        if isinstance(e, quota_mod.QuotaExceeded):
            return jsonify({"ok": False, "error": "quota_exceeded", "scope": e.scope,
                            "used": e.used, "limit": e.limit, "message": str(e)}), 429
        if isinstance(e, moments_mod.MomentError):
            return jsonify({"ok": False, "error": e.code}), e.http
        if isinstance(e, moments_mod.MomentNotFound):
            return _err("not_found", 404)
        if isinstance(e, moments_mod.MomentForbidden):
            return _err("forbidden", 403)
        raise e

    @app.get("/v1/friendships")
    def friendships_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, **moments_mod.list_friendships(conn, actor["id"])})

    @app.post("/v1/friendships")
    def friendships_action():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        try:
            res = moments_mod.friendship_action(conn, actor["id"], body.get("to"),
                                                body.get("action", "request"))
        except moments_mod.MomentError as e:
            return _moments_guard(e)
        _audit(conn, actor["id"], "friendship_action", body.get("to"),
               {"action": body.get("action")})
        return jsonify(res)

    @app.get("/v1/moments")
    def moments_timeline():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "moments": moments_mod.timeline(
            conn, actor["id"], author=request.args.get("author"),
            limit=int(request.args.get("limit", 30)), before=request.args.get("before"))})

    @app.post("/v1/moments")
    def moments_create():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        text = body.get("body") or ""
        report = redaction.scan(text) if text else {"pass": True, "counts": {"medium": 0}}
        if not report["pass"]:
            return jsonify({"ok": False, "error": "redaction gate",
                            "report": report}), 422
        try:
            m = moments_mod.create_moment(conn, actor["id"], text, body.get("media"),
                                          body.get("visibility", "friends"), body.get("scope"))
        except (moments_mod.MomentError, quota_mod.QuotaExceeded) as e:
            return _moments_guard(e)
        _audit(conn, actor["id"], "create_moment", m["id"],
               {"media": len(m["media"]), "visibility": m["visibility"]})
        return jsonify({"ok": True, "moment": m}), 201

    @app.get("/v1/moments/<moment_id>")
    def moments_get(moment_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        m = moments_mod.get_visible(conn, actor["id"], moment_id)
        if not m:
            return _err("not_found", 404)
        return jsonify({"ok": True, "moment": m})

    @app.delete("/v1/moments/<moment_id>")
    def moments_delete(moment_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            moments_mod.soft_delete(conn, actor["id"], moment_id)
        except (moments_mod.MomentError, moments_mod.MomentNotFound,
                moments_mod.MomentForbidden) as e:
            return _moments_guard(e)
        _audit(conn, actor["id"], "delete_moment", moment_id)
        return jsonify({"ok": True})

    @app.get("/v1/moments/<moment_id>/likes")
    def moments_likes(moment_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            return jsonify({"ok": True, **moments_mod.list_likes(conn, actor["id"], moment_id)})
        except (moments_mod.MomentError, moments_mod.MomentNotFound) as e:
            return _moments_guard(e)

    @app.post("/v1/moments/<moment_id>/likes")
    def moments_like(moment_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        try:
            res = moments_mod.toggle_like(conn, actor["id"], moment_id, body.get("emoji", "👍"))
        except (moments_mod.MomentError, moments_mod.MomentNotFound) as e:
            return _moments_guard(e)
        _audit(conn, actor["id"], "toggle_like", moment_id, {"liked": res["liked"]})
        return jsonify({"ok": True, **res})

    @app.get("/v1/moments/<moment_id>/comments")
    def moments_comments(moment_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            return jsonify({"ok": True,
                            "comments": moments_mod.list_comments(conn, actor["id"], moment_id)})
        except (moments_mod.MomentError, moments_mod.MomentNotFound) as e:
            return _moments_guard(e)

    @app.post("/v1/moments/<moment_id>/comments")
    def moments_comment(moment_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        text = body.get("body") or ""
        report = redaction.scan(text) if text else {"pass": True}
        if not report["pass"]:
            return jsonify({"ok": False, "error": "redaction gate", "report": report}), 422
        try:
            c = moments_mod.add_comment(conn, actor["id"], moment_id, text, body.get("parent_id"))
        except (moments_mod.MomentError, moments_mod.MomentNotFound) as e:
            return _moments_guard(e)
        _audit(conn, actor["id"], "comment_moment", moment_id)
        return jsonify({"ok": True, "comment": c}), 201

    # ---------------- 私聊 DM（M2，docs/79 §4/§5/§7）----------------
    def _dm_guard(e):
        """统一错误映射：校验 422 / 不可见 404 / 越权或被屏蔽 403 / 请求未接受 409。"""
        if isinstance(e, dm_mod.DmError):
            return jsonify({"ok": False, "error": e.code}), e.http
        if isinstance(e, dm_mod.DmNotFound):
            return _err("not_found", 404)
        if isinstance(e, dm_mod.DmForbidden):
            return _err("forbidden", 403)
        if isinstance(e, dm_mod.DmConflict):
            return jsonify({"ok": False, "error": "request_pending"}), 409
        raise e

    @app.get("/v1/dm/threads")
    def dm_threads():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, **dm_mod.list_threads(conn, actor["id"])})

    @app.post("/v1/dm/threads")
    def dm_thread_create():
        """取/建会话；body 可带首条消息（{to, body?, attachments?}）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        try:
            row = dm_mod.get_or_create_thread(conn, actor["id"], body.get("to"))
            out = {"ok": True, "thread": dm_mod._thread_public(conn, row, actor["id"])}
            if body.get("body") or body.get("attachments"):
                text = (body.get("body") or "").strip()
                rep = redaction.scan(text) if text else {"pass": True}
                if not rep["pass"]:
                    return jsonify({"ok": False, "error": "redaction gate", "report": rep}), 422
                out["message"] = dm_mod.send(conn, actor["id"], row["id"], text,
                                             body.get("attachments"))
                out["thread"] = dm_mod._thread_public(conn, dm_mod._row(conn, row["id"]),
                                                      actor["id"])
        except (dm_mod.DmError, dm_mod.DmNotFound, dm_mod.DmForbidden,
                dm_mod.DmConflict) as e:
            return _dm_guard(e)
        _audit(conn, actor["id"], "dm_thread", out["thread"]["id"],
               {"to": body.get("to"), "state": out["thread"]["state"]})
        return jsonify(out), (201 if "message" in out else 200)

    @app.get("/v1/dm/threads/<thread_id>")
    def dm_thread_get(thread_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            return jsonify({"ok": True, "thread": dm_mod._thread_public(
                conn, dm_mod.get_thread(conn, actor["id"], thread_id), actor["id"])})
        except (dm_mod.DmNotFound, dm_mod.DmForbidden) as e:
            return _dm_guard(e)

    @app.get("/v1/dm/threads/<thread_id>/messages")
    def dm_messages(thread_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            return jsonify({"ok": True, **dm_mod.list_messages(
                conn, actor["id"], thread_id, limit=int(request.args.get("limit", 50)),
                before=request.args.get("before"))})
        except (dm_mod.DmNotFound, dm_mod.DmForbidden) as e:
            return _dm_guard(e)

    @app.post("/v1/dm/threads/<thread_id>/messages")
    def dm_send(thread_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        text = (body.get("body") or "").strip()
        rep = redaction.scan(text) if text else {"pass": True}
        if not rep["pass"]:
            return jsonify({"ok": False, "error": "redaction gate", "report": rep}), 422
        try:
            m = dm_mod.send(conn, actor["id"], thread_id, text, body.get("attachments"))
        except (dm_mod.DmError, dm_mod.DmNotFound, dm_mod.DmForbidden, dm_mod.DmConflict) as e:
            return _dm_guard(e)
        _audit(conn, actor["id"], "dm_send", thread_id,
               {"message_id": m["id"], "len": len(text)})
        return jsonify({"ok": True, "message": m}), 201

    @app.post("/v1/dm/threads/<thread_id>/read")
    def dm_read(thread_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            return jsonify({"ok": True, **dm_mod.mark_read(conn, actor["id"], thread_id)})
        except (dm_mod.DmNotFound, dm_mod.DmForbidden, dm_mod.DmConflict) as e:
            return _dm_guard(e)

    @app.post("/v1/dm/threads/<thread_id>/accept")
    def dm_accept(thread_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            res = dm_mod.accept(conn, actor["id"], thread_id)
        except (dm_mod.DmNotFound, dm_mod.DmForbidden, dm_mod.DmConflict) as e:
            return _dm_guard(e)
        _audit(conn, actor["id"], "dm_accept", thread_id)
        return jsonify(res)

    @app.post("/v1/dm/threads/<thread_id>/reject")
    def dm_reject(thread_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            res = dm_mod.reject(conn, actor["id"], thread_id)
        except (dm_mod.DmNotFound, dm_mod.DmForbidden, dm_mod.DmConflict) as e:
            return _dm_guard(e)
        _audit(conn, actor["id"], "dm_reject", thread_id)
        return jsonify(res)

    @app.post("/v1/dm/threads/<thread_id>/block")
    def dm_block(thread_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            res = dm_mod.block(conn, actor["id"], thread_id)
        except (dm_mod.DmNotFound, dm_mod.DmForbidden, dm_mod.DmConflict) as e:
            return _dm_guard(e)
        _audit(conn, actor["id"], "dm_block", thread_id)
        return jsonify(res)

    @app.post("/v1/dm/messages/<message_id>/recall")
    def dm_recall(message_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        try:
            m = dm_mod.recall(conn, actor["id"], message_id)
        except (dm_mod.DmNotFound, dm_mod.DmForbidden) as e:
            return _dm_guard(e)
        _audit(conn, actor["id"], "dm_recall", message_id)
        return jsonify({"ok": True, "message": m})

    # ---------------- federation：更新历史 + 提案协商（R32/R33）----------------
    def _federation_auto_apply(conn, p, actor_id):
        """auto 策略：达到阈值即自动 apply（fetch+验签+沙箱+快照）。"""
        if config.get("federation.apply_policy", "manual",
                      env="TEAMAI_APPLY_POLICY").lower() != "auto":
            return None
        thr = config.get_int("federation.auto_apply_threshold", 3,
                             env="TEAMAI_APPLY_THRESHOLD")
        if float(p.get("weight") or 0) < thr:
            return None
        src = p.get("bundle_url") or ""
        if not src:
            return None
        tok = None
        try:
            with open(os.path.join(ROOT, "bootstrap", "enroll.key"), encoding="utf-8") as fh:
                tok = fh.read().strip() or None
        except OSError:
            pass
        try:
            m, data = apply_mod.fetch_bundle(src, tok)
            res = apply_mod.apply_bundle(data, cur_version=distribution.runtime_version(),
                                         cur_major=protocol.PROTOCOL_MAJOR)
        except Exception as e:
            federation.append_update(conn, "system", "auto-apply-failed", p["title"],
                                     str(e)[:200], meta={"proposal_id": p["proposal_id"]})
            return None
        if res.get("ok"):
            federation.append_update(
                conn, "system", "auto-apply", f"auto-apply {p['proposal_id']}",
                res.get("log", ""), m.get("runtime_version", ""),
                (m.get("bundle") or {}).get("sha256", ""),
                {"proposal_id": p["proposal_id"], "source": src})
        return res

    @app.get("/v1/federation/policy")
    def federation_policy():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True,
                        "apply_policy": config.get("federation.apply_policy", "manual",
                                                   env="TEAMAI_APPLY_POLICY"),
                        "auto_apply_threshold": config.get_int("federation.auto_apply_threshold", 3,
                                                               env="TEAMAI_APPLY_THRESHOLD")})

    @app.post("/v1/federation/update")
    def federation_update():
        """定向更新本节点代码到 source_peer 的版本（只换代码，保留 agent 设置/数据）。"""
        conn = get_db()
        agent, _ = auth.authenticate(conn, request)
        authorized = bool(auth.enroll_token_row(conn, _enroll_token_header())) or agent is not None
        if not authorized:
            return _err("enroll token or key required", 401)
        b = request.get_json(force=True, silent=True) or {}
        src = b.get("source_peer") or ""
        if not src:
            return _err("source_peer required", 400)
        before = apply_mod.agent_fingerprint(conn)
        try:
            m, data = apply_mod.fetch_bundle(src, b.get("token"))
        except Exception as e:
            return _err(f"fetch/verify failed: {e}", 400)
        to_v, from_v = m.get("runtime_version", ""), distribution.runtime_version()
        if b.get("target_version") and b["target_version"] != to_v:
            return _err(f"target_version mismatch: source={to_v} want={b['target_version']}", 409)
        if not b.get("force") and not apply_mod.version_gt(to_v, from_v):
            return _err(f"not an upgrade: {from_v} -> {to_v}（如需强制加 force）", 409)
        if b.get("dry_run"):
            staged = apply_mod.stage(data)
            pc = apply_mod.precheck(staged, from_v, protocol.PROTOCOL_MAJOR)
            return jsonify({"ok": True, "dry_run": True, "from_version": from_v,
                            "to_version": to_v, "precheck": pc,
                            "preserved": apply_mod.PRESERVED})
        res = apply_mod.apply_bundle(data, cur_version=from_v, cur_major=protocol.PROTOCOL_MAJOR,
                                     install_deps=bool(b.get("install_deps")))
        if not res.get("ok"):
            return jsonify({"ok": False, **res}), 422
        after = apply_mod.agent_fingerprint(conn)
        preserved_ok = before["hash"] == after["hash"]
        federation.append_update(
            conn, (agent["id"] if agent else "federation"), "update",
            f"update {from_v}->{to_v}", res.get("log", ""), to_v,
            (m.get("bundle") or {}).get("sha256", ""),
            {"source": src, "snapshot": res.get("snapshot"), "from": from_v,
             "to": to_v, "preserved_ok": preserved_ok})
        return jsonify({"ok": True, "from_version": from_v, "to_version": to_v,
                        "snapshot": res.get("snapshot"), "precheck": res.get("precheck"),
                        "preserved": apply_mod.PRESERVED,
                        "agents_before": before["count"], "agents_after": after["count"],
                        "preserved_ok": preserved_ok, "restart_required": True})

    @app.post("/v1/peers/update")
    def peers_update():
        """A 触发：把自己的版本推给指定 peers（1-多 rollout）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        b = request.get_json(force=True, silent=True) or {}
        peers = b.get("peers") or []
        if not peers:
            return _err("peers required", 400)
        base = f"{request.scheme}://{request.host}"
        results = []
        for item in peers:
            addr = str(item).split("=", 1)[-1].strip().rstrip("/")
            url = addr if addr.startswith("http") else f"http://{addr}"
            payload = {"source_peer": base, "token": b.get("token"),
                       "dry_run": bool(b.get("dry_run")),
                       "install_deps": bool(b.get("install_deps")), "force": bool(b.get("force"))}
            try:
                req = urllib.request.Request(
                    url + "/v1/federation/update", data=json.dumps(payload).encode(),
                    headers={"Content-Type": "application/json",
                             "X-Enroll-Token": b.get("token") or ""}, method="POST")
                with urllib.request.urlopen(req, timeout=300) as r:
                    results.append({"peer": addr, **json.loads(r.read().decode())})
            except urllib.error.HTTPError as e:
                try:
                    results.append({"peer": addr, **json.loads(e.read().decode())})
                except Exception:
                    results.append({"peer": addr, "ok": False, "error": f"HTTP {e.code}"})
            except Exception as e:
                results.append({"peer": addr, "ok": False, "error": str(e)[:200]})
        return jsonify({"ok": True, "source": base, "results": results})

    @app.get("/v1/federation/sync")
    def federation_sync():
        """供对端 gossip 反熵：增量更新历史 + 全部提案（enroll token 或 key 均可）。"""
        conn = get_db()
        authorized = bool(auth.enroll_token_row(conn, _enroll_token_header()))
        if not authorized:
            agent, _ = auth.authenticate(conn, request)
            authorized = agent is not None
        if not authorized:
            return _err("enroll token or key required", 401)
        since = int(request.args.get("since", 0) or 0)
        return jsonify({"ok": True, "node": _node_log().node_id,
                        "updates": federation.list_updates(conn, since),
                        "proposals": federation.list_proposals(conn),
                        "ranks": federation.list_ranks(conn)})

    @app.get("/v1/updates")
    def updates_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        since = int(request.args.get("since", 0) or 0)
        return jsonify({"ok": True, "updates": federation.list_updates(conn, since)})

    @app.post("/v1/updates")
    def updates_post():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        b = request.get_json(force=True, silent=True) or {}
        uid = federation.append_update(
            conn, actor["id"], b.get("kind", "note"), b.get("title", ""),
            b.get("summary", ""), b.get("target_version", ""),
            b.get("artifact_hash", ""), b.get("meta"))
        return jsonify({"ok": True, "update_id": uid})

    @app.get("/v1/proposals")
    def proposals_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "proposals": federation.list_proposals(conn)})

    @app.post("/v1/proposals")
    def proposals_publish():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        b = request.get_json(force=True, silent=True) or {}
        try:
            pid = federation.publish(conn, actor["id"], b)
        except ValueError as e:
            return _err(str(e), 400)
        return jsonify({"ok": True, "proposal": federation.get_proposal(conn, pid)})

    @app.post("/v1/proposals/rank")
    def proposals_rank():
        """对某 topic 的提案排序（Borda 投票）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        b = request.get_json(force=True, silent=True) or {}
        try:
            order = federation.rank(conn, actor["id"], b.get("topic"), b.get("order"))
        except ValueError as e:
            return _err(str(e), 400)
        return jsonify({"ok": True, "topic": b.get("topic"), "order": order})

    @app.get("/v1/proposals/conflicts")
    def proposals_conflicts():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "conflicts": federation.conflicts(conn)})

    @app.get("/v1/proposals/<pid>")
    def proposals_get(pid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        p = federation.get_proposal(conn, pid)
        return jsonify({"ok": True, "proposal": p}) if p else _err("proposal not found", 404)

    @app.post("/v1/proposals/<pid>/vote")
    def proposals_vote(pid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        b = request.get_json(force=True, silent=True) or {}
        try:
            p = federation.vote(conn, pid, actor["id"], b.get("vote"), b.get("reason", ""))
        except (ValueError, KeyError) as e:
            return _err(str(e), 400)
        auto = None
        if b.get("vote") == "adopt":
            auto = _federation_auto_apply(conn, p, actor["id"])
        return jsonify({"ok": True, "proposal": p,
                        "auto_applied": bool(auto and auto.get("ok"))})

    @app.post("/v1/proposals/<pid>/apply")
    def proposals_apply(pid):
        """沙箱应用提案对应的发行版（需 yes=true；保留快照可回滚）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        b = request.get_json(force=True, silent=True) or {}
        if not b.get("yes"):
            return _err("confirmation required (yes=true)", 400)
        p = federation.get_proposal(conn, pid)
        if not p:
            return _err("proposal not found", 404)
        src = b.get("source_peer") or p.get("bundle_url") or ""
        if not src:
            return _err("source_peer required (提议需带 bundle_url 或请求指定)", 400)
        try:
            m, data = apply_mod.fetch_bundle(src, b.get("token"))
        except Exception as e:
            return _err(f"fetch/verify failed: {e}", 400)
        res = apply_mod.apply_bundle(data, cur_version=distribution.runtime_version(),
                                     cur_major=protocol.PROTOCOL_MAJOR,
                                     install_deps=bool(b.get("install_deps")))
        if not res.get("ok"):
            return jsonify({"ok": False, **res}), 422
        federation.append_update(conn, actor["id"], "apply", f"apply proposal {pid}",
                                 res.get("log", ""), m.get("runtime_version", ""),
                                 (m.get("bundle") or {}).get("sha256", ""),
                                 {"proposal_id": pid, "source": src,
                                  "snapshot": res.get("snapshot")})
        return jsonify({"ok": True, "runtime_version": m.get("runtime_version"),
                        "snapshot": res.get("snapshot"), "note": "重启服务后生效"})

    @app.post("/v1/proposals/<pid>/precheck")
    def proposals_precheck(pid):
        """跨版本/依赖预检（不落地）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        b = request.get_json(force=True, silent=True) or {}
        p = federation.get_proposal(conn, pid)
        if not p:
            return _err("proposal not found", 404)
        src = b.get("source_peer") or p.get("bundle_url") or ""
        if not src:
            return _err("source_peer required", 400)
        try:
            m, data = apply_mod.fetch_bundle(src, b.get("token"))
        except Exception as e:
            return _err(f"fetch/verify failed: {e}", 400)
        staged = apply_mod.stage(data)
        pc = apply_mod.precheck(staged, distribution.runtime_version(), protocol.PROTOCOL_MAJOR)
        return jsonify({"ok": True, "runtime_version": m.get("runtime_version"), "precheck": pc})

    @app.post("/v1/federation/offer")
    def federation_offer():
        """接收对端推送的发行版（双向同步，如 B→A）：验签 + 存包 + 登记版本。"""
        conn = get_db()
        agent, _ = auth.authenticate(conn, request)
        authorized = bool(auth.enroll_token_row(conn, _enroll_token_header())) or agent is not None
        if not authorized:
            return _err("enroll token or key required", 401)
        b = request.get_json(force=True, silent=True) or {}
        m = b.get("manifest") or {}
        b64 = b.get("bundle_b64") or ""
        if not m or not b64:
            return _err("manifest 与 bundle_b64 必填", 400)
        if not distribution.verify_manifest(m, m.get("pubkey", "")):
            return _err("manifest signature invalid", 400)
        try:
            data = base64.b64decode(b64)
        except Exception:
            return _err("bundle_b64 非法", 400)
        sha = hashlib.sha256(data).hexdigest()
        if sha != (m.get("bundle") or {}).get("sha256"):
            return _err("bundle sha mismatch", 400)
        node = str(b.get("node") or m.get("host") or m.get("key_fingerprint") or "peer")
        offers = os.path.join(ROOT, ".offers")
        os.makedirs(offers, exist_ok=True)
        path = os.path.join(offers, f"{node}-{sha[:12]}.tgz")
        with open(path, "wb") as fh:
            fh.write(data)
        federation.record_version(conn, node, m, sha)
        _audit(conn, (agent["id"] if agent else "federation"), "federation_offer", node,
               {"version": m.get("runtime_version")})
        return jsonify({"ok": True, "node": node, "version": m.get("runtime_version"),
                        "bundle_sha": sha})

    @app.post("/v1/federation/adopt-offer")
    def federation_adopt_offer():
        """采纳某对端推送的版本（从 .offers 应用，沙箱+快照）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor.get("kind") != "human":
            return _err(err or "forbidden", 403)
        b = request.get_json(force=True, silent=True) or {}
        node = b.get("node")
        row = conn.execute("SELECT bundle_sha, version FROM peer_versions WHERE node_id=?",
                           (node,)).fetchone()
        if not row:
            return _err("unknown peer version", 404)
        path = os.path.join(ROOT, ".offers", f"{node}-{(row['bundle_sha'] or '')[:12]}.tgz")
        if not os.path.exists(path):
            return _err("offer bundle missing", 404)
        with open(path, "rb") as fh:
            data = fh.read()
        res = apply_mod.apply_bundle(data, cur_version=distribution.runtime_version(),
                                     cur_major=protocol.PROTOCOL_MAJOR)
        if not res.get("ok"):
            return jsonify({"ok": False, **res}), 422
        federation.append_update(conn, actor["id"], "adopt-offer",
                                 f"adopt {node} v{row['version']}", res.get("log", ""),
                                 row["version"], row["bundle_sha"], {"node": node})
        return jsonify({"ok": True, "node": node, "version": row["version"],
                        "snapshot": res.get("snapshot"), "note": "重启后生效"})

    @app.get("/v1/federation/versions")
    def federation_versions():
        """列出本机与各对端版本，并标出是否与本地分歧。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        self_m = distribution.manifest()
        self_sha = (self_m.get("bundle") or {}).get("sha256")
        peers = federation.list_versions(conn)
        for p in peers:
            p["diverged"] = (p.get("bundle_sha") != self_sha)
        return jsonify({"ok": True,
                        "self": {"node": _node_log().node_id,
                                 "version": self_m.get("runtime_version"),
                                 "bundle_sha": self_sha, "serial": self_m.get("serial")},
                        "peers": peers})

    @app.get("/v1/federation/snapshots")
    def federation_snapshots():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "snapshots": apply_mod.list_snapshots()})

    @app.post("/v1/federation/rollback")
    def federation_rollback():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        snap = apply_mod.rollback()
        if not snap:
            return _err("no snapshot to rollback", 404)
        federation.append_update(conn, actor["id"], "rollback", f"rollback to {snap.name}",
                                 meta={"snapshot": snap.name})
        return jsonify({"ok": True, "restored": snap.name, "note": "重启服务后生效"})

    @app.get("/v1/net/events")
    def events_get():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        since = int(request.args.get("since", 0) or 0)
        log = _node_log()
        return jsonify({"ok": True, "node": log.node_id, "lamport": log.lamport(),
                        "events": log.since(since)})

    @app.post("/v1/net/events")
    def events_post():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        if not body.get("type"):
            return _err("type required")
        e = _node_log().append(body["type"], body.get("payload") or {})
        return jsonify({"ok": True, "event": e})

    @app.get("/v1/node/peers")
    def node_peers():
        return jsonify({"ok": True, "node": _node_log().node_id,
                        "peers": (_GOSSIP.peers() if _GOSSIP else {})})

    @app.get("/v1/tools")
    def tools_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "tools": tool.catalog()})

    @app.post("/v1/tools/<name>/call")
    def tools_call(name):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        t = tool.get(name)
        if not t:
            return _err("unknown tool", 404)
        body = request.get_json(force=True, silent=True) or {}
        # ★ 2026-10-08（Carol 真跨机验收：13+ 次调用此前**无审计**）：工具调用落审计。
        #   只记"谁/哪个工具/哪个 op/结果/耗时"，**不记完整 args**（隐私与体积）。
        import time as _t
        _t0 = _t.time()
        _args = body.get("args") or {}
        try:
            res = t.call(actor["id"], _args)
            _ok = bool(res.get("ok", True)) if isinstance(res, dict) else True
            _audit(conn, actor["id"], "tool_call", name,
                   {"op": _args.get("op"), "ok": _ok,
                    "reason": (res or {}).get("reason") if isinstance(res, dict) else None,
                    "ms": int((_t.time() - _t0) * 1000),
                    "kind": getattr(t, "kind", "local")})
            conn.commit()
            return jsonify({"ok": True, "result": res})
        except Exception as e:
            try:
                _audit(conn, actor["id"], "tool_call", name,
                       {"op": _args.get("op"), "ok": False, "error": f"{type(e).__name__}",
                        "ms": int((_t.time() - _t0) * 1000), "kind": getattr(t, "kind", "local")})
                conn.commit()
            except Exception:  # noqa: BLE001
                pass
            return _err(f"tool error: {e}", 400)

    @app.post("/v1/capture")
    def capture_endpoint():
        """通用抓取 web.capture：正文级抽取（直传 html/text 优先，profile 兜底）。

        隐私：受限/原文全文**默认不落盘**（返回 persisted=False）；审计只记元数据，
        **不记 html/text/正文**。登录态只来自调用者自己的 `.pwprofile`，不绕付费墙。
        """
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        url = (body.get("url") or "").strip() or None
        html = body.get("html")
        text = body.get("text")
        if not (url or html or text):
            return _err("url / html / text 至少给一个", 400)
        from . import capture as capture_mod
        import time as _t
        _t0 = _t.time()
        try:
            res = capture_mod.capture(url=url, html=html, text=text,
                                      mode=body.get("mode") or "text", agent=actor["id"],
                                      headed=bool(body.get("headed")),
                                      allow_network=bool(body.get("allow_network", True)))
        except Exception as e:  # noqa: BLE001
            try:
                _audit(conn, actor["id"], "capture", url or "upload",
                       {"ok": False, "error": type(e).__name__})
                conn.commit()
            except Exception:  # noqa: BLE001
                pass
            return _err(f"capture error: {e}", 400)
        if body.get("probe"):
            res["login_probe"] = capture_mod.probe_login(
                agent=actor["id"], url=url or capture_mod.ACCOUNT_URL)
        # 审计：只记「谁 / 来源 / 是否直传 / 长度 / 是否落盘 / 耗时」，**不记正文**
        try:
            _audit(conn, actor["id"], "capture", (res.get("source_url") or url or "upload"),
                   {"ok": True, "source": res.get("source"), "fetched": res.get("fetched"),
                    "text_len": res.get("text_len"), "persisted": res.get("persisted"),
                    "ms": int((_t.time() - _t0) * 1000)})
            conn.commit()
        except Exception:  # noqa: BLE001
            pass
        return jsonify({"ok": True, "result": res})

    # ---------------- 手机 APP 分发（docs/331） ----------------
    # 扫码 → 短期令牌 → 节点下载（带 sha256 校验）。私有 GitHub 库只当构建归档，
    # 不把 PAT 塞进二维码。发布/签发令牌要身份；下载要令牌（不要求登录）。
    def _apps_base() -> str:
        return f"http://{_public_host()}"

    @app.get("/v1/apps")
    def apps_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        app = (request.args.get("app") or "").strip() or None
        return jsonify({"ok": True, "releases": appdist.list_releases(conn, app),
                        "platforms": list(appdist.PLATFORMS)})

    @app.post("/v1/apps/publish")
    def apps_publish():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        from werkzeug.utils import secure_filename
        f = request.files.get("file")
        if f is None or not f.filename:
            return _err("file required (multipart)", 400)
        if (request.content_length or 0) > 200 * 1024 * 1024:
            return _err("package too large (max 200MB)", 413)
        import tempfile
        name = secure_filename(f.filename) or "package.bin"
        tmpdir = tempfile.mkdtemp(prefix="appdist-", dir=str(appdist.app_root()))
        tmp = os.path.join(tmpdir, name)
        try:
            f.save(tmp)
            rel = appdist.publish(conn, pathlib.Path(tmp),
                                  request.form.get("app", ""),
                                  request.form.get("version", ""),
                                  request.form.get("platform", ""),
                                  notes=request.form.get("notes", ""),
                                  channel=request.form.get("channel", "stable"),
                                  by=actor["id"])
        except ValueError as e:
            return _err(str(e), 400)
        except FileNotFoundError as e:
            return _err(str(e), 404)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)
        return jsonify({"ok": True, **rel})

    @app.post("/v1/apps/<app>/token")
    def apps_token(app):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        b = request.get_json(force=True, silent=True) or {}
        try:
            t = appdist.issue_token(conn, app, b.get("version"), b.get("platform"),
                                    ttl_hours=int(b.get("ttl_hours") or 72),
                                    max_uses=int(b.get("max_uses") or 50),
                                    by=actor["id"])
        except ValueError as e:
            return _err(str(e), 404 if "尚未发布" in str(e) else 400)
        land = f"{_apps_base()}/v1/apps/land?token={t['token']}"
        return jsonify({"ok": True, **t, "landing_url": land,
                        "download_url": f"{_apps_base()}/v1/apps/download?token={t['token']}",
                        "qr_url": f"{_apps_base()}/v1/apps/qr.png?token={t['token']}"})

    @app.get("/v1/apps/qr.png")
    def apps_qr():
        """公开：把落地页编码成二维码（令牌本身就是鉴权，页面里没有文件内容）。"""
        token = request.args.get("token") or ""
        if not appdist.resolve_token(get_db(), token):
            return _err("invalid or expired token", 403)
        png = appdist.qr_png(f"{_apps_base()}/v1/apps/land?token={token}")
        return Response(png, mimetype="image/png",
                        headers={"cache-control": "no-store"})

    @app.get("/v1/apps/land")
    def apps_land():
        token = request.args.get("token") or ""
        conn = get_db()
        t = appdist.resolve_token(conn, token)
        if not t:
            return _err("invalid or expired token", 403)
        rel = (appdist.get_release(conn, t["app"], t["version"], t["platform"])
               if t.get("app") else None)
        if not rel:
            return _err("release missing", 404)
        return Response(appdist.landing_html(
            rel["app"], rel["version"], rel["platform"], rel["sha256"], rel["size"],
            t["expires_at"], f"{_apps_base()}/v1/apps/download?token={token}"),
            mimetype="text/html; charset=utf-8",
            headers={"cache-control": "no-store"})

    @app.get("/v1/apps/download")
    def apps_download():
        """公开（凭令牌）：限量下载 + 每次校验 sha256；包被换过就拒发。"""
        token = request.args.get("token") or ""
        conn = get_db()
        t = appdist.resolve_token(conn, token)
        if not t:
            return _err("invalid or expired token", 403)
        rel = appdist.get_release(conn, t["app"], t["version"], t["platform"])
        if not rel:
            return _err("release missing", 404)
        p = appdist.blob_path(rel)
        if not p:
            return _err("blob missing", 404)
        if appdist.sha256_file(p) != rel["sha256"]:
            return _err("package checksum mismatch (refusing to serve)", 409)
        if not appdist.consume_token(conn, token):
            return _err("token exhausted", 403)
        resp = send_file(str(p), as_attachment=True, download_name=rel["filename"],
                         mimetype="application/octet-stream")
        # 让手机端/脚本能核对内容：sha256 与版本随包下发（不是装饰，是验收依据）
        resp.headers["X-App-Sha256"] = rel["sha256"]
        resp.headers["X-App-Version"] = rel["version"]
        resp.headers["X-App-Platform"] = rel["platform"]
        return resp

    @app.post("/v1/tools/publish")
    def tools_publish():
        """发布工具包到武器库（隐私扫描 + 打包 + #tools 发帖）。"""
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        b = request.get_json(force=True, silent=True) or {}
        name = (b.get("name") or "").strip()
        if not name:
            return _err("name required", 400)
        issues = toolpkg.privacy_scan(name)
        if issues and not b.get("force"):
            return jsonify({"ok": False, "privacy_issues": issues,
                            "hint": "移除个人 key/绝对路径后重试，或 force=true"}), 422
        try:
            pkg = toolpkg.publish(conn, name, _node_log().node_id, actor["id"],
                                  str(b.get("version", "1")))
        except FileNotFoundError as e:
            return _err(str(e), 404)
        try:
            if not conn.execute("SELECT 1 FROM channels WHERE id='#tools'").fetchone():
                community.create_channel(conn, actor["id"], "tools", purpose="工具/武器库")
            doc = ""
            dp = os.path.join(ROOT, "tools", name, "TOOL.md")
            if os.path.exists(dp):
                with open(dp, encoding="utf-8") as fh:
                    doc = fh.read()[:1500]
            pid = "p-" + hashlib.sha1(f"{name}{time.time()}".encode()).hexdigest()[:8]
            conn.execute("INSERT INTO posts(id,channel_id,author_id,type,title,body,status) "
                         "VALUES (?,?,?,?,?,?,?)",
                         (pid, "#tools", actor["id"], "artifact",
                          f"工具发布：{name} v{pkg['version']}",
                          doc or f"工具 {name} 已发布，sha={pkg['sha256'][:12]}"))
            conn.commit()
        except Exception:
            pass
        return jsonify({"ok": True, **pkg, "channel": "#tools"})

    @app.get("/v1/tools/packages")
    def tools_packages():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "packages": toolpkg.list_packages(conn)})

    @app.get("/v1/tools/packages/<name>/download")
    def tools_download(name):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        sha = request.args.get("sha")
        if sha:
            row = conn.execute("SELECT blob FROM tool_packages WHERE name=? AND sha256=?",
                               (name, sha)).fetchone()
        else:
            row = conn.execute("SELECT blob FROM tool_packages WHERE name=? "
                               "ORDER BY created_at DESC LIMIT 1", (name,)).fetchone()
        if not row:
            return _err("package not found", 404)
        p = toolpkg.blob_path(row["blob"])
        if not p:
            return _err("blob missing", 404)
        return send_file(str(p), as_attachment=True, download_name=row["blob"],
                         mimetype="application/gzip")

    @app.post("/v1/tools/install")
    def tools_install():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        b = request.get_json(force=True, silent=True) or {}
        name = (b.get("name") or "").strip()
        if not name:
            return _err("name required", 400)
        try:
            res = toolpkg.install(conn, name, b.get("sha"))
        except FileNotFoundError as e:
            return _err(str(e), 404)
        loaded = tool.user_tools.load_all()
        return jsonify({"ok": True, **res, "loaded": loaded})

    @app.get("/v1/media/keys")
    def media_keys():
        return jsonify({"ok": True, "keys": {k: bool(v) for k, v in media.KEYS.items()}})

    @app.post("/v1/media/search")
    def media_search():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        q = (body.get("query") or "").strip()
        if not q:
            return _err("query required")
        try:
            urls = media.bing_images(q, int(body.get("n", 8)))
        except Exception as e:
            return _err(f"search failed: {e}", 502)
        return jsonify({"ok": True, "results": urls})

    @app.post("/v1/media/fetch")
    def media_fetch():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        url = (body.get("url") or "").strip()
        if not url.startswith("http"):
            return _err("url required")
        try:
            return jsonify({"ok": True, "url": media.download_image(url)})
        except Exception as e:
            return _err(f"fetch failed: {e}", 502)

    @app.post("/v1/media/generate")
    def media_generate():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        prompt = (body.get("prompt") or "").strip()
        if not prompt:
            return _err("prompt required")
        try:
            return jsonify({"ok": True, "url": media.ark_generate(prompt, body.get("size", "2K"))})
        except Exception as e:
            return _err(f"generate failed: {e}", 502)

    @app.get("/v1/media/library")
    def media_library():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "images": media.local_library()})

    @app.post("/v1/media/local")
    def media_local():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        try:
            return jsonify({"ok": True, "url": media.local_copy(body.get("path") or "")})
        except Exception as e:
            return _err(f"local copy failed: {e}", 400)

    @app.post("/v1/media/screenshot")
    def media_screenshot():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        url = (body.get("url") or "").strip()
        if not url.startswith("http"):
            return _err("url required")
        try:
            return jsonify({"ok": True, "url": media.screenshot(url, bool(body.get("full")))}) 
        except Exception as e:
            return _err(f"screenshot failed: {e}", 502)

    @app.post("/v1/media/browse")
    def media_browse():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        url = (body.get("url") or "").strip()
        if not url.startswith("http"):
            return _err("url required")
        try:
            r = media.browse(url, body.get("actions") or [], bool(body.get("full")))
            return jsonify({"ok": True, **r})
        except Exception as e:
            return _err(f"browse failed: {e}", 502)

    @app.post("/v1/rooms/<rid>/report")
    def room_report(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        text = (body.get("text") or "").strip()
        if not text:
            return _err("text required")
        agent_id = body.get("agent_id") or actor["id"]
        if actor.get("kind") != "human" and agent_id != actor["id"]:
            return _err("forbidden", 403)
        try:
            res = rooms.report(conn, rid, agent_id, text)
        except ValueError as e:
            return _err(str(e), 404)
        _audit(conn, actor["id"], "room_report", rid, res)
        conn.commit()
        return jsonify({"ok": True, **res})

    @app.post("/v1/rooms/<rid>/members")
    def room_members_add(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        if not body.get("agent_id"):
            return _err("agent_id required")
        try:
            res = rooms.force_add_member(conn, rid, body["agent_id"])
        except ValueError as e:
            return _err(str(e), 404)
        _audit(conn, actor["id"], "room_add_member", rid, res)
        conn.commit()
        return jsonify({"ok": True, **res})

    @app.get("/v1/rooms/<rid>/boundaries")
    def room_boundaries(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        out = []
        for m in conn.execute("SELECT agent_id, kind FROM room_members WHERE room_id=?", (rid,)).fetchall():
            a = conn.execute("SELECT persona_json FROM agents WHERE id=?", (m["agent_id"],)).fetchone()
            p = _loads(a["persona_json"], {}) if a else {}
            out.append({"agent_id": m["agent_id"], "kind": m["kind"],
                        "boundaries": persona_mod.boundary_view(p)})
        return jsonify({"ok": True, "members": out})

    @app.post("/v1/rooms/<rid>/boundary-check")
    def room_boundary_check(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        text = body.get("text") or ""
        out = []
        for m in conn.execute("SELECT agent_id FROM room_members WHERE room_id=? AND kind='ai'", (rid,)).fetchall():
            a = conn.execute("SELECT persona_json FROM agents WHERE id=?", (m["agent_id"],)).fetchone()
            p = _loads(a["persona_json"], {}) if a else {}
            out.append({"agent_id": m["agent_id"], **persona_mod.boundary_check(p, text)})
        return jsonify({"ok": True, "results": out})

    @app.post("/v1/rooms/<rid>/share")
    def room_share(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        as_agent = (body.get("as_agent") or rooms.human_id(conn)).strip() or rooms.human_id(conn)
        # 远程 agent 若未在本节点登记，建 stub（kind=remote），以便参与工作群
        if as_agent != rooms.human_id(conn) and not conn.execute(
                "SELECT 1 FROM agents WHERE id=?", (as_agent,)).fetchone():
            conn.execute(
                "INSERT INTO agents(id, name, kind, full_name, role, persona_json, status, last_seen) "
                "VALUES (?,?,?,?,?,?,?,datetime('now','localtime'))",
                (as_agent, as_agent, "ai", as_agent, "executor", "{}", "active"))
            conn.commit()
        try:
            tok = rooms.share_token(conn, rid, by=actor["id"], as_agent=as_agent)
        except ValueError as e:
            return _err(str(e), 404)
        _audit(conn, actor["id"], "room_share", rid, {"as_agent": as_agent})
        conn.commit()
        url = f"http://{_public_host()}/?join={tok}"
        return jsonify({"ok": True, "token": tok, "as_agent": as_agent, "url": url,
                        "qr_url": f"/v1/rooms/{rid}/qr.png?token={tok}"})

    @app.get("/v1/rooms/<rid>/qr.png")
    def room_qr(rid):
        conn = get_db()
        token = request.args.get("token")
        sh = rooms.resolve_share(conn, token)
        if not sh or sh["room_id"] != rid:
            return _err("invalid token", 403)
        url = f"http://{_public_host()}/?join={token}"
        try:
            import io
            import qrcode
            qr = qrcode.QRCode(box_size=8, border=2)
            qr.add_data(url)
            qr.make(fit=True)
            img = qr.make_image(fill_color="#0f1720", back_color="white")
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            buf.seek(0)
            return send_file(buf, mimetype="image/png")
        except Exception as e:
            return _err(f"qr error: {e}", 500)

    @app.get("/v1/rooms/<rid>/messages/<int:mid>/graph")
    def room_graph(rid, mid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        r = conn.execute("SELECT * FROM argument_graphs WHERE message_id=?", (mid,)).fetchone()
        if not r:
            return _err("graph not found", 404)
        d = dict(r)
        d["graph"] = _loads(d.get("graph_json"), {})
        return jsonify({"ok": True, "argument": d})

    @app.get("/v1/rooms/<rid>/messages/<int:mid>/png")
    def room_png(rid, mid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        p = os.path.join(ROOT, "rooms", rid, f"msg-{mid}.png")
        if not os.path.exists(p):
            return _err("png not found", 404)
        return send_file(p, mimetype="image/png")

    @app.post("/v1/graphs/eval")
    def graph_eval():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        g = body.get("graph") or {}
        if not g.get("nodes"):
            return _err("graph.nodes required")
        evd = arguments.expected_value(g)
        return jsonify({"ok": True, "validation": arguments.validate(g),
                        "ev": (evd or {}).get("ev"), "ev_detail": evd})

    @app.put("/v1/rooms/<rid>/messages/<int:mid>/graph")
    def room_graph_put(rid, mid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        body = request.get_json(force=True, silent=True) or {}
        g = body.get("graph") or {}
        if not g.get("nodes"):
            return _err("graph.nodes required")
        if not conn.execute("SELECT 1 FROM argument_graphs WHERE message_id=?", (mid,)).fetchone():
            return _err("graph not found", 404)
        val = arguments.validate(g)
        evd = arguments.expected_value(g)
        post = arguments.posterior(g)
        conn.execute(
            "UPDATE argument_graphs SET graph_json=?, posterior=?, n_nodes=?, n_edges=?, ev=?, validation=? "
            "WHERE message_id=?",
            (json.dumps(g, ensure_ascii=False), post, len(g.get("nodes", [])), len(g.get("edges", [])),
             (evd or {}).get("ev"), json.dumps(val, ensure_ascii=False), mid))
        _audit(conn, actor["id"], "graph_edit", rid, {"message_id": mid})
        conn.commit()
        try:
            arguments.render_png(g, os.path.join(ROOT, "rooms", rid, f"msg-{mid}.png"))
        except Exception as e:
            print(f"[graph_put] render err: {e}")
        return jsonify({"ok": True, "validation": val, "ev": (evd or {}).get("ev"), "posterior": post})

    @app.get("/v1/rooms/<rid>/graphs")
    def room_graphs(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "graphs": rooms.list_graphs(conn, rid)})

    @app.get("/v1/rooms/<rid>/summary")
    def room_summary(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "summary": rooms.summary(conn, rid)})

    @app.post("/v1/rooms/<rid>/reeval")
    def room_reeval(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "reeval": rooms.reeval_room(conn, rid)})

    @app.get("/v1/rooms/<rid>/reeval")
    def room_reeval_get(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM reevals WHERE room_id=? ORDER BY id DESC LIMIT 200", (rid,)).fetchall()]
        consistent = sum(1 for r in rows if r["consistent"])
        return jsonify({"ok": True, "total": len(rows), "consistent": consistent, "items": rows})

    @app.get("/v1/agents/<agent_id>/aesthetic")
    def agent_aesthetic(agent_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "aesthetic": rooms.get_aesthetic(conn, agent_id)})

    @app.post("/v1/agents/<agent_id>/aesthetic/extract")
    def agent_aesthetic_extract(agent_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "aesthetic": rooms.extract_aesthetic(conn, agent_id)})

    @app.get("/v1/requirements")
    def requirements_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "requirements": rooms.list_requirements(
            conn, status=request.args.get("status"))})

    @app.post("/v1/requirements/extract")
    def requirements_extract():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        added = rooms.extract_requirements_from_posts(conn, body.get("channel_id"))
        return jsonify({"ok": True, "added": len(added), "items": added})

    @app.get("/v1/readings")
    def readings_list():
        conn = get_db()
        book = request.args.get("book")
        sql = "SELECT * FROM readings"
        params = []
        if book:
            sql += " WHERE book=?"
            params.append(book)
        sql += " ORDER BY ord, id"
        return jsonify({"ok": True, "readings": [dict(r) for r in conn.execute(sql, params).fetchall()]})

    @app.post("/v1/requirements/<int:req_id>/promote")
    def requirement_promote(req_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor or actor["id"] == "anonymous":
            return _err(err or "login required", 401)
        r = conn.execute("SELECT * FROM requirements WHERE id=?", (req_id,)).fetchone()
        if not r:
            return _err("requirement not found", 404)
        tid = task_mod.new_id("t")
        conn.execute(
            "INSERT INTO tasks(id, title, description, acceptance_criteria, priority, status, created_by) "
            "VALUES (?,?,?,?,?,?,?)",
            (tid, (r["text"] or "")[:60], r["text"],
             f"来源：需求池 #{req_id}（房间 {r['source_room']}，提出者 {r['source_agent']}）",
             2, "backlog", actor["id"]))
        task_mod.record_event(conn, tid, actor["id"], None, "backlog", "create")
        conn.execute("UPDATE requirements SET status='accepted' WHERE id=?", (req_id,))
        _audit(conn, actor["id"], "promote_requirement", str(req_id), {"task_id": tid})
        conn.commit()
        return jsonify({"ok": True, "task_id": tid})

    @app.get("/v1/team/profile")
    def team_profile():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "team": rooms.team_profile(conn)})

    @app.post("/v1/rooms/<rid>/end")
    def room_end(rid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        # M4：结束前抽取审美画像 + 需求池
        for m in conn.execute("SELECT agent_id FROM room_members WHERE room_id=? AND kind='ai'", (rid,)).fetchall():
            try:
                rooms.extract_aesthetic(conn, m["agent_id"])
            except Exception:
                pass
        try:
            rooms.extract_requirements(conn, rid)
        except Exception:
            pass
        rooms.end_room(conn, rid)
        s = rooms.summary(conn, rid)
        # 自动汇总发 #reading
        arena = "；".join(f"{a['agent_id']} #{a['rank']}({a['score']})" for a in s["arena"])
        lines = [f"《{s['room']['topic']}》会话汇总", "", f"- 轮次：{s['room']['current_round']}",
                 f"- arena：{arena or '无'}", ""]
        for m in s["messages"][-20:]:
            if m["kind"] != "system":
                lines.append(f"- [{m['round']}] {m['agent_id']}（{m['kind']}，{m.get('score')}）：{(m['body'] or '')[:120]}")
        pid = community.create_post(conn, actor["id"], s["room"].get("channel_id") or "#reading",
                                    "artifact", "\n".join(lines),
                                    title=f"会话汇总：{s['room']['topic']}", tags=["读书会", "汇总"])
        _audit(conn, actor["id"], "room_end", rid, {"summary_post": pid})
        conn.commit()
        return jsonify({"ok": True, "summary_post": pid})

    @app.get("/v1/audit")
    def audit_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "audit": _audit_page(
            conn, limit=int(request.args.get("limit", 50)))})

    @app.get("/v1/reputation/leaderboard")
    def reputation_leaderboard():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        rows = conn.execute(
            "SELECT r.agent_id, a.full_name, ROUND(SUM(r.points),1) AS points, COUNT(*) AS events "
            "FROM reputation_events r LEFT JOIN agents a ON a.id=r.agent_id "
            "GROUP BY r.agent_id ORDER BY points DESC").fetchall()
        return jsonify({"ok": True, "leaderboard": [dict(r) for r in rows]})

    @app.post("/v1/retro")
    def retro_create():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        period = body.get("period", "daily")
        if period not in ("daily", "weekly"):
            return _err("period must be daily|weekly")
        res = community.post_retro(conn, period, actor["id"])
        return jsonify({"ok": True, **res})

    @app.get("/v1/retros")
    def retro_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "retros": community.list_retros(conn)})

    @app.get("/v1/search")
    def search_posts():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        q = request.args.get("q", "").strip()
        if not q:
            return _err("q required")
        return jsonify({"ok": True, "results": community.search(
            conn, q, channel=request.args.get("channel"),
            limit=int(request.args.get("limit", 20)))})

    @app.get("/v1/notifications")
    def notifications():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        unread_only = request.args.get("unread") == "1"
        return jsonify({"ok": True, "unread": community.unread_count(conn, actor["id"]),
                        "notifications": community.list_notifications(
                            conn, actor["id"], unread_only=unread_only,
                            limit=int(request.args.get("limit", 50)))})

    @app.post("/v1/notifications/read")
    def notifications_read():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "marked": community.mark_notifications_read(conn, actor["id"])})

    # ---------------- direct messages (DM / 对话) ----------------
    @app.post("/v1/messages")
    def message_send():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        to_id = body.get("to")
        if not to_id or not body.get("body"):
            return _err("to and body required")
        report = redaction.scan(body["body"])
        if not report["pass"]:
            return jsonify({"ok": False, "error": "redaction gate", "report": report}), 422
        try:
            mid = community.send_message(conn, actor["id"], to_id, body["body"])
        except ValueError as e:
            return _err(str(e))
        _audit(conn, actor["id"], "send_message", to_id, {"message_id": mid, "len": len(body["body"])})
        conn.commit()
        return jsonify({"ok": True, "message_id": mid, "from": actor["id"], "to": to_id})

    @app.get("/v1/messages")
    def message_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        box = request.args.get("box", "in")
        return jsonify({"ok": True, "unread": community.unread_message_count(conn, actor["id"]),
                        "messages": community.list_messages(
                            conn, actor["id"], with_agent=request.args.get("with"), box=box,
                            unread_only=request.args.get("unread") == "1",
                            limit=int(request.args.get("limit", 50)))})

    @app.post("/v1/messages/read")
    def message_read():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "marked": community.mark_messages_read(conn, actor["id"])})

    @app.post("/v1/topics")
    def topic_open():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        if not body.get("title"):
            return _err("title required")
        tid = community.open_topic(conn, actor["id"], body["title"],
                                   body.get("prompt"), body.get("channel_id", "#lobby"))
        return jsonify({"ok": True, "topic_id": tid})

    @app.get("/v1/topics")
    def topic_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        return jsonify({"ok": True, "topics": community.list_topics(conn),
                        "active": community.active_topic(conn)})

    @app.post("/v1/topics/<tid>/close")
    def topic_close(tid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        community.close_topic(conn, tid)
        return jsonify({"ok": True})

    @app.post("/v1/redact-check")
    def redact_check():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        return jsonify({"ok": True, "report": redaction.scan(body.get("text", ""))})

    # ---------------- profiles (G1: 务虚摘要) ----------------
    def _profile_of(conn, agent_id):
        arow = conn.execute("SELECT * FROM agents WHERE id=?", (agent_id,)).fetchone()
        if not arow:
            return None
        p = _loads(arow["persona_json"], {})
        base = persona_mod.persona_view(p)
        rich = {k: base[k] for k in ("avatar", "avatar_url", "color", "gender", "pronouns",
                                     "motto", "bio", "rhythm", "cycle")}   # 不给 body（私密维度）
        row = conn.execute("SELECT summary_json FROM agent_profiles WHERE agent_id=?", (agent_id,)).fetchone()
        if row:
            d = _loads(row["summary_json"], {})
            d.setdefault("agent_id", agent_id)
            d.setdefault("display_name", arow["full_name"] or arow["name"])
            d.setdefault("role", arow["role"])
            d.update(rich)
            return d
        vals = {k: (v.get("value") if isinstance(v, dict) else v)
                for k, v in (p.get("values") or {}).items()}
        return {"agent_id": agent_id, "display_name": arow["full_name"] or arow["name"],
                "role": arow["role"], "values": vals,
                "interests": p.get("interests", []),
                "thinking_style": p.get("reasoning_policy", {}), **rich}

    @app.post("/v1/agents/<agent_id>/profile")
    def profile_push(agent_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        if actor["id"] != agent_id:
            return _err("can only push your own profile", 403)
        body = request.get_json(force=True, silent=True) or {}
        summary = profiles.sanitize(body.get("summary") or {})
        summary.setdefault("agent_id", agent_id)
        rep = float(body.get("reputation", 0))
        conn.execute(
            "INSERT INTO agent_profiles(agent_id, summary_json, values_json, interests_json, reputation, updated_at) "
            "VALUES (?,?,?,?,?,datetime('now','localtime')) "
            "ON CONFLICT(agent_id) DO UPDATE SET summary_json=excluded.summary_json, "
            "values_json=excluded.values_json, interests_json=excluded.interests_json, "
            "reputation=excluded.reputation, updated_at=datetime('now','localtime')",
            (agent_id, json.dumps(summary, ensure_ascii=False),
             json.dumps(summary.get("values", {}), ensure_ascii=False),
             json.dumps(summary.get("interests", []), ensure_ascii=False), rep))
        _audit(conn, actor["id"], "profile_push", agent_id)
        conn.commit()
        return jsonify({"ok": True, "agent_id": agent_id})

    @app.get("/v1/agents/<agent_id>/profile")
    def profile_get(agent_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        p = _profile_of(conn, agent_id)
        if not p:
            return _err("profile not found", 404)
        return jsonify({"ok": True, "profile": p})

    @app.get("/v1/profiles")
    def profile_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        rows = conn.execute("SELECT id FROM agents ORDER BY full_name").fetchall()
        out = []
        for r in rows:
            p = _profile_of(conn, r["id"])
            if p:
                out.append(p)
        return jsonify({"ok": True, "profiles": out})

    @app.get("/v1/agents/<agent_id>/complements")
    def complements(agent_id):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        me = _profile_of(conn, agent_id)
        if not me:
            return _err("profile not found", 404)
        limit = int(request.args.get("limit", 5))
        scored = []
        for r in conn.execute("SELECT id FROM agents WHERE id!=?", (agent_id,)).fetchall():
            other = _profile_of(conn, r["id"])
            if other:
                c = profiles.complementarity(me, other)
                scored.append({"agent_id": r["id"], "display_name": other.get("display_name"),
                               "role": other.get("role"), **c})
        scored.sort(key=lambda x: x["score"], reverse=True)
        return jsonify({"ok": True, "agent_id": agent_id, "complements": scored[:limit]})

    # ---------------- mentorship (G2: 申请 + 确认) ----------------
    @app.post("/v1/mentorship/request")
    def mentor_request():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        body = request.get_json(force=True, silent=True) or {}
        mentor = body.get("mentor_id")
        if not mentor or not conn.execute("SELECT 1 FROM agents WHERE id=?", (mentor,)).fetchone():
            return _err("valid mentor_id required")
        if mentor == actor["id"]:
            return _err("cannot mentor yourself")
        mid = community.new_id("m")
        conn.execute("INSERT INTO mentorships(id, mentee_id, mentor_id, status, note) VALUES (?,?,?,?,?)",
                     (mid, actor["id"], mentor, "pending", body.get("note")))
        conn.commit()
        return jsonify({"ok": True, "mentorship_id": mid, "status": "pending"})

    @app.post("/v1/mentorship/<mid>/confirm")
    def mentor_confirm(mid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        row = conn.execute("SELECT * FROM mentorships WHERE id=?", (mid,)).fetchone()
        if not row:
            return _err("not found", 404)
        if row["mentor_id"] != actor["id"]:
            return _err("only the mentor can confirm", 403)
        conn.execute("UPDATE mentorships SET status='active', confirmed_at=datetime('now','localtime') WHERE id=?", (mid,))
        conn.commit()
        return jsonify({"ok": True, "mentorship_id": mid, "status": "active"})

    @app.post("/v1/mentorship/<mid>/decline")
    def mentor_decline(mid):
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        row = conn.execute("SELECT * FROM mentorships WHERE id=?", (mid,)).fetchone()
        if not row or row["mentor_id"] != actor["id"]:
            return _err("only the mentor can decline", 403)
        conn.execute("UPDATE mentorships SET status='declined' WHERE id=?", (mid,))
        conn.commit()
        return jsonify({"ok": True, "status": "declined"})

    @app.get("/v1/mentorship")
    def mentor_list():
        conn = get_db()
        actor, err = _require_agent(conn)
        if not actor:
            return _err(err, 401)
        aid = request.args.get("agent") or actor["id"]
        rows = conn.execute(
            "SELECT m.*, me.full_name AS mentee, mr.full_name AS mentor FROM mentorships m "
            "LEFT JOIN agents me ON me.id=m.mentee_id LEFT JOIN agents mr ON mr.id=m.mentor_id "
            "WHERE m.mentee_id=? OR m.mentor_id=? ORDER BY m.requested_at DESC", (aid, aid)).fetchall()
        return jsonify({"ok": True, "mentorships": [dict(r) for r in rows]})

    try:
        from core.app_ui import register as register_app_ui
        register_app_ui(app)
    except Exception as e:  # noqa: BLE001
        print(f"[app_ui] 注册失败：{e}")

    try:
        from core.deliverables_ui import register as register_deliverables_ui
        register_deliverables_ui(app)
    except Exception as e:  # noqa: BLE001
        print(f"[deliverables_ui] 注册失败：{e}")

    return app


# ------------------------------------------------------------------ clock thread
def _sync_loop(interval_min: int):
    while True:
        time.sleep(interval_min * 60)
        try:
            conn = db.connect()
            conn.execute("INSERT INTO sync_ticks(interval_m, digest) VALUES (?, ?)",
                         (interval_min, json.dumps({"note": "auto tick"})))
            auth.cleanup_nonces(conn)
            conn.commit()
            for r in community.maybe_post_retro(conn):
                print(f"[retro] posted {r['period']} -> {r['post_id']}")
            conn.close()
        except Exception:
            pass


def _start_clock():
    threading.Thread(target=_sync_loop, args=(SYNC_INTERVAL_MIN,), daemon=True).start()

def _moment_loop(interval=30):
    """朋友圈赛马扫描：Phase 1 dry-run，只收集候选，不发布。"""
    if os.environ.get("TEAMAI_MOMENT_RACE", "dry-run").lower() in ("0", "off", "false"):
        return
    judge = None
    if os.environ.get("TEAMAI_MOMENT_JUDGE", "on").lower() not in ("0", "off", "false"):
        judge = moment_reward.judge_candidates
    while True:
        try:
            conn = db.connect()
            try:
                r = moment_reward.tick(conn, judge=judge)
            finally:
                conn.close()
            if r.get("candidates") or r.get("winner"):
                print(f"[moment-race] {r.get('round')} {r.get('status')} "
                      f"candidates={r.get('candidates')} winner={r.get('winner')} (dry-run)")
        except Exception as e:  # noqa: BLE001
            print(f"[moment-race] err: {e}")
        time.sleep(interval)


def _start_moment_loop():
    threading.Thread(target=_moment_loop, daemon=True).start()


def _room_watch_loop(interval=15):
    """AI 自升级闭环 · 第一步：持续监控运行中的房间，把真人发言蒸馏进「需求池」。"""
    while True:
        try:
            conn = db.connect()
            for r in conn.execute(
                    "SELECT id, current_round, watcher_round FROM rooms WHERE status='running'").fetchall():
                if rooms.auto_end_if_due(conn, r["id"]):   # 会话超时强制结束
                    print(f"[room-watch] {r['id']} 会话到点，自动结束")
                    continue
                added = rooms.extract_requirements(conn, r["id"], only_human=True)
                if added:
                    conn.execute("UPDATE rooms SET watcher_round=? WHERE id=?",
                                 (r["current_round"], r["id"]))
                    conn.commit()
                    print(f"[room-watch] {r['id']} +{len(added)} 需求")
            conn.close()
        except Exception as e:
            print(f"[room-watch] err: {e}")
        time.sleep(interval)


def _start_room_watcher():
    threading.Thread(target=_room_watch_loop, daemon=True).start()


def _style_loop(interval=1800):
    """周期性更新每个 AI 的语言风格（口头禅轮换 + 向真人语料学节奏）。默认 30 分钟。"""
    while True:
        try:
            conn = db.connect()
            for a in conn.execute("SELECT id, persona_json FROM agents WHERE kind='ai'").fetchall():
                aid = a["id"]
                own = [r["body"] for r in conn.execute(
                    "SELECT body FROM room_messages WHERE agent_id=? AND kind NOT IN ('skip','system') "
                    "ORDER BY id DESC LIMIT 30", (aid,)).fetchall()]
                human = [r["body"] for r in conn.execute(
                    "SELECT body FROM room_messages WHERE agent_id=? AND kind NOT IN ('skip','system') "
                    "ORDER BY id DESC LIMIT 30", (rooms.human_id(conn),)).fetchall()]
                try:                                     # 以**本机**人格为基（保住私密维度），回退到库
                    p = persona_mod.load_persona(aid)
                except Exception:  # noqa: BLE001
                    p = _loads(a["persona_json"], {})
                p["voice"] = style_mod.evolve_style(p, own, human)     # 口头禅轮换 + 基础统计
                # 风格学习 v2：LLM 按该 agent 的人设判断采纳什么/采纳多少/不学什么
                try:
                    lr = style_mod.learn_style(p, human, own)
                    if lr.get("ok"):
                        vo = dict(p.get("voice") or {})
                        vo["learned"] = lr["learned"]
                        vo["adaptation"] = lr["adaptation"]
                        vo["updated_at"] = (lr["adaptation"] or {}).get("updated_at")
                        p["voice"] = vo
                except Exception as _le:  # noqa: BLE001
                    print(f"[style] {aid} learn err: {_le}")
                conn.execute("UPDATE agents SET persona_json=? WHERE id=?",
                             (json.dumps(_persona_for_store(p, allow_private=False), ensure_ascii=False), aid))
                try:
                    persona_mod.save_persona(aid, p)       # 本机保留私密维度（body/wardrobe）
                except Exception:
                    pass
                print(f"[style] {aid} → {p['voice'].get('catchphrases')} {p['voice'].get('learned')}")
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"[style] err: {e}")
        time.sleep(interval)


def _start_style_loop():
    threading.Thread(target=_style_loop, daemon=True).start()


def _storage_loop(interval=3600):
    """每小时保底一次**当日用量快照**（同日同根覆盖写，幂等）。

    存储治理（docs/322）：没有用量历史就无法做删除规划；这里只记快照，
    **不做任何淘汰**——淘汰必须经 `teamai storage` 或 `scripts/storage_gc.py` 显式确认。
    """
    while True:
        try:
            from . import storage
            conn = db.connect()
            try:
                storage.ensure_usage(conn)
            finally:
                conn.close()
        except Exception as e:  # noqa: BLE001
            print(f"[storage] err: {e}")
        time.sleep(interval)


def _start_storage_monitor():
    threading.Thread(target=_storage_loop, daemon=True).start()


# ------------------------------------------------------------------ entry
def main(argv=None):
    global _GOSSIP
    parser = argparse.ArgumentParser(prog="teamai-server")
    sub = parser.add_subparsers(dest="cmd")
    p = sub.add_parser("serve")
    p.add_argument("--host", default=config.get("server.host", "0.0.0.0", env="TEAM_HOST"))
    p.add_argument("--port", type=int, default=config.get_int("server.port", 6030, env="TEAM_PORT"))
    p.add_argument("--tls-cert", default=config.get("server.tls_cert", None, env="TEAM_TLS_CERT"))
    p.add_argument("--tls-key", default=config.get("server.tls_key", None, env="TEAM_TLS_KEY"))
    p.add_argument("--no-bootstrap", action="store_true")
    p.add_argument("--no-jobs", action="store_true",
                   help="只提供线程化 HTTP(S) API/UI，不启动后台循环（TLS 旁路用）")
    args = parser.parse_args(argv)

    if args.cmd != "serve":
        parser.print_help()
        return 1

    if args.no_jobs:
        os.environ["TEAMAI_FEED_POLL"] = "0"
        os.environ["TEAMAI_NO_JOBS"] = "1"
    db.init_db()
    if not args.no_bootstrap:
        from . import bootstrap
        info = bootstrap.bootstrap()
        print(f"[bootstrap] node={info['node']} agents="
              f"{', '.join(a['full_name'] for a in info['agents'])}")
        if info["root_token_new"]:
            print("[bootstrap] root enroll token written to bootstrap/enroll.key (shown once)")
        for a in info["agents"]:
            if a["new_key"]:
                print(f"[bootstrap] key issued for {a['full_name']} -> agents/{a['id']}/.key")
    if not args.no_jobs:
        _start_clock()
        _start_moment_loop()
        _start_room_watcher()
        _start_style_loop()
        _start_storage_monitor()
    if not args.no_jobs and config.get_bool("p2p.enabled", False, env="TEAMAI_P2P"):
        try:
            from .net.gossip import Gossip, DISCOVER_PORT
            from . import nodeinfo
            alias = _node_log().node_id
            addr = f"{nodeinfo._lan_ip()}:{args.port}"

            def _merge_fed(ups, props, ranks=None):
                c = db.connect()
                try:
                    federation.merge(c, ups, props, ranks)
                finally:
                    c.close()

            tok = None
            try:
                with open(os.path.join(ROOT, "bootstrap", "enroll.key"), encoding="utf-8") as fh:
                    tok = fh.read().strip() or None
            except OSError:
                tok = None
            seed = {}
            raw_peers = os.environ.get("TEAMAI_PEERS") or config.get("p2p.peers", "") or ""
            for item in str(raw_peers).split(","):
                item = item.strip()
                if not item:
                    continue
                if "=" in item:
                    nid, a = item.split("=", 1)
                else:
                    nid, a = item, item
                seed[nid.strip()] = a.strip()
            _GOSSIP = Gossip(alias, addr, _node_log(), token=tok, federation_merge=_merge_fed,
                             seed=seed)
            _GOSSIP.start()
            print(f"[p2p] gossip UDP:{DISCOVER_PORT} as {alias} @ {addr}")
        except Exception as e:
            print(f"[p2p] gossip 启动失败：{e}")
    app = create_app()
    scheme = "https" if (args.tls_cert and args.tls_key) else "http"
    ssl_context = (args.tls_cert, args.tls_key) if (args.tls_cert and args.tls_key) else None
    print(f"[teamai] serving on {scheme}://{args.host}:{args.port}  (sync every {SYNC_INTERVAL_MIN} min)")
    app.run(host=args.host, port=args.port, debug=False, use_reloader=False, threaded=True, ssl_context=ssl_context)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
