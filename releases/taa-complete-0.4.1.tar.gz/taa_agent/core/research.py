"""主题调研/写作 —— 把导师的写作纪律固化成可执行小工具。

七步（docs/36 真人风格 · 工作法）：
  1 大纲 → 2 查资料 → 3 建事实库 → 4 写作 → 5 核查 → 6 微调(可润可不润就不润) → 7 提交

本模块**确定性、不调 LLM**：只做脚手架与门禁（结构/出处/占位/字数）。
事实库格式沿用既有约定（`## F###` 含 claim/URL/来源分级/原文摘录/用于），与 `scripts/facts_check.py` 对齐。
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / "research"

STEPS = [
    ("1 大纲", "先出写作大纲（目标/读者/结论主张/章节/每章所需资料点）"),
    ("2 查资料", "按大纲逐点查资料；来源分级（官方/一手 > 权威二手）；英文优先"),
    ("3 建事实库", "FACTS.md：每条 `## F###` 含 claim/URL/来源分级/原文摘录/用于"),
    ("4 写作", "按大纲与事实库写作；**事实库没支撑的不写**"),
    ("5 核查", "稿中每个 URL/数字须能在事实库找到；找不到=捏造→删"),
    ("6 微调", "只润必须润的；**可润可不润就不润**"),
    ("7 提交", "事实库 + 稿 + 核查结论 一起交付"),
]

OUTLINE_TMPL = """# 大纲 · {title}

> 第 1 步（docs/37）。先出大纲，再查资料。

## 目标 / 读者
- 目标：
- 读者：

## 结论主张（一句话）
- 

## 章节大纲（每章列出「需要的资料点」）
1. 
2. 

## 事实需求清单（第 2 步据此查资料）
- [ ] 
"""

FACTS_TMPL = """# 事实库 · {title}

> 第 3 步：每条 `## F###` 含 claim / URL / 来源分级(一手|官方|权威二手) / 原文摘录 / 用于。
> 纪律：**事实库中没有的，写作时不得出现**。门禁：`teamai research check {slug}`

## F001
- claim：
- URL：
- 来源分级：一手
- 原文摘录：
- 用于：
"""

DRAFT_TMPL = """# 稿 · {title}

> 第 4 步：只写事实库支撑的内容。第 5 步：稿中每个数字/引语都要能在 FACTS.md 找到出处。

（正文）
"""


def _slug_ok(s: str) -> bool:
    return bool(re.match(r"^[a-zA-Z0-9][a-zA-Z0-9_-]{0,60}$", s or ""))


def new(slug: str, title: str | None = None, root: Path | None = None) -> dict:
    root = root or WORK
    if not _slug_ok(slug):
        raise ValueError("slug 仅限字母数字-_（≤60）")
    d = root / slug
    d.mkdir(parents=True, exist_ok=True)
    t = title or slug
    (d / "OUTLINE.md").write_text(OUTLINE_TMPL.format(title=t), encoding="utf-8")
    (d / "FACTS.md").write_text(FACTS_TMPL.format(title=t, slug=slug), encoding="utf-8")
    (d / "DRAFT.md").write_text(DRAFT_TMPL.format(title=t), encoding="utf-8")
    return {"dir": str(d), "slug": slug}


def parse_facts(text: str) -> list[dict]:
    blocks = [b for b in re.split(r"\n(?=## )", text or "") if b.strip().startswith("## ")]
    out = []
    for b in blocks:
        fid = b[3:].split()[0] if len(b) > 3 else "?"
        urls = re.findall(r"https?://[^\s)>\]]+", b)
        out.append({
            "id": fid,
            "urls": urls,
            "url_ok": bool(urls) or ("无公开 URL" in b),
            "has_excerpt": ("原文摘录" in b) or ("原文" in b),
            "has_used": "用于" in b,
            "has_grade": ("来源分级" in b) or ("来源" in b),
        })
    return out


def _words(text: str) -> int:
    return len(re.findall(r"[\u4e00-\u9fff]|[A-Za-z]+|\d+", text or ""))


def check(slug: str, *, min_words: int = 0, max_words: int = 0, root: Path | None = None) -> dict:
    root = root or WORK
    d = root / slug
    res: dict = {"slug": slug, "checks": [], "ok": True}

    def add(name, ok, detail=""):
        res["checks"].append({"name": name, "ok": bool(ok), "detail": str(detail)[:180]})
        if not ok:
            res["ok"] = False

    if not d.exists():
        add("目录存在", False, f"research/{slug} 不存在（先 `research new {slug}`）")
        return res
    facts = (d / "FACTS.md").read_text(encoding="utf-8") if (d / "FACTS.md").exists() else ""
    draft = (d / "DRAFT.md").read_text(encoding="utf-8") if (d / "DRAFT.md").exists() else ""
    fs = [f for f in parse_facts(facts) if f["id"] != "F000"]
    add("事实条数≥3", len([f for f in fs if f["has_excerpt"]]) >= 3, f"{len(fs)} 条")
    bad = [f["id"] for f in fs if not (f["url_ok"] and f["has_excerpt"] and f["has_used"])]
    add("每条含 URL/原文/用于", not bad, "缺: " + ", ".join(bad))
    domains = set()
    for f in fs:
        for u in f["urls"]:
            m = re.match(r"https?://([^/]+)", u)
            domains.add(m.group(1) if m else u)
    add("独立域名≥2", len(domains) >= 2, f"{len(domains)}: {sorted(domains)[:4]}")
    ph = re.findall(r"待核|待证|待补|待填|TODO|TBD", draft)
    add("稿中无占位符", not ph, ",".join(sorted(set(ph))))
    fu = set()
    for f in fs:
        fu |= set(f["urls"])
    miss = [u for u in set(re.findall(r"https?://[^\s)>\]]+", draft)) if u not in fu]
    add("稿中 URL 都能在事实库找到", not miss, "缺出处: " + ", ".join(miss[:3]))
    words = _words(draft)
    if min_words:
        add(f"字数≥{min_words}", words >= min_words, str(words))
    if max_words:
        add(f"字数≤{max_words}", words <= max_words, str(words))
    res["facts"] = len(fs)
    res["words"] = words
    return res


def status(slug: str, root: Path | None = None) -> dict:
    root = root or WORK
    d = root / slug
    facts = parse_facts((d / "FACTS.md").read_text(encoding="utf-8")) if (d / "FACTS.md").exists() else []
    draft = (d / "DRAFT.md").read_text(encoding="utf-8") if (d / "DRAFT.md").exists() else ""
    return {"slug": slug, "outline": (d / "OUTLINE.md").exists(),
            "facts": len([f for f in facts if f["id"] != "F000"]),
            "draft_words": _words(draft)}


def ask(slug: str, prompt: str, *, model: str = "deepseek-v4-pro", system: str | None = None,
        temperature: float = 0.3, max_tokens: int = 16000, timeout: int = 900,
        tag: str = "", root: Path | None = None, json_mode: bool = False) -> dict:
    """[v2 升级件] 用 DeepSeek（默认 v4 pro）就某一问题做调研，输出存 research/<slug>/ask/。
    脚手架与门禁仍为确定性；此命令负责「查资料 / 深想 / 给判据」。"""
    import json as _json, os as _os, time as _time, urllib.request as _url
    root = root or WORK
    d = root / slug
    if not d.exists():
        raise ValueError(f"research/{slug} 不存在（先 `research new {slug}`）")
    key = (_os.environ.get("DS_KEY") or "").strip()
    if not key:
        kp = ROOT / "bootstrap" / "deepseek.key"
        key = kp.read_text(encoding="utf-8").strip() if kp.exists() else ""
    if not key:
        raise RuntimeError("缺 DeepSeek key：设 DS_KEY，或放 bootstrap/deepseek.key")
    msgs = ([{"role": "system", "content": system}] if system else []) + [{"role": "user", "content": prompt}]
    payload = {"model": model, "messages": msgs, "temperature": temperature,
               "max_tokens": max_tokens, "stream": False}
    if json_mode:
        payload["response_format"] = {"type": "json_object"}
    body = _json.dumps(payload).encode("utf-8")
    req = _url.Request("https://api.deepseek.com/chat/completions", data=body, method="POST",
                       headers={"Content-Type": "application/json", "Authorization": f"Bearer {key}"})
    last = None
    for attempt in range(4):
        try:
            with _url.urlopen(req, timeout=timeout) as r:
                data = _json.loads(r.read().decode("utf-8"))
            break
        except Exception as e:  # noqa: BLE001
            last = e
            code = getattr(e, "code", 0)
            if code not in (429, 500, 502, 503, 504) or attempt == 3:
                raise
            _time.sleep((4, 12, 30)[attempt])
    else:
        raise last  # type: ignore[misc]
    ans = ((data.get("choices") or [{}])[0].get("message") or {}).get("content", "")
    finish = ((data.get("choices") or [{}])[0] or {}).get("finish_reason", "")
    usage = data.get("usage", {})
    outdir = d / "ask"; outdir.mkdir(exist_ok=True)
    name = _time.strftime("%Y%m%d_%H%M%S") + (f"_{tag}" if tag else "") + ".md"
    p = outdir / name
    p.write_text(f"# ask · {model}\n\n- 时间：{_time.strftime('%Y-%m-%d %H:%M:%S')}\n- 用量：{usage}\n"
                 f"- finish：{finish}\n- tag：{tag or '-'}\n\n## 提问\n\n{prompt}\n\n## 回答\n\n{ans}\n", encoding="utf-8")
    return {"file": str(p), "chars": len(ans), "usage": usage, "text": ans, "finish_reason": finish}


# ------------------------------------------------------------------ deep ask（多轮深挖）
DEEP_SYSTEM = (
    "你是严谨的科研调研助手，服务一位博士生。纪律："
    "①英文/官方一手来源优先，二手来源须注明；"
    "②结论尽量附**可核验的来源线索**（标准号/文献/机构/链接），给不出时显式标注「无来源」；"
    "③严格区分「事实」与「判断」；④不确定处显式标注，不得臆造；"
    "⑤中文作答，专业术语首次出现即用人话解释。"
)

# 每轮追问模板（第 1 轮含问题本体）
DEEP_PROMPTS = [
    "{q}\n\n请按：①把问题拆成 3–6 个可独立调研的子问题；②逐一给出初步回答（分节），"
    "每个结论后标注来源线索与置信度（高/中/低），缺口显式写「缺证据」。",
    "针对你上一轮回答的每个子问题，做三件事：①补上可核验的来源线索（标准号/文献标题/机构/链接）；"
    "②给出反例、争议或适用边界；③列出仍缺证据的缺口与验证方法。",
    "综合前两轮，输出一份**结构化深挖报告**：\n(1) 结论与置信度；\n"
    "(2) 支撑证据（含来源线索与分级：官方/一手/权威二手）；\n(3) 争议与反对观点；\n"
    "(4) 尚未解决的问题 + 建议的下一步调研路径；\n"
    "(5) 可供事实库入库的候选条目（每条给 claim / 来源线索 / 分级 / 用于）。",
]


def _deepseek_key() -> str:
    import os as _os
    key = (_os.environ.get("DS_KEY") or "").strip()
    if not key:
        kp = ROOT / "bootstrap" / "deepseek.key"
        key = kp.read_text(encoding="utf-8").strip() if kp.exists() else ""
    if not key:
        raise RuntimeError("缺 DeepSeek key：设 DS_KEY，或放 bootstrap/deepseek.key")
    return key


def _chat(messages: list[dict], *, model: str, temperature: float, max_tokens: int,
          timeout: int) -> tuple[str, dict]:
    import json as _json, urllib.request as _url
    key = _deepseek_key()
    body = _json.dumps({"model": model, "messages": messages, "temperature": temperature,
                        "max_tokens": max_tokens, "stream": False}).encode("utf-8")
    req = _url.Request("https://api.deepseek.com/chat/completions", data=body, method="POST",
                       headers={"Content-Type": "application/json", "Authorization": f"Bearer {key}"})
    with _url.urlopen(req, timeout=timeout) as r:
        data = _json.loads(r.read().decode("utf-8"))
    ans = ((data.get("choices") or [{}])[0].get("message") or {}).get("content", "")
    return ans, data.get("usage", {})


def ask_deep(slug: str, question: str, *, rounds: int = 3, model: str = "deepseek-v4-pro",
             system: str | None = None, temperature: float = 0.3, max_tokens: int = 16000,
             timeout: int = 900, tag: str = "", root: Path | None = None,
             progress=lambda *a: None) -> dict:
    """[深挖件] 多轮迭代调研：拆解 → 寻证/反例 → 综合。

    - 逐轮累积上下文（同一会话多轮），每轮落盘 `ask/<ts>_deep/roundN.md`；
    - 末轮产出 `SYNTHESIS.md`（含候选事实条目，便于并入 FACTS.md）。
    - 轮数可调（默认 3）；确定性门禁仍由 `check` 负责，本命令只负责「查/想/给线索」。
    """
    root = root or WORK
    d = root / slug
    if not d.exists():
        raise ValueError(f"research/{slug} 不存在（先 `research new {slug}`）")
    rounds = max(1, min(int(rounds), len(DEEP_PROMPTS)))
    import time as _time
    sys = system if system is not None else DEEP_SYSTEM
    messages: list[dict] = [{"role": "system", "content": sys}]
    outdir = d / "ask" / (_time.strftime("%Y%m%d_%H%M%S") + (f"_{tag}" if tag else "") + "_deep")
    outdir.mkdir(parents=True, exist_ok=True)
    total_usage: dict = {}
    files = []
    last = ""
    for i in range(rounds):
        prompt = DEEP_PROMPTS[i].format(q=question)
        messages.append({"role": "user", "content": prompt})
        progress(f"  第 {i + 1}/{rounds} 轮 …（{len(prompt)} 字提示）")
        ans, usage = _chat(messages, model=model, temperature=temperature,
                           max_tokens=max_tokens, timeout=timeout)
        messages.append({"role": "assistant", "content": ans})
        for k, v in usage.items():
            if isinstance(v, (int, float)):
                total_usage[k] = total_usage.get(k, 0) + v
        fp = outdir / f"round{i + 1}.md"
        fp.write_text(f"# deep · 第 {i + 1}/{rounds} 轮 · {model}\n\n## 追问\n\n{prompt}\n\n"
                      f"## 回答\n\n{ans}\n", encoding="utf-8")
        files.append(str(fp))
        last = ans
    synth = outdir / "SYNTHESIS.md"
    synth.write_text(f"# deep 深挖综合 · {slug}\n\n- 时间：{_time.strftime('%Y-%m-%d %H:%M:%S')}\n"
                     f"- 模型：{model} · 轮数：{rounds}\n- 累计用量：{total_usage}\n\n"
                     f"## 问题\n\n{question}\n\n## 综合结论（末轮）\n\n{last}\n\n"
                     f"## 各轮原文\n\n" + "\n".join(f"- {f}" for f in files) + "\n", encoding="utf-8")
    return {"dir": str(outdir), "file": str(synth), "rounds": rounds, "chars": len(last),
            "files": files, "usage": total_usage}
