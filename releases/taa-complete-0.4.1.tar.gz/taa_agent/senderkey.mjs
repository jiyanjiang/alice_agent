// 群聊「发送者密钥」(sender key) —— 替代逐对加密
// 问题：逐对加密下，一条消息要按人头各加密一份（N 人群 = N-1 份密文）。
// 方案：每个发送者持有一条**发送者密钥**，用**逐对密钥**一次性分发给各成员（wrap）；
//       之后**每条消息只加密一次**，成员用同一 kid/序号解密。
// 序号 n 单调递增 → **重放/旧消息一律拒绝**。
// 遗留（诚实）：暂不做 chain 轮换（前向安全），属 P1（见 docs/139 遗留清单）。
import { b64u, open as pwOpen, seal as pwSeal } from "./e2e.mjs";

const enc = new TextEncoder();
const dec = new TextDecoder();
const SALT = enc.encode("alice-sk-v1");

export const ALG_SK = "SK-v1";

export function newSenderKey() {
  return { kid: crypto.randomUUID().slice(0, 8), chain: crypto.getRandomValues(new Uint8Array(32)), n: 0 };
}

async function msgKey(chain, n) {
  const hk = await crypto.subtle.importKey("raw", chain, "HKDF", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "HKDF", hash: "SHA-256", salt: SALT, info: enc.encode("sk:" + n) }, hk, 256);
  return crypto.subtle.importKey("raw", bits, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}

/** 加密一条群消息（**只加密一次**）→ 信封（中继只见密文） */
export async function skEncrypt(sk, obj, aad = "") {
  const n = sk.n++;
  const key = await msgKey(sk.chain, n);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv, additionalData: enc.encode(aad) }, key, enc.encode(JSON.stringify(obj)));
  return { v: 2, alg: ALG_SK, kid: sk.kid, n, iv: b64u.enc(iv), ct: b64u.enc(ct) };
}

/** 解密（校验 kid 与序号单调；重放/旧消息抛错，绝不降级） */
export async function skDecrypt(sk, envelope, aad = "") {
  if (envelope?.v !== 2 || envelope.alg !== ALG_SK) throw new Error("不是 SK-v1 信封");
  if (envelope.kid !== sk.kid) throw new Error("sender key 不匹配（kid 不同）");
  if (envelope.n < sk.n) throw new Error("重放或旧消息被拒（序号回退）");
  const key = await msgKey(sk.chain, envelope.n);
  const pt = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: b64u.dec(envelope.iv), additionalData: enc.encode(aad) },
    key, b64u.dec(envelope.ct));
  if (envelope.n >= sk.n) sk.n = envelope.n + 1;
  return JSON.parse(dec.decode(pt));
}

/** 一次性分发：用**逐对密钥**把 sender key 包给某成员（不是每条消息都 wrap） */
export async function wrapSenderKey(pairwiseAesKey, sk) {
  return pwSeal(pairwiseAesKey, { kid: sk.kid, chain: b64u.enc(sk.chain), n: sk.n }, "sk-wrap");
}

/** 成员解开分发（得到可直接解密的 sender key 副本） */
export async function unwrapSenderKey(pairwiseAesKey, wrapped) {
  const w = await pwOpen(pairwiseAesKey, wrapped, "sk-wrap");
  return { kid: w.kid, chain: b64u.dec(w.chain), n: 0 };   // 新成员从 0 开始（历史消息不追）
}
