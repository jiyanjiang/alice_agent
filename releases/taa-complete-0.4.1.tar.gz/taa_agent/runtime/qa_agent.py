#!/usr/bin/env python3
"""qa_agent —— 监督闭环常驻进程：持续盯某目标(target)的产出，逐轮质检+记录+反馈，判收敛。

用法：
    python dist/qa_agent.py --as alice --target carol --topic salam-archive \
        --channel '#reading' --room room-55e1cd08 --interval 120
环境：TEAMAI_URL（默认 6030；本项目 6080）
说明：只对「新产出」开新循环（增量，游标=上轮 last_seen），避免空转刷屏；反馈走工作群「开发日志」。
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import secrets
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT))


def _key(agent: str) -> dict:
    return json.loads((ROOT / "agents" / agent / ".key").read_text(encoding="utf-8"))


def _sign(key: str, method: str, path: str, body: bytes, ts: str, nonce: str) -> str:
    canon = f"{method.upper()}\n{path}\n{hashlib.sha256(body).hexdigest()}\n{ts}\n{nonce}"
    return hmac.new(key.encode(), canon.encode(), hashlib.sha256).hexdigest()


class Client:
    def __init__(self, base: str, agent: str):
        self.base = base.rstrip("/")
        self.agent = agent
        self.k = _key(agent)

    def call(self, method: str, path: str, body: dict | None = None) -> dict:
        data = json.dumps(body, ensure_ascii=False).encode() if body is not None else b""
        ts, nonce = str(int(time.time())), secrets.token_hex(8)
        req = urllib.request.Request(self.base + path, data=data if body is not None else None, method=method)
        req.add_header("Content-Type", "application/json")
        req.add_header("X-TeamAI-Key", self.k["key_id"])
        req.add_header("X-TeamAI-Timestamp", ts)
        req.add_header("X-TeamAI-Nonce", nonce)
        req.add_header("X-TeamAI-Signature", _sign(self.k["key"], method, path, data, ts, nonce))
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            return {"_http": e.code, "_body": e.read().decode()[:200]}
        except urllib.error.URLError as e:
            return {"_err": str(e)}


def cycle(cli: Client, agent: str, target: str, topic: str, channel: str | None,
          room: str | None, mode: str = "post") -> dict | None:
    from core import memory, qa
    import urllib.parse
    q = [f"author={urllib.parse.quote(target)}", "limit=20"]
    if channel:
        q.append("channel=" + urllib.parse.quote(channel))
    posts = cli.call("GET", "/v1/posts?" + "&".join(q)).get("posts", [])
    prev = memory.list_review_cycles(agent, topic, target)
    last_seen = prev[-1]["last_seen"] if prev and prev[-1].get("last_seen") else None
    fresh = [p for p in posts if not last_seen or (p.get("created_at") or "") > last_seen]
    if not fresh:
        return None
    newest = max([p.get("created_at") or "" for p in fresh], default=None)
    res = qa.run_cycle(agent, topic, target, fresh, last_seen=newest, mode=mode)
    print(f"  {time.strftime('%H:%M:%S')} cycle#{res['cycle_no']} items={res['items']} "
          f"defects={res['defects']} passed={res['passed']} "
          f"series={res['convergence']['series']} converged={res['convergence']['converged']}", flush=True)
    if room and res["items"]:
        cli.call("POST", f"/v1/rooms/{room}/report",
                 {"text": res["feedback"], "agent_id": agent})
        print(f"    → 反馈已发 {room}", flush=True)
    return res


def main() -> None:
    ap = argparse.ArgumentParser(description="监督闭环常驻进程")
    ap.add_argument("--as", dest="as_agent", required=True)
    ap.add_argument("--target", required=True, help="被监督者，如 carol")
    ap.add_argument("--topic", required=True, help="监督主题，如 salam-archive")
    ap.add_argument("--url", default=os.environ.get("TEAMAI_URL", "http://127.0.0.1:6030"))
    ap.add_argument("--channel", help="只看某频道的产出，如 '#reading'")
    ap.add_argument("--room", help="反馈发到的工作群 room_id")
    ap.add_argument("--mode", choices=["post", "script"], default="post")
    ap.add_argument("--interval", type=int, default=120)
    ap.add_argument("--once", action="store_true")
    args = ap.parse_args()

    cli = Client(args.url, args.as_agent)
    print(f"[qa] agent={args.as_agent} → target={args.target} topic={args.topic} "
          f"channel={args.channel} mode={args.mode} room={args.room} interval={args.interval}s", flush=True)
    while True:
        try:
            cycle(cli, args.as_agent, args.target, args.topic, args.channel, args.room, args.mode)
        except Exception as e:
            print(f"  [qa] err: {e}", flush=True)
        if args.once:
            break
        time.sleep(max(15, args.interval))


if __name__ == "__main__":
    main()
