#!/usr/bin/env python3
"""supervisor —— 客户端入口：监控并自动更新 loop worker，启动失败自动回滚。

用法：
    python runtime/supervisor.py --as bob --role executor --interval 30
行为：
  - 拉起 loop.py（worker）；worker 首拍成功后写 runtime/.healthy
  - 启动 90s 内未健康 / worker 崩溃 → 回滚 loop.py.bak 并重启 + 告警
  - 每 5 分钟验签查 manifest；loop.py 有变更 → 下载→验签→备份→替换→重启→健康检查
  - 本地 status=busy 时跳过 manifest 检查
"""
from __future__ import annotations

# Windows 控制台常为 GBK：print emoji/非 GBK 字符会 UnicodeEncodeError 直接崩（Darwin 实测 loop.py:192）
try:  # noqa: SIM105
    import sys as _sys
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

import argparse
import atexit
import base64
import hashlib
import json
import os
import secrets
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
START_TIMEOUT = int(os.environ.get("TEAMAI_START_TIMEOUT", "90"))


def _key(agent: str) -> dict:
    return json.loads((ROOT / "agents" / agent / ".key").read_text(encoding="utf-8"))


def _sign(key: str, method: str, path: str, body: bytes, ts: str, nonce: str) -> str:
    canon = f"{method.upper()}\n{path}\n{hashlib.sha256(body).hexdigest()}\n{ts}\n{nonce}"
    return __import__("hmac").new(key.encode(), canon.encode(), hashlib.sha256).hexdigest()


def get_manifest(base: str, agent: str, ctx) -> dict:
    k = _key(agent)
    ts, nonce = str(int(time.time())), secrets.token_hex(8)
    path = "/v1/bootstrap/manifest"
    req = urllib.request.Request(base + path, method="GET")
    req.add_header("X-TeamAI-Key", k["key_id"])
    req.add_header("X-TeamAI-Timestamp", ts)
    req.add_header("X-TeamAI-Nonce", nonce)
    req.add_header("X-TeamAI-Signature", _sign(k["key"], "GET", path, b"", ts, nonce))
    with urllib.request.urlopen(req, timeout=30, context=ctx) as r:
        return json.loads(r.read().decode())


def verify(manifest: dict, pubkey_b64: str) -> bool:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    try:
        pub = Ed25519PublicKey.from_public_bytes(base64.urlsafe_b64decode(pubkey_b64))
        canon = json.dumps({k: v for k, v in manifest.items() if k not in ("signature", "ok")},
                           sort_keys=True, ensure_ascii=False).encode()
        pub.verify(base64.urlsafe_b64decode(manifest["signature"]), canon)
        return True
    except Exception:
        return False


def pinned_pubkey() -> str | None:
    p = ROOT / "runtime" / ".server_pubkey"
    return p.read_text(encoding="utf-8").strip() if p.exists() else None


def local_sha(name: str) -> str | None:
    p = ROOT / "runtime" / f"{name}.py"
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None


def download(base: str, url: str, dest: Path, agent: str, ctx) -> str:
    k = _key(agent)
    ts, nonce = str(int(time.time())), secrets.token_hex(8)
    req = urllib.request.Request(base + url)
    req.add_header("X-TeamAI-Key", k["key_id"])
    req.add_header("X-TeamAI-Timestamp", ts)
    req.add_header("X-TeamAI-Nonce", nonce)
    req.add_header("X-TeamAI-Signature", _sign(k["key"], "GET", url, b"", ts, nonce))
    with urllib.request.urlopen(req, timeout=120, context=ctx) as r:
        data = r.read()
    dest.write_bytes(data)
    return hashlib.sha256(data).hexdigest()


def _env(url: str | None) -> dict:
    e = dict(os.environ)
    if url:
        e["TEAMAI_URL"] = url
    # ★ Windows 控制台默认 GBK：子进程 print emoji/非 GBK 字符会 UnicodeEncodeError 崩溃
    #   （Darwin 实测：loop.py 打印 🎉 即崩）→ 统一强制 UTF-8。
    e.setdefault("PYTHONIOENCODING", "utf-8")
    e.setdefault("PYTHONUTF8", "1")
    return e


def spawn(agent: str, role: str, interval: int, url: str | None = None) -> subprocess.Popen:
    cmd = [sys.executable, "-u", str(HERE / "loop.py"), "--as", agent,
           "--role", role, "--interval", str(interval)]
    if url:
        cmd += ["--url", url]
    return subprocess.Popen(cmd, cwd=ROOT, env=_env(url))


def wait_healthy(agent: str, t0: float) -> bool:
    h = ROOT / "runtime" / f".healthy.{agent}"
    deadline = time.time() + START_TIMEOUT
    while time.time() < deadline:
        if h.exists() and h.stat().st_mtime > t0:
            return True
        time.sleep(2)
    return False


def _single_instance(agent: str) -> bool:
    """同一 agent 只允许一个 supervisor；否则会重复拉起 loop/dispatcher/chatroom。"""
    lock = ROOT / "runtime" / f".supervisor.{agent}.lock"
    lock.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
    except FileExistsError:
        alive = False
        old = 0
        try:
            old = int(lock.read_text(encoding="utf-8").strip() or "0")
            os.kill(old, 0)
            alive = True
        except Exception:  # noqa: BLE001
            alive = False
        if alive:
            print(f"[supervisor] 已有实例在跑（{lock.name} pid={old}），本进程退出")
            return False
        lock.write_text(str(os.getpid()), encoding="utf-8")
    atexit.register(lambda: lock.unlink(missing_ok=True))
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--as", dest="agent", required=True)
    ap.add_argument("--role", choices=["executor", "coordinator"], default="executor")
    ap.add_argument("--interval", type=int, default=None)
    ap.add_argument("--url", default=os.environ.get("TEAMAI_URL", "http://127.0.0.1:6030"))
    ap.add_argument("--manifest-interval", type=int, default=5)
    ap.add_argument("--fingerprint")
    ap.add_argument("--no-autoupdate", action="store_true")
    ap.add_argument("--no-dispatch", action="store_true", help="不启动 dispatcher（不交给 opencode 执行）")
    ap.add_argument("--no-chatroom", action="store_true", help="不托管 chatroom 驱动")
    ap.add_argument("--ca", help="CA 证书路径（https）")
    ap.add_argument("--insecure", action="store_true")
    a = ap.parse_args()
    if not _single_instance(a.agent):
        return
    base = a.url.rstrip("/")
    interval = a.interval or (5 if a.role == "coordinator" else 30)
    ctx = None
    if base.startswith("https"):
        cafile = a.ca or os.environ.get("TEAMAI_CA")
        ctx = ssl.create_default_context(cafile=cafile) if cafile else ssl.create_default_context()
        if a.insecure:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

    loop = ROOT / "runtime" / "loop.py"
    bak = ROOT / "runtime" / "loop.py.bak"
    proc = spawn(a.agent, a.role, interval, base)
    t0 = time.time()
    print(f"[supervisor] worker pid={proc.pid} role={a.role} interval={interval}min START_TIMEOUT={START_TIMEOUT}")
    if not wait_healthy(a.agent, t0):
        print("[supervisor] worker 启动未健康（继续观察）")

    disp = None
    if not a.no_dispatch:
        disp = subprocess.Popen([sys.executable, "-u", str(HERE / "dispatcher.py"),
                                 "--as", a.agent, "--interval", "60", "--url", base],
                                cwd=ROOT, env=_env(base))
        print(f"[supervisor] dispatcher pid={disp.pid}（认领任务交给 opencode 执行）")

    # chatroom 驱动也纳入托管：退出即重启（此前无人管，崩了就永久离线）
    chat = None
    if not a.no_chatroom:
        chat = subprocess.Popen([sys.executable, str(HERE / "chatroom_agent.py"),
                                 "--as", a.agent, "--url", base, "--interval", "2"],
                                cwd=ROOT, env=_env(base))
        print(f"[supervisor] chatroom pid={chat.pid}（退出自动重启）")

    last_check = 0.0
    while True:
        # worker 存活
        if proc.poll() is not None:
            print(f"[supervisor] worker 退出 code={proc.returncode}，重启")
            proc = spawn(a.agent, a.role, interval, base)
            t0 = time.time()
            wait_healthy(a.agent, t0)
        # dispatcher 存活
        if disp is not None and disp.poll() is not None:
            print(f"[supervisor] dispatcher 退出 code={disp.returncode}，重启")
            disp = subprocess.Popen([sys.executable, "-u", str(HERE / "dispatcher.py"),
                                     "--as", a.agent, "--interval", "60", "--url", base],
                                    cwd=ROOT, env=_env(base))
        # chatroom 存活（自愈）
        if chat is not None and chat.poll() is not None:
            print(f"[supervisor] chatroom 退出 code={chat.returncode}，重启")
            chat = subprocess.Popen([sys.executable, str(HERE / "chatroom_agent.py"),
                                     "--as", a.agent, "--url", base, "--interval", "2"],
                                    cwd=ROOT, env=_env(base))

        # busy 时跳过 manifest 检查
        st = ROOT / "agents" / a.agent / ".status"
        busy = st.exists() and st.read_text(encoding="utf-8").strip() == "busy"
        if a.no_autoupdate or busy or (time.time() - last_check < a.manifest_interval * 60):
            time.sleep(20)
            continue
        last_check = time.time()
        try:
            man = get_manifest(base, a.agent, ctx)
            pub = pinned_pubkey()
            if not pub:
                pub = man.get("pubkey")
                if a.fingerprint and man.get("key_fingerprint") != a.fingerprint:
                    print("[supervisor] fingerprint mismatch, 放弃更新")
                    continue
                (ROOT / "runtime").mkdir(exist_ok=True)
                (ROOT / "runtime" / ".server_pubkey").write_text(pub, encoding="utf-8")
            if not verify(man, pub):
                print("[supervisor] manifest 验签失败，忽略")
                continue
            # 全量更新：版本或 bundle sha 变化时，先应用整包，再由 helper 重启整棵进程树。
            # 旧实现只替换 loop.py，dispatcher/chatroom/supervisor 仍是旧代码，重启后照样跑旧活。
            try:
                import sys as _sys
                if str(ROOT) not in _sys.path:
                    _sys.path.insert(0, str(ROOT))
                from core import apply as apply_mod
                from core import distribution
                local_v = distribution.runtime_version()
                remote_v = man.get("runtime_version") or ""
                bundle_sha = ((man.get("bundle") or {}).get("sha256") or "").strip()
                marker = ROOT / "runtime" / ".bundle_sha"
                applied_sha = marker.read_text(encoding="utf-8").strip() if marker.exists() else ""
                need = bool(remote_v and apply_mod.version_gt(remote_v, local_v))
                if bundle_sha and bundle_sha != applied_sha:
                    need = True
                if need:
                    print(f"[supervisor] 全量更新 {local_v} -> {remote_v} bundle={bundle_sha[:12]}")
                    _m, data = apply_mod.fetch_bundle(base, agent=a.agent, ctx=ctx)
                    res = apply_mod.apply_bundle(data, cur_version=local_v, cur_major=1)
                    if not res.get("ok"):
                        print(f"[supervisor] 全量更新失败：{res.get('stage')} {res.get('log')}")
                        continue
                    marker.write_text(bundle_sha, encoding="utf-8")
                    helper = ROOT / "runtime" / "restart_agent.py"
                    if not helper.exists():
                        print("[supervisor] 缺少 restart_agent.py，无法自动收敛")
                        continue
                    print("[supervisor] 更新完成，安排整棵进程树重启")
                    subprocess.Popen([sys.executable, str(helper), "--as", a.agent,
                                      "--url", base, "--role", a.role,
                                      "--interval", str(interval)],
                                     cwd=str(ROOT), env=_env(base),
                                     stdin=subprocess.DEVNULL,
                                     stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL,
                                     start_new_session=True)
                    return
            except Exception as e:  # noqa: BLE001
                print(f"[supervisor] 全量更新检查失败：{e}")
                continue
        except urllib.error.URLError as e:
            print(f"[supervisor] 服务器不可达: {e.reason}")
        except Exception as e:
            print(f"[supervisor] 检查异常: {e}")
        time.sleep(20)


if __name__ == "__main__":
    main()
