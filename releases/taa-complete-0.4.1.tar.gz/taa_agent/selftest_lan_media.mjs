#!/usr/bin/env node
// 手机同网看产物 自检：/lan 页（大字号地址）· /lan/media 列表 · /lan/file 取图 · 防路径穿越
import { spawn } from "node:child_process";
import fs from "node:fs"; import os from "node:os"; import path from "node:path";
const PORT = 9600 + Math.floor(Math.random() * 200), tag = Math.random().toString(36).slice(2, 6);
let PASS = 0, FAIL = 0;
const ck = (n, c, d = "") => { console.log(`  [${c ? "PASS" : "FAIL"}] ${n}${d ? `  (${d})` : ""}`); c ? PASS++ : FAIL++; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const home = fs.mkdtempSync(path.join(os.tmpdir(), "alice-lm-"));
const media = path.join(home, "media"); fs.mkdirSync(media, { recursive: true });
fs.writeFileSync(path.join(media, "shot-1.svg"), '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><circle cx="32" cy="32" r="30" fill="#3b46c4"/></svg>');
const p = spawn(process.execPath, ["client/daemon.mjs", "--center", "http://127.0.0.1:9", "--port", String(PORT), "--home", home, "--media", media, "--id", `lm-${tag}/a`], { stdio: ["ignore", "pipe", "pipe"] });
const tok = await new Promise((res, rej) => { let o = ""; p.stdout.on("data", (b) => { o += b; const m = o.match(/token=([0-9a-f-]{36})/); if (m) res(m[1]); }); p.stderr.on("data", () => {}); setTimeout(() => rej(new Error("超时")), 15000); });
await sleep(600);
let cookie = "";
const jget = async (x) => { const r = await fetch(`http://127.0.0.1:${PORT}${x}`, { headers: cookie ? { cookie } : {} }); const sc = r.headers.get("set-cookie"); if (sc) cookie = sc.split(";")[0]; let j = null; try { j = await r.json(); } catch {} return { status: r.status, j, ct: r.headers.get("content-type") }; };

console.log("[1] /lan 需要 token（手机扫码带 token 才进得来）");
ck("无 token → 401", (await fetch(`http://127.0.0.1:${PORT}/lan`)).status === 401);
const page = await fetch(`http://127.0.0.1:${PORT}/lan?token=${tok}`);
const html = await page.text();
ck("/lan 打开 200（HTML）", page.status === 200 && (page.headers.get("content-type") ?? "").includes("html"));
ck("★ 页内含局域网地址（大字号）", html.includes(`http://`) && html.includes(String(PORT)), html.match(/http:\/\/[0-9.]+:\d+/)?.[0] ?? "");
cookie = (page.headers.get("set-cookie") ?? "").split(";")[0];

console.log("[2] 媒体目录：列表 + 取图 + 防穿越");
const list = await jget("/lan/media");
ck("列出媒体（1 个）", list.j?.count === 1 && list.j?.items?.[0]?.name === "shot-1.svg", JSON.stringify(list.j?.items ?? []).slice(0, 80));
const img = await fetch(`http://127.0.0.1:${PORT}/lan/file/shot-1.svg`, { headers: cookie ? { cookie } : {} });
ck("取图 200 且是 SVG", img.status === 200 && (img.headers.get("content-type") ?? "").includes("svg"));
const trav = await fetch(`http://127.0.0.1:${PORT}/lan/file/..%2Fdevice.json`, { headers: cookie ? { cookie } : {} });
ck("★ 路径穿越被拒（400/404）", [400, 404].includes(trav.status), `HTTP ${trav.status}`);
p.kill("SIGKILL");
console.log(`  ---- PASS=${PASS} FAIL=${FAIL} ----`);
console.log(FAIL === 0 ? "  ✅ 局域网媒体自检通过" : "  ❌ 自检失败");
process.exit(FAIL === 0 ? 0 : 1);
