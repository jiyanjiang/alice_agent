#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
# 人类所有者身份收敛（2026-10-09）：统一到 jiyanjiang；human/Owner 保留记录但不再默认。
# 可用环境变量覆盖：TEAM_HUMAN_ID / TEAM_HUMAN_NAME
export TEAM_HUMAN_ID="${TEAM_HUMAN_ID:-jiyanjiang}"
export TEAM_HUMAN_NAME="${TEAM_HUMAN_NAME:-jiyanjiang}"
exec ../venv/bin/python -m core.server serve "$@"
