#!/usr/bin/env python3
import json, os, pathlib, sys, urllib.request

def main() -> int:
    cfg = pathlib.Path(os.environ.get("TAA_HOME", "~/.taa")).expanduser() / "config.toml"
    print("  python:", sys.version.split()[0])
    print("  config:", "ok" if cfg.exists() else "missing（先跑 ./bin/taa）")
    if not cfg.exists():
        return 1
    text = cfg.read_text()
    base = next((l.split('"')[1] for l in text.splitlines() if l.startswith("base =")), "")
    key = next((l.split('"')[1] for l in text.splitlines() if l.startswith("key =")), "")
    req = urllib.request.Request(base.rstrip("/") + "/agent/me", headers={"authorization": "Bearer " + key})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            j = json.loads(r.read())
        print("  identity:", (j.get("agent") or {}).get("name"), "ok")
        return 0
    except Exception as e:
        print("  identity: failed", e)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
