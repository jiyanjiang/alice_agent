#!/usr/bin/env python3
"""从源自己的**公开目录**拉「新文章清单」（只拿 URL/标题/时间，**不拿正文**）。

Owner 问："你无法穷尽网站里所有文章。你认为呢？" —— 答：**列清单 ≠ 抓文章**。
网站自己就公开了目录，机器问它们就行，比"扫全站"又快又不会封：

  · **RSS / Atom**（增量：最新文章流）——physicsworld `/feed/` 实测一次给 **160 条**（标题+URL+时间）；
  · **sitemap.xml**（全量：全站 URL 索引）——physicsworld 有；一次可拿历史全部文章 URL；
  · 若站点挡机器（physics.aps.org 对服务端 **403 Cloudflare**）→ 改由**你的浏览器**同源拉
    （`static/ingest.user.js` 里的 feed 发现），服务端**零抓取**。

规矩（自我约束，也解释"为什么不会被封"）：
  · **只拉目录**（列表），**永不拉正文**——正文只能由真人在登录态浏览器里读出来；
  · 遵守 `robots.txt`（physicsworld 声明 `Crawl-delay: 600` → 同一站点 **≥10 分钟**才拉一次）；
  · 拉下来的东西只有 URL/标题/时间，进「待看清单」，等你点开。

用法：
    ../venv/bin/python scripts/feed_pull.py                 # 拉所有源（受 crawl-delay 约束）
    ../venv/bin/python scripts/feed_pull.py --source physicsworld --force
"""
from __future__ import annotations

import email.utils
import html as _html
import json
import os
import re
import sqlite3
import sys
import time
import urllib.request
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from core import captures as cap      # noqa: E402

UA = "TeamAI-Reader/1.0 (+human-reads-articles; feed-only)"

TAG = lambda t, x: (re.search(rf"<{t}[^>]*>(.*?)</{t}>", x, re.S | re.I) or [None, ""])[1]


def to_iso(s: str) -> str:
    """把 RFC822("Wed, 14 Oct 2026 12:00:44 +0000") / ISO8601 统一成 `YYYY-MM-DD HH:MM`
    —— 否则清单按**字符串**排序，"30 Sep" 会排在 "14 Oct" 前面（实测踩过）。"""
    s = (s or "").strip()
    if not s:
        return ""
    try:
        return email.utils.parsedate_to_datetime(s).strftime("%Y-%m-%d %H:%M")
    except Exception:  # noqa: BLE001
        pass
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})", s)
    if m:
        return " ".join(m.groups()[:3]) + " " + ":".join(m.groups()[3:])
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", s)
    return m.group(0) if m else s


def _clean(s: str) -> str:
    s = re.sub(r"<!\[CDATA\[(.*?)\]\]>", r"\1", s or "", flags=re.S)
    return _html.unescape(re.sub(r"<[^>]+>", "", s)).strip()


def parse_feed(xml: str) -> list[dict]:
    """RSS `<item>` 与 Atom `<entry>` 都吃。返回 [{url,title,published_at}]。"""
    out: list[dict] = []
    for chunk in re.findall(r"<item>(.*?)</item>", xml, re.S | re.I):
        link = _clean(TAG("link", chunk)) or _clean(TAG("guid", chunk))
        if link:
            out.append({"url": link, "title": _clean(TAG("title", chunk)),
                        "published_at": to_iso(_clean(TAG("pubDate", chunk)))})
    for chunk in re.findall(r"<entry>(.*?)</entry>", xml, re.S | re.I):
        m = re.search(r'<link[^>]*href="([^"]+)"', chunk)
        if m:
            out.append({"url": m.group(1).strip(), "title": _clean(TAG("title", chunk)),
                        "published_at": to_iso(_clean(TAG("updated", chunk)) or _clean(TAG("published", chunk)))})
    seen, uniq = set(), []
    for it in out:
        u = it["url"].split("#")[0]
        if u and u not in seen:
            seen.add(u)
            it["url"] = u
            uniq.append(it)
    return uniq


def crawl_delay(domain: str, default: int = 600) -> int:
    """读 robots.txt 的 Crawl-delay（读不到就用默认 600s）。"""
    try:
        req = urllib.request.Request(f"https://{domain}/robots.txt", headers={"User-Agent": UA})
        txt = urllib.request.urlopen(req, timeout=10).read().decode("utf-8", "ignore")
        m = re.search(r"Crawl-delay:\s*(\d+)", txt, re.I)
        return int(m.group(1)) if m else default
    except Exception:  # noqa: BLE001
        return default


def pull_one(conn, src: dict, force: bool = False) -> dict:
    if src.get("browser_fetch"):          # ★ 该源由**页面侧**获取（Cloudflare 拦服务器），不在这里拉
        return {"source": src["id"], "skipped": "browser_fetch=true（服务端被 Cloudflare 拦，改由页面侧获取）"}
    feed = (src.get("feed_url") or "").strip()
    if not feed:
        # **通用**：source.yaml 没写 feed 就自己找（首页 <link rel=alternate> 或常见路径）
        from core import feed_discover as F
        d = F.discover("https://" + (src.get("domain") or ""))
        feed = d.get("feed") or ""
        if feed and not cap.source_patterns(src.get("url_patterns")):
            # 顺手把**自动反推**的文章形态写进注册表（护栏 fail-closed 仍成立，但不必手写）
            conn.execute("UPDATE sources SET url_patterns=?, discover_url=? WHERE id=?",
                         (json.dumps(d["url_patterns"], ensure_ascii=False), feed, src["id"]))
            conn.commit()
            src = dict(src, url_patterns=json.dumps(d["url_patterns"]), exclude_patterns=src.get("exclude_patterns") or "[]")
    if not feed:
        return {"source": src["id"], "skipped": "没找到目录（feed 地址需人工给一次）"}
    dom = (src.get("domain") or "").split("/")[0]
    delay = crawl_delay(dom)
    if not force:
        row = conn.execute("SELECT MAX(at) FROM feed_polls WHERE source_id=?", (src["id"],)).fetchone()
        last = (row[0] if row else "") or ""
        if last and (time.time() - time.mktime(time.strptime(last, "%Y-%m-%d %H:%M:%S"))) < delay:
            return {"source": src["id"], "skipped": f"未到 crawl-delay（{delay}s）"}
    req = urllib.request.Request(feed, headers={"User-Agent": UA, "Accept": "application/rss+xml, application/xml, text/xml"})
    try:
        xml = urllib.request.urlopen(req, timeout=20).read().decode("utf-8", "ignore")
    except Exception as e:  # noqa: BLE001
        return {"source": src["id"], "error": f"{type(e).__name__}: {str(e)[:80]}"}
    items = parse_feed(xml)
    pats, exc = cap.source_patterns(src.get("url_patterns")), cap.source_patterns(src.get("exclude_patterns"))
    try:
        from core import ingest_guard as g
    except ImportError:
        from core import ingest_guard as g  # type: ignore
    kept = 0
    for it in items:
        kind, _why = g.classify(it["url"], pats, exc)
        if kind == "article":
            cap.upsert_link(conn, it["url"], source_id=src["id"], title=it["title"],
                            published_at=it["published_at"])
            kept += 1
    conn.execute("INSERT OR REPLACE INTO feed_polls(source_id,at,items,kept) VALUES(?,?,?,?)",
                 (src["id"], time.strftime("%Y-%m-%d %H:%M:%S"), len(items), kept))
    conn.commit()
    return {"source": src["id"], "feed": feed, "items": len(items), "articles": kept}


def main() -> int:
    only = sys.argv[sys.argv.index("--source") + 1] if "--source" in sys.argv else ""
    force = "--force" in sys.argv
    conn = sqlite3.connect(os.environ.get("TEAMAI_DB") or str(ROOT / "data.db"))
    conn.row_factory = sqlite3.Row
    cap.ensure_schema(conn)
    for d in sorted((ROOT / "sources").glob("*/")):
        f = d / "source.yaml"
        if not f.exists():
            continue
        spec = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        spec.setdefault("id", d.name)
        if only and spec["id"] != only:
            continue
        print("  ", pull_one(conn, spec, force))
    return 0


if __name__ == "__main__":
    sys.exit(main())
