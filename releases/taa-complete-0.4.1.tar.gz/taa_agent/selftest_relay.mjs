#!/usr/bin/env node
// S4-③ 自检：**直连优先 → 中继兜底**（用"对端只监听本机(--no-lan)"强制直连失败）
// 判据：① 对端 --no-lan 时直连不可达 ② /peer/send 自动走中继且 via="relay"
//      ③ 中心房间通道确有该消息（证明中继生效）④ 对端本地收件箱为空（证明直连确实失败）
import { spawn } from "node:child_process";
import fs from "node:fs"; import os from "node:os"; import path from "node:path";
const C = process.env.BASE || "https://dev.alice.loomsci.com";
const tag = Math.random().toString(36).slice(2, 6);
const A_ID = `rl-${tag}/a`, B_ID = `rl-${tag}/b`, T = `rl-${tag}`;
let PASS = 0, FAIL = 0;
const ck = (n, c, d = "") => { console.log(`  [${c ? "PASS" : "FAIL"}] ${n}${d ? `  (${d})` : ""}`); c ? PASS++ : FAIL++; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const post = async (p, b) => (await fetch(C + p, { method: "POST", headers: { "content-type": "application/json", "user-agent": "alice-rl/0.1" }, body: JSON.stringify(b) })).json();
const get = async (p) => (await fetch(C + p, { headers: { "user-agent": "alice-rl/0.1" } })).json();
function start(port, id, extra = []) {
  return new Promise((res, rej) => {
    const home = fs.mkdtempSync(path.join(os.tmpdir(), "alice-rl-"));
    const p = spawn(process.execPath, ["client/daemon.mjs", "--center", C, "--port", String(port), "--home", home, "--id", id, ...extra], { stdio: ["ignore", "pipe", "pipe"] });
    let out = ""; p.stdout.on("data", (b) => { out += b; const m = out.match(/token=([0-9a-f-]{36})/); if (m) res({ p, token: m[1], port, out: () => out }); });
    p.stderr.on("data", (b) => { out += b; }); setTimeout(() => rej(new Error("超时 " + out.slice(-120))), 15000);
  });
}
const jpost = async (port, tok, p, b) => {
  const url = tok && !tok.startsWith("alice_session=") ? `http://127.0.0.1:${port}${p}?token=${tok}` : `http://127.0.0.1:${port}${p}`;
  const h = { "content-type": "application/json" }; if (tok && tok.startsWith("alice_session=")) h.cookie = tok;
  const r = await fetch(url, { method: "POST", headers: h, body: JSON.stringify(b ?? {}) });
  let j = null; try { j = await r.json(); } catch {} return { status: r.status, j, cookie: (r.headers.get("set-cookie") ?? "").split(";")[0] };
};
const jget = async (port, p, cookie) => { const r = await fetch(`http://127.0.0.1:${port}${p}`, { headers: cookie ? { cookie } : {} }); let j=null; try{j=await r.json();}catch{} return { status: r.status, j }; };

console.log("[0] 造数据：同队 A/B + 两队真人 + 批准好友");
await post("/team/create", { id: `rl1-${tag}`, name: "RL1", owner_human: `rl1-${tag}/human` });
await post("/team/create", { id: `rl2-${tag}`, name: "RL2", owner_human: `rl2-${tag}/human` });
await post("/member/add", { id: `rl1-${tag}/human`, team_id: `rl1-${tag}`, kind: "human" });
await post("/member/add", { id: `rl2-${tag}/human`, team_id: `rl2-${tag}`, kind: "human" });
await post("/member/add", { id: A_ID, team_id: `rl1-${tag}`, kind: "agent", endpoint: "" });
await post("/member/add", { id: B_ID, team_id: `rl2-${tag}`, kind: "agent", endpoint: "" });
const rq = await post("/friend/request", { from: A_ID, to: B_ID });
await post("/friend/decide", { id: rq.id, by: `rl2-${tag}/human`, approve: true });
ck("好友已批准", true);

console.log("[1] A 局域网监听开启；B **--no-lan**（只监听 127 → 直连不可达）");
const PA = 9100 + Math.floor(Math.random() * 300), PB = PA + 1;
const da = await start(PA, A_ID), db = await start(PB, B_ID, ["--no-lan"]);
await sleep(700);
const ha = await jpost(PA, da.token, "/api/hello", {}); const ca = ha.cookie;
const hb = await jpost(PB, db.token, "/api/hello", {}); const cb = hb.cookie;
ck("两端均握手成功", ha.j?.ok === true && hb.j?.ok === true);
const epB = (await jget(PB, "/peer/info", cb)).j?.local ?? "";
ck("B 的 endpoint 是局域网地址（但未监听局域网）", epB.includes("192.") || epB.includes("10."), epB);
let directFail = false;
try { await fetch(`http://${epB}/peer/info`, { headers: { "user-agent": "alice-rl/0.1" } }); } catch { directFail = true; }
ck("直连确实不可达（预期：B 只监听 127）", directFail);

console.log("[2] ★ A 发消息 → 直连失败 → **自动中继兜底**");
const send = await jpost(PA, ca, "/peer/send", { peer_id: B_ID, text: "经由中继的消息" });
console.log("  [diag] /peer/send 完整返回:", JSON.stringify(send.j));
ck("发送成功且 via=relay", send.j?.ok === true && send.j?.via === "relay", `via=${send.j?.via}`);
const room = send.j?.room;
console.log("  [diag] room =", room);
let pk1 = { j: { log: [] } };
if (room) {
  const u = `${C}/rooms/${encodeURIComponent(room)}/peek`;
  console.log("  [diag] URL =", u);
  const r1 = await fetch(u, { headers: { "user-agent": "alice-rl/0.1" } });
  console.log("  [diag] HTTP =", r1.status, "| content-type =", r1.headers.get("content-type"));
  pk1 = { j: await r1.json().catch(() => null) };
}
console.log("  [diag] peek#1 count =", pk1.j?.count, "| log =", JSON.stringify(pk1.j?.log ?? []).slice(0, 160));

ck("★ 中心房间通道确有该消息（中继生效）", (pk1.j?.log ?? []).some((m) => m.text === "经由中继的消息"), `count=${pk1.j?.count}`);
const inbox = await jget(PB, "/local/stats", cb);
ck("对端本地收件箱为空（证明直连确实失败）", !(inbox.j?.rooms ?? []).some((r) => (r.room || "").startsWith("inbox:")), JSON.stringify(inbox.j?.rooms ?? []).slice(0, 60));
da.p.kill("SIGKILL"); db.p.kill("SIGKILL");
console.log(`  ---- PASS=${PASS} FAIL=${FAIL} ----`);
console.log(FAIL === 0 ? "  ✅ S4-③ 中继兜底自检通过" : "  ❌ 自检失败");
process.exit(FAIL === 0 ? 0 : 1);
