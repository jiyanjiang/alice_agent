// alice 客户端 E2E 加密（X25519 + HKDF-SHA256 + AES-256-GCM）
// 铁律：**私钥永不离开设备**（本模块只导出公钥；私钥由调用方在本地保管，绝不随消息/握手外发）。
// 中继（中心）不参与任何密码学：它只转发不透明信封 `enc`（见 docs/139 与 scripts/selftest_e2e.mjs）。
const enc = new TextEncoder();
const dec = new TextDecoder();

export const ALG = "X25519+HKDF-SHA256+AES-256-GCM";
export const b64u = {
  enc: (buf) => Buffer.from(buf).toString("base64url"),
  dec: (s) => new Uint8Array(Buffer.from(s, "base64url")),
};

/** 生成设备密钥对（X25519）。返回 {priv(不导出), pub(raw bytes), pubB64} */
export async function genKeyPair() {
  const kp = await crypto.subtle.generateKey({ name: "X25519" }, false, ["deriveBits"]); // ★ extractable=false
  const pub = new Uint8Array(await crypto.subtle.exportKey("raw", kp.publicKey));
  return { priv: kp.privateKey, pub, pubB64: b64u.enc(pub) };
}

/** ECDH(X25519) → HKDF-SHA256 → AES-256-GCM 会话密钥（双方各自算出的 must equal） */
export async function sharedKey(myPriv, peerPubB64, ctx = "alice-e2e-v1") {
  const peerPub = await crypto.subtle.importKey("raw", b64u.dec(peerPubB64), { name: "X25519" }, false, []);
  const ikm = await crypto.subtle.deriveBits({ name: "X25519", public: peerPub }, myPriv, 256);
  const hk = await crypto.subtle.importKey("raw", ikm, "HKDF", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "HKDF", hash: "SHA-256", salt: enc.encode(ctx), info: enc.encode("alice-room-msg") }, hk, 256);
  return crypto.subtle.importKey("raw", bits, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}

/** 加密（明文只在本地出现；AAD 绑定房间，防跨房间重放/搬运） */
export async function seal(aesKey, obj, aad = "") {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv, additionalData: enc.encode(aad) }, aesKey, enc.encode(JSON.stringify(obj)));
  return { v: 1, alg: ALG, iv: b64u.enc(iv), ct: b64u.enc(ct) };
}

/** 解密（失败即抛，绝不"降级为明文"） */
export async function open(aesKey, envelope, aad = "") {
  const pt = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: b64u.dec(envelope.iv), additionalData: enc.encode(aad) },
    aesKey, b64u.dec(envelope.ct));
  return JSON.parse(dec.decode(pt));
}

/** 构造可直接投递到中继的信封：**明文字段仅元数据（from/kind/epk），内容只在 enc** */
export async function envelope(aesKey, { from, kind, to }, payload, room) {
  return { from, kind, to, enc: await seal(aesKey, payload, room) };
}
