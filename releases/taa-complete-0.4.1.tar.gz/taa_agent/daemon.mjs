#!/usr/bin/env node
// alice 本地 daemon —— "启动 QQ/微信"那一步（Owner 第 3 点）
// 职责：① 只监听 127.0.0.1；② 浏览器**一次性 token** 握手（token 用完即换，防本机其它程序乱连）；
//      ③ 设备密钥对**只存本机**（0600，私钥永不外发，仅公钥交中心）；④ 与中心握手 + 取在线目录；
//      ⑤ 为后续 E2E 群聊、局域网扫码（本机 IP:端口）、中继回家提供本地入口。
//
// 用法：node client/daemon.mjs [--center URL] [--port N] [--home DIR] [--id ID]
import { createServer } from "node:http";
import { randomUUID } from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { loadOrCreateDevice } from "./device.mjs";

// ★ C5（docs/135 §7.3）：心跳 60s，走服务端**应用级自动应答**（不计时长费）；空闲 15 分钟断连
const HEARTBEAT_S = 60;
const IDLE_CLOSE_S = 15 * 60;
let lastActivity = Date.now();
// ★ T1（docs/143）：个人节点自己承载群聊 —— 局域网内的消息**只在本节点**，不过中心
const localBus = new Map();        // room -> [{from,kind,text,enc,ts}]（只在内存，中心不可见）
const LOCAL_MAX = 200;
let directHits = 0;
// ★ C6（docs/135 §7.3）：中心不可用/触顶时的降级——**退避重试 + 本地缓存 + 节点仍可用**
let lastPeers = [];              // 最近一次成功的目录（缓存）
let centerFailures = 0;          // 中心调用失败次数（观测）
let degraded = false;            // 当前是否处于降级态
const BACKOFF = [0, 150, 450, 900];   // 指数退避（首次立即，之后 150/450/900ms）      // S4-②：点对点直连命中次数（中心不参与数据面）
let link = null;                                  // 与中心的 WS 长连接（心跳/信令/群聊通道）

const arg = (k, d) => { const i = process.argv.indexOf(`--${k}`); return i > -1 ? process.argv[i + 1] : d; };
const CENTER = (arg("center", "https://dev.alice.loomsci.com")).replace(/\/$/, "");
const PORT = Number(arg("port", 8799));
const HOME = arg("home", path.join(os.homedir(), ".alice"));
const ID = arg("id", `${os.hostname().toLowerCase().replace(/[^a-z0-9-]/g, "")}/daemon`);
// ★ 局域网监听：手机扫码必须走局域网 IP（仅 127 做不到）。默认开启，可用 --no-lan 关闭；访问仍需一次性 token。
const LAN = process.argv.includes("--no-lan") ? false : true;
const BIND = LAN ? "0.0.0.0" : "127.0.0.1";
// ★ 手机同网看产物：本地媒体目录（默认 ~/.alice/media），只读、禁止越权路径
const MEDIA = arg("media", path.join(HOME, "media"));
const MIME = { ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp",
               ".svg": "image/svg+xml", ".gif": "image/gif", ".mp4": "video/mp4", ".md": "text/markdown; charset=utf-8" };

let token = randomUUID();          // 一次性（首次成功使用后轮换）
let session = null;                // 轮换后发给浏览器的会话 cookie
const dev = await loadOrCreateDevice(HOME, ID);

const authed = (req, url) => {
  const q = url.searchParams.get("token");
  const c = (req.headers.cookie ?? "").match(/alice_session=([^;]+)/)?.[1];
  if (q && q === token) {                        // ★ 一次性：用完立刻轮换 + 发 cookie
    token = randomUUID(); session = randomUUID();
    console.log(`[daemon] token 已使用并轮换；新入口：http://127.0.0.1:${PORT}/?token=${token}`);
    return { ok: true, setCookie: `alice_session=${session}; HttpOnly; SameSite=Strict; Path=/` };
  }
  if (c && c === session) return { ok: true };
  return { ok: false };
};

/** 带退避的中心调用：全部失败 → 返回 null 并置降级态（**不抛错、不阻塞本地**） */
const centerRetry = async (p, init) => {
  for (const wait of BACKOFF) {
    if (wait) await new Promise((r) => setTimeout(r, wait));
    try {
      const r = await center(p, init, true);      // 内部不吞错
      if (r && r.status < 500) { degraded = false; return r; }
    } catch { /* 继续退避 */ }
  }
  centerFailures++; degraded = true;
  return null;
};

const center = async (p, init, throwOnError = false) => {
  const r = await fetch(CENTER + p, { ...init, headers: { "content-type": "application/json", "user-agent": "alice-daemon/0.1", ...(init?.headers ?? {}) } });
  if (throwOnError && r.status >= 500) throw new Error("center " + r.status);
  return { status: r.status, j: await r.json().catch(() => null) };
};
const hello = () => center("/hello", { method: "POST", body: JSON.stringify({
  id: dev.id, team: dev.id.split("/")[0], kind: "device",
  endpoint: `${localIP()}:${PORT}`, pubkey: dev.pubB64 }) });

const localIP = () => {
  const n = os.networkInterfaces();
  for (const k of Object.keys(n)) for (const a of n[k] ?? []) if (a.family === "IPv4" && !a.internal) return a.address;
  return "127.0.0.1";
};

function connectCenter(room = "public") {
  try {
    const ws = new WebSocket(CENTER.replace(/^http/, "ws") + `/rooms/${room}/ws`);
    link = ws;
    ws.addEventListener("open", () => { console.log(`[daemon] 已连中心房间 ${room}（心跳 ${HEARTBEAT_S}s，走自动应答）`); });
    ws.addEventListener("message", (e) => {
      if (e.data === "pong") return;                       // 自动应答，不记日志
      try { const j = JSON.parse(e.data); if (j.type === "message") console.log(`[daemon] ${j.from}: ${j.enc ? "[密文]" : j.text}`); } catch { /* 忽略 */ }
    });
    ws.addEventListener("close", () => { link = null; setTimeout(() => connectCenter(room), 5000); });
  } catch (e) { console.log(`[daemon] 连中心失败：${e.message}`); }
}
setInterval(() => {                                       // 心跳（空闲则断连，避免无谓额度）
  if (Date.now() - lastActivity > IDLE_CLOSE_S * 1000) {
    if (link) { console.log("[daemon] 空闲超时 → 断开心跳（省钱；有活动再连）"); link.close(); link = null; }
    return;
  }
  if (!link) return connectCenter();
  try { link.send("ping"); } catch { /* 断线由 close 处理 */ }
}, HEARTBEAT_S * 1000);
connectCenter();

const page = () => `<!doctype html><meta charset="utf-8"><title>alice daemon</title>
<style>body{background:#0f1218;color:#e8ecf3;font:15px/1.6 -apple-system,"PingFang SC",sans-serif;padding:24px}
code{background:#11151d;padding:1px 5px;border-radius:5px} .dim{color:#8b95a7;font-size:13px}
li{margin:4px 0} .ok{color:#5ad1a5}</style>
<h2>alice 本地节点 <span class="dim">(127.0.0.1:${PORT})</span></h2>
<ul>
  <li>我的 id：<code>${dev.id}</code></li>
  <li>我的公钥（已交中心）：<code>${dev.pubB64.slice(0, 24)}…</code></li>
  <li>私钥：<b class="ok">仅存本机</b> <code>${path.join(HOME, "device.json")}</code>（0600）</li>
  <li>中心：<code>${CENTER}</code></li>
  <li>局域网入口（手机同网可扫）：<code>http://${localIP()}:${PORT}/</code></li>
</ul>
<p class="dim">接口：<code>/api/me</code> · <code>/api/hello</code>（向中心握手）· <code>/api/peers</code>（在线目录）</p>
<p class="dim">注意：本页需一次性 token 进入；token 用过即轮换（见终端输出）。</p>`;

const srv = createServer(async (req, res) => {
  const url = new URL(req.url, `http://127.0.0.1:${PORT}`);
  lastActivity = Date.now();                              // 本地有活动 → 保持心跳
  // ---- S4-② 直连身份：**公开最小信息**（id/公钥本就在中心目录中），不暴露任何本地内容 ----
  // ---- 手机同网：局域网页（大字号地址 + 配对码）与媒体画廊 ----
  if (url.pathname === "/lan/media" || url.pathname.startsWith("/lan/file/")) {
    try { fs.mkdirSync(MEDIA, { recursive: true }); } catch {}
    if (url.pathname === "/lan/media") {
      const items = fs.readdirSync(MEDIA).filter((f) => !f.startsWith(".")).map((f) => {
        const st = fs.statSync(path.join(MEDIA, f));
        return { name: f, bytes: st.size, mtime: st.mtime.toISOString(), url: `/lan/file/${encodeURIComponent(f)}` };
      }).sort((a, b) => (a.mtime < b.mtime ? 1 : -1));
      return res.writeHead(200, { "content-type": "application/json; charset=utf-8" })
        .end(JSON.stringify({ ok: true, dir: MEDIA, count: items.length, items }));
    }
    const name = decodeURIComponent(url.pathname.slice("/lan/file/".length));
    const full = path.resolve(MEDIA, name);
    if (!full.startsWith(path.resolve(MEDIA) + path.sep)) {      // ★ 防路径穿越
      return res.writeHead(400, { "content-type": "text/plain; charset=utf-8" }).end("bad path");
    }
    if (!fs.existsSync(full)) return res.writeHead(404, { "content-type": "text/plain" }).end("not found");
    const ext = path.extname(full).toLowerCase();
    return res.writeHead(200, { "content-type": MIME[ext] ?? "application/octet-stream",
      "cache-control": "public, max-age=60" }).end(fs.readFileSync(full));
  }

  if (url.pathname === "/peer/info") {
    return res.writeHead(200, { "content-type": "application/json; charset=utf-8" })
      .end(JSON.stringify({ ok: true, direct: true, id: dev.id, pubkey: dev.pubB64,
                            local: `${localIP()}:${PORT}` }));
  }
  if (url.pathname === "/lan") {                                  // 手机打开这一页（需 token）
    const a0 = authed(req, url);
    if (!a0.ok) { res.writeHead(401, { "content-type": "text/plain; charset=utf-8" }); return res.end("401 need token"); }
    const H0 = { "content-type": "text/html; charset=utf-8" };
    if (a0.setCookie) H0["set-cookie"] = a0.setCookie;
    const lan = `http://${localIP()}:${PORT}`;
    return res.writeHead(200, H0).end(`<!doctype html><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>alice · LAN</title>
<style>body{background:#f6f7fc;color:#161a33;font:16px/1.6 -apple-system,"PingFang SC",Arial;margin:0;padding:20px}
h1{font-size:18px;margin:0 0 6px}.big{font-size:22px;font-weight:800;color:#3b46c4;word-break:break-all}
.card{background:#fff;border:1px solid #e4e7f4;border-radius:12px;padding:14px;margin:12px 0}
.g{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.it{background:#fff;border:1px solid #e4e7f4;border-radius:10px;padding:8px}
.it img{width:100%;border-radius:8px;display:block}.n{font-size:11px;color:#6b7280;word-break:break-all}</style>
<h1>alice 本地节点 · 手机同网</h1>
<div class="card"><div class="dim" style="color:#6b7280;font-size:13px">在手机浏览器输入（同一 Wi-Fi）：</div>
<div class="big">${lan}/lan?token=${token}</div>
<div class="n" style="margin-top:8px">私钥只在本机；媒体文件也只在你的电脑上（中心不承载字节）</div></div>
<div class="card"><div style="font-weight:700;margin-bottom:8px">最近的产物</div><div class="g" id="g"></div></div>
<script>fetch("/lan/media?token=" + new URLSearchParams(location.search).get("token")).then(r=>r.json()).then(j=>{
  const g=document.getElementById("g"); if(!j.items.length){g.innerHTML="<div class='n'>目录为空：" + j.dir + "</div>";return;}
  g.innerHTML=j.items.map(i=>"<div class='it'><img src='"+i.url+"?token="+new URLSearchParams(location.search).get("token")+"'><div class='n'>"+i.name+"</div></div>").join("");
});</script>`);
  }

  const a = authed(req, url);
  if (!a.ok) { res.writeHead(401, { "content-type": "text/plain; charset=utf-8" }); return res.end("401 Unauthorized: 需要一次性 token（见 daemon 终端输出）\n"); }
  const H = { "content-type": "application/json; charset=utf-8" };
  if (a.setCookie) H["set-cookie"] = a.setCookie;

  // ---- T1 本地群聊（LAN 内，不经过中心）----
  if (url.pathname === "/local/say" && req.method === "POST") {
    let b = ""; for await (const c of req) b += c;
    let m; try { m = JSON.parse(b); } catch { res.writeHead(400, H); return res.end(JSON.stringify({ ok: false, error: "invalid_json" })); }
    if (!m.room || !m.from) { res.writeHead(400, H); return res.end(JSON.stringify({ ok: false, error: "bad_request" })); }
    const arr = localBus.get(m.room) ?? [];
    arr.push({ from: m.from, kind: m.kind ?? "agent", text: m.text, enc: m.enc, ts: new Date().toISOString() });
    while (arr.length > LOCAL_MAX) arr.shift();
    localBus.set(m.room, arr);
    console.log(`[local] ${m.room} ← ${m.from}: ${m.enc ? "[密文]" : (m.text ?? "")}`);   // 只在本地日志
    return res.writeHead(200, H).end(JSON.stringify({ ok: true, local_only: true, room: m.room, count: arr.length,
      note: "本消息只存在个人节点（LAN 直连路径），未经中心" }));
  }
  if (url.pathname === "/local/messages") {
    const room = url.searchParams.get("room") ?? "";
    const since = Number(url.searchParams.get("since") ?? 0) || 0;
    const arr = localBus.get(room) ?? [];
    return res.writeHead(200, H).end(JSON.stringify({ ok: true, room, total: arr.length, messages: arr.slice(since) }));
  }
  // ---- S4-② 直连：先向中心取信令（仅已批准好友），再**直接**连对端（数据不过中心）----
  if (url.pathname === "/peer/connect" && req.method === "POST") {
    let b = ""; for await (const c of req) b += c;
    let m; try { m = JSON.parse(b); } catch { res.writeHead(400, H); return res.end(JSON.stringify({ ok: false, error: "invalid_json" })); }
    const peerId = String(m.peer_id ?? "").trim();
    if (!peerId) { res.writeHead(400, H); return res.end(JSON.stringify({ ok: false, error: "bad_request" })); }
    const sig = await center(`/signal?id=${encodeURIComponent(dev.id)}&to=${encodeURIComponent(peerId)}`);
    const ep = sig.j?.endpoint;
    if (!sig.j?.ok || !ep) {
      return res.writeHead(403, H).end(JSON.stringify({ ok: false, stage: "signal", status: sig.status,
        error: sig.j?.error ?? "no_endpoint", note: "信令只对已批准好友下发（S4-① 门禁）" }));
    }
    const t0 = Date.now();
    try {
      const r = await fetch(`http://${ep}/peer/info`, { headers: { "user-agent": "alice-daemon/0.1" } });
      const j = await r.json();
      directHits++;
      console.log(`[direct] ${dev.id} → ${peerId} @ ${ep} (${Date.now() - t0}ms) 直连成功，未过中心数据面`);
      return res.writeHead(200, H).end(JSON.stringify({ ok: true, via: "direct", endpoint: ep,
        ms: Date.now() - t0, peer: j, note: "对方信息由对方节点直接返回；中心只在信令阶段参与" }));
    } catch (e) {
      return res.writeHead(502, H).end(JSON.stringify({ ok: false, stage: "direct", endpoint: ep, err: String(e).slice(0, 100) }));
    }
  }

  // ---- S4-③ 直连：本地收件箱（对端直连投递到这里）----
  if (url.pathname === "/peer/inbox" && req.method === "POST") {
    let b = ""; for await (const c of req) b += c;
    let m; try { m = JSON.parse(b); } catch { res.writeHead(400, H); return res.end(JSON.stringify({ ok: false, error: "invalid_json" })); }
    const arr = localBus.get("inbox:" + (m.from || "?")) ?? [];
    arr.push({ from: m.from, text: m.text, enc: m.enc, ts: new Date().toISOString(), via: "direct" });
    localBus.set("inbox:" + (m.from || "?"), arr.slice(-LOCAL_MAX));
    console.log(`[inbox] ${m.from}: ${m.enc ? "[ciphertext]" : (m.text ?? "")}`);
    return res.writeHead(200, H).end(JSON.stringify({ ok: true, via: "direct", count: arr.length }));
  }

  // ---- S4-③ 发送：**直连优先，失败则中继兜底**（对称 NAT/CGNAT 场景）----
  if (url.pathname === "/peer/send" && req.method === "POST") {
    let b = ""; for await (const c of req) b += c;
    let m; try { m = JSON.parse(b); } catch { res.writeHead(400, H); return res.end(JSON.stringify({ ok: false, error: "invalid_json" })); }
    const peerId = String(m.peer_id ?? "").trim(), text = String(m.text ?? "");
    if (!peerId || !text) { res.writeHead(400, H); return res.end(JSON.stringify({ ok: false, error: "bad_request" })); }
    const sig = await center(`/signal?id=${encodeURIComponent(dev.id)}&to=${encodeURIComponent(peerId)}`);
    const ep = sig.j?.endpoint;
    if (ep) {                                                    // ① 直连优先
      try {
        const r = await fetch(`http://${ep}/peer/inbox`, { method: "POST", headers: { "content-type": "application/json", "user-agent": "alice-daemon/0.1" },
          body: JSON.stringify({ from: dev.id, text }) });
        if (r.ok) { directHits++; return res.writeHead(200, H).end(JSON.stringify({ ok: true, via: "direct", endpoint: ep })); }
      } catch { /* 落到中继 */ }
    }
    // ② 中继兜底：由中心房间通道转发（内容为密文时，中心亦不可读）
    const dm = await center("/conversations/dm", { method: "POST", body: JSON.stringify({ me: dev.id, peer: peerId }) });
    if (dm.j?.ok !== true) return res.writeHead(409, H).end(JSON.stringify({ ok: false, stage: "relay", error: dm.j?.error ?? "no_room" }));
    const relay = await center(`/rooms/${dm.j.room_id}/say`, { method: "POST",
      body: JSON.stringify({ from: dev.id, kind: m.kind === "human" ? "human" : "human", text,
                             enc: m.enc }) });                    // 用 human 语义保证窗口规则不挡中继
    return res.writeHead(200, H).end(JSON.stringify({ ok: relay.status === 200, via: "relay",
      endpoint: ep ?? null, room: dm.j.room_id, status: relay.status, note: "direct failed → relayed via center room" }));
  }

  if (url.pathname === "/local/stats") {
    const rooms = [...localBus.entries()].map(([r, a]) => ({ room: r, count: a.length }));
    return res.writeHead(200, H).end(JSON.stringify({ ok: true, rooms, direct_hits: directHits, center: CENTER, note: "这些消息从未经过中心" }));
  }

  if (url.pathname === "/api/config") return res.writeHead(200, H).end(JSON.stringify({ ok: true, heartbeat_s: HEARTBEAT_S, idle_close_s: IDLE_CLOSE_S, auto_response: "ping/pong", linked: !!link, degraded, center_failures: centerFailures, cached_peers: lastPeers.length }));
  if (url.pathname === "/api/me") return res.writeHead(200, H).end(JSON.stringify({ ok: true, id: dev.id, pubkey: dev.pubB64, center: CENTER, home: HOME, local: `${localIP()}:${PORT}` }));
  if (url.pathname === "/api/hello") { const r = await hello(); return res.writeHead(200, H).end(JSON.stringify({ ok: r.j?.ok === true, ...r.j })); }
  if (url.pathname === "/api/peers") {
    const r = await centerRetry(`/peers?id=${encodeURIComponent(dev.id)}`);
    if (!r) return res.writeHead(200, H).end(JSON.stringify({ ok: true, degraded: true, peers: lastPeers,
      note: "center unreachable; serving local cache (C6)" }));      // ★ 降级：仍有数据，不报错
    if (r.j?.ok) lastPeers = r.j.peers ?? lastPeers;                   // 缓存最近一次成功结果
    return res.writeHead(200, H).end(JSON.stringify({ ok: r.j?.ok === true, degraded, ...r.j }));
  }
  if (url.pathname === "/api/goodbye") { const r = await center("/goodbye", { method: "POST", body: JSON.stringify({ id: dev.id }) }); return res.writeHead(200, H).end(JSON.stringify({ ok: true, ...r.j })); }
  res.writeHead(200, { ...H, "content-type": "text/html; charset=utf-8" }).end(page());
});

try { await hello(); } catch (e) {                    // ★ C6：中心不可达也要能启动（降级态）
  degraded = true;
  console.log(`[daemon] 中心不可达（${String(e).slice(0, 60)}）→ 以降级态启动：本地/局域网仍可用`);
}
srv.listen(PORT, BIND, () => {
  console.log(`[daemon] id=${dev.id} 本地入口：http://127.0.0.1:${PORT}/?token=${token}`);
  if (LAN) console.log(`[daemon] 局域网（手机同网可扫）：http://${localIP()}:${PORT}/?token=${token}`);
  console.log(`[daemon] 绑定=${BIND}（局域网监听${LAN ? "开启" : "已关闭 --no-lan"}；访问仍需一次性 token）`);
  console.log(`[daemon] 私钥本地：${path.join(HOME, "device.json")}（0600，永不出设备）`);
});
