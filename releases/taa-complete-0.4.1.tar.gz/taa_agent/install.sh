#!/usr/bin/env bash
# Team AI Agent installer (center): code -> ~/.taa/app, config -> ~/.taa, command -> ~/.local/bin
set -euo pipefail
BASE="${1:-https://alice.loomsci.com}"
TAA_HOME="${TAA_HOME:-$HOME/.taa}"
DEST="${TAA_HOME}/app"
TMP="$(mktemp -d)"
trap 'rm -rf "${TMP}"' EXIT

if [ -z "${TAA_DOWNLOAD_TOKEN:-}" ]; then
  echo "  x 需要下载 token；登录中心 → 使用指引，复制带 TAA_DOWNLOAD_TOKEN 的安装命令" >&2
  exit 1
fi

echo "[0/5] python"
PY="${TAA_PYTHON:-}"
if [ -z "${PY}" ]; then
  PY="$(command -v python3.12 || command -v python3)"
fi
if [ -z "${PY}" ] || ! "${PY}" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)'; then
  echo "  x 需要 Python 3.12（或 3.11+）；可用 TAA_PYTHON=/path/to/python3.12 指定" >&2
  exit 1
fi
"${PY}" -V

echo "[1/5] download from ${BASE}"
curl -fsSL -H "Authorization: Bearer ${TAA_DOWNLOAD_TOKEN}" "${BASE}/dist/agent/latest.tar.gz" -o "${TMP}/taa.tgz"
mkdir -p "${TAA_HOME}"
tar xzf "${TMP}/taa.tgz" -C "${TMP}"
SRC="$(find "${TMP}" -maxdepth 1 -type d \( -name 'taa_agent' -o -name 'alice_agent' \) | head -1)"
if [ -z "${SRC}" ] || [ ! -x "${SRC}/bin/taa" ]; then
  echo "  x 包结构异常：找不到 bin/taa" >&2
  exit 1
fi
rm -rf "${DEST}"
mv "${SRC}" "${DEST}"

echo "[2/5] dependencies"
if [ "${TAA_SKIP_DEPS:-0}" = "1" ]; then
  echo "  skipped (TAA_SKIP_DEPS=1)"
else
  VENV="${TAA_HOME}/venv"
  if [ ! -x "${VENV}/bin/python" ]; then
    "${PY}" -m venv "${VENV}" || {
      echo "  x 无法创建 venv；请先安装 Python venv 支持，或设置 TAA_SKIP_DEPS=1" >&2
      exit 1
    }
  fi
  "${VENV}/bin/python" -m pip install --disable-pip-version-check -r "${DEST}/requirements-core.txt" || {
    echo "  x core 依赖安装失败；网络恢复后重跑 install.sh" >&2
    exit 1
  }
  PY="${VENV}/bin/python"
  echo "  python: ${PY}"
fi

echo "[3/5] command entry"
mkdir -p "${HOME}/.local/bin"
printf '%s\n' "${PY}" > "${TAA_HOME}/python"
cat > "${HOME}/.local/bin/taa" <<WRAP
#!/usr/bin/env bash
exec "${PY}" "${DEST}/bin/taa" "\$@"
WRAP
chmod +x "${HOME}/.local/bin/taa"
cat > "${HOME}/.local/bin/taa-core" <<WRAP
#!/usr/bin/env bash
TAA_PYTHON="${PY}" exec "${DEST}/bin/taa-core" "\$@"
WRAP
chmod +x "${HOME}/.local/bin/taa-core"

echo "[4/5] version"
cat "${DEST}/VERSION" 2>/dev/null || true

echo "[5/5] done"
echo "  code:    ${DEST}"
echo "  config:  ${TAA_HOME}/config.toml (created on first run)"
echo "  command: ${HOME}/.local/bin/taa"
echo "  next:    taa --base ${BASE} --key taa_xxx && taa setup && taa run
  local:   taa-core   # 完整 TA core + /app 本地 UI"
