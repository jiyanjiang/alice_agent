"""weather —— 天气 + 穿搭建议（**地点不固定**）。

链路（Owner 指定）：**地点 → 经纬度 → 当天该地天气 → 按本人衣柜/性别给出穿搭建议**。

- 数据源：Open-Meteo（免密钥；geocoding + forecast）。
- 衣柜：读 `agents/<id>/persona.yaml` 的 `wardrobe`（颗粒度见 docs/64；参考 soul 项目 wardrobe.json）。
- **纯函数 `recommend()`** 与网络解耦，可离线单测。
"""
from __future__ import annotations

import json
import os
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
GEOCODE_API = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_API = "https://api.open-meteo.com/v1/forecast"

# WMO 天气代码 → 文案
WMO = {
    0: "☀️ 晴朗", 1: "🌤️ 基本晴朗", 2: "⛅ 部分多云", 3: "☁️ 阴天",
    45: "🌫️ 雾", 48: "🌫️ 雾凇",
    51: "🌦️ 轻微毛毛雨", 53: "🌦️ 中等毛毛雨", 55: "🌧️ 浓密毛毛雨",
    61: "🌧️ 轻微降雨", 63: "🌧️ 中等降雨", 65: "🌧️ 强降雨",
    66: "🌧️ 冻雨", 67: "🌧️ 强冻雨",
    71: "🌨️ 轻微降雪", 73: "🌨️ 中等降雪", 75: "❄️ 强降雪", 77: "🌨️ 雪粒",
    80: "🌦️ 轻微阵雨", 81: "🌦️ 中等阵雨", 82: "⛈️ 强阵雨",
    85: "🌨️ 阵雪", 86: "❄️ 强阵雪",
    95: "⛈️ 雷暴", 96: "⛈️ 雷暴伴冰雹", 99: "⛈️ 强雷暴伴冰雹",
}


def wmo_desc(code) -> str:
    try:
        return WMO.get(int(code), f"未知({code})")
    except (TypeError, ValueError):
        return "未知"


def wmo_category(code) -> str:
    """归为 sunny / cloudy / rainy / snowy，供衣柜规则匹配。"""
    try:
        c = int(code)
    except (TypeError, ValueError):
        return "cloudy"
    if c in (0, 1):
        return "sunny"
    if c in (2, 3, 45, 48):
        return "cloudy"
    if c in (71, 73, 75, 77, 85, 86):
        return "snowy"
    if 51 <= c <= 67 or 80 <= c <= 82 or c >= 95:
        return "rainy"
    return "cloudy"


def _get(url: str, params: dict, timeout: float = 12.0) -> dict:
    q = urllib.parse.urlencode(params)
    req = urllib.request.Request(f"{url}?{q}", headers={"User-Agent": "teamai-weather/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def geocode(place: str) -> dict | None:
    """地点 → 经纬度（最匹配一条）。"""
    d = _get(GEOCODE_API, {"name": place, "count": 1, "language": "zh", "format": "json"})
    rs = d.get("results") or []
    if not rs:
        return None
    r = rs[0]
    return {"name": r.get("name"), "country": r.get("country"), "admin1": r.get("admin1"),
            "lat": r.get("latitude"), "lon": r.get("longitude"), "timezone": r.get("timezone")}


def forecast(lat: float, lon: float, timezone: str = "auto", days: int = 1) -> dict:
    """取「当前 + 今日（可选 N 日）」天气。days>1 时附 `daily` 列表。"""
    days = max(1, min(int(days or 1), 14))
    d = _get(FORECAST_API, {
        "latitude": lat, "longitude": lon, "timezone": timezone or "auto",
        "current": "temperature_2m,relative_humidity_2m,apparent_temperature,weathercode,windspeed_10m",
        "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max,weathercode",
        "forecast_days": days,
    })
    cur = d.get("current") or {}
    day = d.get("daily") or {}
    def _at(k, i=0):
        v = day.get(k) or []
        return v[i] if i < len(v) else None
    dates = day.get("time") or []
    daily = [{"date": dates[i],
              "code": _at("weathercode", i), "desc": wmo_desc(_at("weathercode", i)),
              "cat": wmo_category(_at("weathercode", i)),
              "t_max": _at("temperature_2m_max", i), "t_min": _at("temperature_2m_min", i),
              "precip_prob": _at("precipitation_probability_max", i)}
             for i in range(len(dates))]
    return {
        "temp": cur.get("temperature_2m"),
        "feels": cur.get("apparent_temperature"),
        "humidity": cur.get("relative_humidity_2m"),
        "wind": cur.get("windspeed_10m"),
        "code": cur.get("weathercode"),
        "desc": wmo_desc(cur.get("weathercode")),
        "cat": wmo_category(cur.get("weathercode")),
        "t_max": _at("temperature_2m_max"),
        "t_min": _at("temperature_2m_min"),
        "precip_prob": _at("precipitation_probability_max"),
        "day_code": _at("weathercode"),
        "daily": daily,
        "timezone": d.get("timezone"),
    }


# ------------------------------------------------------------------ 穿搭（纯函数）
def _items(wardrobe: dict) -> dict:
    """只取**非私密**单品：`private: true` 的（如贴身衣物）**永不**出现在建议/输出里。"""
    it = wardrobe.get("items") or {}
    return {k: [x for x in (v or []) if not (isinstance(x, dict) and x.get("private"))]
            for k, v in it.items()}


def _fits(item: dict, temp: float, cat: str) -> bool:
    rng = item.get("temperature_range")
    if isinstance(rng, (list, tuple)) and len(rng) == 2:
        lo, hi = float(rng[0]), float(rng[1])
        if not (lo - 3 <= temp <= hi + 3):
            return False
    return True


#: 场景 → (中文名, 适配场合关键词, 提示)
SCENES: dict[str, tuple] = {
    "commute": ("通勤", ["办公", "正式", "评审", "外出"], "通勤：优先得体、好走的鞋；外套便于穿脱"),
    "outdoor": ("户外", ["运动", "外出", "休闲"], "户外：防晒/防风/防水、浅色耐脏，备帽"),
    "formal": ("正式", ["正式", "评审", "办公"], "正式：成套素色、无 logo"),
    "home": ("居家", ["居家", "休闲"], "居家：棉质、宽松"),
    "sport": ("运动", ["运动", "健身"], "运动：速干透气"),
}

#: 无衣柜时的通用建议（按温度带）
_GENERIC = [
    (28, ["透气浅色短袖/衬衫", "短裤或薄长裤", "帽子 / 防晒"]),
    (22, ["长袖衬衫或薄针织", "长裤或及踝长裙"]),
    (16, ["薄毛衣 + 长裤", "可备薄外套"]),
    (8, ["针织衫 + 长裤 + 外套", "围巾"]),
    (-99, ["厚毛衣 + 保暖内层 + 大衣 / 羽绒", "帽 / 围巾 / 手套"]),
]


def _generic(temp: float, cat: str) -> list[str]:
    out = list(next(v for lo, v in _GENERIC if temp >= lo))
    if cat == "rainy":
        out.append("带伞；鞋选防水")
    if cat == "snowy":
        out.append("防滑鞋")
    return out


def recommend(weather: dict, wardrobe: dict, gender: str | None = None,
              scene: str | None = None) -> dict:
    """按天气 + 本人衣柜给出穿搭建议（不调 LLM，纯规则 + 衣柜数据）。"""
    temp = weather.get("temp")
    if temp is None:
        temp = (weather.get("t_max") or 20)
    temp = float(temp)
    cat = weather.get("cat") or "cloudy"
    items = _items(wardrobe)
    gender = (gender or "").lower()
    scene = (scene or "").strip().lower() or None
    scene_meta = SCENES.get(scene) if scene else None

    if not any(items.values()):            # 衣柜未建 → 通用建议（不臆造个人风格）
        return {"outfit": [], "generic": _generic(temp, cat),
                "notes": ["本机衣柜未建：以下是**通用**建议；建好 `persona.wardrobe` 后按你的风格推荐"],
                "basis": {"temp": temp, "cat": cat, "desc": weather.get("desc"), "scene": scene},
                "source": "Open-Meteo（通用档）"}

    allow_dress = gender in ("female", "f", "woman", "女") and bool(items.get("dresses"))
    occ_pref = scene_meta[1] if scene_meta else []

    def _scene_key(x):
        occ = x.get("occasion") or []
        return 0 if any(o in occ for o in occ_pref) else 1

    def pick(kind: str, n: int = 1):
        cand = [x for x in items.get(kind, []) if _fits(x, temp, cat)]
        if occ_pref:
            cand = sorted(cand, key=_scene_key)
        return cand[:n]

    def nearest(kind: str):
        """严格过滤为空时的兜底：取温度区间离当前最近的一件。"""
        cand = items.get(kind, []) or []
        if not cand:
            return []
        def dist(x):
            rng = x.get("temperature_range")
            if isinstance(rng, (list, tuple)) and len(rng) == 2:
                lo, hi = float(rng[0]), float(rng[1])
                return 0 if lo <= temp <= hi else min(abs(temp - lo), abs(temp - hi))
            return 999
        return sorted(cand, key=dist)[:1]

    picks: list[dict] = []
    # 极热/极冷 → 连衣裙优先（女）
    if allow_dress and temp >= 22:
        picks += pick("dresses")
    if not any(p.get("type") == "连衣裙" for p in picks):
        picks += pick("tops")
        picks += pick("bottoms")
    if temp < 18:                         # 天冷才加外层
        picks += pick("outerwear", 1)
    # 兜底：确保有内搭（上装或连衣裙）+ 下装（极端温度也不至于只剩外套）
    if not any(p.get("type") in ("上装", "连衣裙") for p in picks):
        picks += nearest("tops")
    if not any(p.get("type") in ("长裤", "半身裙", "短裤", "运动裤", "连衣裙") for p in picks):
        picks += nearest("bottoms")
    # 配饰（鞋/发饰/信物）：不限温
    picks += (items.get("accessories") or [])[:2]

    # 规则兜底（wardrobe.outfit_rules.weather_based）
    rules = ((wardrobe.get("outfit_rules") or {}).get("weather_based") or {})
    rule_hit = None
    for band in (rules.get(cat) or {}).values():
        rng = band.get("range") or []
        if len(rng) == 2 and rng[0] - 3 <= temp <= rng[1] + 3:
            rule_hit = band
            break
    if not picks and rule_hit:
        idx = {x.get("id"): x for k in items for x in items[k]}
        picks = [idx[i] for i in (rule_hit.get("recommend") or []) if i in idx]

    # 去重
    seen, uniq = set(), []
    for p in picks:
        pid = p.get("id") or p.get("name")
        if pid in seen:
            continue
        seen.add(pid)
        uniq.append(p)

    rain = cat == "rainy"
    snow = cat == "snowy"
    notes = []
    if rain:
        notes.append("有降水：带伞，鞋选防水/深色，外层选易干的")
    if snow:
        notes.append("有雪：保暖优先，鞋要防滑")
    if temp >= 28:
        notes.append("偏热：选透气浅色，备防晒")
    if temp <= 8:
        notes.append("偏冷：加保暖内层与围巾/外套")
    if (weather.get("wind") or 0) and float(weather["wind"]) >= 25:
        notes.append("风大：外层要挡风")
    if scene_meta:
        notes.append(scene_meta[2])

    return {
        "outfit": [{"name": p.get("name"), "type": p.get("type"), "color": p.get("color"),
                    "style": p.get("style")} for p in uniq],
        "notes": notes,
        "basis": {"temp": temp, "feels": weather.get("feels"), "cat": cat,
                  "desc": weather.get("desc"), "scene": scene},
        "source": "本机衣柜（persona.wardrobe）+ Open-Meteo",
    }


def center_geo(base: str | None = None) -> dict | None:
    """Read the center's Cloudflare request city. Never invent a city."""
    base = (base or os.environ.get("TAA_CENTER_URL") or os.environ.get("TEAMAI_URL") or "").rstrip("/")
    if not base:
        # Installed TAA: use the user's configured center, not a hardcoded host.
        try:
            from .center_sync import _cfg
            base = _cfg()[0].rstrip("/")
        except Exception:  # noqa: BLE001
            base = ""
    if not base:
        return None
    try:
        d = _get(base + "/geo/suggest", {}, timeout=5)
    except Exception:  # noqa: BLE001
        return None
    if not d.get("ok") or not d.get("city"):
        return None
    return {
        "city": str(d.get("city") or "").strip(),
        "region": str(d.get("region") or "").strip(),
        "country": str(d.get("country") or "").strip(),
        "timezone": str(d.get("timezone") or "").strip(),
        "label": str(d.get("label") or d.get("city") or "").strip(),
    }


def image_prompt(loc: dict, weather: dict, advice: dict) -> str:
    """Build a non-private image prompt from weather + public outfit items."""
    place = loc.get("name") or loc.get("label") or "city"
    items = " / ".join(o.get("name", "") for o in (advice.get("outfit") or []) if o.get("name"))
    generic = " / ".join(advice.get("generic") or [])
    wearing = items or generic or "weather-appropriate clothing"
    return (f"A realistic editorial photo of a person dressed for {place}, "
            f"{weather.get('desc', '')}, {weather.get('temp', '')}°C, wearing {wearing}. "
            "Natural light, full-body or three-quarter view, no text, no logos.")


def outfit_for(agent_id: str, place: str, days: int = 1, scene: str | None = None,
               center_base: str | None = None, image: bool = False,
               image_engine: str | None = None, image_size: str | None = None) -> dict:
    """完整链路：地点 → 经纬度 → 天气（可 N 日）→ 按本人衣柜/性别建议。"""
    # 读本人衣柜（本地私有）；地点为空时尝试用 persona.residence.
    wardrobe, gender, residence = {}, None, ""
    try:
        import sys
        if str(ROOT) not in sys.path:
            sys.path.insert(0, str(ROOT))
        from core import persona as P
        p = P.load_persona(agent_id)
        wardrobe = p.get("wardrobe") or {}
        gender = (p.get("identity") or {}).get("gender")
        residence = str((p.get("residence") or {}).get("city") or "").strip()
    except Exception:  # noqa: BLE001
        pass
    place = str(place or "").strip()
    place_source = "user" if place else ""
    if not place and residence:
        place, place_source = residence, "persona"
    if not place:
        geo = center_geo(center_base)
        if geo:
            place, place_source = geo["city"], "cloudflare"
            try:
                from core import persona as _P
                _P.set_residence(agent_id, place, region=geo.get("region", ""),
                                 country=geo.get("country", ""),
                                 timezone=geo.get("timezone", ""), source="cloudflare")
            except Exception:  # noqa: BLE001
                pass
    if not place:
        return {"ok": False, "error": "需要地点",
                "hint": "请提供城市名，或在 persona.residence.city 设置默认城市；也可连接中心使用 CF 城市",
                "examples": ["成都", "上海", "Boston"]}
    loc = geocode(place)
    if not loc:
        return {"ok": False, "error": f"地点未找到：{place}",
                "hint": "请设置城市名（可带省份/国家）后重试；也可设置 persona.residence.city",
                "examples": ["成都", "上海", "Boston"]}
    w = forecast(loc["lat"], loc["lon"], loc.get("timezone") or "auto", days)
    adv = recommend(w, wardrobe, gender, scene)
    # N 日：逐日建议
    daily = []
    if days and int(days) > 1:
        for d in (w.get("daily") or []):
            wd = {"temp": d.get("t_max"), "t_max": d.get("t_max"), "t_min": d.get("t_min"),
                  "cat": d.get("cat"), "desc": d.get("desc"), "wind": 0}
            daily.append({"date": d.get("date"), "desc": d.get("desc"),
                          "t_min": d.get("t_min"), "t_max": d.get("t_max"),
                          "precip_prob": d.get("precip_prob"),
                          "advice": recommend(wd, wardrobe, gender, scene)})
    result = {"ok": True, "place": loc, "place_source": place_source,
              "weather": w, "gender": gender, "scene": scene,
              "advice": adv, "daily": daily}
    if image:
        try:
            from . import media
            url = media.generate_image(image_prompt(loc, w, adv),
                                       size=image_size or "2K",
                                       engine=image_engine or "auto")
            result["image"] = {"ok": True, "url": url}
        except Exception as exc:  # noqa: BLE001
            # Image is optional; never fail the weather/outfit response for it.
            result["image"] = {"ok": False, "error": str(exc)[:240]}
    return result
