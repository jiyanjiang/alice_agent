# email.send · 一键发信

## 是什么
在 IDE / agent / 群聊里**一键发送邮件**：正文、把文件并入正文、加附件。

## 激发方法（三种）

### ① 终端一键（推荐，IDE 里直接跑）
```bash
../venv/bin/python cli/teamai.py email --as alice \
  --to someone@example.com --subject "标题" \
  --body "正文"  [--file a.md]  [--attach b.pdf]  [--html c.html]
# 也可把整份 md 作为正文：--file notes.md
# 或把邮件正文/收件人放进文件，用 ... 见 --file/--attach
```

### ② 工具调用（agent / IDE 内部）
```bash
curl -s -X POST http://127.0.0.1:6080/v1/tools/email.send/call \
  -H "Content-Type: application/json" -H "X-Enroll-Token: <token>" \
  -d '{"args":{"to":"someone@example.com","subject":"标题","body":"正文","attachments":["/abs/path.pdf"]}}'
```
（正式调用应带 agent 签名头；此工具与其它工具一致，经 `/v1/tools/<name>/call`。）

### ③ 群聊即控制台
在工作群里让 agent 调用该工具即可（由 chatwork 判定后执行）。

## 配置（gitignored）
`config.yaml`：
```yaml
smtp:
  host: smtp.126.com
  port: 465
  sender: you@126.com
  auth_code: ********      # 邮箱授权码（非登录密码）
  name: TeamAI
```
或用环境变量：`SMTP_HOST/SMTP_PORT/SMTP_EMAIL/SMTP_AUTH_CODE/SMTP_NAME`。

## 依赖
仅标准库（smtplib / email）。无第三方依赖。

## 隐私声明
本工具**不含任何账号/授权码/绝对路径**；凭据由使用者的 config.yaml 或环境变量提供。
