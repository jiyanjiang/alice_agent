# screen.capture

## 功能
截取**本机屏幕**（含 opencode / IDE 界面），返回图片 URL，供 agent 在群里汇报进度。

## 用法
```json
{"tool":"screen.capture","args":{}}
```
返回：`{"url":"/static/uploads/screen-<agent>-<ts>.png","machine":"<hostname>"}`

## 依赖
- macOS：系统自带 `screencapture`（需「屏幕录制」权限；首次会弹窗）。
- Linux：`imagemagick`(`import`) 或 `gnome-screenshot`。

## 隐私
- 只在**运行该工具的机器**上截当前屏幕，不涉及远端、不涉及他人机器。
- 图片落在本机 `static/uploads/`（已 gitignore）。

## 维护者（主电脑）
- MBP32G（alice）
