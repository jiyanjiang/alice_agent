#!/usr/bin/env python3
"""dispatcher —— 把「派活简报」交给 opencode 执行（方案 B）。

loop.py 认领任务后写 agents/<id>/inbox/<task_id>.json；
dispatcher 轮询收件箱，用 `opencode run` 在 agent 工作区执行，完成后移入 inbox/done/。

用法：
    python runtime/dispatcher.py --as bob --interval 60      # 常驻
    python runtime/dispatcher.py --as bob --once             # 跑一遍
"""
from __future__ import annotations

# Windows 控制台常为 GBK：print emoji/非 GBK 字符会 UnicodeEncodeError 直接崩（Darwin 实测 loop.py:192）
try:  # noqa: SIM105
    import sys as _sys
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

import argparse
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
from pathlib import Path

BUDDYCN = shutil.which("buddycn") or str(Path.home() / ".codebuddy" / "bin" / "buddycn")

ROOT = Path.cwd()
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# P1.5：收件箱唯一口径。默认走 core.db.AGENTS_DIR（与 data.db 同源）；
# 测试可把 AGENTS_ROOT 指到沙箱（旧实现直接用 cwd，部署时与写入端不一致）。
AGENTS_ROOT: Path | None = None


def _inbox_dir(agent: str) -> Path:
    if AGENTS_ROOT is not None:
        return Path(AGENTS_ROOT) / str(agent) / "inbox"
    try:
        from core.db import brief_inbox
        return brief_inbox(agent)
    except Exception:  # noqa: BLE001
        return ROOT / "agents" / str(agent) / "inbox"

# 执行进度上报（统一状态上报，t-5e7abb71）。缺 report 时静默降级，不影响派活。
try:
    from core import report as _report
except Exception:  # noqa: BLE001
    _report = None

PROGRESS_HEARTBEAT_S = int(os.environ.get("TEAMAI_PROGRESS_HEARTBEAT", "60"))
STATUS_CHANNEL = os.environ.get("TEAMAI_STATUS_CHANNEL", "#projects/team-ai")


def _report_progress(agent: str, base: str, stage: str, brief: dict,
                     extra: dict | None = None, post: bool = False) -> None:
    """上报 start/progress/done。失败静默，绝不阻塞/影响执行主流程。"""
    if _report is None:
        return
    try:
        _report.report(agent, stage, brief.get("task_id"), brief.get("title"),
                       detail=extra, base=base,
                       post_to_channel=STATUS_CHANNEL if post else None,
                       set_status=True)
    except Exception:  # noqa: BLE001
        pass


def _heartbeat(agent: str, base: str, brief: dict, t0: float, stop: threading.Event) -> None:
    """执行期间的后台心跳：每 PROGRESS_HEARTBEAT_S 秒上报一次 progress（仅看板+日志）。"""
    while not stop.wait(PROGRESS_HEARTBEAT_S):
        elapsed = int(time.time() - t0)
        _report_progress(agent, base, "progress", brief, {"elapsed_s": elapsed}, post=False)


def _deepseek_key() -> str | None:
    # 优先级：环境变量 > config.yaml(llm.deepseek_api_key) > bootstrap/deepseek.key
    try:
        import sys
        if str(ROOT) not in sys.path:
            sys.path.insert(0, str(ROOT))
        from core import config
        k = config.deepseek_key()
        if k:
            return k
    except Exception:
        pass
    for env in ("DEEPSEEK_API_KEY", "DS_KEY"):
        if os.environ.get(env):
            return os.environ[env].strip()
    p = ROOT / "bootstrap" / "deepseek.key"
    if p.exists():
        return p.read_text(encoding="utf-8").strip()
    return None


def _ensure_opencode_config() -> Path | None:
    """复用共享实现：确保 opencode 配置含随包声明的模型（含视觉模型）。"""
    try:
        import sys
        if str(ROOT) not in sys.path:
            sys.path.insert(0, str(ROOT))
        from core.llm.opencode import ensure_config
        return ensure_config(ROOT)
    except Exception:
        return None


def _teamai_path() -> str:
    for rel in ("runtime/teamai.py", "cli/teamai.py"):
        p = ROOT / rel
        if p.exists():
            return str(p)
    return str(ROOT / "cli" / "teamai.py")


# ---------------------------------------------------------------------------
# 派活产物兜底：submit 前校验 + 自动补挂（上游包第 3 处修复 / Alice 方案 t-e7b5cd44）
# 根因：executor 产出只落本地（research/… 等）、不上帖、不 upload 附件，任务帖只剩
#      进度回执；而 submit 门禁只验「有帖」不验「有附件」→ 每次都靠人工补挂。
# 兜底：opencode 跑完后、上报 done 前，校验任务帖是否带附件；无附件则扫描本轮产物、
#      逐个 upload 并自动发一篇带 task_id 的 artifact 帖（含 attachments）；无产物可补
#      时显式告警，绝不静默。任何失败都不阻塞主流程。
# ---------------------------------------------------------------------------
ARTIFACT_EXTS = {
    # 与 core/media.UPLOAD_EXTS 对齐（服务端允许的上传类型），避免扫描到不可上传的产物
    ".md", ".txt", ".csv", ".tsv", ".json", ".yaml", ".yml", ".log", ".pdf",
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg",
    ".zip", ".tar", ".gz", ".tgz", ".xlsx", ".docx", ".pptx",
}
ARTIFACT_SCAN_DIRS = tuple(
    d for d in os.environ.get(
        "TEAMAI_ARTIFACT_DIRS", "research,plan,data,deliverables,work,reports,docs"
    ).split(",") if d)
ARTIFACT_SKIP_DIRS = {"raw", "__pycache__", "node_modules", ".git", ".staging", "venv"}
ARTIFACT_MAX = int(os.environ.get("TEAMAI_ARTIFACT_MAX", "8"))
ATTACH_POST_TAGS = ["auto-attach", "guard"]


def _load_teamai_module():
    """惰性加载 CLI 模块，复用其带签名的 HTTP 客户端（不复制签名逻辑）。"""
    try:
        import importlib.util
        path = Path(_teamai_path())
        spec = importlib.util.spec_from_file_location("_teamai_client", path)
        if spec is None or spec.loader is None:
            return None
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:  # noqa: BLE001
        return None


def _task_posts(agent: str, base: str, task_id: str) -> list[dict] | None:
    """查该任务的帖子（含 attachments）。None = 查不到（无 task_id / 服务或网络不可用）。"""
    if not task_id:
        return None
    mod = _load_teamai_module()
    if mod is None:
        return None
    mod.BASE = base.rstrip("/")
    try:
        q = urllib.parse.urlencode({"task_id": task_id, "limit": 50})
        data = mod.call("GET", f"/v1/posts?{q}", agent_id=agent)
        return data.get("posts") or []
    except SystemExit:   # call() 在 HTTP 错误时 sys.exit
        return None
    except Exception:    # noqa: BLE001
        return None


def _has_attachment(posts: list[dict]) -> bool:
    return any((p.get("attachments") or []) for p in posts)


def _artifact_candidates(since_ts: float) -> list[Path]:
    """本轮产物候选：常见产出目录中 mtime ≥ 起点、扩展名在册的文件（排除 raw/ 等）。"""
    found: list[tuple[float, Path]] = []
    for d in ARTIFACT_SCAN_DIRS:
        root = ROOT / d
        if not root.is_dir():
            continue
        for p in root.rglob("*"):
            try:
                if not p.is_file():
                    continue
                rel = p.relative_to(ROOT).parts
                if any(part in ARTIFACT_SKIP_DIRS for part in rel):
                    continue
                if p.suffix.lower() not in ARTIFACT_EXTS:
                    continue
                mtime = p.stat().st_mtime
                if mtime < since_ts - 1:
                    continue
            except OSError:
                continue
            found.append((mtime, p))
    found.sort(key=lambda x: x[0], reverse=True)
    return [p for _, p in found[:ARTIFACT_MAX]]


def _upload_artifact(agent: str, base: str, path: Path) -> str | None:
    """调用 CLI 上传，返回 /static/uploads/… URL；失败返回 None。"""
    cmd = [sys.executable, _teamai_path(), "upload", str(path), "--url", base, "--as", agent]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    except Exception:  # noqa: BLE001
        return None
    for line in reversed((r.stdout or "").splitlines()):
        line = line.strip()
        if "/static/uploads/" in line:
            return line.split()[-1]
    return None


def _auto_attach_post(agent: str, base: str, brief: dict, urls: list[str]) -> bool:
    tid = brief.get("task_id")
    channel = brief.get("channel") or STATUS_CHANNEL
    title = f"[自动补挂] {brief.get('title') or tid}"
    body = (f"executor 未自行挂附件，由派活链**兜底补挂**（task={tid}）。\n\n"
            f"本轮产物 {len(urls)} 件，见附件。\n"
            f"说明：派活链路「完成即校验附件」守卫自动触发，非人工发帖。")
    cmd = [sys.executable, _teamai_path(), "post", "--as", agent, "--url", base,
           "--channel", channel, "--type", "artifact", "--task", tid,
           "--title", title, "--body", body, "--tags", *ATTACH_POST_TAGS]
    for u in urls:
        cmd += ["--attach", u]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return r.returncode == 0
    except Exception:  # noqa: BLE001
        return False


def _is_progress_post(p: dict) -> bool:
    """系统自动进度帖（'执行进度（系统自动 · 非交付）'）不算交付帖。"""
    tags = p.get("tags")
    s = tags if isinstance(tags, str) else json.dumps(tags or [], ensure_ascii=False)
    if '"activity"' in s or '"status"' in s:
        return True
    return "执行进度" in (p.get("title") or "")


def _ensure_delivery_post(agent: str, base: str, brief: dict, out: str) -> str:
    """P1A/A4 闭环：没有交付帖时，由 dispatcher 用本轮输出代发一篇 canonical 结果帖。

    为什么必须有这一步：A4 把 submit 权从 agent 收回后，`submit` 门禁依然要求
    "至少 1 篇带 --task 的交付帖"。若 agent 忘了发（模型很常见），任务会卡在门禁上，
    再被判失败 → 大面积 failed。所以"收权"必须配套"兜底发帖"，否则是把一个坑换成另一个坑。

    返回：exists / created / unreachable / failed:<reason>
    """
    tid = (brief.get("task_id") or "").strip()
    if not tid:
        return "failed:no-task-id"
    posts = _task_posts(agent, base, tid)
    if posts is None:
        return "unreachable"
    if [p for p in posts if not _is_progress_post(p)]:
        return "exists"
    body = (out or "").strip()
    if not body:
        return "failed:empty-output"
    channel = brief.get("channel") or STATUS_CHANNEL
    title = f"{brief.get('title') or tid}（系统代发 · 进程已退出）"
    cmd = [sys.executable, _teamai_path(), "post", "--as", agent, "--url", base,
           "--channel", channel, "--type", "artifact", "--task", tid,
           "--title", title, "--body", body[-4000:],
           "--tags", "auto-delivery", "executor"]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if r.returncode == 0:
            print(f"[submit] {agent} {tid} 无交付帖 → 已用本轮输出代发 ✓")
            return "created"
        print(f"[submit] ⚠️ {agent} {tid} 代发交付帖失败：{((r.stdout or '') + (r.stderr or ''))[-300:]}")
        return "failed:post-rejected"
    except Exception as e:  # noqa: BLE001
        return f"failed:{e}"


def _ensure_artifact_attached(agent: str, base: str, brief: dict, since_ts: float,
                              dry_run: bool = False) -> str:
    """submit 前守卫：任务帖须带附件，否则扫描本轮产物自动补挂（失败只告警）。

    返回状态：ok（已有附件）/ attached（已补挂）/ dryrun / manual（需人工）/ unknown（查不到）。
    """
    tid = brief.get("task_id") or ""
    posts = _task_posts(agent, base, tid)
    if posts is None:
        print(f"[verify] ⚠️ {agent} {tid} 无法查询任务帖（服务不可达？），跳过附件校验")
        return "unknown"
    if _has_attachment(posts):
        print(f"[verify] {agent} {tid} 已有带附件产出帖 ✓（跳过）")
        return "ok"

    cands = _artifact_candidates(since_ts)
    if not cands:
        print(f"[verify] ⚠️ {agent} {tid} 任务帖无附件、且未发现本轮产物 → 请人工补挂")
        return "manual"
    if dry_run:
        print(f"[verify] {agent} {tid} 待补挂 {len(cands)} 件："
              f"{', '.join(c.name for c in cands)}")
        return "dryrun"

    urls: list[str] = []
    for c in cands:
        u = _upload_artifact(agent, base, c)
        if u:
            urls.append(u)
    if not urls:
        print(f"[verify] ⚠️ {agent} {tid} 产物上传失败 → 请人工补挂")
        return "manual"
    if _auto_attach_post(agent, base, brief, urls):
        print(f"[verify] {agent} {tid} 已自动补挂 {len(urls)} 件附件 ✓")
        return "attached"
    print(f"[verify] ⚠️ {agent} {tid} 自动补挂发帖失败 → 请人工补挂")
    return "manual"


def _persona(agent: str) -> dict:
    p = ROOT / "agents" / agent / "persona.yaml"
    if p.exists():
        try:
            import yaml
            return yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        except Exception:
            pass
    return {}


def _values(agent: str) -> dict:
    import sqlite3
    db = ROOT / "agents" / agent / "memory.db"
    if not db.exists():
        return {}
    try:
        c = sqlite3.connect(db)
        return {r[0]: round(r[1], 2) for r in c.execute("SELECT key, value FROM values_t")}
    except Exception:
        return {}


def _clip(s, n: int) -> str:
    s = (s or "").strip()
    return s if len(s) <= n else s[:n] + "\n…（已截断）"


def _agents_md(agent: str, cap: int = 3500) -> str:
    p = ROOT / "agents" / agent / "AGENTS.md"
    try:
        t = p.read_text(encoding="utf-8").strip()
    except Exception:  # noqa: BLE001
        return ""
    return t if len(t) <= cap else t[:cap] + "\n…（已截断）"


def _soul_note(agent: str, cap: int = 1200) -> str:
    try:
        from core import persona as _P
        return _P.soul_note(_P.load_persona(agent))[:cap]
    except Exception:  # noqa: BLE001
        return ""


def _memory_digest(agent: str, cap: int = 1400) -> str:
    """本地记忆摘要：方法论(playbook) + 事实(facts)。缺表/缺库则静默。"""
    db = ROOT / "agents" / agent / "memory.db"
    if not db.exists():
        return ""
    import sqlite3
    out: list[str] = []
    try:
        conn = sqlite3.connect(db)
        try:
            rs = list(conn.execute("SELECT type, statement FROM playbook "
                                   "ORDER BY salience DESC, id DESC LIMIT 6"))
            if rs:
                out.append("方法论：" + "；".join(f"[{r[0]}] {r[1]}" for r in rs if r[1]))
        except Exception:  # noqa: BLE001
            pass
        try:
            rs = list(conn.execute("SELECT statement, source FROM facts "
                                   "ORDER BY salience DESC, id DESC LIMIT 6"))
            if rs:
                out.append("事实：" + "；".join(f"{r[0]}（源:{r[1] or '—'}）" for r in rs if r[0]))
        except Exception:  # noqa: BLE001
            pass
    except Exception:  # noqa: BLE001
        return ""
    return "\n".join(out)[:cap]


def _assets_digest(cap: int = 900) -> str:
    """团队资产台账摘要（data.db:assets）；无表则给指针。"""
    try:
        import sqlite3
        # ROOT 是 **cwd**（正式部署 = <home>/app），拿它拼 data.db 会落到 app/data.db，
        # 与 canonical 库分叉（P0-1 同类根因）。统一走 core.db.DB_PATH。
        from core.db import DB_PATH as _CANON_DB
        conn = sqlite3.connect(_CANON_DB)
        rs = list(conn.execute("SELECT name, owner_node, path, note FROM assets ORDER BY rowid LIMIT 8"))
        if rs:
            return "\n".join(
                f"- {r[0]}（宿主 {r[1] or '—'}）" + (f"：{r[2]}" if r[2] else "")
                + (f"｜{r[3]}" if r[3] else "") for r in rs)[:cap]
    except Exception:  # noqa: BLE001
        pass
    return "（台账见 `teamai assets`；**本队自建 arXiv 全量全文库 @Win16G** 为权威语料）"


def build_prompt(agent: str, brief: dict, base: str, card: dict | None = None) -> str:
    p = _persona(agent)
    ident = p.get("identity") or {}
    vals = _values(agent)
    teamai = _teamai_path()
    tid = brief.get("task_id")
    title = (brief.get("title") or "任务").strip()
    # 控本：单次上下文限幅（防超长 description/AC/card 把单次成本抬高）
    desc = _clip(brief.get("description"), int(os.environ.get("TEAMAI_DESC_CAP", "2000")))
    ac = _clip(brief.get("acceptance_criteria"), int(os.environ.get("TEAMAI_AC_CAP", "1500")))
    card_s = _clip(json.dumps(card or {}, ensure_ascii=False, indent=2),
                   int(os.environ.get("TEAMAI_CARD_CAP", "3000")))
    channel = brief.get("channel") or "#projects/team-ai"
    tags = brief.get("tags") or []
    tags_s = " ".join(tags) if isinstance(tags, list) else str(tags)
    ptype = "reading" if "reading" in channel else "artifact"
    plan_line = ("\n【规划优先】先给出可执行方案（目标/步骤/事实源清单/事实库schema/验收判据/分工轮次/风险），"
                 "请 Alice 过审；**过审后再执行**。\n"
                 if ("先出方案" in ac or "先出可执行方案" in ac) else "")
    agents_md = _clip(_agents_md(agent), int(os.environ.get("TEAMAI_AGENTSMD_CAP", "3500")))
    soul_txt = _soul_note(agent)
    mem_txt = _memory_digest(agent)
    assets_txt = _assets_digest()
    return f"""【开工前置 · 强制三步（先做，再答题）】
1) 读我的 **AGENTS.md**（身份与思维规程，见下）；
2) 查我的**本地记忆**（方法论 / 事实，见下）；
3) 申报四样：已知 / 未知 / **本次数据源与理由** / 验收判据。
   数据源优先级：**本队自建资产 ＞ 官方一手源 ＞ 第三方 / API**；本队已有专业语料时，**禁止默认走外部 API**。
你的回答**必须以这 1)-3) 开头**，之后才执行任务；**LLM 只执行方案，不替你决定"我是谁 / 用什么源"**。

【我的 AGENTS.md（身份与思维规程）】
{agents_md or "（缺：请先建档 agents/" + agent + "/AGENTS.md）"}

【我的灵魂宣言（据此思想与说话）】
{soul_txt or "（未设）"}

【我的本地记忆（方法论 / 事实）】
{mem_txt or "（空：开工前先 `teamai playbook/facts --as " + agent + "` 补课）"}

【团队资产台账】
{assets_txt}

---

你是团队 AI 的 agent「{p.get('name', agent)}」（id={agent}），角色={p.get('role', 'executor')}。
人设：{ident.get('motto', '')}；价值观权重：{json.dumps(vals, ensure_ascii=False)}。

【任务】{tid} · {title}
说明：{desc}
验收标准：{ac}{plan_line}
请**现在直接完成**上面的任务：按「说明」与「验收标准」产出成果，用你本机的能力/工具（可 browse 抓网页、可写文件、可计算）。
**若任务含计算/数据处理/生成文件，请写并运行程序（如 python）**，并**必须**把生成的文件作为**附件**发到帖子里：
`--attach` **可直接给本地文件路径**（如 `--attach out.csv`，会自动上传成 `/static/uploads/…`）；
**不要**把 `C:\…` 这类本地路径手写进正文或当作 URL（那样附件点不开）。附件缺失会被 `compute_check` 判为不合格。
若涉及事实/数据，必须附可回溯出处（URL+原文摘录）；无源即删，**不要编造**。不要空谈、不要反问。

完成后只做**一步**（正文用你的完整成果）：
发帖（**必须发到频道 {channel}，不得改到别的频道**）：
python {teamai} post --as {agent} --channel "{channel}" --type {ptype} --task {tid} --tags {tags_s} --title "{title}" --body "你的完整成果"

**不要再执行 `teamai start` / `teamai submit`**（这条是 P1A/A4 的硬规则）：
任务状态由系统在你的进程**退出之后**统一推进。你若自己 submit，任务会在你还在跑的时候就被推进 review，
评审看到的是半成品（P0-3 的根因）。你只负责"把活干完 + 发一篇带 --task 的交付帖"。

硬性要求：**发帖命令必须带 `--task {tid}`**（系统据此认领交付帖、才会替你提交评审）；**频道固定为 {channel}**；成果正文=你的完整产出；禁止占位符（待核/待证/TODO）；事实性内容带出处；不泄露 key/绝对路径/内网 IP/真名；只发必要篇数。
**⚠ 系统会有一条标题含「执行进度（系统自动 · 非交付）」的进度帖——那不是你的交付帖。你必须自己发一篇 `--task {tid}` 的交付帖**（正文=完整产出；有生成文件必须 `--attach`），否则 `submit` 会因"缺交付帖"返回 409。
环境变量 TEAMAI_URL={base}（已设置）。

【你的操作卡（由服务端握手下发，机器可读）】
{card_s}

【需要与统筹 Alice 沟通时，用 API 发私信（不要等）】
python {teamai} ask --as {agent} --to alice --body "你的问题"
然后读回复：python {teamai} messages --as {agent} --with alice"""


def _fetch_card(agent: str, base: str) -> dict:
    """调用 teamai CLI 取 agent 操作卡（握手内容），注入 prompt。"""
    cmd = [sys.executable, _teamai_path(), "card", "--url", base, "--as", agent]
    ca = os.environ.get("TEAMAI_CA")
    if ca:
        cmd += ["--ca", ca]
    try:
        r = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True, timeout=30)
        return json.loads(r.stdout)
    except Exception:
        return {}



# ---------------- ★ 超时/失败处置（Owner 2026-10-14：「超时应该退出重处理，或者放弃」）----------------
MAX_RETRY = 1          # 只给 1 次重试机会


def decide_failure(priority: int, attempts: int) -> str:
    """失败/超时后的处置：`retry`（放回队列）或 `abandon`（放弃并置 blocked）。

    规则（Owner 定的口径）：
      · **低重要性（P2/P3）**：不重试，**直接放弃**（"这些任务的重要性显然不高"）；
      · **高重要性（P0/P1）**：最多重试 **1** 次；第 2 次失败即放弃；
      · 无论哪种，**都不许卡住整条队列**（放回/置 blocked 都立刻让出执行位）。
    """
    if int(priority or 1) >= 2:
        return "abandon"
    return "retry" if int(attempts or 0) < MAX_RETRY else "abandon"


def _attempts_file(agent: str):
    d = _inbox_dir(agent)
    d.mkdir(parents=True, exist_ok=True)
    return d / "_attempts.json"


def _bump_attempt(agent: str, task_id: str) -> int:
    import json as _json
    f = _attempts_file(agent)
    try:
        data = _json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    except Exception:  # noqa: BLE001
        data = {}
    data[task_id] = int(data.get(task_id, 0)) + 1
    try:
        f.write_text(_json.dumps(data), encoding="utf-8")
    except OSError:
        pass
    return data[task_id]


def _pause_timeout(agent: str, base: str, brief: dict, brief_path: Path,
                   since_ts: float, elapsed: int) -> bool:
    """长任务到软预算：保存断点、置 paused、把简报移入 inbox/paused。"""
    tid = brief.get("task_id") or ""
    if not tid:
        return False
    artifacts = [str(p.relative_to(ROOT)) for p in _artifact_candidates(since_ts)]
    checkpoint = {
        "phase": brief.get("phase") or "run",
        "reason": "timeout",
        "elapsed_s": elapsed,
        "artifacts": artifacts,
        "next": "resume from this phase; do not rerun completed work",
    }
    try:
        r = subprocess.run(
            [sys.executable, _teamai_path(), "pause", tid,
             "--checkpoint", json.dumps(checkpoint, ensure_ascii=False),
             "--as", agent, "--url", base],
            cwd=str(ROOT), capture_output=True, text=True, timeout=60)
        if r.returncode != 0:
            print(f"[dispatch] pause failed rc={r.returncode}: {(r.stderr or r.stdout)[-300:]}")
            return False
    except Exception as e:  # noqa: BLE001
        print(f"[dispatch] pause err: {e}")
        return False
    paused_dir = brief_path.parent / "paused"
    paused_dir.mkdir(parents=True, exist_ok=True)
    try:
        brief_path.replace(paused_dir / brief_path.name)
    except OSError as e:
        print(f"[dispatch] move paused brief failed: {e}")
    print(f"[dispatch] long task {tid} paused at phase checkpoint; slot released")
    return True


def _handle_failure(agent: str, base: str, brief: dict, timed_out: bool, rc, out: str) -> str:
    """失败/超时 → 放回队列 或 放弃（并留痕、发帖）。返回 'retry'/'abandon'。"""
    tid = brief.get("task_id") or ""
    if not tid:
        return "abandon"
    n = _bump_attempt(agent, tid)
    action = decide_failure(brief.get("priority", 1), n - 1)   # 本次算第 n 次尝试
    why = ("超时" if timed_out else "执行失败") + f"（第 {n} 次"
    why += "，exit=" + str(rc) + "）"
    try:
        cmd = [sys.executable, _teamai_path(), "release" if action == "retry" else "block",
               tid, "--reason", why + ("：放回队列重试" if action == "retry" else "：放弃"),
               "--as", "alice", "--url", base]
        subprocess.run(cmd, cwd=str(ROOT), capture_output=True, timeout=60)
    except Exception as e:  # noqa: BLE001
        print(f"[dispatch] 失败处置调用出错：{e}")
    # 留痕 + 公告（不许静默）
    try:
        subprocess.run([sys.executable, _teamai_path(), "post", "--as", "alice",
                        "--channel", "#system", "--type", "note",
                        "--title", f"[dispatch] {tid} {why} → {action}",
                        "--body", f"任务 {tid}（P{brief.get('priority')}）第 {n} 次{why}；"
                                  f"处置：**{'放回队列重试' if action == 'retry' else '放弃并置 blocked'}**。"
                                  f"低优先级不重试，避免卡住整队。尾输出：{(out or '')[-300:]}",
                        "--url", base],
                       cwd=str(ROOT), capture_output=True, timeout=60)
    except Exception:  # noqa: BLE001
        pass
    return action


def _backend(agent: str) -> str:
    """执行后端优先级：`agents/<id>/backend` > env `TEAM_AGENT_BACKEND` > **自动探测**。

    自动探测：按可用性选 opencode → qoder → codebuddy；都没有则 `manual`（生成待办提示，不静默失败）。
    这样**异机异 IDE（如 Win16G/Qoder）无需任何配置**即可被派活。
    """
    p = ROOT / "agents" / agent / "backend"
    if p.exists():
        v = p.read_text(encoding="utf-8").strip().lower()
        if v:
            return v
    env = (os.environ.get("TEAM_AGENT_BACKEND") or "").strip().lower()
    if env:
        return env
    try:
        import sys as _sys
        if str(ROOT) not in _sys.path:
            _sys.path.insert(0, str(ROOT))
        from core.llm import available as _avail
        av = _avail()
        for name in ("opencode", "qoder", "codebuddy"):
            if av.get(name):
                return name
    except Exception:  # noqa: BLE001
        pass
    return "manual"


def _submit_after_run(agent: str, base: str, brief: dict, exit_code: int | None = 0) -> str:
    """P1A/A4：进程退出后，由 dispatcher 统一推进任务状态（start → submit）。

    为什么必须由 dispatcher 做：旧 prompt 直接要求 agent 自己 `teamai submit`，
    而 submit 只校验"有交付帖"，**不校验进程是否还在跑**。
    于是 agent 一边跑一边把任务推到 review（Delta 实测 19:32:07 review、
    19:32:34 仍 progress），评审看到半成品。

    P1.4：服务端只接受 `writer=dispatcher` + 真实 `exit_code` 的 submit——
    凭据由本函数通过子进程环境变量注入，agent 侧默认不带，故无法抢跑。

    返回：ok / noop / failed:<摘要>
    """
    tid = (brief.get("task_id") or "").strip()
    if not tid:
        return "noop"

    def _run(*args: str, env_extra: dict | None = None) -> tuple[int, str]:
        cmd = [sys.executable, _teamai_path(), *args, "--as", agent, "--url", base]
        env = {**os.environ, **(env_extra or {})}
        try:
            r = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True,
                               timeout=90, env=env)
            return r.returncode, ((r.stdout or "") + (r.stderr or "")).strip()
        except Exception as e:  # noqa: BLE001
            return 1, f"{e}"

    rc, out = _run("start", tid)
    if rc != 0:
        # 已 in_progress / 已 claimed 都属正常，继续 submit
        low = out.lower()
        if not any(k in low for k in ("already", "in_progress", "invalid transition")):
            print(f"[submit] {agent} {tid} start 未成功（仍尝试 submit）：{out[-200:]}")
    rc, out = _run("submit", tid, env_extra={"TEAMAI_TASK_WRITER": "dispatcher",
                                             "TEAMAI_TASK_EXIT_CODE": str(exit_code)})
    if rc == 0:
        print(f"[submit] {agent} {tid} 已在进程退出后提交评审 ✓")
        return "ok"
    print(f"[submit] ⚠️ {agent} {tid} submit 失败（任务保持原状态，不假装完成）：{out[-300:]}")
    return f"failed:{out[-160:]}"


def run_one(agent: str, brief_path: Path, base: str, backend: str | None = None) -> None:
    backend = backend or _backend(agent)
    brief = json.loads(brief_path.read_text(encoding="utf-8"))
    # 记录本次选取的 priority（t-6ce29ebd 判据：日志可见「本次选取的 priority」）
    print(f"[dispatch] 本次选取 priority=p{brief.get('priority')} task={brief.get('task_id')} "
          f"（排序判据：priority 升序, mtime 升序）")
    prompt = build_prompt(agent, brief, base, _fetch_card(agent, base))

    # manual：只生成待办提示
    if backend == "manual":
        pf = brief_path.with_suffix(".prompt.md")
        if pf.exists():
            return
        pf.write_text(prompt, encoding="utf-8")
        print(f"[dispatch] MANUAL {agent} <- {brief['task_id']}；待办提示：agents/{agent}/inbox/{pf.name}"
              f"；完成后 `teamai submit {brief['task_id']} --as {agent}`")
        return

    # codebuddy：用 CodeBuddy 的 agent CLI `buddycn chat --mode agent` 触发执行
    if backend == "codebuddy":
        pf = brief_path.with_suffix(".prompt.md")
        pf.write_text(prompt, encoding="utf-8")
        ws = ROOT / "agents" / agent / "workspace"
        ws.mkdir(parents=True, exist_ok=True)
        if not Path(BUDDYCN).exists():
            print(f"[dispatch] 未找到 buddycn（{BUDDYCN}），改为手动：agents/{agent}/inbox/{pf.name}")
            return
        cmd = [BUDDYCN, "chat", "--mode", "agent", "--new-window", prompt]
        try:
            subprocess.Popen(cmd, cwd=str(ws))
            print(f"[dispatch] CodeBuddy agent 已触发（buddycn chat --mode agent）{agent} <- {brief['task_id']}"
                  f"「{brief.get('title')}」")
        except Exception as e:
            print(f"[dispatch] buddycn 触发失败：{e}；待办提示：agents/{agent}/inbox/{pf.name}")
        done = brief_path.parent / "done"
        done.mkdir(exist_ok=True)
        (done / brief_path.name).write_text(
            json.dumps({**brief, "_backend": "codebuddy", "_launched": True}, ensure_ascii=False, indent=2),
            encoding="utf-8")
        brief_path.unlink()
        return

    ws = ROOT / "agents" / agent / "workspace"
    ws.mkdir(parents=True, exist_ok=True)
    if backend == "opencode" and not _ensure_opencode_config():
        print("[dispatch] 警告：未找到 DeepSeek key（env DEEPSEEK_API_KEY 或 bootstrap/deepseek.key）")
    model = os.environ.get("TEAMAI_OPENCODE_MODEL", "deepseek/deepseek-flash")
    lane = "long" if brief.get("lane") == "long" else "short"
    # workspace 隔离是可选的：默认 root，显式 workspace 才切 cwd 并加锁。
    run_root = ROOT
    ws_lock = None
    ws_mod = None
    brief_ws = str(brief.get("workspace") or "root")
    if brief_ws not in ("", "root"):
        try:
            from runtime import workspace as ws_mod
            run_root = ws_mod.allocate(ROOT, brief.get("task_id") or "unknown", lane)
            ws_lock = ws_mod.lock(run_root)
            print(f"[dispatch] workspace={run_root.relative_to(ROOT)}")
        except Exception as e:  # noqa: BLE001
            print(f"[dispatch] workspace unavailable, falling back root: {e}")
            run_root, ws_lock, ws_mod = ROOT, None, None
    # 单次 run 的软预算：到点先保存断点，不再直接把任务判失败。
    default_timeout = "1800" if lane == "long" else "300"
    timeout = int(os.environ.get(f"TEAMAI_{lane.upper()}_TIMEOUT",
                                os.environ.get("TEAMAI_DISPATCH_TIMEOUT", default_timeout)))
    print(f"[dispatch] {agent} <- {brief['task_id']} lane={lane} {brief.get('title')}  "
          f"(backend={backend}, model={model}, timeout={timeout}s)")
    # 上报 start（看板+工作群），随后每 HEARTBEAT 秒心跳 progress（仅看板+日志），不阻塞执行
    _report_progress(agent, base, "start", brief, post=True)
    t0 = time.time()
    stop_hb = threading.Event()
    hb_thread = threading.Thread(
        target=_heartbeat, args=(agent, base, brief, t0, stop_hb), daemon=True)
    hb_thread.start()
    # 统一走 LLM 适配层（app/llm）；工作目录用项目根，避免沙箱权限拒绝
    timed_out = False
    try:
        import sys as _sys
        if str(ROOT) not in _sys.path:
            _sys.path.insert(0, str(ROOT))
        from core.llm import get as _llm_get
        res = _llm_get(backend).run(prompt, model=model, cwd=str(run_root),
                                    title=f"{agent}:{brief['task_id']}", timeout=timeout,
                                    env_extra={"TEAMAI_URL": base})
        out, rc = res.text, res.returncode
        if not res.ok and "timeout" in (res.text or "").lower():
            timed_out = True
    except Exception as e:
        out, rc = f"[dispatch] llm err: {e}", None
    stop_hb.set()
    if ws_mod is not None and ws_lock is not None:
        try:
            got = ws_mod.collect(run_root, ROOT)
            if got:
                print(f"[dispatch] collected {len(got)} workspace artifact(s)")
        except Exception as e:  # noqa: BLE001
            print(f"[dispatch] workspace collect err: {e}")
        finally:
            ws_mod.unlock(ws_lock)
    elapsed = int(time.time() - t0)
    ok = (rc == 0)
    # 长任务超时不是失败：保存阶段断点、置 paused、让出执行位。
    if not ok and timed_out and lane == "long":
        if _pause_timeout(agent, base, brief, brief_path, t0, elapsed):
            _report_progress(agent, base, "progress", brief,
                             {"paused": True, "elapsed_s": elapsed, "reason": "timeout"})
            return
    # ★ A4 闭环，顺序不能换：① 确保有交付帖（没有就代发）② 校验/补挂附件 ③ 才 submit。
    #   少任何一步，任务都会卡在"缺交付帖/缺附件"的提交门禁上。
    post_state = _ensure_delivery_post(agent, base, brief, out or "") if ok else "skip"
    attach_state = _ensure_artifact_attached(agent, base, brief, t0)
    # ★ P1A/A4：状态推进权在这里——opencode 已经退出，此刻才是 review 的合法时点。
    submit_state = "skip"
    if ok:
        if str(post_state).startswith("failed"):
            submit_state = f"failed:no-delivery-post({post_state})"
            print(f"[submit] ⚠️ {agent} {brief.get('task_id')} 无可用交付帖，放弃提交（简报进 failed/）")
        else:
            try:
                submit_state = _submit_after_run(agent, base, brief, exit_code=rc)
            except Exception as e:  # noqa: BLE001
                # fail-closed：状态推进异常绝不假装完成，brief 进 failed/ 等人看。
                submit_state = f"failed:submit-exc:{type(e).__name__}"
                print(f"[submit] ⚠️ 状态推进异常（任务保持原状态）：{e}")
    _report_progress(agent, base, "done" if ok else "failed", brief,
                     {"elapsed_s": elapsed, "exit_code": rc, "timeout": timed_out,
                      "post": post_state, "attach": attach_state, "submit": submit_state,
                      "err": None if ok else (out or "")[-600:]}, post=True)
    print(f"[dispatch] exit={rc}{' (timeout)' if timed_out else ''} elapsed={elapsed}s "
          f"ok={ok} submit={submit_state}")
    if not ok:
        print(f"[dispatch] ⚠ 执行**未成功**（backend={backend}）：{(out or '')[:300]}")
        act = _handle_failure(agent, base, brief, timed_out, rc, out or "")
        print(f"[dispatch] 处置={act}（超时/失败不再卡整队；P2/P3 直接放弃，P0/P1 最多重试 1 次）")
    # 只有"执行成功 + 已提交评审"才进 done/；其余进 failed/ 等人看，
    # 绝不把"跑完了但没提交"的简报塞进 done/ 假装收工（否则队列上看起来一切正常）。
    dest = "done" if (ok and submit_state == "ok") else "failed"
    outdir = brief_path.parent / dest
    outdir.mkdir(exist_ok=True)
    (outdir / brief_path.name).write_text(
        json.dumps({**brief, "_backend": backend, "_exit": rc, "_timeout": timed_out,
                    "_post": post_state, "_submit": submit_state, "_attach": attach_state,
                    "_tail": (out or "")[-2000:]},
                   ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        brief_path.unlink()
    except FileNotFoundError:
        pass   # 并发 dispatcher 已处理同一简报（竞态），无害
    print(f"[dispatch] brief -> inbox/{dest}/{brief_path.name}")


# ---------------------------------------------------------------------------
# 取活排序（t-6ce29ebd）：按 (priority 升序, 文件 mtime 升序) 取简报。
# 旧实现 `sorted(glob("*.json"))` 只按**任务 id 字母序**，brief 里的 priority 完全没被用
# → 实测现象：Bob 在做一个 P2，而 6 个 P0 在排队（只能靠人工停放 brief 纠偏）。
# 语义：priority 数值**越小越先做**（DB 里 P0=1、P1=2、P2=3）；同优先级**先进先出**（FIFO）。
# 缺 priority / 坏简报不因排序而崩——排到最后（_PRIORITY_UNSET），并保持 FIFO，绝不静默改变语义。
# ---------------------------------------------------------------------------
_PRIORITY_UNSET = 10 ** 6   # 缺失/非法 priority 的哨兵值：视为最低优先级（排最后）


def _brief_priority(path: Path) -> int:
    """读简报的 priority；缺失/非法 → _PRIORITY_UNSET（最低，排最后）。"""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict) and data.get("priority") is not None:
            return int(data["priority"])
    except Exception:  # noqa: BLE001 —— 坏文件不阻塞取活排序
        pass
    return _PRIORITY_UNSET


def _brief_mtime(path: Path) -> float:
    """文件 mtime（FIFO 第二判据）；stat 失败 → +inf（排最后）。"""
    try:
        return path.stat().st_mtime
    except OSError:
        return float("inf")


def _brief_task_id(path: Path) -> str:
    """读简报里的 task_id；不是简报（无 task_id / 坏 JSON）→ 空串。"""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return str(data.get("task_id") or "")
    except Exception:  # noqa: BLE001
        pass
    return ""


def _briefs(agent: str) -> list[Path]:
    """收件箱待办简报，按 **(priority 升序, 文件 mtime 升序)** 排序。

    priority 数值越小越先做（P0=1 → P1=2 → P2=3）；同优先级按 mtime 升序先进先出。

    ★ P1A/A5（2026-10-30 部署实测）：只认"真简报"。
      原来 `glob("*.json")` 把 `inbox/_attempts.json`（重试计数记账文件）也当成一份简报，
      启动日志里出现 `收件箱 1 件 → _attempts(p1000000)` 并去抢 lease。
      现在：下划线开头的记账文件跳过；没有 task_id 的 JSON 跳过。
    """
    d = _inbox_dir(agent)
    if not d.exists():
        return []
    files = []
    for p in d.glob("*.json"):
        if not p.is_file() or p.name.startswith("_"):
            continue
        if not _brief_task_id(p):
            print(f"[dispatch] 跳过非简报文件：{p.name}（缺 task_id）")
            continue
        files.append(p)
    return sorted(files, key=lambda p: (_brief_priority(p), _brief_mtime(p)))


def _lease_path(agent: str, task_id: str) -> Path:
    return _inbox_dir(agent) / f".running-{task_id}.lock"


def _acquire_lease(agent: str, task_id: str) -> Path | None:
    """同一 task 只允许一个 dispatcher 执行。

    两个 chatroom/旧进程即使看到同一份 brief，也只能有一个拿到 lease；
    另一个跳过，不会出现“先报 DUPLICATE、又照样执行”。
    """
    if not task_id:
        return None
    p = _lease_path(agent, task_id)
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(p), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
        return p
    except FileExistsError:
        try:
            old = int(p.read_text(encoding="utf-8").strip() or "0")
            os.kill(old, 0)
            return None  # 仍有 live 执行者
        except Exception:  # noqa: BLE001
            p.write_text(str(os.getpid()), encoding="utf-8")
            return p


def _release_lease(path: Path | None) -> None:
    if path is None:
        return
    try:
        path.unlink()
    except FileNotFoundError:
        pass


def _task_active(agent: str, base: str, task_id: str) -> bool | None:
    """任务是否仍归本 agent 且处于可执行状态。

    None = 查询失败（网络/服务不可用）：保持旧行为，不因临时断网误删简报。
    False = 明确不能执行：done/review/blocked/cancelled/backlog，或已改派别人。
    """
    if not task_id:
        return False
    mod = _load_teamai_module()
    if mod is None:
        return None
    try:
        d = mod.call("GET", f"/v1/tasks/{task_id}", agent_id=agent)
    except SystemExit as exc:
        # teamai.call() sys.exit()s on HTTP errors.  A 404 means the brief
        # belongs to another/deleted DB and must be quarantined, not crash the
        # whole dispatcher loop every cycle.
        msg = str(exc)
        if "HTTP 404" in msg or "not found" in msg.lower():
            return False
        return None
    except Exception:  # noqa: BLE001
        return None
    task = (d or {}).get("task") or {}
    if not task:
        return False
    status = task.get("status")
    assigned = task.get("assigned_to")
    if status not in ("claimed", "in_progress"):
        return False
    if assigned and assigned != agent:
        return False
    return True


def _quarantine_brief(agent: str, path: Path, reason: str) -> None:
    """把旧/失效简报移到 inbox/stale/，保留审计，不再参与派活。"""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        data = {"_raw": path.name}
    data["_stale_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    data["_stale_reason"] = reason
    stale = path.parent / "stale"
    stale.mkdir(parents=True, exist_ok=True)
    dest = stale / path.name
    dest.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        path.unlink()
    except FileNotFoundError:
        pass
    print(f"[dispatch] stale brief {path.stem} -> inbox/stale/ ({reason})")


def pending(agent: str) -> list[Path]:
    """向后兼容别名：等价于 `_briefs(agent)`（旧调用点仍可用）。"""
    return _briefs(agent)


def agents() -> list[str]:
    d = ROOT / "agents"
    human = "human"
    try:
        import sys
        if str(ROOT) not in sys.path:
            sys.path.insert(0, str(ROOT))
        from core import db as _db
        conn = _db.connect()
        row = conn.execute("SELECT id FROM agents WHERE kind='human' LIMIT 1").fetchone()
        if row:
            human = row[0]
        conn.close()
    except Exception:
        pass
    return sorted(p.name for p in d.iterdir() if (p / ".key").exists() and p.name != human)


_LAST_GC = 0.0
GC_INTERVAL_S = int(os.environ.get("TEAMAI_BRIEF_GC_INTERVAL", "300"))


def _housekeeping(force: bool = False) -> None:
    """P1A/A5+A3：周期清扫——终态任务的残留 brief 搬走，过期 claim 租约回收。

    这是"同事务"之外的兜底：进程崩溃、断电、人工改库都会留下不一致，
    不靠事后人工发现，靠每 5 分钟一次的对账。
    """
    global _LAST_GC
    now = time.time()
    if not force and now - _LAST_GC < GC_INTERVAL_S:
        return
    _LAST_GC = now
    try:
        from core import brief_gc as _bg
        st = _bg.scan()
        if st.get("moved_done") or st.get("moved_stale") or st.get("errors"):
            print(f"[dispatch] brief GC: 扫描 {st['scanned']} / 归 done {st['moved_done']} / "
                  f"归 stale {st['moved_stale']} / 错误 {st['errors']}")
    except Exception as e:  # noqa: BLE001
        print(f"[dispatch] brief GC 跳过（{e}）")
    try:
        import sqlite3 as _sql
        from core import message_route as _mr
        from core.db import DB_PATH as _DB
        c = _sql.connect(_DB, timeout=5)
        try:
            n = _mr.release_expired(c)
        finally:
            c.close()
        if n:
            print(f"[dispatch] message_route 回收过期租约 {n} 条")
    except Exception as e:  # noqa: BLE001
        print(f"[dispatch] 租约回收跳过（{e}）")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--as", dest="agent")
    ap.add_argument("--backend", choices=["opencode", "codebuddy", "manual"],
                    help="覆盖执行后端（默认读 agents/<id>/backend）")
    ap.add_argument("--url", default=os.environ.get("TEAMAI_URL", "http://127.0.0.1:6080"))
    ap.add_argument("--ca", help="CA 证书路径（https）")
    ap.add_argument("--interval", type=int, default=60)
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--verify-attach", metavar="TASK_ID",
                    help="只做一次「完成即校验附件」守卫（不派活）：查任务帖→缺附件则扫描本轮产物补挂")
    ap.add_argument("--dry-run", action="store_true", help="配合 --verify-attach：只报告不补挂")
    a = ap.parse_args()
    base = a.url.rstrip("/")
    os.environ["TEAMAI_URL"] = base
    if a.ca:
        os.environ["TEAMAI_CA"] = a.ca

    # 单次校验模式：只跑「附件兜底」守卫并退出（便于离线/一次性验证，不派活、不加锁）
    if a.verify_attach:
        agent = a.agent or "bob"
        brief = {"task_id": a.verify_attach, "title": a.verify_attach}
        state = _ensure_artifact_attached(agent, base, brief, time.time() - 86400,
                                          dry_run=a.dry_run)
        print(f"[verify] state={state}")
        return

    # 单例锁：同一 agent 只允许一个 dispatcher（防重复进程导致简报不被消费）
    lock_key = a.agent or "all"
    lock = ROOT / "runtime" / f".dispatcher.{lock_key}.lock"
    lock.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
    except FileExistsError:
        alive = False
        old = None
        try:
            old = int(lock.read_text().strip() or 0)
            os.kill(old, 0)
            alive = True
        except Exception:
            alive = False
        if alive:
            print(f"[dispatch] 已有实例在跑（{lock.name} pid={old}），本进程退出")
            return
        lock.write_text(str(os.getpid()))
    import atexit
    atexit.register(lambda: lock.unlink(missing_ok=True))

    _housekeeping(force=True)          # P1A/A5：启动即对账（清历史残留）
    while True:
        _housekeeping()                # 之后每 GC_INTERVAL_S 一次
        targets = [a.agent] if a.agent else agents()
        for ag in targets:
            briefs = _briefs(ag)
            if briefs:
                ordered = ", ".join(f"{b.stem}(p{_brief_priority(b)})" for b in briefs)
                print(f"[dispatch] {ag} 收件箱 {len(briefs)} 件，按 (priority 升序, mtime 升序) 取活 → {ordered}")
            for b in briefs:
                lease = None
                try:
                    brief = json.loads(b.read_text(encoding="utf-8"))
                    task_id = str(brief.get("task_id") or "")
                    lease = _acquire_lease(ag, task_id)
                    if lease is None:
                        print(f"[dispatch] skip {b.stem}: another executor holds task lease")
                        continue
                    active = _task_active(ag, base, task_id)
                    if active is False:
                        _quarantine_brief(ag, b, "task not claimed/in_progress or assigned elsewhere")
                        continue
                    run_one(ag, b, base, backend=a.backend)
                except Exception as e:
                    print(f"[dispatch] error on {b}: {e}")
                finally:
                    _release_lease(lease)
        if a.once:
            break
        time.sleep(a.interval)


if __name__ == "__main__":
    main()
