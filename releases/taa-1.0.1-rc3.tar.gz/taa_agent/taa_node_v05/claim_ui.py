"""Gate 9A: installer browser handoff to the center claim page."""
from __future__ import annotations

import pathlib
import threading
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable

from .center import CenterClient, CenterError
from .identity import load_state, now_iso, save_state


class _Callback:
    def __init__(self, lang: str = "zh-CN") -> None:
        self.event = threading.Event()
        self.query: dict[str, list[str]] = {}
        outer = self
        if lang == "zh-CN":
            body = ("<html><body><h3>TAA 认领完成</h3>"
                    "<p>可以关闭本页，回到本地 TAA。</p></body></html>").encode("utf-8")
        else:
            body = b"<html><body><h3>TAA claim complete</h3><p>You can close this tab.</p></body></html>"

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                outer.query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                payload = body
                self.send_response(200)
                self.send_header("content-type", "text/html; charset=utf-8")
                self.send_header("content-length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)
                outer.event.set()

            def log_message(self, *args):
                pass

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *args):
        self.server.shutdown()
        self.server.server_close()

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.server.server_address[1]}/callback"


def _register_agents(client: CenterClient, state: Any) -> None:
    for agent in state.agents:
        try:
            result = client.register_agent(
                node_key=state.node.node_key,
                agent_id=agent.agent_id,
                agent_key=agent.agent_key,
                display_name=agent.display_name,
            )
            assigned = str((result.get("agent") or {}).get("display_name") or "")
            if assigned:
                agent.display_name = assigned
        except CenterError as exc:
            if exc.status != 409:
                raise
            # A retry / legacy row can already exist under a name assigned by
            # the center (for example after a collision migration).
            try:
                me = client.agent_me(agent_key=agent.agent_key)
                assigned = str((me.get("agent") or {}).get("display_name") or "")
                if assigned:
                    agent.display_name = assigned
            except Exception:  # noqa: BLE001
                pass


def claim_with_browser(
    home: pathlib.Path,
    *,
    base: str,
    lang: str = "zh-CN",
    timeout: int = 180,
    open_browser: bool = True,
    on_url: Callable[[str], None] | None = None,
) -> dict[str, Any]:
    home = pathlib.Path(home).expanduser()
    state = load_state(home)
    client = CenterClient(base)
    claim_token = ""
    try:
        reg = client.register_node(
            node_id=state.node.node_id,
            node_key=state.node.node_key,
            alias=state.node.alias,
            fingerprint_hash=state.node.fingerprint_hash,
            enc_pubkey=state.node.enc_pubkey,
        )
        claim_token = str(reg.get("claim_token") or "")
    except CenterError as exc:
        if exc.status != 409:
            raise
        current = client.node_me(node_key=state.node.node_key)
        node = current.get("node") or {}
        if node.get("status") == "active":
            state.center.base = base.rstrip("/")
            state.center.owner_id = str(node.get("owner_id") or "")
            state.center.claimed_at = state.center.claimed_at or now_iso()
            _register_agents(client, state)
            save_state(home, state)
            return {"ok": True, "status": "active", "node_id": state.node.node_id,
                    "owner_id": state.center.owner_id, "already": True}
        refreshed = client.refresh_claim(node_key=state.node.node_key)
        claim_token = str(refreshed.get("claim_token") or "")
    if not claim_token:
        raise RuntimeError("center did not return a claim token")

    with _Callback(lang) as cb:
        url = (f"{base.rstrip('/')}/v05/claim?claim_token={urllib.parse.quote(claim_token)}"
               f"&callback={urllib.parse.quote(cb.url)}&lang={urllib.parse.quote(lang)}")
        print("CLAIM_URL=" + url)
        if on_url:
            on_url(url)
        if open_browser:
            webbrowser.open(url)
        cb.event.wait(timeout)
        if not cb.event.is_set():
            return {"ok": False, "status": "pending", "node_id": state.node.node_id,
                    "hint": "claim page was not completed; retry with claim-ui"}
        status = (cb.query.get("status") or [""])[0]
        owner_id = (cb.query.get("owner_id") or [""])[0]
        owner_username = (cb.query.get("owner_username") or [""])[0]
        owner_email = (cb.query.get("owner_email") or [""])[0]
        node_id = (cb.query.get("node_id") or [state.node.node_id])[0]
        if status != "ok" or not owner_id:
            return {"ok": False, "status": "pending", "node_id": state.node.node_id,
                    "hint": "claim callback did not confirm ownership"}
        state.node.status = "active"
        state.center.base = base.rstrip("/")
        state.center.owner_id = owner_id
        state.center.claimed_at = now_iso()
        if owner_username:
            state.center.username = owner_username
        if owner_email:
            state.center.email = owner_email
        _register_agents(client, state)
        save_state(home, state)
        return {"ok": True, "status": "active", "node_id": node_id, "owner_id": owner_id}


def start_claim(home: pathlib.Path, *, base: str, lang: str = "zh-CN",
                timeout: int = 180) -> tuple[threading.Thread, str]:
    """Start claim in a daemon thread; return (thread, claim_url).

    The thread keeps the loopback callback server alive while the user completes
    the center page. The local identity is updated by claim_with_browser.
    """
    holder: dict[str, str] = {}
    ready = threading.Event()

    def on_url(url: str) -> None:
        holder["url"] = url
        ready.set()

    def run() -> None:
        try:
            claim_with_browser(home, base=base, lang=lang, timeout=timeout,
                               open_browser=False, on_url=on_url)
        except Exception:
            # The caller can inspect the identity/status; avoid killing the web process.
            pass

    thread = threading.Thread(target=run, daemon=True)
    thread.start()
    ready.wait(8)
    return thread, holder.get("url", "")


def ide_bootstrap_prompt(home: pathlib.Path, *, base: str) -> str:
    """Prompt to paste into opencode/codebuddy to start node registration."""
    home = pathlib.Path(home).expanduser()
    return f"""TAA Node v0.5 bootstrap

Run this command in the terminal on this computer:

python3 -m taa_node_v05 claim-ui --home {home} --base {base}

Then open the printed CLAIM_URL, sign in to an existing Owner or create one,
and confirm this computer. Report the final center owner id and node status.
Do not print node_key or agent_key.
"""
