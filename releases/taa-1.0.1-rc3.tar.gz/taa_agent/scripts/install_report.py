#!/usr/bin/env python3
"""install_report —— 安装后自检报告（P2.1 第一公里）。

回答一个问题：**这台机器现在能用了么？哪一步没过、下一步做什么。**

设计口径：
  * 只读：不写数据库、不改配置、不启动服务；
  * 零第三方依赖：只用标准库，安装器在依赖装坏时也能跑；
  * 三态：ok / warn（可继续，但该修）/ fail（走不到"发第一条指令"）；
  * **脱敏硬要求**：报告里不出现 key 明文、用户绝对路径、内网 IP（见 `_redact`）。

用法：
    ../venv/bin/python scripts/install_report.py                 # 报告写到 $TAA_HOME/install-report.{md,json}
    ../venv/bin/python scripts/install_report.py --home ~/.taa --port 6080
    ../venv/bin/python scripts/install_report.py --json-only     # 只输出 JSON 到 stdout
退出码：0 = 无 fail；1 = 有 fail（--no-fail 可强制 0）。
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import re
import socket
import sqlite3
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

SCHEMA = 1
LOOPBACK = "127.0.0.1"

# 报告要检查的目录骨架（缺一个就走不到"发第一条指令"）
LAYOUT_REQUIRED = ("core", "runtime", "static/index.html", "bin/taa", "requirements-core.txt")
# 最小运行依赖（与 requirements-core.txt 对齐）
DEPS = ("flask", "yaml", "cryptography", "PIL", "markdown")


# ------------------------------------------------------------------ 脱敏
_HOME_RE = re.compile(r"/(?:Users|home)/[A-Za-z0-9._-]+")
_TMP_RE = re.compile(r"/(?:var/folders|tmp|private/var/folders)/[^\s\"']*")
_KEY_RE = re.compile(r"\b(?:sk|taa|ak|ag)-?[A-Za-z0-9_-]{12,}\b")
_LAN_IP_RE = re.compile(r"\b(?:192\.168|10\.|172\.(?:1[6-9]|2\d|3[01]))(?:\.[0-9]{1,3}){1,3}\b")


def _redact(text: str) -> str:
    """把可能泄漏本机信息的片段替换掉。顺序敏感：先路径后 key。"""
    if not text:
        return ""
    out = str(text)
    home = str(Path.home())
    if home:
        out = out.replace(home, "~")
    out = _HOME_RE.sub("~", out)
    out = _TMP_RE.sub("<tmp>", out)
    out = _KEY_RE.sub("<redacted>", out)
    out = _LAN_IP_RE.sub("<lan-ip>", out)
    return out


# ------------------------------------------------------------------ 检查项
def _check(cid: str, title: str, status: str, detail: str = "", next_step: str = "") -> dict:
    assert status in ("ok", "warn", "fail")
    return {"id": cid, "title": title, "status": status,
            "detail": _redact(detail), "next_step": _redact(next_step)}


def _python_check(home: Path) -> dict:
    venv_py = home / "venv" / "bin" / "python"
    exe = venv_py if venv_py.is_file() else Path(sys.executable)
    try:
        out = subprocess.run([str(exe), "-c", "import sys;print('%d.%d' % sys.version_info[:2])"],
                             capture_output=True, text=True, timeout=15)
        ver = (out.stdout or "").strip()
        major_minor = tuple(int(x) for x in ver.split(".")) if re.fullmatch(r"\d+\.\d+", ver) else (0, 0)
    except Exception as exc:                                   # noqa: BLE001
        return _check("python", "Python 版本", "fail", f"{type(exc).__name__}: {exc}",
                      "确认 `$TAA_HOME/venv/bin/python` 可执行，或重跑安装器并设 TAA_PYTHON")
    if major_minor < (3, 10):
        return _check("python", "Python 版本", "fail", f"{ver}（需要 3.10+）",
                      "安装 Python 3.10+ 后重跑安装器（可设 TAA_PYTHON=/path/to/python3.12）")
    kind = "venv" if venv_py.is_file() else "系统解释器（未建 venv）"
    return _check("python", "Python 版本", "ok" if venv_py.is_file() else "warn",
                  f"{ver} · {kind}",
                  "" if venv_py.is_file() else "重跑安装器以创建 $TAA_HOME/venv")


def _layout_check(home: Path) -> dict:
    app = home / "app"
    if not app.is_dir():
        return _check("layout", "代码目录", "fail", f"缺少 {app.name}/",
                      "先跑安装器（scripts/install_v1.sh）；它会把运行时装到 $TAA_HOME/app")
    missing = [rel for rel in LAYOUT_REQUIRED if not (app / rel).exists()]
    if missing:
        return _check("layout", "代码目录", "fail", "缺 " + ", ".join(missing),
                      "安装包不完整：重新下载完整包后重跑安装器")
    return _check("layout", "代码目录", "ok", f"{len(LAYOUT_REQUIRED)} 项齐全")


def _deps_check(home: Path) -> dict:
    venv_py = home / "venv" / "bin" / "python"
    if not venv_py.is_file():
        return _check("deps", "运行依赖", "warn", "未建 venv，跳过依赖检查",
                      "重跑安装器（不加 --skip-deps）")
    code = "import {0}".format(", ".join(DEPS))
    try:
        out = subprocess.run([str(venv_py), "-c", code], capture_output=True, text=True, timeout=60)
    except Exception as exc:                                   # noqa: BLE001
        return _check("deps", "运行依赖", "fail", f"{type(exc).__name__}: {exc}",
                      "重跑安装器重新安装依赖")
    if out.returncode != 0:
        tail = (out.stderr or "").strip().splitlines()
        bad = next((ln.split("'")[1] for ln in tail if "ModuleNotFoundError" in ln and "'" in ln), "")
        return _check("deps", "运行依赖", "fail", (f"缺 {bad}" if bad else (tail[-1] if tail else "导入失败")),
                      "运行 `$TAA_HOME/venv/bin/python -m pip install -r $TAA_HOME/app/requirements-core.txt`")
    return _check("deps", "运行依赖", "ok", f"{len(DEPS)} 个核心包可导入")


def _render_check(home: Path) -> dict:
    """论证图/穿搭图渲染能力（2026-10-31 豆腐块事故的安装侧防线）。

    三项：① 中文字体文件可用；② playwright 与 chromium（决定渲染质量）；
    ③ **豆腐探针**：同一字号渲染「论证」与「结论」两张图，字节若相同说明两个
    不同汉字被画成同一堆方框（= 缺字形），必须判失败——这是"图能生成但全是□□"
    唯一可靠的自动判据。
    """
    venv_py = home / "venv" / "bin" / "python"
    app = home / "app"
    if not venv_py.is_file():
        return _check("render", "中文渲染", "warn", "未建 venv，跳过", "重跑安装器")
    code = r"""
import sys, io, hashlib
sys.path.insert(0, {app!r})
try:
    from PIL import Image, ImageDraw
except Exception as e:
    print("PIL_MISSING", e); raise SystemExit(0)
from core.arguments import cjk_font_path, load_cjk_font
fp = cjk_font_path()
def sig(s):
    f, _ = load_cjk_font(14)
    img = Image.new("RGB", (80, 24), "white")
    ImageDraw.Draw(img).text((2, 2), s, font=f, fill=(0, 0, 0))
    b = io.BytesIO(); img.save(b, "PNG")
    return hashlib.sha1(b.getvalue()).hexdigest()
same = sig("论证") == sig("结论")
pw = False
try:
    import playwright  # noqa: F401
    pw = True
except Exception:
    pass
from pathlib import Path
chromium = any(d.exists() and any(p.name.startswith("chromium") for p in d.iterdir())
               for d in (Path.home()/".cache"/"ms-playwright",
                         Path.home()/"Library"/"Caches"/"ms-playwright"))
print("FONT", fp or "-")
print("TOFU", 1 if same else 0)
print("PW", 1 if pw else 0)
print("CHROMIUM", 1 if chromium else 0)
""".format(app=str(app))
    try:
        out = subprocess.run([str(venv_py), "-c", code], capture_output=True, text=True, timeout=120)
    except Exception as exc:                                   # noqa: BLE001
        return _check("render", "中文渲染", "fail", f"{type(exc).__name__}: {exc}", "重跑安装器")
    txt = out.stdout or ""
    if "PIL_MISSING" in txt:
        return _check("render", "中文渲染", "fail", "Pillow 未安装，论证图无法渲染",
                      "pip install -r requirements-core.txt")
    if not txt.strip():
        # 旧包没有 core/fonts.py，或 venv 缺 Pillow → 直接看 stderr 首行点明
        tail = (out.stderr or "").strip().splitlines()
        why = tail[-1] if tail else "渲染探针无输出"
        return _check("render", "中文渲染", "warn", why[:160],
                      "升级到含 core/fonts.py 的版本，或 pip install Pillow")
    kv = dict(ln.split(" ", 1) for ln in txt.strip().splitlines() if " " in ln)
    font = kv.get("FONT", "-")
    tofu = kv.get("TOFU") == "1"
    pw = kv.get("PW") == "1"
    chromium = kv.get("CHROMIUM") == "1"
    if tofu:
        return _check("render", "中文渲染", "fail",
                      f"豆腐探针未过（字体={font}）：中文会渲染成方框",
                      "装 Hiragino Sans GB / Noto Sans CJK；或 pip install playwright "
                      "&& python -m playwright install chromium")
    quality = "playwright+chromium" if (pw and chromium) else (
        "pillow（无 chromium，质量较低）" if not (pw and chromium) else "pillow")
    status = "ok" if (pw and chromium) else "warn"
    return _check("render", "中文渲染", status,
                  f"中文正常，字体={font or '-'}，渲染={quality}",
                  "" if status == "ok" else
                  "pip install playwright && python -m playwright install chromium")


def _data_check(home: Path) -> dict:
    db = home / "data.db"
    stray = home / "app" / "data.db"
    if not db.is_file():
        return _check("data", "数据目录", "warn", "尚无 data.db（首次启动时自动创建）",
                      "启动服务后自动建库，无需手工处理")
    try:
        conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=5)
        try:
            n_tables = conn.execute(
                "SELECT count(*) FROM sqlite_master WHERE type='table'").fetchone()[0]
            agents = 0
            try:
                agents = conn.execute("SELECT count(*) FROM agents").fetchone()[0]
            except sqlite3.Error:
                pass
        finally:
            conn.close()
    except Exception as exc:                                   # noqa: BLE001
        return _check("data", "数据目录", "fail", f"data.db 打不开：{type(exc).__name__}",
                      "库可能被占用或损坏：先停服务，再备份后用 sqlite3 integrity_check 核对")
    detail = f"{n_tables} 张表 · {agents} 个 agent"
    if stray.is_file() and stray.stat().st_size > 0:
        return _check("data", "数据目录", "warn",
                      detail + "；app/data.db 仍有历史副本",
                      "历史残留不影响运行（统一路径已生效），确认无进程在用后可移入备份目录")
    return _check("data", "数据目录", "ok", detail)


def _port_open(port: int, timeout: float = 1.5) -> bool:
    try:
        with socket.create_connection((LOOPBACK, port), timeout=timeout):
            return True
    except OSError:
        return False


def _service_check(port: int) -> dict:
    if _port_open(port):
        return _check("service", "本地服务", "ok", f"{LOOPBACK}:{port} 在监听")
    return _check("service", "本地服务", "warn", f"{LOOPBACK}:{port} 未监听",
                  "启动服务：$TAA_HOME/app/taa start（或让安装器自动启动）")


def _http_get(url: str, timeout: float = 5.0) -> tuple[int, str]:
    req = urllib.request.Request(url, headers={"User-Agent": "taa-install-report"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, r.read(4096).decode("utf-8", "ignore")


def _version_check(port: int) -> dict:
    if not _port_open(port):
        return _check("version", "服务版本", "warn", "服务未运行，跳过",
                      "启动服务后重跑本报告")
    try:
        status, body = _http_get(f"http://{LOOPBACK}:{port}/v1/version")
        info = json.loads(body)
    except urllib.error.HTTPError as exc:
        return _check("version", "服务版本", "fail", f"HTTP {exc.code}",
                      "服务起来了但接口异常：查看 $TAA_HOME/runtime/*.log")
    except Exception as exc:                                   # noqa: BLE001
        return _check("version", "服务版本", "fail", f"{type(exc).__name__}",
                      "服务未正常响应：查看日志后重启")
    ver = info.get("runtime_version") or info.get("version") or "?"
    return _check("version", "服务版本", "ok" if status == 200 else "fail",
                  f"HTTP {status} · {ver}")


def _setup_check(port: int) -> dict:
    if not _port_open(port):
        return _check("setup", "认领向导", "warn", "服务未运行，跳过", "启动服务后重跑本报告")
    try:
        status, _ = _http_get(f"http://{LOOPBACK}:{port}/setup/")
    except urllib.error.HTTPError as exc:
        status = exc.code
    except Exception as exc:                                   # noqa: BLE001
        return _check("setup", "认领向导", "fail", f"{type(exc).__name__}",
                      "确认安装包含 taa_node_v05/，否则重装完整包")
    if status in (200, 302):
        return _check("setup", "认领向导", "ok", f"HTTP {status}")
    return _check("setup", "认领向导", "fail", f"HTTP {status}",
                  "安装包缺 onboarding 组件：重装完整包（身份模块应随仓打入，构建时不应为空）")


def _entry_check(home: Path, user_home: Path | None = None) -> dict:
    base = user_home or Path.home()
    cands = [base / ".local" / "bin" / "taa", home / "app" / "taa"]
    found = [p for p in cands if p.is_file() and os.access(p, os.X_OK)]
    if found:
        return _check("entry", "命令入口", "ok", f"{len(found)} 个可用")
    return _check("entry", "命令入口", "fail", "找不到可执行的 taa",
                  "重跑安装器写入 ~/.local/bin/taa；或直接用 $TAA_HOME/app/taa")


def collect(home: Path, port: int, user_home: Path | None = None) -> dict:
    checks = [
        _python_check(home),
        _layout_check(home),
        _deps_check(home),
        _render_check(home),
        _data_check(home),
        _service_check(port),
        _version_check(port),
        _setup_check(port),
        _entry_check(home, user_home),
    ]
    counts = {k: sum(1 for c in checks if c["status"] == k) for k in ("ok", "warn", "fail")}
    overall = "fail" if counts["fail"] else ("warn" if counts["warn"] else "ok")
    return {
        "schema": SCHEMA,
        "generated_at": _dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "taa_home": _redact(str(home)),
        "port": port,
        "overall": overall,
        "counts": counts,
        "checks": checks,
    }


# ------------------------------------------------------------------ 输出
_ICON = {"ok": "✅", "warn": "⚠️ ", "fail": "❌"}


def render_md(rep: dict) -> str:
    lines = [
        "# TAA 安装自检报告",
        "",
        f"- 时间：{rep['generated_at']}",
        f"- 安装目录：`{rep['taa_home']}` · 端口：{rep['port']}",
        f"- 结论：**{ {'ok': '可用', 'warn': '基本可用（有提醒项）', 'fail': '不可用'}[rep['overall']] }**"
        f"（通过 {rep['counts']['ok']} · 提醒 {rep['counts']['warn']} · 失败 {rep['counts']['fail']}）",
        "",
        "| 检查 | 结果 | 说明 |",
        "|---|---|---|",
    ]
    for c in rep["checks"]:
        lines.append(f"| {c['title']} | {_ICON[c['status']]} {c['status']} | {c['detail'] or '—'} |")
    todo = [c for c in rep["checks"] if c["status"] != "ok" and c["next_step"]]
    if todo:
        lines += ["", "## 需要处理", ""]
        for c in todo:
            lines.append(f"- **{c['title']}**：{c['next_step']}")
    else:
        lines += ["", "## 下一步", "", "浏览器打开 `http://127.0.0.1:%d/setup/` 认领 Owner，"
                  "然后在群里 @ 你的 agent 发第一条指令。" % rep["port"]]
    return "\n".join(lines) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description="TAA 安装后自检报告")
    ap.add_argument("--home", default=os.environ.get("TAA_HOME") or "~/.taa")
    ap.add_argument("--port", type=int, default=int(os.environ.get("TAA_HTTP_PORT") or 6080))
    ap.add_argument("--json-out", default="")
    ap.add_argument("--md-out", default="")
    ap.add_argument("--json-only", action="store_true", help="只把 JSON 打到 stdout，不落盘")
    ap.add_argument("--no-fail", action="store_true", help="即使有 fail 也退出 0")
    args = ap.parse_args()

    home = Path(args.home).expanduser().resolve()
    rep = collect(home, args.port)

    if args.json_only:
        print(json.dumps(rep, ensure_ascii=False, indent=2))
        return 0 if (args.no_fail or rep["overall"] != "fail") else 1

    md = render_md(rep)
    json_path = Path(args.json_out).expanduser() if args.json_out else home / "install-report.json"
    md_path = Path(args.md_out).expanduser() if args.md_out else home / "install-report.md"
    for path, body in ((json_path, json.dumps(rep, ensure_ascii=False, indent=2) + "\n"),
                       (md_path, _redact(md))):
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(body, encoding="utf-8")
        except OSError as exc:
            print(f"! 报告写不进去（{type(exc).__name__}）：{_redact(str(path))}", file=sys.stderr)

    for c in rep["checks"]:
        print(f"[{c['status'].upper():4}] {c['title']}：{c['detail']}")
        if c["status"] != "ok" and c["next_step"]:
            print(f"       → {c['next_step']}")
    print(f"\n结论：{rep['overall']}（ok={rep['counts']['ok']} warn={rep['counts']['warn']} "
          f"fail={rep['counts']['fail']}）")
    print(f"报告：{_redact(str(md_path))}")
    return 0 if (args.no_fail or rep["overall"] != "fail") else 1


if __name__ == "__main__":
    raise SystemExit(main())
