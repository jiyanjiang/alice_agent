#!/usr/bin/env python3
"""One-shot agent-name repair: center is the authority, agent_id is the key.

Run on each node (Host and Delta):

    cd ~/.taa/app
    ../venv/bin/python scripts/fix_agent_names.py --dry-run
    ../venv/bin/python scripts/fix_agent_names.py --apply

It reads the node's center groups, builds ``agent_id -> canonical name`` and
renames the local agents in a collision-safe transaction (temporary names first,
so Alice/Alicia-style swaps do not violate the case-insensitive unique index).
It never changes agent_id, history, owner_id, or unrelated human rows.
"""
from __future__ import annotations

import argparse
import os
import re
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HOME = Path(os.environ.get("TAA_HOME") or (Path.home() / ".taa")).expanduser()
DB = Path(os.environ.get("TEAMAI_DB") or (HOME / "data.db"))
sys.path.insert(0, str(ROOT))


def ensure_agent_columns(conn: sqlite3.Connection) -> None:
    """Old installs may predate owner_id/owner_name; repair names without them."""
    cols = {str(r[1]) for r in conn.execute("PRAGMA table_info(agents)").fetchall()}
    if "owner_id" not in cols:
        conn.execute("ALTER TABLE agents ADD COLUMN owner_id TEXT")
    if "owner_name" not in cols:
        conn.execute("ALTER TABLE agents ADD COLUMN owner_name TEXT")
    conn.commit()


def center_names() -> dict[str, tuple[str, str]]:
    """agent_id -> (canonical display name, owner_id) from center groups."""
    from taa_node_v05.identity import load_state
    from taa_node_v05.center import CenterClient

    st = load_state(HOME)
    if not (st.center.base and st.node.node_key):
        raise RuntimeError("no center identity/node key on this machine")
    cl = CenterClient(st.center.base)
    groups = cl.groups_for_node(node_key=st.node.node_key).get("groups") or []
    out: dict[str, tuple[str, str]] = {}
    for g in groups:
        gid = str(g.get("group_id") or "")
        if not gid:
            continue
        detail = cl.group_for_node(node_key=st.node.node_key, group_id=gid)
        for m in detail.get("members") or []:
            aid = str(m.get("agent_id") or "").strip()
            name = str(m.get("agent_name") or "").strip()
            if aid and name:
                out[aid] = (name, str(m.get("owner_id") or ""))
    return out


def plan(conn, wanted: dict[str, tuple[str, str]]) -> tuple[list[dict], list[str]]:
    rows = {str(r["id"]): r for r in conn.execute(
        "select id,name,kind,owner_id,owner_name,full_name from agents").fetchall()}
    # All human handles and Owner handles reserve the same namespace.
    reserved: set[str] = set()
    for r in rows.values():
        if str(r["kind"]) == "human":
            reserved.add(str(r["name"] or "").lower())
        if r["owner_name"]:
            reserved.add(str(r["owner_name"]).lower())
    changes: list[dict] = []
    errors: list[str] = []
    for aid, (name, owner_id) in wanted.items():
        r = rows.get(aid)
        if not r or str(r["kind"]) != "ai":
            continue
        old = str(r["name"] or "")
        if old == name:
            continue
        if name.lower() in reserved:
            errors.append(f"{aid}: canonical {name!r} collides with a human/Owner handle")
            continue
        full = str(r["full_name"] or "")
        new_full = (f"{name}@{full.rsplit('@', 1)[1]}" if "@" in full else name)
        changes.append({"id": aid, "old": old, "new": name, "full": new_full,
                        "owner_id": owner_id, "old_full": full})
    names = [c["new"].lower() for c in changes]
    if len(set(names)) != len(names):
        errors.append("canonical names are not unique")
    # A target may collide with an unrelated AI that is not being renamed.
    changed_ids = {c["id"] for c in changes}
    for r in rows.values():
        if str(r["kind"]) != "ai" or str(r["id"]) in changed_ids:
            continue
        if str(r["name"] or "").lower() in set(names):
            errors.append(f"{r['id']}: unrelated agent already uses {r['name']!r}")
    return changes, errors


def apply(conn, changes: list[dict]) -> None:
    if not changes:
        return
    # Free all old names first; then install canonical names. This is what
    # makes an Alice <-> Alicia swap legal under the unique index.
    for c in changes:
        conn.execute("update agents set name=? where id=?",
                     (f"__taa_name_{c['id'][-12:]}", c["id"]))
    conn.commit()
    for c in changes:
        conn.execute("update agents set name=?, full_name=?, owner_id=coalesce(nullif(?,''), owner_id) where id=?",
                     (c["new"], c["full"], c["owner_id"], c["id"]))
    conn.commit()
    # persona.yaml is a local projection; keep its name aligned.
    for c in changes:
        p = ROOT / "agents" / c["id"] / "persona.yaml"
        if not p.is_file():
            continue
        try:
            text = p.read_text(encoding="utf-8")
            if re.search(r"(?m)^name:\s*.*$", text):
                text = re.sub(r"(?m)^name:\s*.*$", f"name: {c['new']}", text, count=1)
            else:
                text = f"name: {c['new']}\n" + text
            p.write_text(text, encoding="utf-8")
        except Exception as exc:  # noqa: BLE001
            print(f"WARN persona {c['id']}: {exc}", file=sys.stderr)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    if not DB.exists():
        print(f"DB not found: {DB}", file=sys.stderr)
        return 2
    wanted = center_names()
    conn = sqlite3.connect(DB, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout=30000")
    try:
        ensure_agent_columns(conn)
        changes, errors = plan(conn, wanted)
        print(f"center_agents={len(wanted)} changes={len(changes)} db={DB}")
        for c in changes:
            print(f"  {c['id']}: {c['old']!r} -> {c['new']!r}  full={c['full']!r}")
        for e in errors:
            print("ERROR", e)
        if errors:
            return 1
        if a.apply and not a.dry_run:
            apply(conn, changes)
            print("applied")
        else:
            print("dry-run" if a.dry_run or not a.apply else "")
        # Re-audit local AI names after the transaction.
        names = [str(r["name"] or "").lower() for r in conn.execute(
            "select name from agents where kind='ai'")]
        dup = sorted({n for n in names if names.count(n) > 1})
        print("duplicate_ai_names", dup)
        return 0 if not dup else 1
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
