#!/usr/bin/env python3
"""Replay local-origin group messages that never reached peer/center.

Default is dry-run.  It only replays local human/agent messages; remote-human
stubs and system rows are deliberately excluded.
"""
from __future__ import annotations

import argparse
import json
import os
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from core import outbox  # noqa: E402


def db_path() -> Path:
    explicit = os.environ.get("TEAMAI_UI_DB")
    if explicit:
        return Path(explicit)
    for candidate in (ROOT / "data.db",
                      Path(os.environ.get("TAA_HOME") or (Path.home() / ".taa")) / "data.db"):
        try:
            con = sqlite3.connect(f"file:{candidate}?mode=ro", uri=True)
            ok = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='room_messages'").fetchone()
            con.close()
            if ok:
                return candidate
        except Exception:  # noqa: BLE001
            continue
    return ROOT / "data.db"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--room", default="")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    con = sqlite3.connect(db_path(), timeout=30)
    con.row_factory = sqlite3.Row
    try:
        before = outbox.pending(con, a.room)
        result = {"dry_run": not a.apply, "before": before, "after": before}
        if a.apply:
            from core import app_ui
            rooms = sorted({str(r["room_id"]) for r in before})
            errors = []
            for rid in rooms:
                try:
                    app_ui.sync_group_messages_for_room(rid)
                except Exception as exc:  # noqa: BLE001
                    errors.append({"room": rid, "error": str(exc)[:200]})
            # Let the direct/center write commit before auditing.
            result["after"] = outbox.pending(con, a.room)
            result["errors"] = errors
        if a.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(f"pending={len(before)} dry_run={not a.apply}")
            for r in before:
                print(f"  {r['id']} {r['room_id']} {r['agent_id']} {r['client_message_id'] or '-'}")
            if a.apply:
                print(f"remaining={len(result['after'])}")
                for e in result.get("errors", []):
                    print("ERR", e)
        return 0 if not result.get("errors") else 1
    finally:
        con.close()


if __name__ == "__main__":
    raise SystemExit(main())
