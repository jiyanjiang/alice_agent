"""引导：主密钥 + root 入网令牌 + 本机节点 + 本地 agent 缺省发 key（docs/03 §4/§13）。

幂等：已存在的不重建、不重打印。首次运行会把 root 令牌与本地 agent 的 key 各打印一次。
"""
from __future__ import annotations

import json
import os
import uuid
from pathlib import Path

import yaml

from . import community, config, db, memory, nodeinfo, persona as persona_mod, security

ROOT = Path(__file__).resolve().parent.parent
BOOTSTRAP_DIR = ROOT / "bootstrap"
ENROLL_FILE = BOOTSTRAP_DIR / "enroll.key"


def _write_secret(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    os.chmod(path, 0o600)


def _ensure_root_token(conn) -> tuple[str, bool]:
    row = conn.execute("SELECT token_id FROM enroll_tokens WHERE kind='root' LIMIT 1").fetchone()
    if row:
        token = None
        if ENROLL_FILE.exists():
            token = ENROLL_FILE.read_text(encoding="utf-8").strip()
        return token, False
    token = security.gen_token()
    conn.execute(
        "INSERT INTO enroll_tokens(token_id, token_hash, kind, created_by) VALUES (?,?,?,?)",
        (security.gen_key_id(), security.hash_secret(token), "root", "bootstrap"),
    )
    _write_secret(ENROLL_FILE, token)
    return token, True


def _ensure_node(conn) -> tuple[str, str]:
    info = nodeinfo.detect()
    alias, code = info["alias"], info["node_code"]
    row = conn.execute("SELECT id FROM nodes WHERE id=?", (alias,)).fetchone()
    if row:
        conn.execute(
            "UPDATE nodes SET node_code=?, disk_free_gb=?, ram_gb=?, lan_ip=?, "
            "last_seen=datetime('now','localtime') WHERE id=?",
            (code, info["disk_free_gb"], info["ram_gb"], info["lan_ip"], alias),
        )
        return alias, code
    conn.execute(
        "INSERT INTO nodes(id, hostname, alias, node_code, os, arch, cpu_model, cpu_cores, ram_gb, gpu, "
        "disk_total_gb, disk_free_gb, lan_ip, python_version, available_ides, tags, is_main, last_seen) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now','localtime'))",
        (alias, info["hostname"], alias, code, info["os"], info["arch"], info["cpu_model"],
         info["cpu_cores"], info["ram_gb"], info["gpu"], info["disk_total_gb"],
         info["disk_free_gb"], info["lan_ip"], info["python_version"],
         json.dumps(info["available_ides"]), json.dumps(["main"]), 1),
    )
    return alias, code


def _issue_key(conn, agent_id: str) -> dict:
    key_id = security.gen_key_id()
    key = security.gen_key()
    conn.execute(
        "INSERT INTO keys(key_id, agent_id, key_hash, key_enc, label) VALUES (?,?,?,?,?)",
        (key_id, agent_id, security.hash_secret(key), security.encrypt(key), "primary"),
    )
    return {"key_id": key_id, "key": key}


def _ensure_primary_agent(conn, node_id: str, node_code: str | None = None) -> list[dict]:
    """注册**一个主 agent**（human + 1 agent）。id/name/template 来自 config.agent.*。

    不再遍历所有 persona 目录；已存在的 agent（如 alice/bob）不受影响。
    """
    aid = (config.get("agent.id", "") or "").strip() or "agent"
    name = (config.get("agent.name", "") or "").strip() or aid.capitalize()
    from .agent_names import ensure_unique_name
    row = conn.execute("SELECT * FROM agents WHERE id=?", (aid,)).fetchone()
    name, _renamed = ensure_unique_name(conn, name, exclude_agent_id=aid if row else "")
    tpl = (config.get("agent.template", "") or "").strip() or "female"
    try:
        p = persona_mod.load_template(tpl)
    except FileNotFoundError:
        p = {"id": aid, "name": name, "role": "executor", "identity": {"avatar": "🙂"}}
    p["id"] = aid
    p["name"] = name
    p.pop("_template", None)
    # 衣柜展开（2026-10-31）：模板只写 starters.<gender>，落盘前把 18 件展开成 items 快照，
    # 这样运行期（weather.recommend）不依赖 presets/ 是否随包下发。
    p = persona_mod.render_starter(p)
    av, h = config.get("agent.avatar"), config.get("agent.height_cm")
    if av:
        p.setdefault("identity", {})["avatar"] = av
    if h:
        p.setdefault("body", {})["height_cm"] = h

    full_name = f"{name}@{node_code or node_id}"      # 唯一机器码（隐藏）保证唯一
    created = False
    # 私密维度（body/wardrobe）**默认不入共享库**，留在本机 persona.yaml；TEAM_PERSONA_SYNC_PRIVATE=1 才同步
    _p_store = (p if os.environ.get("TEAM_PERSONA_SYNC_PRIVATE") == "1"
                else persona_mod.strip_private(p))
    if row:
        conn.execute("UPDATE agents SET name=?, node_id=?, full_name=?, "
                     "last_seen=datetime('now','localtime') WHERE id=?",
                     (name, node_id, full_name, aid))
        if not row["persona_json"]:
            conn.execute("UPDATE agents SET persona_json=? WHERE id=?",
                         (json.dumps(_p_store, ensure_ascii=False), aid))
    else:
        conn.execute("INSERT INTO agents(id, name, node_id, full_name, role, persona_json, last_seen) "
                     "VALUES (?,?,?,?,?,?,datetime('now','localtime'))",
                     (aid, name, node_id, full_name, p.get("role", "executor"),
                      json.dumps(_p_store, ensure_ascii=False)))
        created = True
    if not conn.execute("SELECT key_id FROM keys WHERE agent_id=? AND revoked_at IS NULL",
                        (aid,)).fetchone():
        k = _issue_key(conn, aid)
        _write_secret(persona_mod.agent_dir(aid) / ".key", json.dumps(k, ensure_ascii=False))
        created = True
    # 首次落 persona.yaml（已存在则不覆盖）
    pdir = persona_mod.agent_dir(aid)
    pdir.mkdir(parents=True, exist_ok=True)
    yp = pdir / "persona.yaml"
    if not yp.exists():
        yp.write_text(yaml.safe_dump(p, allow_unicode=True, sort_keys=False), encoding="utf-8")
    else:
        # 老库迁移（幂等）：档案已存在但衣柜为空 → 只补 wardrobe，不动其它字段；
        # 已有衣物一律不覆盖（用户的衣服是用户自己的）。
        try:
            persona_mod.ensure_wardrobe(aid)
        except Exception as _e:                            # noqa: BLE001
            print(f"[bootstrap] 补缺省衣柜跳过：{_e}")
    memory.seed_from_persona(aid, p)
    memory.generate_resume(aid)
    community.ensure_default_channels(conn)
    community.autojoin_all_public(conn, aid)
    return [{"id": aid, "full_name": full_name, "role": p.get("role"), "new_key": created}]


def _ensure_human(conn) -> dict:
    """创建人类所有者账户（全体 agent 的导师）。"""
    hid = os.environ.get("TEAM_HUMAN_ID", "human")
    name = os.environ.get("TEAM_HUMAN_NAME", "Owner")
    row = conn.execute("SELECT id FROM agents WHERE id=?", (hid,)).fetchone()
    created = False
    persona = {"id": hid, "name": name, "kind": "human", "role": "coordinator",
               "identity": {"avatar": "🧑‍💼", "motto": "人类所有者 / 全体 agent 的导师"}}
    if row:
        conn.execute("UPDATE agents SET kind='human', role='coordinator', "
                     "last_seen=datetime('now','localtime') WHERE id=?", (hid,))
    else:
        conn.execute(
            "INSERT INTO agents(id, name, kind, full_name, role, persona_json, status, last_seen) "
            "VALUES (?,?, 'human', ?, 'coordinator', ?, 'active', datetime('now','localtime'))",
            (hid, name, name, json.dumps(persona, ensure_ascii=False)))
        created = True
    active = conn.execute("SELECT key_id FROM keys WHERE agent_id=? AND revoked_at IS NULL",
                          (hid,)).fetchone()
    if not active:
        k = _issue_key(conn, hid)
        _write_secret(persona_mod.agent_dir(hid) / ".key", json.dumps(k, ensure_ascii=False))
        created = True
    return {"id": hid, "name": name, "new_key": created}


def _seed_constitution(conn) -> None:
    rules = [
        ("task_lifecycle", "任务必须走看板状态机 idea→backlog→claimed→in_progress→review→done。"),
        ("review_gate", "进 review 需 ≥1 产出帖 + 验收证据 + 脱敏校验 high_count=0。"),
        ("redaction", "禁止泄露 key/绝对路径/内网 IP/真名；保留依赖版本、算法、SOP。"),
        ("wip_limit", "每个 agent 默认 WIP 上限 2；claimed 2 小时未开始自动释放。"),
        ("work_topic", "只针对工件评论，不做人身攻击。"),
    ]
    for key, content in rules:
        conn.execute(
            "INSERT OR IGNORE INTO constitution_rules(version, rule_key, content) VALUES (?,?,?)",
            ("v1", key, content),
        )


def bootstrap() -> dict:
    db.init_db()
    security.master_key()
    conn = db.connect()
    try:
        root_token, root_new = _ensure_root_token(conn)
        node_id, node_code = _ensure_node(conn)
        agents = _ensure_primary_agent(conn, node_id, node_code)
        human = _ensure_human(conn)
        community.autojoin_all_public(conn, human["id"])
        _seed_constitution(conn)
        conn.commit()
    finally:
        conn.close()

    result = {
        "node": node_id,
        "root_token_new": root_new,
        "human": human,
        "agents": [{"id": a["id"], "full_name": a["full_name"],
                    "role": a["role"], "new_key": a["new_key"]} for a in agents],
    }
    # 依赖自愈：确保 playwright Chromium（本地工具 / 网页截图依赖），best-effort、幂等
    try:
        from .deps import ensure_chromium
        result["deps"] = ensure_chromium(quiet=True)
    except Exception as e:  # noqa: BLE001
        result["deps"] = {"ok": False, "action": "skip", "detail": f"{type(e).__name__}: {e}"}
    return result


if __name__ == "__main__":
    info = bootstrap()
    print(json.dumps(info, ensure_ascii=False, indent=2))
    if info["root_token_new"]:
        print(f"\n[root enroll token] {ENROLL_FILE}（已打印一次，妥善保管）")
    for a in info["agents"]:
        if a["new_key"]:
            print(f"[key issued] {a['full_name']} -> agents/{a['id']}/.key")
