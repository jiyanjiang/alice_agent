"""本地工具页：AI 写 PPT（loomdoc deck）。"""
from __future__ import annotations

import datetime
import html
import json
import pathlib
import re
import shutil
import subprocess
import sys
import time
import urllib.request
import uuid

ROOT = pathlib.Path(__file__).resolve().parent.parent


def esc(x) -> str:
    return html.escape(str(x if x is not None else ""))


def chrome_path() -> str:
    return next((c for c in (
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        shutil.which("google-chrome"), shutil.which("chromium"))
        if c and pathlib.Path(c).exists()), "")


def pptx_ready() -> bool:
    try:
        import pptx  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def llm_slides(topic: str, audience: str, pages: int, tone: str):
    from core.config import alibaba_key, deepseek_key

    providers = [
        ("DeepSeek", deepseek_key(), "https://api.deepseek.com/chat/completions", "deepseek-flash"),
        ("阿里云百炼", alibaba_key(),
         "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions", "qwen-plus"),
    ]
    prompt = (
        "你是资深演示设计师。为主题写一份中文 PPT 大纲。\n"
        f"主题：{topic}\n受众：{audience or '通用'}\n语气：{tone or '专业、具体'}\n"
        f"总页数（含封面）：{pages}；slides 数组长度必须是 {max(1, pages - 1)}。\n"
        '只输出严格 JSON，不要 Markdown：\n'
        '{"title":"封面标题","subtitle":"一句副标题","slides":[{"title":"页标题","bullets":["要点1","要点2","要点3"],"note":"讲者备注（可选，一句话）"}]}\n'
        "封面 title ≤18 个汉字，subtitle ≤30 字；每页 3-5 条短句；不要编造具体数字；不确定就写“待核实”。"
    )
    errors = []
    for name, key, url, model in providers:
        if not key:
            continue
        body = json.dumps({
            "model": model, "temperature": 0.5, "max_tokens": 2400,
            "messages": [{"role": "user", "content": prompt}],
        }).encode()
        req = urllib.request.Request(
            url, data=body,
            headers={"content-type": "application/json", "authorization": f"Bearer {key}"})
        try:
            from core.net_retry import urlopen_retry
            with urlopen_retry(req, timeout=90) as r:
                j = json.loads(r.read())
            text = j["choices"][0]["message"]["content"]
            m = re.search(r"\{.*\}", text, re.S)
            deck = json.loads(m.group(0) if m else text)
            if not isinstance(deck, dict) or not isinstance(deck.get("slides"), list):
                raise ValueError("模型返回的不是 PPT JSON")
            deck["_provider"] = name
            return deck, None
        except Exception as e:  # noqa: BLE001
            detail = str(e)[:120]
            if hasattr(e, "read"):
                try:
                    detail = e.read().decode("utf-8", "ignore")[:160]
                except Exception:  # noqa: BLE001
                    pass
            errors.append(f"{name}: {detail}")
    if not errors:
        return None, "未配置模型 Key：请在 设置 → 模型 KEY 添加 DeepSeek 或阿里云百炼（如何申请 → /app/help/keys）"
    return None, "模型调用失败：" + "；".join(errors)


def _write_pptx(deck: dict, outdir: pathlib.Path, title: str, sub: str):
    """可编辑 16:9 PPTX（python-pptx）；失败返回 None，不影响 HTML/PDF。"""
    try:
        from pptx import Presentation
        from pptx.dml.color import RGBColor
        from pptx.enum.shapes import MSO_SHAPE
        from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
        from pptx.util import Inches, Pt
    except Exception:  # noqa: BLE001
        return None

    ink = RGBColor(0x12, 0x18, 0x22)
    dark = RGBColor(0x0B, 0x12, 0x20)
    blue = RGBColor(0x2F, 0x6B, 0xE4)
    muted = RGBColor(0x6B, 0x77, 0x88)
    line_c = RGBColor(0xE3, 0xE8, 0xF0)
    card_c = RGBColor(0xF6, 0xF8, 0xFC)
    white = RGBColor(0xFF, 0xFF, 0xFF)
    font = "PingFang SC"

    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank = prs.slide_layouts[6]

    def tx(slide, x, y, w, h, text, size, color=ink, bold=False,
           align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, line=1.1):
        box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf = box.text_frame
        tf.word_wrap = True
        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
        tf.vertical_anchor = anchor
        p = tf.paragraphs[0]
        p.alignment = align
        p.line_spacing = line
        r = p.add_run()
        r.text = str(text)
        r.font.size = Pt(size)
        r.font.name = font
        r.font.bold = bold
        r.font.color.rgb = color
        return box

    def rect(slide, x, y, w, h, fill, rounded=False):
        shp = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE if rounded else MSO_SHAPE.RECTANGLE,
            Inches(x), Inches(y), Inches(w), Inches(h))
        if rounded:
            shp.adjustments[0] = 0.06
        shp.fill.solid()
        shp.fill.fore_color.rgb = fill
        shp.line.fill.background()
        shp.shadow.inherit = False
        return shp

    def hline(slide, x1, x2, y, color=line_c):
        ln = slide.shapes.add_connector(1, Inches(x1), Inches(y), Inches(x2), Inches(y))
        ln.line.color.rgb = color
        ln.line.width = Pt(0.8)
        ln.shadow.inherit = False

    # ── 封面 ──
    s = prs.slides.add_slide(blank)
    rect(s, 0, 0, 13.333, 7.5, dark)
    rect(s, 0.65, 2.0, 0.08, 2.7, blue)
    tx(s, 0.95, 2.0, 11.6, 0.3, "TEAM AI · DECK", 10, blue, True)
    tx(s, 0.95, 2.38, 11.6, 1.35, title, 40 if len(title) <= 18 else 32, white, True, line=1.12)
    if sub:
        tx(s, 0.95, 3.88, 11.6, 0.6, sub, 18, RGBColor(0xDB, 0xE6, 0xFF))
    tx(s, 0.95, 4.62, 11.6, 0.3,
       f"Team AI · 奇迹笔记 · {datetime.date.today().isoformat()}", 11,
       RGBColor(0x93, 0xA5, 0xC9))
    if deck.get("note"):
        s.notes_slide.notes_text_frame.text = str(deck["note"])

    slides = deck.get("slides") or []
    for idx, sld in enumerate(slides, 2):
        pts = [str(b) for b in (sld.get("bullets") or [])]
        title_i = str(sld.get("title") or "")
        s = prs.slides.add_slide(blank)
        rect(s, 0.65, 0.52, 0.07, 0.48, blue)
        tx(s, 0.84, 0.5, 11.8, 0.28, "TEAM AI · DECK", 9, blue, True)
        tx(s, 0.65, 0.86, 12.0, 0.9, title_i, 24 if len(title_i) <= 22 else 20, ink, True)
        hline(s, 0.65, 12.68, 1.9)

        if len(pts) == 3:
            for i, p in enumerate(pts):
                y = 2.15 + i * 1.45
                tx(s, 0.75, y + 0.42, 0.6, 0.3, f"{i + 1:02d}", 14, blue, True)
                tx(s, 1.42, y + 0.24, 10.9, 0.9, p, 20 if len(p) <= 26 else 17, ink, line=1.25)
                if i < len(pts) - 1:
                    hline(s, 0.65, 12.68, y + 1.32)
        elif len(pts) == 4:
            for i, p in enumerate(pts):
                x = 0.65 + (i % 2) * 6.1
                y = 2.15 + (i // 2) * 2.2
                rect(s, x, y, 5.95, 1.95, card_c, rounded=True)
                rect(s, x, y + 0.18, 0.06, 1.58, blue)
                tx(s, x + 0.28, y + 0.28, 0.6, 0.25, f"{i + 1:02d}", 10, blue, True)
                tx(s, x + 0.28, y + 0.64, 5.3, 1.0, p, 16 if len(p) <= 22 else 14, ink, line=1.25)
        elif len(pts) >= 5:
            for i, p in enumerate(pts):
                y = 2.05 + i * 0.82
                tx(s, 0.75, y + 0.2, 0.6, 0.25, f"{i + 1:02d}", 12, blue, True)
                tx(s, 1.35, y + 0.1, 11.0, 0.62, p, 16 if len(p) <= 24 else 14, ink, line=1.18)
                hline(s, 0.65, 12.68, y + 0.72)
        else:
            for i, p in enumerate(pts):
                tx(s, 0.9, 2.25 + i * 0.78, 11.6, 0.6, "•  " + p, 20, ink, line=1.25)

        tx(s, 0.65, 7.05, 5.0, 0.25, "Team AI · 奇迹笔记", 9, muted)
        tx(s, 11.9, 7.05, 0.8, 0.25, f"{idx:02d}", 9, muted, align=PP_ALIGN.RIGHT)
        if sld.get("note"):
            s.notes_slide.notes_text_frame.text = str(sld["note"])

    out = outdir / "deck.pptx"
    prs.save(out)
    return out


def build_deck(deck: dict, topic: str, pages: int | None = None):
    stamp = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
    outdir = ROOT / "static" / "uploads" / f"loomdoc-{stamp}"
    outdir.mkdir(parents=True, exist_ok=True)
    title = str(deck.get("title") or topic)[:24]
    sub = str(deck.get("subtitle") or "")[:40]
    slides = deck.get("slides") or []
    if pages:
        slides = slides[: max(1, pages - 1)]
    parts = [
        '<!-- slide -->\n<!-- layout:cover -->\n'
        '<style>.slide.cover .inner{right:84px}.slide.cover h1{font-size:54px;line-height:1.12}</style>'
        '<div class="inner"><div class="label">TEAM AI · DECK</div>'
        f'<h1>{esc(title)}</h1><div class="tagline">{esc(sub)}</div>'
        f'<div class="meta">Team AI · 奇迹笔记 · {datetime.date.today().isoformat()}</div></div>'
    ]
    for sld in slides:
        pts = [esc(str(b)) for b in (sld.get("bullets") or [])]
        if len(pts) == 3:
            rows = "".join(
                f'<div class="trow"><span>{i:02d}</span><p>{p}</p></div>'
                for i, p in enumerate(pts, 1))
            body = ('<style>.trows{display:flex;flex-direction:column;flex:1;margin-top:2px}'
                    '.trow{display:flex;gap:26px;align-items:center;flex:1;'
                    'border-bottom:1px solid var(--line)}'
                    '.trow span{font-size:18px;font-weight:700;color:var(--accent);min-width:42px}'
                    '.trow p{font-size:26px;line-height:1.4;margin:0;color:var(--ink)}</style>'
                    f'<div class="trows">{rows}</div>')
        elif len(pts) >= 4:
            cards = "".join(
                f'<div class="gcard"><h3>{i:02d}</h3><p>{p}</p></div>'
                for i, p in enumerate(pts, 1))
            body = ('<style>.grid2{grid-auto-rows:1fr}'
                    '.gcard{display:flex;flex-direction:column;justify-content:center}'
                    '.gcard h3{font-size:15px;letter-spacing:.12em;color:var(--accent-dark)}'
                    '.gcard p{font-size:21px;line-height:1.55}</style>'
                    f'<div class="grid2">{cards}</div>')
        else:
            body = '<ul class="blist">' + "".join(f"<li>{p}</li>" for p in pts) + "</ul>"
        parts.append('<!-- slide -->\n<div class="kicker">TEAM AI · DECK</div>'
                     f'<div class="stitle">{esc(str(sld.get("title") or ""))}</div>{body}')
    src = outdir / "deck_source.html"
    src.write_text("\n".join(parts), encoding="utf-8")
    html_out = outdir / "deck.html"
    pdf_out = outdir / "deck.pdf"
    engine = ROOT / "tools" / "loomdoc" / "engine" / "build_slides.py"
    try:
        r = subprocess.run(
            [sys.executable, str(engine), "--source", str(src), "--html", str(html_out),
             "--pdf", str(pdf_out), "--footer", "Team AI · 奇迹笔记"],
            capture_output=True, text=True, timeout=240)
        if r.returncode != 0 or not html_out.exists():
            return None, (r.stdout + r.stderr)[-700:]
        preview = outdir / "preview.png"
        chrome = chrome_path()
        if chrome:
            try:
                subprocess.run(
                    [chrome, "--headless=new", "--disable-gpu", "--hide-scrollbars",
                     "--force-device-scale-factor=1", "--window-size=1280,720",
                     f"--screenshot={preview}", html_out.resolve().as_uri()],
                    capture_output=True, timeout=90)
            except Exception:  # noqa: BLE001
                pass
        deck_used = dict(deck)
        deck_used["slides"] = slides
        try:
            pptx_out = _write_pptx(deck_used, outdir, title, sub)
        except Exception:  # noqa: BLE001
            pptx_out = None
        return {
            "html": f"/static/uploads/{outdir.name}/deck.html",
            "pdf": f"/static/uploads/{outdir.name}/deck.pdf" if pdf_out.exists() else "",
            "pptx": f"/static/uploads/{outdir.name}/deck.pptx" if pptx_out else "",
            "preview": f"/static/uploads/{outdir.name}/preview.png" if preview.exists() else "",
            "name": outdir.name, "slides": len(slides) + 1,
            "provider": deck.get("_provider", ""),
        }, ""
    except Exception as e:  # noqa: BLE001
        return None, str(e)[:400]


def page_tools(shell, result=None, error: str = "", form: dict | None = None):
    from flask import request
    from core import i18n
    loc = i18n.locale_of(request.cookies.get("taa_lang")) if request else i18n.DEFAULT
    def T(key: str, zh: str) -> str:
        return i18n.t(key, zh, loc)
    f = form or {}
    topic_v = esc(f.get("topic", ""))
    audience_v = esc(f.get("audience", ""))
    tone_v = esc(f.get("tone", ""))
    try:
        pages_v = max(4, min(16, int(f.get("pages") or 8)))
    except (TypeError, ValueError):
        pages_v = 8
    from core.config import alibaba_key, deepseek_key
    ds, ali = deepseek_key(), alibaba_key()
    has_key = bool(ds or ali)
    both_keys = bool(ds and ali)
    cfg = T("tools.configured", "已配"); ncfg = T("tools.not_configured", "未配")
    key_state = f"DeepSeek {cfg if ds else ncfg} · {T('tools.alibaba', '阿里')} {cfg if ali else ncfg}"
    if has_key and not both_keys:
        key_state += T("tools.need_other_fmt", "（{x}）").format(x=T('tools.need_other', '建议补另一个'))
    local_ok = bool(chrome_path() and pptx_ready())
    local_state = (T("tools.ready", "Chrome + python-pptx 就绪") if local_ok
                   else ("缺 " + ("Chrome " if not chrome_path() else "") + ("python-pptx" if not pptx_ready() else "")).strip())
    try:
        from core.deliverables_ui import history_items
        hist = history_items(12)
    except Exception:  # noqa: BLE001
        hist = []

    def _hsize(n: int) -> str:
        for unit, div in (("MB", 1 << 20), ("KB", 1 << 10)):
            if n >= div:
                return f"{n / div:.1f} {unit}"
        return f"{n} B"

    hist_rows = "".join(
        f'<tr><td><span class="dlname">{esc(r["name"])}</span>'
        f'<div class="dim" style="font-size:12px">{esc(r["kind"])}'
        f'{" · " + esc(r["dir"]) if r.get("dir") else ""}</div></td>'
        f'<td class="dim" style="white-space:nowrap">{datetime.datetime.fromtimestamp(r["mtime"]).strftime("%Y-%m-%d %H:%M")}'
        f'<div style="font-size:12px">{_hsize(r["size"])}</div></td>'
        f'<td><div class="deckacts" style="margin:0">'
        f'<a class="btn" href="{esc(r["url"])}" target="_blank" rel="noopener">打开</a>'
        f'<a class="btn" href="{esc(r["url"])}?download=1">下载</a></div></td></tr>'
        for r in hist)
    if not hist_rows:
        hist_rows = '<tr><td colspan="3" class="dim">还没有生成记录。上面生成一次后，这里会按时间列出每一版。</td></tr>'
    dep = f"""
  <section class="card depcard">
    <div class="kicker">{T("tools.dep", "使用前提 · 依赖链")}</div>
    <p class="dim" style="margin:6px 0 10px">{T("tools.dep_note", "AI 写 PPT 不能只在中心节点使用：中心负责账号与登记，出片必须发生在本机。缺哪一步，下面会标出来。")}</p>
    <div class="deps">
      <div class="depstep done"><b>1</b><span>{T("tools.center_account", "中心账号")}</span><em>{T("tools.invite", "邀请注册")}</em></div>
      <div class="depstep done"><b>2</b><span>{T("tools.create_agent", "创建 agent")}</span><em>{T("tools.center_create", "中心创建 · 本机部署")}</em></div>
      <div class="depstep ok"><b>3</b><span>{T("tools.local_run", "本地 TAA 运行")}</span><em>{T("tools.here", "当前页面即本地")}</em></div>
      <div class="depstep {'ok' if both_keys else ('part' if has_key else 'warn')}"><b>4</b><span>{T("tools.model_key", "模型 Key")}</span><em>{esc(key_state)}</em></div>
      <div class="depstep {'ok' if local_ok else 'warn'}"><b>5</b><span>{T("tools.render_deps", "出片依赖")}</span><em>{esc(local_state)}</em></div>
    </div>
    <p class="dim" style="margin:10px 0 0"><a href="/app/help/keys">{T("tools.how", "如何申请 / 充值模型 Key →")}</a> · <a href="/app/settings#models">{T("tools.settings_key", "去设置 Key")}</a> · <a href="/deliverables/">{T("tools.history_deliver", "查看历史生成的 PPT / 交付包 →")}</a></p>
    <p class="dim" style="margin:6px 0 0">{T("tools.old_version", "找旧版：交付中心 → 顶部「PPT 生成历史」按时间打开最近生成；或选任务 → 按修改时间挑版本。每次生成都在独立的 loomdoc-时间戳 目录，不会覆盖上一版。")}</p>
  </section>"""
    body = f"""
  {dep}
  <section class="card" style="padding:18px 20px">
    <div class="kicker">{T("tools.office", "AI 办公")}</div>
    <h2 style="margin:6px 0 6px">{T("tools.title", "AI 写 PPT")}</h2>
    <p class="dim" style="margin:0 0 12px">{T("tools.intro", "给主题 → 模型写大纲 → 本地 loomdoc 出 16:9 演示（HTML + PDF + PPTX）。模型 key 只在本机。")}</p>
    <form method="post" action="/app/tools/loomdoc" class="tform">
      <input id="topic" name="topic" value="{topic_v}" placeholder="{T("tools.topic", "主题，例如：中微子天文学 2026 进展")}" required>
      <input name="audience" value="{audience_v}" placeholder="{T("tools.audience", "受众（可选）")}">
      <div class="trow"><input name="pages" type="number" min="4" max="16" value="{pages_v}">
        <input name="tone" value="{tone_v}" placeholder="{T("tools.tone", "语气（可选，如：专业、克制）")}">
        <button class="btn primary" type="submit">{T("tools.generate", "生成 PPT")}</button></div>
    </form>
    <div class="chips"><span>{T("tools.try", "试试：")}</span>
      <button type="button" class="chip" data-topic="给团队新人的 4 页介绍：TAA 是什么、为什么本地优先">{T("tools.examples", "团队新人介绍")}</button>
      <button type="button" class="chip" data-topic="项目复盘：我们做对了什么、哪里可以更好、下一步">{T("tools.example2", "项目复盘")}</button>
      <button type="button" class="chip" data-topic="给客户的 8 页方案：问题、方案、证据、实施计划">{T("tools.example3", "客户方案")}</button>
    </div>
    {f'<div class="errbox">{esc(error)}</div>' if error else ''}
    {_result_html(result) if result else ''}
  </section>
  <section class="card" id="ppt-history" style="padding:18px 20px;margin-top:12px">
    <div class="kicker">{T("tools.history", "PPT 生成历史")}</div>
    <h2 style="margin:6px 0 6px">{T("tools.history_title", "最近生成的演示（按时间倒序）")}</h2>
    <p class="dim" style="margin:0 0 10px">{T("tools.history_note", "每一版都在独立的 loomdoc-时间戳 目录，不会覆盖上一版；点「打开」看演示，点「下载」取回文件。全部交付物与按任务的历史版本见交付中心。")}</p>
    <table class="histtable">
      <thead><tr><th>{T("tools.source", "文件 / 来源")}</th><th>{T("tools.time", "生成时间")}</th><th>{T("tools.actions", "操作")}</th></tr></thead>
      <tbody>{hist_rows}</tbody>
    </table>
  </section>
  <style>
  .tform{{display:grid;gap:8px}}
  .tform input{{padding:10px 12px;border:1px solid var(--pearl);border-radius:12px;font:inherit;background:#fff}}
  .trow{{display:grid;grid-template-columns:90px 1fr auto;gap:8px;align-items:center}}
  .trow .btn{{min-height:48px}}
  .chips{{display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin:0 0 4px;font-size:12px;color:var(--muted)}}
  .chip{{border:1px solid var(--pearl);background:#fff;border-radius:999px;padding:5px 10px;font:inherit;font-size:12px;color:var(--ink-soft);cursor:pointer}}
  .chip:hover{{border-color:var(--powder);background:var(--powder-light)}}
  .depcard{{padding:16px 18px;margin-bottom:12px}}
  .deps{{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px}}
  .depstep{{border:1px solid var(--hair);border-radius:12px;padding:10px 11px;background:var(--porcelain);display:flex;flex-direction:column;gap:2px;min-width:0}}
  .depstep b{{font-size:11px;color:var(--muted);letter-spacing:.08em}}
  .depstep span{{font-size:13px;font-weight:600;line-height:1.35}}
  .depstep em{{font-style:normal;font-size:12px;color:var(--muted);line-height:1.45}}
  .depstep.ok{{border-color:#CBE9DA;background:#F4FBF7}} .depstep.ok b{{color:#1f5c42}}
  .depstep.warn{{border-color:#F3DCC2;background:#FDF6EC}} .depstep.warn b{{color:#8a5300}}
  .depstep.part{{border-color:#D6E7F5;background:#F7FBFF}} .depstep.part b{{color:#2F6BE4}}
  @media(max-width:860px){{.deps{{grid-template-columns:1fr 1fr}}}}
  @media(max-width:520px){{.deps{{grid-template-columns:1fr}}}}
  .errbox{{margin-top:10px;padding:10px 12px;border:1px solid #F3DCC2;background:#FDF1E3;color:#8a5300;border-radius:10px;font-size:13px}}
  .histtable{{width:100%;border-collapse:collapse;font-size:13px}}
  .histtable th{{text-align:left;font-weight:600;color:var(--muted);border-bottom:1px solid var(--pearl);padding:8px 6px}}
  .histtable td{{border-bottom:1px solid var(--hair);padding:9px 6px;vertical-align:top}}
  .histtable tr:last-child td{{border-bottom:0}}
  .histtable .dlname{{font-weight:600;overflow-wrap:anywhere}}
  .deckpreview{{display:block;width:100%;height:auto;border:1px solid var(--hair);border-radius:14px;margin-top:12px;background:#0b0f16}}
  .deckacts{{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}}
  @media(max-width:520px){{.trow{{grid-template-columns:90px 1fr}}.trow .btn{{grid-column:1/-1}}}}
  </style>
  <script>
  document.querySelectorAll('.chip').forEach(function(b){{ b.addEventListener('click', function(){{ var el=document.getElementById('topic'); el.value=b.dataset.topic; el.focus(); }}); }});
  </script>"""
    side = (
        '<div class="sidebox"><div class="shead">TOOLS</div>'
        '<a class="citem on" href="/app/tools"><span class="cname">AI 写 PPT</span></a>'
        '<a class="citem" href="/app/tools"><span class="cname">BP / MEMO</span></a>'
        '<a class="citem" href="/app/tools"><span class="cname">调研 / 天气</span></a></div>')
    detail = (f'<div class="card" style="padding:16px 18px"><div class="kicker">{T("tools.note_title", "说明")}</div>'
              f'<p class="dim" style="margin:8px 0 0">{T("tools.note", "PPT 在本机出片；生成后可打开全屏演示，或下载 PDF / 可编辑 PPTX。")}</p></div>')
    return shell("工具", body, "tools", "写作、调研与生活工具", side=side, detail=detail)


def _result_html(result: dict) -> str:
    pdf = (f'<a class="btn" href="{result["pdf"]}" download>下载 PDF</a>' if result.get("pdf") else "")
    pptx = (f'<a class="btn" href="{result["pptx"]}" download>下载 PPTX</a>' if result.get("pptx") else "")
    img = (f'<img class="deckpreview" src="{result["preview"]}" alt="PPT 封面预览">'
           if result.get("preview") else "")
    return (
        '<div style="margin-top:14px"><div class="kicker">生成完成 · '
        f'{result["slides"]} 页' + (f' · {esc(result["provider"])}' if result.get("provider") else '') + '</div><div class="deckacts">'
        f'<a class="btn primary" href="{result["html"]}" target="_blank">全屏演示</a>{pdf}{pptx}</div>'
        f'{img}</div>')
