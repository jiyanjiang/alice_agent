"""SQLite 存取层。"""
from __future__ import annotations

import os
import sqlite3
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def taa_home() -> Path:
    """解析 TAA 家目录（**唯一口径**，所有模块共用，不再各算各的）。

    优先级：
      1) 环境变量 TAA_HOME（部署/测试显式指定）；
      2) 代码位于 <home>/app/ 且同级有 agents/ → 取 <home>（正式部署布局）；
      3) 否则取代码根（开发仓库布局）。

    背景（2026-10-30 实测）：supervisor / dispatcher / chatroom 都以 `cwd` 为 ROOT，
    正式部署时 cwd=<home>/app，于是 `<cwd>/data.db` 落到 app/data.db（12KB 空库），
    而 web 服务拿的是 TEAMAI_DB=<home>/data.db → 两个 message_route 表，
    claim 各写各的，单一路由失效（P0-1）。
    """
    env = (os.environ.get("TAA_HOME") or "").strip()
    if env:
        return Path(env).expanduser()
    if ROOT.name == "app" and (ROOT.parent / "agents").exists():
        return ROOT.parent
    return ROOT


HOME = taa_home()


def home_mismatch_warning(setup_home) -> str:
    """向导目录 vs 主数据目录是否分家（P2.2b）。返回中文告警；一致时返回空串。"""
    try:
        a = Path(setup_home).expanduser().resolve()
    except Exception:                                          # noqa: BLE001
        return ""
    b = Path(HOME).expanduser().resolve()
    if a == b:
        return ""
    return (f"向导目录与主数据目录不一致：{a} ≠ {b}。"
            "向导创建的 identity 可能与主程序 data.db 分家，"
            "请检查 TAA_HOME / TAA_V05_HOME 是否指向同一目录。")
# 可经 TEAMAI_DB 指向临时库（自检/测试**隔离**，避免污染生产 data.db）。
DB_PATH = Path(os.environ.get("TEAMAI_DB") or (HOME / "data.db"))
SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"

# —— agents 根目录（P1.5 唯一口径）——
# 背景（2026-10-30 实测）：brief 的**写入端**用代码根（core/chatwork.ROOT，部署时 =<home>/app），
# **治理端** core/brief_gc 用 HOME/agents（=<home>/agents），dispatcher 又用 cwd。
# 三处不一致 → 部署布局下 GC 扫的是空目录，P0-4「旧 brief 堵队列」照旧发生。
# 现在统一：brief 一律走 AGENTS_DIR（TEAMAI_AGENTS_DIR > <home>/agents）。
# 注意：密钥 / persona / backend 等既有文件暂仍留在代码根（迁移会丢身份），
# 只有 inbox 简报与 .chatwork 游标用本口径。
AGENTS_DIR = Path(os.environ.get("TEAMAI_AGENTS_DIR") or (HOME / "agents"))


def brief_inbox(agent: str) -> Path:
    """某 agent 的 inbox —— 写 brief 与读 brief 都必须走这里。"""
    return AGENTS_DIR / str(agent) / "inbox"


def stray_route_dbs() -> list[Path]:
    """找出除 canonical 之外、仍然带 message_route 表的库（P0-1 自检用）。"""
    canonical = DB_PATH.resolve()
    cands = [ROOT / "data.db", ROOT / "app" / "data.db",
             HOME / "data.db", HOME / "app" / "data.db"]
    out: list[Path] = []
    seen: set[str] = set()
    for p in cands:
        try:
            rp = p.resolve()
        except OSError:
            continue
        key = str(rp)
        if key in seen or rp == canonical or not p.exists():
            continue
        seen.add(key)
        try:
            c = sqlite3.connect(f"file:{rp}?mode=ro", uri=True, timeout=3)
            n = c.execute("SELECT count(*) FROM sqlite_master WHERE type='table' "
                          "AND name='message_route'").fetchone()[0]
            c.close()
            if n:
                out.append(rp)
        except sqlite3.Error:
            continue
    return out


def _route_rows(p: Path) -> int:
    try:
        c = sqlite3.connect(f"file:{p}?mode=ro", uri=True, timeout=3)
        try:
            return int(c.execute("SELECT count(*) FROM message_route").fetchone()[0])
        finally:
            c.close()
    except sqlite3.Error:
        return 0


def assert_single_route_db() -> list[str]:
    """启动自检：第二个 message_route 库里**确实有记录**才算危险。

    语义（为什么不是"有表就炸"）：空表只是历史残留，不影响单一路由；
    只有写了记录才意味着 claim 真的分叉了。

    处置顺序（Delta 复核意见，2026-10-30）：**先隔离，再硬失败**。
    直接拒绝启动会把现网 brick——升级时 app/data.db 里本来就有几行记录。
    默认动作 = quarantine：把整库**改名**保留（不删、不合并），带时间戳，启动继续；
    只有改名失败或显式要求 strict 时才抛错。
    可用 TEAMAI_STRAY_ROUTE_ACTION=quarantine|fail 覆盖（默认 quarantine）。
    """
    stray = stray_route_dbs()
    if not stray:
        return []
    dangerous = [(p, _route_rows(p)) for p in stray]
    dangerous = [(p, n) for p, n in dangerous if n > 0]
    if not dangerous:
        return [f"[db] 发现空的 message_route 残留库（无害，建议择机清理）："
                + ", ".join(str(p) for p in stray)]

    action = (os.environ.get("TEAMAI_STRAY_ROUTE_ACTION") or "quarantine").strip().lower()
    notes: list[str] = []
    if action != "fail":
        left: list[tuple[Path, int]] = []
        for p, n in dangerous:
            dst = p.with_name(f"{p.name}.stray-{time.strftime('%Y%m%d-%H%M%S')}")
            try:
                os.replace(p, dst)          # 同盘原子改名，不删数据
                notes.append(f"[db] 已隔离非 canonical 路由库：{p}（{n} 行）→ {dst}")
            except OSError as e:  # noqa: BLE001
                notes.append(f"[db] 隔离失败：{p}（{e}）")
                left.append((p, n))
        if not left:
            return notes
        dangerous = left

    msg = ("[db] 单一路由已被破坏：以下库各自持有 message_route 记录 —— "
           + ", ".join(f"{p}({n} 行)" for p, n in dangerous)
           + f"；canonical={DB_PATH}。请先合并/清理，再启动。")
    if (os.environ.get("TEAMAI_STRICT_SINGLE_ROUTE", "1") or "1").strip() != "0":
        raise RuntimeError(msg)
    return notes + [msg]


def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 30000")   # 并发写等待，缓解 "database is locked"
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _ensure_column(conn: sqlite3.Connection, table: str, col: str, ddl: str) -> None:
    cols = [r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()]
    if col not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")


def _migrate_legacy_columns(conn: sqlite3.Connection) -> None:
    """老库补列，必须早于 executescript(SCHEMA_PATH)。

    beta.x 老库与新 schema 有两处不兼容，都会让 init_db 直接抛
    `sqlite3.OperationalError`，进而使升级后的新服务起不来 → 原子升级回滚
    （beta.35 → 1.0.0 实测必现）：

    1. `schema.sql` 建表后立刻建两个唯一索引
       （ux_room_messages_center / ux_room_messages_client），引用
       `room_messages.center_message_id` / `client_message_id`；老库这两列
       不存在（beta.35 的 schema.sql 里根本没有这两个词）。
    2. `ensure_message_columns()` 的回填 UPDATE 引用 `agents.owner_id`；
       老库 agents 只有 id/name/kind/... 没有 owner_id，且 init_db 里没有
       任何给 agents 补列的语句（`owner_name` 只在 app_ui 首次使用时懒补）。
    """
    if conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='room_messages'").fetchone():
        _ensure_column(conn, "room_messages", "center_message_id", "center_message_id TEXT")
        _ensure_column(conn, "room_messages", "client_message_id", "client_message_id TEXT")
    if conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='agents'").fetchone():
        _ensure_column(conn, "agents", "owner_id", "owner_id TEXT")
        _ensure_column(conn, "agents", "owner_name", "owner_name TEXT")


def ensure_message_columns(conn: sqlite3.Connection) -> None:
    """Add message idempotency + canonical UTC columns to an old local DB.

    `created_at` remains local for legacy queries; `created_at_utc` is the
    canonical wire value. Center/peer rows historically stored UTC in the
    legacy column, so they are converted to local for compatibility here.
    """
    row = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='room_messages'").fetchone()
    if not row:
        return
    _ensure_column(conn, "room_messages", "center_message_id", "center_message_id TEXT")
    _ensure_column(conn, "room_messages", "peer_message_id", "peer_message_id TEXT")
    _ensure_column(conn, "room_messages", "client_message_id", "client_message_id TEXT")
    _ensure_column(conn, "room_messages", "direct_delivered",
                   "direct_delivered INTEGER DEFAULT 0")
    # 直投终态（2026-10-31）：pending / delivered / skipped / gave_up。
    # direct_delivered 只表示"真送到了"，绝不能拿它冒充"放弃投递"。
    _ensure_column(conn, "room_messages", "direct_state", "direct_state TEXT")
    _ensure_column(conn, "room_messages", "direct_attempts",
                   "direct_attempts INTEGER DEFAULT 0")
    _ensure_column(conn, "room_messages", "direct_next_at", "direct_next_at REAL")
    _ensure_column(conn, "room_messages", "direct_last_error", "direct_last_error TEXT")
    conn.execute("UPDATE room_messages SET direct_state='delivered' "
                 "WHERE direct_state IS NULL AND COALESCE(direct_delivered,0)=1")
    _ensure_column(conn, "room_messages", "created_at_utc", "created_at_utc TEXT")
    _ensure_column(conn, "room_messages", "executor_dispatched",
                   "executor_dispatched INTEGER DEFAULT 0")
    _ensure_column(conn, "room_messages", "reply_to_id", "reply_to_id INTEGER")
    _ensure_column(conn, "room_messages", "reply_to_center_id", "reply_to_center_id TEXT")
    _ensure_column(conn, "room_messages", "sender_owner_id", "sender_owner_id TEXT")
    _ensure_column(conn, "room_messages", "sender_kind", "sender_kind TEXT")
    _ensure_column(conn, "room_messages", "target_owner_id", "target_owner_id TEXT")
    _ensure_column(conn, "room_messages", "target_agent_id", "target_agent_id TEXT")
    _ensure_column(conn, "room_messages", "presence_snapshot", "presence_snapshot TEXT")
    # Owner identity is the canonical human identity. Backfill old rows from
    # the agents projection; system rows (no agent) stay NULL.
    conn.execute(
        "UPDATE room_messages SET "
        " sender_owner_id=COALESCE(sender_owner_id, "
        "   (SELECT a.owner_id FROM agents a WHERE a.id=room_messages.agent_id)), "
        " sender_kind=COALESCE(NULLIF(sender_kind,''), "
        "   (SELECT a.kind FROM agents a WHERE a.id=room_messages.agent_id)) "
        "WHERE sender_owner_id IS NULL OR sender_kind IS NULL OR sender_kind=''")
    # One projection trigger keeps every insert path (UI, center sync, peer,
    # screenshot, system notices) aligned with the agents table.
    conn.execute("""
        CREATE TRIGGER IF NOT EXISTS trg_room_messages_sender
        AFTER INSERT ON room_messages
        WHEN NEW.sender_owner_id IS NULL OR NEW.sender_kind IS NULL OR NEW.sender_kind = ''
        BEGIN
          UPDATE room_messages
             SET sender_owner_id = COALESCE(sender_owner_id,
                   (SELECT a.owner_id FROM agents a WHERE a.id = NEW.agent_id)),
                 sender_kind = COALESCE(NULLIF(sender_kind, ''),
                   (SELECT a.kind FROM agents a WHERE a.id = NEW.agent_id))
           WHERE id = NEW.id;
        END
    """)
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_room_messages_center "
                 "ON room_messages(center_message_id) WHERE center_message_id IS NOT NULL")
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_room_messages_client "
                 "ON room_messages(room_id, client_message_id) "
                 "WHERE client_message_id IS NOT NULL")
    # Old DBs cannot ALTER ADD with a non-constant default; a trigger fills
    # the canonical UTC value for inserts that omit the column.
    conn.execute("""
        CREATE TRIGGER IF NOT EXISTS trg_room_messages_utc
        AFTER INSERT ON room_messages
        WHEN NEW.created_at_utc IS NULL OR NEW.created_at_utc = ''
        BEGIN
          UPDATE room_messages
             SET created_at_utc = strftime('%Y-%m-%dT%H:%M:%SZ','now')
           WHERE id = NEW.id;
        END
    """)
    from . import timeutil
    rows = conn.execute(
        "SELECT id,created_at,source,center_message_id,peer_message_id "
        "FROM room_messages WHERE created_at_utc IS NULL OR created_at_utc = ''"
    ).fetchall()
    for r in rows:
        raw = r["created_at"]
        source = str(r["source"] or "")
        # Legacy center/peer rows were stored as UTC without a Z marker.
        # A local chat row can also have a center_message_id after sync; that
        # does NOT make its legacy created_at UTC.
        assume = "utc" if source in ("center", "peer", "p2p") else "local"
        utc = timeutil.to_utc_iso(raw, assume=assume)
        if not utc:
            utc = timeutil.now_utc_iso()
        local = timeutil.to_local_text(utc, assume="utc")
        conn.execute("UPDATE room_messages SET created_at=?,created_at_utc=? WHERE id=?",
                     (local or raw, utc, r["id"]))
    conn.commit()


def _migrate_contributions(conn: sqlite3.Connection) -> None:
    """Ⅱ期（docs/71 §5）：把聊天室回合评分旧表 `contributions` 改名为 `room_contributions`，
    腾出 `contributions` 给「署名与贡献」。仅在旧表存在且含 `room_id`、不含 `project_id` 时执行。
    """
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='contributions'").fetchone()
    if not row:
        return
    sql = (row[0] or "")
    if "room_id" in sql and "project_id" not in sql:
        conn.execute("ALTER TABLE contributions RENAME TO room_contributions")
        conn.commit()


def _migrate_reply_kinds(conn: sqlite3.Connection) -> None:
    """L1 朋友圈（docs/79 v2）：replies.kind CHECK 增补 'comment'（朋友圈卡片内评论）。

    CHECK 约束无法 ALTER，须按 SQLite 官方做法**重建表**；老库（无 'comment'）才执行，
    新库由 schema.sql 直接建出含 'comment' 的表，天然跳过。数据完整搬迁、自增 id 保留。
    """
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='replies'").fetchone()
    if not row:
        return
    sql = (row[0] or "")
    if "'comment'" in sql:
        return
    conn.execute("PRAGMA foreign_keys=OFF")
    conn.commit()
    conn.execute("ALTER TABLE replies RENAME TO replies_old")
    conn.execute(
        "CREATE TABLE replies ("
        "  id              INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  post_id         TEXT NOT NULL REFERENCES posts(id),"
        "  parent_reply_id INTEGER REFERENCES replies(id),"
        "  author_id       TEXT NOT NULL REFERENCES agents(id),"
        "  depth           INTEGER NOT NULL DEFAULT 1,"
        "  kind            TEXT NOT NULL"
        "                  CHECK(kind IN ('fact','derivation','computation','counterexample',"
        "                                 'proposal','question','ack','disagree','comment')),"
        "  body            TEXT NOT NULL,"
        "  evidence        TEXT,"
        "  low_value       INTEGER NOT NULL DEFAULT 0,"
        "  deep            INTEGER NOT NULL DEFAULT 0,"
        "  throttled       INTEGER NOT NULL DEFAULT 0,"
        "  status          TEXT NOT NULL DEFAULT 'visible'"
        "                  CHECK(status IN ('visible','collapsed','removed')),"
        "  created_at      TEXT DEFAULT (datetime('now','localtime'))"
        ")")
    conn.execute(
        "INSERT INTO replies(id,post_id,parent_reply_id,author_id,depth,kind,body,evidence,"
        "low_value,deep,throttled,status,created_at) "
        "SELECT id,post_id,parent_reply_id,author_id,depth,kind,body,evidence,"
        "low_value,deep,throttled,status,created_at FROM replies_old")
    conn.execute("DROP TABLE replies_old")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_replies_post ON replies(post_id, id)")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.commit()


TASKS_DDL_V_STATES = """CREATE TABLE tasks_new (
  id                  TEXT PRIMARY KEY,
  project_id          TEXT REFERENCES projects(id),
  title               TEXT NOT NULL,
  description         TEXT NOT NULL,
  acceptance_criteria TEXT NOT NULL,
  priority            INTEGER NOT NULL DEFAULT 1,
  complexity          REAL NOT NULL DEFAULT 0.5,
  difficulty          REAL NOT NULL DEFAULT 0.5,
  status              TEXT NOT NULL DEFAULT 'idea'
                      CHECK(status IN ('idea','backlog','claimed','in_progress','paused',
                                       'review','done','archived','blocked','cancelled')),
  required_skills     TEXT,
  resource_req        TEXT,
  tags                TEXT,
  parent_id           TEXT REFERENCES tasks(id),
  created_by          TEXT REFERENCES agents(id),
  assigned_to         TEXT REFERENCES agents(id),
  claimed_at TEXT, in_progress_at TEXT, review_at TEXT,
  done_at TEXT, blocked_at TEXT, deadline TEXT,
  metadata            TEXT,
  created_at          TEXT DEFAULT (datetime('now','localtime'))
)"""

TASK_COLUMNS = (
    "id, project_id, title, description, acceptance_criteria, priority, complexity, "
    "difficulty, status, required_skills, resource_req, tags, parent_id, created_by, "
    "assigned_to, claimed_at, in_progress_at, review_at, done_at, blocked_at, deadline, "
    "metadata, created_at")


def _migrate_agent_names(conn: sqlite3.Connection) -> None:
    """Give legacy AI agents case-insensitively unique display names.

    The center is the global authority, but an old local database may still
    contain duplicate rows (for example a remote stub and a primary agent both
    named ``alice``).  Rename only the later duplicates; keep agent ids and
    history intact.  New rows are protected by the partial unique index in
    schema.sql.
    """
    row = conn.execute(
        "SELECT 1 AS x FROM sqlite_master WHERE type='table' AND name='agents'").fetchone()
    if not row:
        return
    from .agent_names import next_available_name

    rows = conn.execute(
        "SELECT id, name, full_name FROM agents WHERE kind='ai' ORDER BY created_at, id"
    ).fetchall()
    used: set[str] = set()
    for r in rows:
        aid = str(r["id"])
        name = str(r["name"] or aid)
        key = name.strip().lower()
        if key and key not in used:
            used.add(key)
            continue
        new_name, _ = next_available_name(conn, name, taken=used)
        full = str(r["full_name"] or "")
        if "@" in full:
            new_full = f"{new_name}@{full.rsplit('@', 1)[1]}"
        else:
            new_full = new_name
        conn.execute(
            "UPDATE agents SET name=?, full_name=? WHERE id=?",
            (new_name, new_full, aid),
        )
        used.add(new_name.lower())


def _migrate_task_status_states(conn: sqlite3.Connection) -> None:
    """老库 tasks.status CHECK 不含 'archived'/'paused'；按 SQLite 官方做法重建表。

    用 tasks_new -> DROP -> RENAME（而不是 RENAME 旧表），避免其他表
    （posts.task_id / task_events.task_id / task_artifacts.task_id）的 FK 被改写。
    """
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='tasks'").fetchone()
    if not row:
        return
    ddl = row[0] or ""
    if "'archived'" in ddl and "'paused'" in ddl:
        return
    conn.commit()
    conn.execute("PRAGMA foreign_keys=OFF")
    conn.execute(TASKS_DDL_V_STATES)
    conn.execute(f"INSERT INTO tasks_new({TASK_COLUMNS}) "
                 f"SELECT {TASK_COLUMNS} FROM tasks")
    conn.execute("DROP TABLE tasks")
    conn.execute("ALTER TABLE tasks_new RENAME TO tasks")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.commit()


def init_db() -> None:
    conn = connect()
    try:
        # WAL 只在初始化时设置一次。每个请求都执行 PRAGMA journal_mode 会在
        # gunicorn 多线程 + 其他写事务并发时争写锁，曾导致认证 nonce 写入 500。
        conn.execute("PRAGMA journal_mode = WAL")
        _migrate_contributions(conn)   # 必须早于 executescript（后者 IF NOT EXISTS 建新表）
        _migrate_reply_kinds(conn)     # 老库 replies.kind 补 'comment'（重建表）
        _migrate_task_status_states(conn)  # 老库 tasks.status 补 'archived'/'paused'（重建表）
        _migrate_agent_names(conn)         # 老库 agent 重名先改名，再加唯一索引
        # 必须早于 executescript：schema.sql 的 room_messages 唯一索引引用
        # center_message_id / client_message_id，老库缺列会让整个初始化失败。
        _migrate_legacy_columns(conn)
        conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
        # room_messages.agent_id has a FK to agents.  System notices are a
        # legitimate sender; without this row SQLite foreign_key_check reports
        # every system notice as an orphan.
        conn.execute(
            "INSERT OR IGNORE INTO agents(id,name,kind,full_name,role,persona_json,status) "
            "VALUES('system','系统','ai','系统@local','executor','{}','active')")
        # Older rows might have been inserted as human by beta.75; never let
        # the system projector become human_id() and hijack the local Owner.
        conn.execute("UPDATE agents SET kind='ai' WHERE id='system' AND kind<>'ai'")
        # 轻量迁移（老库补列）
        _ensure_column(conn, "room_messages", "source", "source TEXT DEFAULT 'chat'")
        _ensure_column(conn, "room_messages", "attachment", "attachment TEXT")
        _ensure_column(conn, "rooms", "kind", "kind TEXT NOT NULL DEFAULT 'group'")
        _ensure_column(conn, "rooms", "title", "title TEXT")
        _ensure_column(conn, "rooms", "rating", "rating TEXT DEFAULT 'general'")
        _ensure_column(conn, "rooms", "content_level", "content_level TEXT")
        _ensure_column(conn, "rooms", "watcher_round", "watcher_round INTEGER DEFAULT 0")
        _ensure_column(conn, "nodes", "node_code", "node_code TEXT")
        _ensure_column(conn, "rooms", "session_started_at", "session_started_at TEXT")
        _ensure_column(conn, "rooms", "session_count", "session_count INTEGER DEFAULT 0")
        _ensure_column(conn, "rooms", "session_limit_minutes", "session_limit_minutes INTEGER DEFAULT 60")
        _ensure_column(conn, "argument_graphs", "ev", "ev REAL")
        _ensure_column(conn, "argument_graphs", "validation", "validation TEXT")
        _ensure_column(conn, "posts", "attachments", "attachments TEXT")
        # docs/83：帖子的「朋友圈/好友可见」分类列（老库补列，默认值保证既有帖不回归）。
        _ensure_column(conn, "posts", "kind",
                       "kind TEXT NOT NULL DEFAULT 'public_channel'")
        _ensure_column(conn, "posts", "visibility",
                       "visibility TEXT NOT NULL DEFAULT 'public'")
        ensure_message_columns(conn)
        # Phase 0：版本页需要看到 agent 的 IDE / backend / model / add-ons。
        _ensure_column(conn, "agent_runtime", "ide", "ide TEXT")
        _ensure_column(conn, "agent_runtime", "backend", "backend TEXT")
        _ensure_column(conn, "agent_runtime", "model", "model TEXT")
        _ensure_column(conn, "agent_runtime", "addons", "addons TEXT DEFAULT '[]'")
        _ensure_column(conn, "agent_runtime", "code_hash", "code_hash TEXT")
        _ensure_column(conn, "projects", "visibility",
                       "visibility TEXT NOT NULL DEFAULT 'project'")        # Phase 2：朋友圈赛马裁判列（老库补列；新库由 schema.sql 建出）
        _ensure_column(conn, "moment_rounds", "published_post_id", "published_post_id TEXT")
        _ensure_column(conn, "moment_rounds", "judge_model", "judge_model TEXT")
        _ensure_column(conn, "moment_rounds", "judge_notes", "judge_notes TEXT")
        for col in ("work_score", "interaction_score", "execution_score",
                    "initiative_score", "readability_score", "citizenship_score",
                    "boundary_score"):
            _ensure_column(conn, "moment_candidates", col, f"{col} REAL")
        _ensure_column(conn, "moment_candidates", "judge_reason", "judge_reason TEXT")
        _ensure_column(conn, "moment_candidates", "gate_ok", "gate_ok INTEGER DEFAULT 1")
        _seed_readings(conn)
        conn.commit()
    finally:
        conn.close()


# 读本种子：英文原文 + 中文标注（可继续扩充）
READINGS_SEED = [
    ("《逻辑哲学论》Tractatus Logico-Philosophicus", "Ludwig Wittgenstein", "命题 1",
     "The world is everything that is the case.",
     "世界是一切「发生的事」（事实的总和），而非事物的总和。开篇即把本体论锚在「事实」上。"),
    ("《逻辑哲学论》Tractatus Logico-Philosophicus", "Ludwig Wittgenstein", "命题 4.003",
     "Most of the propositions and questions to be found in philosophical works are not false but nonsensical.",
     "多数哲学命题不是假，而是无意义——它们越出了可说的边界。这正是「语言批判」的动机。"),
    ("《逻辑哲学论》Tractatus Logico-Philosophicus", "Ludwig Wittgenstein", "命题 7",
     "Whereof one cannot speak, thereof one must be silent.",
     "对于不可说的，必须保持沉默。与 6.522「确有不可说的东西，它显示自身」合读：边界之外只能显示，不能言说。"),
    ("《理想国》Republic", "Plato", "卷七 · 洞穴比喻（514a）",
     "Behold! human beings living in an underground den ... they see only their own shadows, or the shadows of one another, which the fire throws on the opposite wall of the cave.",
     "囚徒只见墙上影子，误以为即真实。洞穴比喻给出「教育与真理」的方法论：转身、走出、再返回。"),
    ("《理想国》Republic", "Plato", "卷四 · 正义（433a）",
     "Justice is ... doing one's own business and not being a busybody.",
     "正义=各部分各司其职。可迁移到 agent 分工：角色清晰、互不越界，是协作的底层约束。"),
    ("《哲学研究》Philosophical Investigations", "Ludwig Wittgenstein", "§43",
     "For a large class of cases ... the meaning of a word is its use in the language.",
     "词的意义在于其用法。反本质主义：别问「它是什么」，问「它怎么被用」。"),
    ("《哲学研究》Philosophical Investigations", "Ludwig Wittgenstein", "§66",
     "... the various resemblances ... family resemblances.",
     "「家族相似」：概念无共同本质，靠重叠的相似网络维系。对「agent 个性」这类模糊概念尤其适用。"),
]


def _seed_readings(conn: sqlite3.Connection) -> None:
    if conn.execute("SELECT COUNT(*) c FROM readings").fetchone()[0]:
        return
    for i, (b, a, s, e, ann) in enumerate(READINGS_SEED):
        conn.execute("INSERT INTO readings(book, author, section, english, annotation, ord) "
                     "VALUES (?,?,?,?,?,?)", (b, a, s, e, ann, i))
    conn.commit()


def rows_to_dicts(rows) -> list[dict]:
    return [dict(r) for r in rows]
