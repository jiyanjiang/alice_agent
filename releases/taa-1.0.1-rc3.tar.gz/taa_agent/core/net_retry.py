"""Tiny network retry helpers for model/API calls.

The failure that motivated this module is macOS/ISP resolver flakiness:

    Error: getaddrinfo ENOTFOUND api.deepseek.com

It is transient and happens *inside* the child process (opencode/Node), so
changing application-level timeouts alone cannot fix it.  We retry the whole
request with a short backoff and classify the final failure as `network_dns`
instead of reporting a misleading auth/model error.
"""
from __future__ import annotations

import os
import socket
import ssl
import subprocess
import time
import urllib.error
import urllib.request

TRANSIENT_TEXT = (
    "enotfound", "getaddrinfo", "name or service not known",
    "nodename nor servname provided", "temporary failure in name resolution",
    "econnreset", "connection reset", "etimedout", "timed out",
    "socket hang up", "fetch failed", "connection refused",
    "network is unreachable", "no route to host",
)

RETRY_HTTP = {408, 425, 429, 500, 502, 503, 504}
DEFAULT_BACKOFF = (2, 5, 60)
_ORIG_GETADDRINFO = socket.getaddrinfo
_DNS_GUARD_INSTALLED = False


def _dig_address(host: str) -> str | None:
    """Resolve an A record via dig, bypassing a broken mDNSResponder cache."""
    host = str(host or "").strip().rstrip(".")
    if not host or host.replace(".", "").isdigit() or ":" in host:
        return None
    try:
        out = subprocess.run(
            ["dig", "+short", "+time=2", "+tries=1", host, "A"],
            capture_output=True, text=True, timeout=5,
        ).stdout
        for line in out.splitlines():
            ip = line.strip()
            if ip.count(".") == 3 and all(p.isdigit() and 0 <= int(p) <= 255 for p in ip.split(".")):
                return ip
    except Exception:  # noqa: BLE001
        return None
    return None


def _fallback_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    """Use the normal resolver first; on failure, resolve via dig and retry
    with AI_NUMERICHOST.  The caller (urllib/http.client) keeps the original
    hostname for TLS SNI, so certificate checks still work."""
    force = os.environ.get("TAA_DNS_GUARD_TEST") == "1"
    if not force:
        try:
            return _ORIG_GETADDRINFO(host, port, family, type, proto, flags)
        except socket.gaierror:
            pass
    h = host.decode("utf-8", "ignore") if isinstance(host, bytes) else host
    ip = _dig_address(str(h))
    if not ip:
        raise socket.gaierror(8, "nodename nor servname provided, or not known")
    use_family = socket.AF_INET if family in (0, socket.AF_UNSPEC, socket.AF_INET) else family
    return _ORIG_GETADDRINFO(ip, port, use_family, type, proto,
                             flags | socket.AI_NUMERICHOST)


def install_socket_fallback() -> None:
    """Install once per process; harmless when getaddrinfo works normally."""
    global _DNS_GUARD_INSTALLED, _ORIG_GETADDRINFO
    if _DNS_GUARD_INSTALLED:
        return
    _ORIG_GETADDRINFO = socket.getaddrinfo
    socket.getaddrinfo = _fallback_getaddrinfo
    _DNS_GUARD_INSTALLED = True


def is_transient(value) -> bool:
    """True for DNS/socket/HTTP-transient failures; false for auth/bad request."""
    text = str(value or "").lower()
    return any(x in text for x in TRANSIENT_TEXT)


def _retryable(exc: BaseException) -> bool:
    if isinstance(exc, urllib.error.HTTPError):
        return exc.code in RETRY_HTTP
    if isinstance(exc, urllib.error.URLError):
        reason = exc.reason
        if isinstance(reason, ssl.SSLError):
            return False
        return is_transient(reason) or isinstance(reason, (socket.timeout, TimeoutError))
    if isinstance(exc, (socket.gaierror, socket.timeout, TimeoutError, ConnectionError)):
        return True
    if isinstance(exc, OSError):
        return is_transient(exc)
    return False


def urlopen_retry(req, *, timeout: int = 60, attempts: int = 4,
                  backoff: tuple[int, ...] = DEFAULT_BACKOFF, context=None):
    """`urllib.request.urlopen` with bounded retries for transient network IO.

    Default is 4 attempts over ~67s (2s/5s/60s) because macOS mDNSResponder
    can keep a partial/negative DNS answer for about a minute; the final 60s
    quiet gap lets that cache expire.  The request body (if any)
    is bytes and can be replayed safely.  Non-transient 4xx/5xx and TLS
    certificate failures are raised immediately.
    """
    last: BaseException | None = None
    attempts = max(1, int(attempts))
    for attempt in range(attempts):
        try:
            if context is not None:
                return urllib.request.urlopen(req, timeout=timeout, context=context)
            return urllib.request.urlopen(req, timeout=timeout)
        except urllib.error.HTTPError as exc:
            last = exc
            if not _retryable(exc) or attempt + 1 >= attempts:
                raise
        except Exception as exc:  # noqa: BLE001
            last = exc
            if not _retryable(exc) or attempt + 1 >= attempts:
                raise
        if attempt + 1 < attempts:
            wait = backoff[min(attempt, len(backoff) - 1)]
            time.sleep(wait)
    raise last or RuntimeError("network request failed")


install_socket_fallback()
