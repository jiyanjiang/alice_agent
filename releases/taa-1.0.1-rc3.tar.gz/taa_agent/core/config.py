"""统一配置：config.yaml（gitignored）+ 环境变量 + 内置默认值。

优先级：环境变量 > config.yaml > 默认值。
用法：
    from . import config
    port = config.get("server.port", 6030, env="TEAM_PORT")
    key  = config.get("llm.deepseek_api_key", "", env="DEEPSEEK_API_KEY")
"""
from __future__ import annotations

import json
import os
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
_CANDIDATES = [ROOT / "config.yaml", ROOT / "config" / "config.yaml"]

_cfg: dict = {}
_loaded = False


def taa_config_path() -> Path:
    """本机 TAA 配置路径（**唯一口径**）：TAA_HOME > ~/.taa。

    背景（P2.2b）：原来硬编码 `Path.home()/".taa"`，用 `--home` 装到别处时
    向导写入的 KEY 会落到错误目录，主程序却按 TAA_HOME 读——两处分家。
    """
    env = (os.environ.get("TAA_HOME") or "").strip()
    home = Path(env).expanduser() if env else Path.home() / ".taa"
    return home / "config.toml"


TAA_CONFIG = taa_config_path()      # 兼容别名（import 时求值；读写请用函数）


def _load() -> None:
    global _cfg, _loaded
    if _loaded:
        return
    _loaded = True
    try:
        import yaml
    except Exception:
        return
    for p in _CANDIDATES:
        if p.exists():
            try:
                _cfg = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            except Exception:
                _cfg = {}
            return


def get(path: str, default=None, env: str | None = None):
    """按点路径读取配置；env 给出环境变量名（最高优先级）。"""
    _load()
    if env and os.environ.get(env):
        return os.environ[env]
    node = _cfg
    for k in path.split("."):
        if isinstance(node, dict) and k in node:
            node = node[k]
        else:
            return default
    return node if node not in (None, "") else default


def get_int(path: str, default: int, env: str | None = None) -> int:
    try:
        return int(get(path, default, env))
    except (TypeError, ValueError):
        return default


def get_bool(path: str, default: bool = False, env: str | None = None) -> bool:
    v = get(path, default, env)
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in ("1", "true", "yes", "on")


def deepseek_key() -> str:
    """DeepSeek key：环境变量 > config.yaml > bootstrap/deepseek.key。"""
    for e in ("DEEPSEEK_API_KEY", "DS_KEY"):
        if os.environ.get(e):
            return os.environ[e].strip()
    v = get("llm.deepseek_api_key")
    if v:
        return str(v).strip()
    taa = _taa_llm()
    v = taa.get("deepseek_api_key") or taa.get("api_key")
    if v:
        return str(v).strip()
    p = ROOT / "bootstrap" / "deepseek.key"
    if p.exists():
        return p.read_text(encoding="utf-8").strip()
    return ""


def _taa_llm() -> dict:
    """~/.taa/config.toml 的 [llm] 段；Key 只在本机。"""
    try:
        data = tomllib.loads(taa_config_path().read_text(encoding="utf-8"))
    except Exception:
        return {}
    llm = data.get("llm") or {}
    return llm if isinstance(llm, dict) else {}


def alibaba_key() -> str:
    """阿里云百炼 / DashScope Key：环境变量 > config.yaml > ~/.taa。"""
    for e in ("DASHSCOPE_API_KEY", "ALIBABA_API_KEY", "QWEN_API_KEY"):
        if os.environ.get(e):
            return os.environ[e].strip()
    v = get("llm.alibaba_api_key")
    if v:
        return str(v).strip()
    taa = _taa_llm()
    v = taa.get("alibaba_api_key") or taa.get("dashscope_api_key")
    return str(v).strip() if v else ""


def volcano_key() -> str:
    """火山方舟 / Ark Key：环境变量 > config.yaml > ~/.taa。"""
    for e in ("ARK_API_KEY", "VOLCANO_API_KEY", "VOLCENGINE_API_KEY"):
        if os.environ.get(e):
            return os.environ[e].strip()
    v = get("llm.volcano_api_key") or get("llm.ark_api_key") or get("providers.ark_api_key")
    if v:
        return str(v).strip()
    taa = _taa_llm()
    v = taa.get("volcano_api_key") or taa.get("ark_api_key")
    return str(v).strip() if v else ""


def save_taa_key(provider: str, key: str) -> bool:
    """把 DeepSeek / 阿里 / 火山 Key 写进 ~/.taa/config.toml 的 [llm]，权限 600。"""
    names = {"deepseek": "deepseek_api_key", "alibaba": "alibaba_api_key",
             "volcano": "volcano_api_key", "ark": "ark_api_key"}
    name = names.get(provider)
    if not name or not key.strip():
        return False
    path = taa_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        text = ""
    lines = text.splitlines()
    start = next((i for i, line in enumerate(lines) if line.strip() == "[llm]"), -1)
    if start < 0:
        lines += ["", "[llm]"]
        start = len(lines) - 1
    end = next((i for i in range(start + 1, len(lines)) if lines[i].strip().startswith("[")), len(lines))
    targets = {name}
    if provider == "deepseek":
        targets.add("api_key")  # 兼容旧版 taa
    for target in targets:
        for i in range(start + 1, end):
            if lines[i].strip().startswith(target) and "=" in lines[i]:
                lines[i] = f"{target} = {json.dumps(key.strip(), ensure_ascii=False)}"
                break
        else:
            lines.insert(start + 1, f"{target} = {json.dumps(key.strip(), ensure_ascii=False)}")
            end += 1
    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    path.chmod(0o600)
    return True

