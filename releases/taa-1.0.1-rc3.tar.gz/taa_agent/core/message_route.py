"""Per-message ownership: one message may be executed by one consumer only.

P1A/A3（2026-10-30）改造要点：
  · claim 仍是原子 `INSERT OR IGNORE`（PK 已是 room_id+message_id，天然唯一）；
  · 新增租约 lease_until：进程崩了也不会永久占位，超时后可被回收；
  · 新增 finish()：claimed → done/failed，让路由表有终态（旧实现全是 claimed，
    路由表事实上退化成"写一行日志"）；
  · 回收**必须可接管**：旧实现 release_expired 只把行改成 failed，claim 仍按 owner 拒绝，
    孤儿行谁都碰不到（2026-10-30 修）；现在 failed/过期租约可被新 owner CAS 接管；
  · 兼容 row_factory 未设置的情况（旧代码读 row["owner"] 会 TypeError；tuple 兜底索引
    曾误写成 row[3]，实测恒空）。
"""
from __future__ import annotations

import sqlite3
import time

LEASE_SECONDS = 900          # 单条消息的执行租约（秒）；超时视为孤儿
NULL_LEASE_GRACE_SECONDS = 3600   # 租约列为 NULL 的历史行，超过此宽限期视为死行


def ensure(conn: sqlite3.Connection) -> None:
    conn.execute("""
      CREATE TABLE IF NOT EXISTS message_route (
        room_id TEXT NOT NULL,
        message_id INTEGER NOT NULL,
        client_message_id TEXT,
        owner TEXT NOT NULL,
        state TEXT NOT NULL DEFAULT 'claimed',
        created_at TEXT DEFAULT (datetime('now','localtime')),
        updated_at TEXT DEFAULT (datetime('now','localtime')),
        PRIMARY KEY (room_id, message_id)
      )
    """)
    # 老库补列（幂等）
    cols = {r[1] for r in conn.execute("PRAGMA table_info(message_route)")}
    if "lease_until" not in cols:
        conn.execute("ALTER TABLE message_route ADD COLUMN lease_until TEXT")
    if "finished_at" not in cols:
        conn.execute("ALTER TABLE message_route ADD COLUMN finished_at TEXT")
    if "note" not in cols:
        conn.execute("ALTER TABLE message_route ADD COLUMN note TEXT")
    conn.commit()


def _field(row, name: str, idx: int):
    """兼容 sqlite3.Row 与普通 tuple（旧代码未设 row_factory）。"""
    if row is None:
        return None
    try:
        return row[name]
    except (IndexError, KeyError, TypeError):
        pass
    try:
        return row[idx]
    except Exception:  # noqa: BLE001
        return None


def _owner_of(row) -> str:
    return str(_field(row, "owner", 0) or "")


def _state_of(row) -> str:
    return str(_field(row, "state", 1) or "")


def _lease_expired(row, now: float | None = None) -> bool:
    """租约是否已失效（到点，或 NULL 租约超过宽限期——历史死行）。"""
    now = time.time() if now is None else now
    stamp = lambda ts: time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))  # noqa: E731
    lu = str(_field(row, "lease_until", 2) or "")
    if lu:
        return lu < stamp(now)
    ca = str(_field(row, "created_at", 3) or "")
    return bool(ca) and ca < stamp(now - NULL_LEASE_GRACE_SECONDS)


def claim(conn: sqlite3.Connection, *, room_id: str, message_id: int,
          client_message_id: str = "", owner: str) -> bool:
    """Atomically acquire an execution owner for one local message."""
    ensure(conn)
    room_id = str(room_id or "")
    message_id = int(message_id or 0)
    owner = str(owner or "")
    if not room_id or not message_id or not owner:
        return False
    lease = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time() + LEASE_SECONDS))
    try:
        cur = conn.execute(
            "INSERT OR IGNORE INTO message_route"
            "(room_id,message_id,client_message_id,owner,state,lease_until) "
            "VALUES(?,?,?,?, 'claimed', ?)",
            (room_id, message_id, client_message_id or None, owner, lease))
        conn.commit()
        if cur.rowcount:
            return True
        row = conn.execute(
            "SELECT owner, state, lease_until, created_at FROM message_route "
            "WHERE room_id=? AND message_id=?",
            (room_id, message_id)).fetchone()
        if row is None:
            return False
        st, cur_owner = _state_of(row), _owner_of(row)
        # 终态不可重入：done/skipped 已经处理完，再放行会造成重复回答/重复执行。
        if st in ("done", "skipped"):
            return False
        expired = _lease_expired(row)
        # ① 同 owner 且租约仍有效 → 幂等重入（刷新租约）
        if st == "claimed" and cur_owner == owner and not expired:
            conn.execute(
                "UPDATE message_route SET lease_until=?, updated_at=datetime('now','localtime') "
                "WHERE room_id=? AND message_id=?",
                (lease, room_id, message_id))
            conn.commit()
            return True
        # ② failed / 租约过期 → 允许**接管**。旧实现只把行改 failed 却仍按 owner 拒绝，
        #    导致"回收"形同虚设：孤儿行永远没人能碰。这里用条件 UPDATE 做 CAS，
        #    并发下只有一个赢家（state/owner/lease 与读到时不一致则写不进去）。
        if st == "failed" or expired:
            old_lease = str(_field(row, "lease_until", 2) or "")
            cur2 = conn.execute(
                "UPDATE message_route SET owner=?, state='claimed', lease_until=?, "
                "finished_at=NULL, note=NULL, updated_at=datetime('now','localtime') "
                "WHERE room_id=? AND message_id=? AND state=? AND coalesce(owner,'')=? "
                "AND coalesce(lease_until,'')=?",
                (owner, lease, room_id, message_id, st, cur_owner, old_lease))
            conn.commit()
            return bool(cur2.rowcount)
        return False
    except sqlite3.Error:
        return False


def finish(conn: sqlite3.Connection, *, room_id: str, message_id: int,
           owner: str, state: str = "done", note: str = "") -> bool:
    """把归属行推进到终态（done/failed）。只有当前 owner 可以收尾。"""
    if state not in ("done", "failed", "skipped"):
        raise ValueError("state must be done|failed|skipped")
    ensure(conn)
    try:
        cur = conn.execute(
            "UPDATE message_route SET state=?, finished_at=datetime('now','localtime'), "
            "updated_at=datetime('now','localtime'), note=?, lease_until=NULL "
            "WHERE room_id=? AND message_id=? AND owner=? AND state='claimed'",
            (state, note or None, str(room_id), int(message_id), str(owner)))
        conn.commit()
        return bool(cur.rowcount)
    except sqlite3.Error:
        return False


def release_expired(conn: sqlite3.Connection, *, null_grace_hours: int = 1) -> int:
    """回收孤儿行，返回条数（供 dispatcher 周期调用）。

    两类孤儿：
      1) 有租约且已过期 —— 进程崩了/执行超时；
      2) **租约为 NULL 且创建超过宽阔限期** —— 历史版本写下的行永远等不到
         过期（`lease_until < now` 对 NULL 恒不成立），会永久占位。
         加 NULL 分支就是为了不再留这种"谁都碰不到"的死行。

    宽限期默认 1 小时：正常 claim 一定带租约，NULL 只可能是旧行或异常写入，
    给足时间避免误杀并发中的插入。
    """
    ensure(conn)
    try:
        cur = conn.execute(
            "UPDATE message_route SET state='failed', finished_at=datetime('now','localtime'), "
            "updated_at=datetime('now','localtime'), note='lease expired' "
            "WHERE state='claimed' AND lease_until IS NOT NULL AND lease_until < datetime('now','localtime')")
        n1 = int(cur.rowcount or 0)
        cur2 = conn.execute(
            "UPDATE message_route SET state='failed', finished_at=datetime('now','localtime'), "
            "updated_at=datetime('now','localtime'), note='lease missing (reclaimed)' "
            "WHERE state='claimed' AND lease_until IS NULL "
            "AND created_at < datetime('now','localtime', ?)",
            (f"-{max(1, int(null_grace_hours))} hours",))
        n2 = int(cur2.rowcount or 0)
        conn.commit()
        return n1 + n2
    except sqlite3.Error:
        return 0


def stats(conn: sqlite3.Connection) -> dict:
    """路由表健康快照（自检/巡检用，只读）。"""
    ensure(conn)
    out = {"claimed": 0, "done": 0, "failed": 0, "skipped": 0, "stale_claimed": 0}
    try:
        for row in conn.execute("SELECT state, COUNT(*) FROM message_route GROUP BY state"):
            st = str(row[0] or "")
            if st in out:
                out[st] = int(row[1] or 0)
        out["stale_claimed"] = int(conn.execute(
            "SELECT COUNT(*) FROM message_route WHERE state='claimed' AND ("
            "(lease_until IS NOT NULL AND lease_until < datetime('now','localtime')) OR "
            "(lease_until IS NULL AND created_at < datetime('now','localtime','-1 hours')))"
        ).fetchone()[0] or 0)
    except sqlite3.Error:
        pass
    return out


def owner(conn: sqlite3.Connection, room_id: str, message_id: int) -> str:
    ensure(conn)
    row = conn.execute(
        "SELECT owner FROM message_route WHERE room_id=? AND message_id=?",
        (str(room_id), int(message_id))).fetchone()
    return _owner_of(row)
