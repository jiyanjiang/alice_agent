"""Inbox brief 生命周期治理（P1A/A5，2026-10-30）。

问题（P0-4）：task 已经是 review/done，`agents/<id>/inbox/<task>.json` 仍留在原地，
dispatcher 还会把它当活干（Delta 实测一条历史 brief 被执行 249 秒，堵住整条队列）。

诚实说明"同事务"的边界：brief 是**文件**，task 状态在 **SQLite**，两者不可能真同事务。
本模块用三件套逼近：
  1) 状态变更瞬间立即搬运（`on_task_terminal`，由 tasks.submit/review/block 调用）；
  2) 启动扫描 + 周期扫描兜底（`scan`，由 dispatcher 调用），覆盖进程崩溃/断电漏搬的情况；
  3) 每次搬运留痕（`stale/MOVED-*.jsonl`），可复盘"为什么这条被搬走"。

搬运一律是 **move，不 delete**：`inbox/done/`（正常完工）或 `inbox/stale/`（终态残留/被取消/阻塞）。
"""
from __future__ import annotations

import json
import os
import shutil
import sqlite3
import time
from pathlib import Path

TERMINAL_TO_DONE = {"review", "done"}
TERMINAL_TO_STALE = {"cancelled", "blocked", "archived"}


def _db_path() -> Path:
    env = (os.environ.get("TEAMAI_UI_DB") or os.environ.get("TEAMAI_DB") or "").strip()
    if env:
        return Path(env)
    from .db import DB_PATH
    return Path(DB_PATH)


def _agents_root() -> Path:
    """brief 的唯一根（P1.5）：与 data.db 同源，见 core.db.AGENTS_DIR。"""
    from .db import AGENTS_DIR
    return Path(AGENTS_DIR)


def _legacy_roots() -> list[Path]:
    """旧的 brief 落点（代码根/agents）。仅用于迁移与兜底，不是权威位置。"""
    from .db import ROOT
    out: list[Path] = []
    try:
        p = Path(ROOT) / "agents"
        if p.exists() and p.resolve() != _agents_root().resolve():
            out.append(p)
    except OSError:
        pass
    return out


def migrate_legacy() -> dict:
    """把旧代码根 inbox 里的简报搬到 AGENTS_DIR（move，不删，不覆盖同名）。

    为什么必须做：升级前 brief 写在 `<home>/app/agents/…`，升级后读 `<home>/agents/…`；
    不迁移的话旧 brief 既不会被执行、也不会被清理，等于**永久占位**（P0-4 同型）。
    只搬顶层 `*.json`（简报本体），不动 `_attempts.json`、`.running-*.lock` 与子目录。
    """
    stats = {"moved": 0, "skipped": 0, "agents": 0}
    dst_root = _agents_root()
    for src_root in _legacy_roots():
        try:
            agent_dirs = sorted(p for p in src_root.iterdir() if p.is_dir())
        except OSError:
            continue
        moved_agents: set[str] = set()
        for agent_dir in agent_dirs:
            inbox = agent_dir / "inbox"
            if not inbox.is_dir():
                continue
            for brief in sorted(inbox.glob("*.json")):
                if brief.name.startswith("_"):
                    continue
                dst_dir = dst_root / agent_dir.name / "inbox"
                dst = dst_dir / brief.name
                if dst.exists():
                    stats["skipped"] += 1
                    continue
                try:
                    dst_dir.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(brief), str(dst))
                    stats["moved"] += 1
                    moved_agents.add(agent_dir.name)
                    _log(dst_dir.parent, {"task_id": brief.stem, "from": str(brief),
                                          "to": str(dst), "reason": "legacy inbox migrated",
                                          "dest": "migrate"})
                except (OSError, shutil.Error):
                    stats["skipped"] += 1
        stats["agents"] = len(moved_agents)
    return stats


def _task_status(task_id: str) -> str:
    try:
        c = sqlite3.connect(f"file:{_db_path()}?mode=ro", uri=True, timeout=5)
        try:
            row = c.execute("SELECT status FROM tasks WHERE id=?", (task_id,)).fetchone()
            return str(row[0] or "") if row else ""
        finally:
            c.close()
    except sqlite3.Error:
        return ""


def _read_brief(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8")) or {}
    except Exception:  # noqa: BLE001
        return {}


def _log(agent_dir: Path, record: dict) -> None:
    d = agent_dir / "inbox" / "stale"
    d.mkdir(parents=True, exist_ok=True)
    line = json.dumps({"ts": time.strftime("%Y-%m-%d %H:%M:%S"), **record},
                      ensure_ascii=False)
    try:
        with open(d / f"MOVED-{time.strftime('%Y%m%d')}.jsonl", "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def _move(brief_path: Path, agent_dir: Path, dest: str, reason: str) -> bool:
    """把 brief 移到 inbox/<dest>/，留痕；已存在同名文件时加时间戳后缀，不覆盖。"""
    target_dir = brief_path.parent / dest
    target_dir.mkdir(parents=True, exist_ok=True)
    dest_path = target_dir / brief_path.name
    if dest_path.exists():
        dest_path = target_dir / f"{brief_path.stem}.{int(time.time())}{brief_path.suffix}"
    try:
        shutil.move(str(brief_path), str(dest_path))
    except (OSError, shutil.Error):
        return False
    _log(agent_dir, {"task_id": brief_path.stem, "from": str(brief_path),
                     "to": str(dest_path), "reason": reason, "dest": dest})
    return True


def on_task_terminal(task_id: str, state: str) -> bool:
    """状态变更瞬间的即时搬运（由 tasks 层调用，失败静默——不能拖垮状态机）。"""
    if not task_id:
        return False
    dest = "done" if state in TERMINAL_TO_DONE else ("stale" if state in TERMINAL_TO_STALE else "")
    if not dest:
        return False
    moved = False
    try:
        root = _agents_root()
        if not root.exists():
            return False
        for agent_dir in root.iterdir():
            p = agent_dir / "inbox" / f"{task_id}.json"
            if p.exists():
                moved = _move(p, agent_dir, dest, f"task -> {state}") or moved
    except OSError:
        pass
    return moved


def scan(dry_run: bool = False) -> dict:
    """启动/周期扫描：先迁移旧位置，再把终态任务的 brief 搬走。返回统计。"""
    stats = {"scanned": 0, "moved_done": 0, "moved_stale": 0, "errors": 0, "migrated": 0}
    if not dry_run:
        # P1.5：升级后的第一次扫描先把旧代码根的 brief 搬过来，再按终态清理
        try:
            stats["migrated"] = int(migrate_legacy().get("moved") or 0)
        except Exception:  # noqa: BLE001
            stats["errors"] += 1
    root = _agents_root()
    if not root.exists():
        return stats
    terminal_cache: dict[str, str] = {}
    for agent_dir in sorted(root.iterdir()):
        inbox = agent_dir / "inbox"
        if not inbox.is_dir():
            continue
        for brief in sorted(inbox.glob("*.json")):
            if brief.name.startswith("_"):
                continue        # `_attempts.json` 之类记账文件不是简报
            stats["scanned"] += 1
            tid = brief.stem
            if tid not in terminal_cache:
                terminal_cache[tid] = _task_status(tid)
            st = terminal_cache[tid]
            if st not in TERMINAL_TO_DONE and st not in TERMINAL_TO_STALE:
                continue
            dest = "done" if st in TERMINAL_TO_DONE else "stale"
            if dry_run:
                stats["moved_done" if dest == "done" else "moved_stale"] += 1
                continue
            try:
                if _move(brief, agent_dir, dest, f"scan: task status={st}"):
                    stats["moved_done" if dest == "done" else "moved_stale"] += 1
            except OSError:
                stats["errors"] += 1
    return stats
