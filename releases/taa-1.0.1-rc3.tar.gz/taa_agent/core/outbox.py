"""Outbox helpers for local-origin group messages that have not synced yet."""
from __future__ import annotations

LOCAL_EXCLUDE = "('center','peer','p2p','system')"


def pending(conn, room_id: str = "", limit: int = 200) -> list[dict]:
    where = [
        "coalesce(source,'chat') NOT IN " + LOCAL_EXCLUDE,
        "coalesce(direct_delivered,0)=0",
        # 终态不再算"未同步"：skipped=结构上不走直投，gave_up=直投放弃（中心兜底）
        "coalesce(direct_state,'pending') NOT IN ('delivered','skipped')",
        "center_message_id IS NULL",
        "kind NOT IN ('skip','system','session')",
        "agent_id <> 'system'",
        "agent_id NOT LIKE 'remote-human-%'",
    ]
    args: list = []
    if room_id:
        where.insert(0, "room_id=?")
        args.append(room_id)
    sql = ("SELECT id,room_id,agent_id,source,kind,created_at,created_at_utc,"
           "client_message_id,substr(body,1,160) body FROM room_messages WHERE " +
           " AND ".join(where) + " ORDER BY id LIMIT ?")
    args.append(int(limit))
    return [dict(r) for r in conn.execute(sql, args).fetchall()]
