"""主题调研/写作 —— 把导师的写作纪律固化成可执行小工具。

七步（docs/36 真人风格 · 工作法）：
  1 大纲 → 2 查资料 → 3 建事实库 → 4 写作 → 5 核查 → 6 微调(可润可不润就不润) → 7 提交

本模块**确定性、不调 LLM**：只做脚手架与门禁（结构/出处/占位/字数）。
事实库格式沿用既有约定（`## F###` 含 claim/URL/来源分级/原文摘录/用于），与 `scripts/facts_check.py` 对齐。
"""
from __future__ import annotations

import contextlib
import hashlib
import json
import os
import re
import threading
import unicodedata
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / "research"
META_FILE = "meta.json"
CODE_PREFIX = "r-"
PROMPT_HASH_LEN = 12
CODE_RE = re.compile(r"^r-[0-9a-f]{12}$")
VERSION_RE = re.compile(r"^v[1-9][0-9]*$")

STEPS = [
    ("1 大纲", "先出写作大纲（目标/读者/结论主张/章节/每章所需资料点）"),
    ("2 查资料", "按大纲逐点查资料；来源分级（官方/一手 > 权威二手）；英文优先"),
    ("3 建事实库", "FACTS.md：每条 `## F###` 含 claim/URL/来源分级/原文摘录/用于"),
    ("4 写作", "按大纲与事实库写作；**事实库没支撑的不写**"),
    ("5 核查", "稿中每个 URL/数字须能在事实库找到；找不到=捏造→删"),
    ("6 微调", "只润必须润的；**可润可不润就不润**"),
    ("7 提交", "事实库 + 稿 + 核查结论 一起交付"),
]

OUTLINE_TMPL = """# 大纲 · {title}

> 第 1 步（docs/37）。先出大纲，再查资料。

## 目标 / 读者
- 目标：
- 读者：

## 结论主张（一句话）
- 

## 章节大纲（每章列出「需要的资料点」）
1. 
2. 

## 事实需求清单（第 2 步据此查资料）
- [ ] 
"""

FACTS_TMPL = """# 事实库 · {title}

> 第 3 步：每条 `## F###` 含 claim / URL / 来源分级(一手|官方|权威二手) / 原文摘录 / 用于。
> 纪律：**事实库中没有的，写作时不得出现**。门禁：`teamai research check {slug}`

## F001
- claim：
- URL：
- 来源分级：一手
- 原文摘录：
- 用于：
"""

DRAFT_TMPL = """# 稿 · {title}

> 第 4 步：只写事实库支撑的内容。第 5 步：稿中每个数字/引语都要能在 FACTS.md 找到出处。

（正文）
"""


def normalize_prompt(prompt: str) -> str:
    """Normalize a prompt for stable identity checks.

    This is deliberately conservative: NFKC, line-ending normalization,
    whitespace collapse, and trim. It does not rewrite punctuation or
    semantics. The normalized text is for dedupe, not for display.
    """
    text = unicodedata.normalize("NFKC", str(prompt or ""))
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        raise ValueError("prompt 不能为空")
    return text


def prompt_identity(prompt: str) -> dict:
    """Return the stable code and full fingerprint for a prompt.

    code is the short, filesystem-safe identity (r-<12 hex>).
    normalized_prompt_hash is the full SHA-256 used as a collision guard.
    """
    normalized = normalize_prompt(prompt)
    digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
    return {
        "code": CODE_PREFIX + digest[:PROMPT_HASH_LEN],
        "normalized_prompt": normalized,
        "normalized_prompt_hash": digest,
    }


def prompt_code(prompt: str) -> str:
    """Return only the filesystem-safe prompt code."""
    return prompt_identity(prompt)["code"]


def _normalize_version(version: str | None) -> str | None:
    if version is None:
        return None
    v = str(version).strip().lower()
    if v.startswith("v"):
        v = v[1:]
    if not re.fullmatch(r"[1-9][0-9]*", v):
        raise ValueError(f"版本格式应为 v1/v2/...，收到：{version!r}")
    return "v" + v


def _read_meta(d: Path) -> dict | None:
    p = d / META_FILE
    if not p.exists():
        return None
    try:
        meta = json.loads(p.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"{d.name}/{META_FILE} 不是合法 JSON：{exc}") from exc
    if not isinstance(meta, dict):
        raise ValueError(f"{d.name}/{META_FILE} 必须是 JSON object")
    return meta


def _available_versions(d: Path, meta: dict) -> list[str]:
    versions = set()
    for v in meta.get("versions") or []:
        if isinstance(v, str) and VERSION_RE.match(v):
            versions.add(v)
    if d.exists():
        for child in d.iterdir():
            if child.is_dir() and VERSION_RE.match(child.name):
                versions.add(child.name)
    return sorted(versions, key=lambda v: int(v[1:]))


_LOCKS: dict[str, threading.Lock] = {}
_LOCKS_GUARD = threading.Lock()


@contextlib.contextmanager
def _code_lock(code_dir: Path):
    """Serialize version allocation for one code, across threads and processes.

    The in-process lock covers threads; fcntl.flock covers separate processes
    on POSIX. A failure to use flock degrades to thread-only locking.
    """
    key = str(code_dir)
    with _LOCKS_GUARD:
        lock = _LOCKS.setdefault(key, threading.Lock())
    with lock:
        code_dir.mkdir(parents=True, exist_ok=True)
        fh = None
        try:
            fh = open(code_dir / ".lock", "a+")
            try:
                import fcntl
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
            except (ImportError, OSError):
                pass
            yield
        finally:
            if fh is not None:
                try:
                    import fcntl
                    fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
                except (ImportError, OSError):
                    pass
                fh.close()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _write_meta(code_dir: Path, meta: dict) -> None:
    """Write meta.json atomically; readers never see a partial JSON document."""
    code_dir.mkdir(parents=True, exist_ok=True)
    tmp = code_dir / f".{META_FILE}.{os.getpid()}.{threading.get_ident()}.tmp"
    tmp.write_text(json.dumps(meta, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                   encoding="utf-8")
    os.replace(tmp, code_dir / META_FILE)


def _write_unique(path: Path, text: str) -> Path:
    """Create a new file without overwriting an existing run."""
    for i in range(1000):
        candidate = path if i == 0 else path.with_name(f"{path.stem}_{i}{path.suffix}")
        try:
            with open(candidate, "x", encoding="utf-8") as fh:
                fh.write(text)
            return candidate
        except FileExistsError:
            continue
    raise RuntimeError(f"无法分配唯一输出文件：{path}")


def _unique_dir(base: Path) -> Path:
    for i in range(1000):
        candidate = base if i == 0 else base.with_name(f"{base.name}_{i}")
        try:
            candidate.mkdir(parents=True, exist_ok=False)
            return candidate
        except FileExistsError:
            continue
    raise RuntimeError(f"无法分配唯一输出目录：{base}")


def _safe_tag(tag: str) -> str:
    return re.sub(r"[\\/:*?\"<>|\s]+", "_", str(tag or "")).strip("._")[:40]


def _default_title(prompt: str) -> str:
    text = normalize_prompt(prompt)
    return text[:80]


def resolve_ref(ref: str, *, version: str | None = None,
                root: Path | None = None) -> dict:
    """Resolve a legacy slug or a modern prompt-code/version to a directory.

    Supported references:
      legacy-slug
      r-<12 hex>
      r-<12 hex>@v2
      r-<12 hex>/v2

    Legacy directories stay at research/<slug>. Modern directories use
    research/<code>/<version>. This function only reads; it never creates
    or overwrites a directory.
    """
    root = root or WORK
    raw = str(ref or "").strip()
    if not raw:
        raise ValueError("research ref 不能为空")

    embedded = None
    if "@" in raw:
        raw, marker = raw.rsplit("@", 1)
        embedded = _normalize_version(marker)
    elif "/" in raw:
        base, marker = raw.rsplit("/", 1)
        if VERSION_RE.match(marker) or marker.isdigit():
            raw, embedded = base, _normalize_version(marker)
        else:
            raise ValueError(f"非法 research 路径：{ref!r}")

    requested_version = _normalize_version(version)
    if embedded and requested_version and embedded != requested_version:
        raise ValueError(f"ref 中的版本 {embedded} 与 --version {requested_version} 冲突")
    version = requested_version or embedded

    if not _slug_ok(raw):
        raise ValueError("research ref 仅限字母数字-_，或 r-<12位十六进制>")

    d = root / raw
    if CODE_RE.match(raw):
        if not d.exists():
            raise ValueError(f"research/{raw} 不存在")
        meta = _read_meta(d)
        if meta is None:
            raise ValueError(f"research/{raw} 缺 {META_FILE}")
        if meta.get("code") and meta["code"] != raw:
            raise ValueError(f"research/{raw} 的 meta.code 不一致：{meta['code']!r}")
        digest = meta.get("normalized_prompt_hash")
        if digest and CODE_PREFIX + str(digest)[:PROMPT_HASH_LEN] != raw:
            raise ValueError(f"research/{raw} 的 prompt hash 与 code 不一致")
        versions = _available_versions(d, meta)
        if not versions:
            raise ValueError(f"research/{raw} 没有 v1/v2 等版本目录")
        if version is None:
            latest = meta.get("latest")
            version = latest if latest in versions else versions[-1]
        if version not in versions:
            raise ValueError(f"research/{raw} 没有 {version}；可用：{', '.join(versions)}")
        vdir = d / version
        if not vdir.is_dir():
            raise ValueError(f"research/{raw}/{version} 不存在")
        return {"kind": "modern", "code": raw, "version": version,
                "path": vdir, "dir": str(vdir), "meta": meta,
                "code_dir": str(d), "requested_version": requested_version}

    if version:
        raise ValueError(f"legacy research/{raw} 不支持 --version")
    if not d.exists():
        raise ValueError(f"research/{raw} 不存在（先 `research new {raw}`）")
    return {"kind": "legacy", "code": None, "version": None,
            "path": d, "dir": str(d), "meta": None, "code_dir": None,
            "requested_version": None}


def _slug_ok(s: str) -> bool:
    return bool(re.match(r"^[a-zA-Z0-9][a-zA-Z0-9_-]{0,60}$", s or ""))


def new(slug: str, title: str | None = None, root: Path | None = None) -> dict:
    root = root or WORK
    if not _slug_ok(slug):
        raise ValueError("slug 仅限字母数字-_（≤60）")
    d = root / slug
    d.mkdir(parents=True, exist_ok=True)
    t = title or slug
    (d / "OUTLINE.md").write_text(OUTLINE_TMPL.format(title=t), encoding="utf-8")
    (d / "FACTS.md").write_text(FACTS_TMPL.format(title=t, slug=slug), encoding="utf-8")
    (d / "DRAFT.md").write_text(DRAFT_TMPL.format(title=t), encoding="utf-8")
    return {"dir": str(d), "slug": slug}


def new_prompt(prompt: str, title: str | None = None, *, reuse: bool = False,
               root: Path | None = None) -> dict:
    """Create or reuse a modern version for a prompt.

    Default behaviour is a new version (v1, then v2...). reuse=True selects
    the latest existing version instead. The allocation and meta update are
    serialized per code; an empty/missing version is never overwritten.
    """
    ident = prompt_identity(prompt)
    code = ident["code"]
    root = root or WORK
    code_dir = root / code
    with _code_lock(code_dir):
        meta = _read_meta(code_dir)
        if meta is not None:
            if meta.get("code") and meta["code"] != code:
                raise ValueError(f"research/{code} 的 meta.code 不一致：{meta['code']!r}")
            digest = meta.get("normalized_prompt_hash")
            if digest and CODE_PREFIX + str(digest)[:PROMPT_HASH_LEN] != code:
                raise ValueError(f"research/{code} 的 prompt hash 与 code 不一致")
        versions = _available_versions(code_dir, meta or {})
        if reuse and versions:
            latest = (meta or {}).get("latest")
            version = latest if latest in versions else versions[-1]
            created = False
        else:
            version = "v1" if not versions else f"v{int(versions[-1][1:]) + 1}"
            created = True

        vdir = code_dir / version
        if created:
            try:
                vdir.mkdir()
            except FileExistsError as exc:
                raise RuntimeError(f"research/{code}/{version} 已被并发创建") from exc
        elif not vdir.is_dir():
            raise ValueError(f"research/{code}/{version} 不存在")

        t = title or (meta or {}).get("title") or _default_title(prompt)
        if created:
            (vdir / "OUTLINE.md").write_text(OUTLINE_TMPL.format(title=t), encoding="utf-8")
            (vdir / "FACTS.md").write_text(
                FACTS_TMPL.format(title=t, slug=f"{code}/{version}"), encoding="utf-8")
            (vdir / "DRAFT.md").write_text(DRAFT_TMPL.format(title=t), encoding="utf-8")

        now = _now()
        if meta is None:
            meta = {
                "code": code,
                "prompt": str(prompt),
                "normalized_prompt": ident["normalized_prompt"],
                "normalized_prompt_hash": ident["normalized_prompt_hash"],
                "title": t,
                "versions": [],
                "latest": None,
                "created_at": now,
            }
        if title:
            meta["title"] = title
        merged = set(versions) | {version}
        for old in meta.get("versions") or []:
            if isinstance(old, str) and VERSION_RE.match(old):
                merged.add(old)
        meta["versions"] = sorted(merged, key=lambda v: int(v[1:]))
        meta["latest"] = version
        meta["updated_at"] = now
        _write_meta(code_dir, meta)

        return {
            "kind": "modern",
            "code": code,
            "version": version,
            "ref": f"{code}@{version}",
            "dir": str(vdir),
            "code_dir": str(code_dir),
            "created": created,
            "title": t,
            "normalized_prompt_hash": ident["normalized_prompt_hash"],
        }


def parse_facts(text: str) -> list[dict]:
    blocks = [b for b in re.split(r"\n(?=## )", text or "") if b.strip().startswith("## ")]
    out = []
    for b in blocks:
        fid = b[3:].split()[0] if len(b) > 3 else "?"
        urls = re.findall(r"https?://[^\s)>\]]+", b)
        out.append({
            "id": fid,
            "urls": urls,
            "url_ok": bool(urls) or ("无公开 URL" in b),
            "has_excerpt": ("原文摘录" in b) or ("原文" in b),
            "has_used": "用于" in b,
            "has_grade": ("来源分级" in b) or ("来源" in b),
        })
    return out


def _words(text: str) -> int:
    return len(re.findall(r"[\u4e00-\u9fff]|[A-Za-z]+|\d+", text or ""))


def check(slug: str, *, min_words: int = 0, max_words: int = 0,
          version: str | None = None, root: Path | None = None) -> dict:
    root = root or WORK
    res: dict = {"slug": slug, "checks": [], "ok": True}

    def add(name, ok, detail=""):
        res["checks"].append({"name": name, "ok": bool(ok), "detail": str(detail)[:180]})
        if not ok:
            res["ok"] = False

    try:
        d = resolve_ref(slug, version=version, root=root)["path"]
    except ValueError as exc:
        add("目录存在", False, str(exc))
        return res
    facts = (d / "FACTS.md").read_text(encoding="utf-8") if (d / "FACTS.md").exists() else ""
    draft = (d / "DRAFT.md").read_text(encoding="utf-8") if (d / "DRAFT.md").exists() else ""
    fs = [f for f in parse_facts(facts) if f["id"] != "F000"]
    add("事实条数≥3", len([f for f in fs if f["has_excerpt"]]) >= 3, f"{len(fs)} 条")
    bad = [f["id"] for f in fs if not (f["url_ok"] and f["has_excerpt"] and f["has_used"])]
    add("每条含 URL/原文/用于", not bad, "缺: " + ", ".join(bad))
    domains = set()
    for f in fs:
        for u in f["urls"]:
            m = re.match(r"https?://([^/]+)", u)
            domains.add(m.group(1) if m else u)
    add("独立域名≥2", len(domains) >= 2, f"{len(domains)}: {sorted(domains)[:4]}")
    ph = re.findall(r"待核|待证|待补|待填|TODO|TBD", draft)
    add("稿中无占位符", not ph, ",".join(sorted(set(ph))))
    fu = set()
    for f in fs:
        fu |= set(f["urls"])
    miss = [u for u in set(re.findall(r"https?://[^\s)>\]]+", draft)) if u not in fu]
    add("稿中 URL 都能在事实库找到", not miss, "缺出处: " + ", ".join(miss[:3]))
    words = _words(draft)
    if min_words:
        add(f"字数≥{min_words}", words >= min_words, str(words))
    if max_words:
        add(f"字数≤{max_words}", words <= max_words, str(words))
    res["facts"] = len(fs)
    res["words"] = words
    return res


def status(slug: str, root: Path | None = None, *, version: str | None = None) -> dict:
    root = root or WORK
    try:
        d = resolve_ref(slug, version=version, root=root)["path"]
    except ValueError:
        if version is not None:
            raise
        # Preserve the old status behaviour: a missing workspace is reported
        # as empty instead of raising.
        return {"slug": slug, "outline": False, "facts": 0, "draft_words": 0}
    facts = parse_facts((d / "FACTS.md").read_text(encoding="utf-8")) if (d / "FACTS.md").exists() else []
    draft = (d / "DRAFT.md").read_text(encoding="utf-8") if (d / "DRAFT.md").exists() else ""
    return {"slug": slug, "outline": (d / "OUTLINE.md").exists(),
            "facts": len([f for f in facts if f["id"] != "F000"]),
            "draft_words": _words(draft)}


def list_research(*, include_legacy: bool = False, root: Path | None = None) -> list[dict]:
    """List modern prompt-code workspaces; optionally include legacy dirs.

    No timestamps are used for ordering. Results are stable by code/slug.
    """
    root = root or WORK
    if not root.exists():
        return []
    out: list[dict] = []
    for d in root.iterdir():
        if (not d.is_dir() or d.name.startswith(".") or d.name.startswith("_")
                or d.name == "__pycache__"):
            continue
        if CODE_RE.match(d.name):
            item = {"kind": "modern", "code": d.name, "slug": None,
                    "title": d.name, "versions": [], "latest": None}
            try:
                meta = _read_meta(d)
                if meta is None:
                    item["error"] = f"缺 {META_FILE}"
                else:
                    versions = _available_versions(d, meta)
                    item["title"] = str(meta.get("title") or d.name)
                    item["versions"] = versions
                    latest = meta.get("latest")
                    item["latest"] = latest if latest in versions else (
                        versions[-1] if versions else None)
                    if not versions:
                        item["error"] = "没有 v1/v2 等版本目录"
            except ValueError as exc:
                item["error"] = str(exc)
            out.append(item)
        elif include_legacy:
            out.append({"kind": "legacy", "code": None, "slug": d.name,
                        "title": d.name, "versions": [], "latest": None})
    return sorted(out, key=lambda x: (0 if x["kind"] == "modern" else 1,
                                      x.get("code") or x.get("slug") or ""))


def ask(slug: str, prompt: str, *, model: str = "deepseek-v4-pro",
        ali_model: str | None = None, system: str | None = None,
        temperature: float = 0.3, max_tokens: int = 16000, timeout: int = 900,
        tag: str = "", version: str | None = None, root: Path | None = None,
        json_mode: bool = False) -> dict:
    """[v2 升级件] 用 DeepSeek（优先）或阿里百炼就某一问题做调研。

    输出存 research/<ref>/ask/。支持 legacy slug 与现代 r-<code>/vN；
    脚手架与门禁仍为确定性。
    """
    import time as _time
    root = root or WORK
    resolved = resolve_ref(slug, version=version, root=root)
    d = resolved["path"]
    msgs = ([{"role": "system", "content": system}] if system else []) + [{"role": "user", "content": prompt}]
    ans, meta = _chat(msgs, model=model, ali_model=ali_model, temperature=temperature,
                      max_tokens=max_tokens, timeout=timeout, json_mode=json_mode)
    finish = meta.get("finish_reason", "")
    usage = meta.get("usage", {})
    outdir = d / "ask"; outdir.mkdir(exist_ok=True)
    tag_text = _safe_tag(tag)
    name = _time.strftime("%Y%m%d_%H%M%S") + (f"_{tag_text}" if tag_text else "") + ".md"
    p = _write_unique(outdir / name,
                      f"# ask · {meta['provider']}/{meta['model']}\n\n"
                      f"- 时间：{_time.strftime('%Y-%m-%d %H:%M:%S')}\n"
                      f"- provider：{meta['provider']}\n"
                      f"- model：{meta['model']}\n"
                      f"- fallback：{meta.get('fallback_from') or '-'}\n"
                      f"- 用量：{usage}\n- finish：{finish}\n- tag：{tag_text or '-'}\n\n"
                      f"## 提问\n\n{prompt}\n\n## 回答\n\n{ans}\n")
    return {
        "file": str(p), "chars": len(ans), "usage": usage, "text": ans,
        "finish_reason": finish, "provider": meta["provider"], "model": meta["model"],
        "fallback_from": meta.get("fallback_from"), "kind": resolved["kind"],
        "code": resolved.get("code"), "version": resolved.get("version"),
        "ref": f"{resolved['code']}@{resolved['version']}" if resolved.get("code") else slug,
    }


# ------------------------------------------------------------------ deep ask（多轮深挖）
DEEP_SYSTEM = (
    "你是严谨的科研调研助手，服务一位博士生。纪律："
    "①英文/官方一手来源优先，二手来源须注明；"
    "②结论尽量附**可核验的来源线索**（标准号/文献/机构/链接），给不出时显式标注「无来源」；"
    "③严格区分「事实」与「判断」；④不确定处显式标注，不得臆造；"
    "⑤中文作答，专业术语首次出现即用人话解释。"
)

# 每轮追问模板（第 1 轮含问题本体）
DEEP_PROMPTS = [
    "{q}\n\n请按：①把问题拆成 3–6 个可独立调研的子问题；②逐一给出初步回答（分节），"
    "每个结论后标注来源线索与置信度（高/中/低），缺口显式写「缺证据」。",
    "针对你上一轮回答的每个子问题，做三件事：①补上可核验的来源线索（标准号/文献标题/机构/链接）；"
    "②给出反例、争议或适用边界；③列出仍缺证据的缺口与验证方法。",
    "综合前两轮，输出一份**结构化深挖报告**：\n(1) 结论与置信度；\n"
    "(2) 支撑证据（含来源线索与分级：官方/一手/权威二手）；\n(3) 争议与反对观点；\n"
    "(4) 尚未解决的问题 + 建议的下一步调研路径；\n"
    "(5) 可供事实库入库的候选条目（每条给 claim / 来源线索 / 分级 / 用于）。",
]


DEEPSEEK_CHAT_URL = "https://api.deepseek.com/chat/completions"
ALI_CHAT_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions"
RETRY_HTTP = {429, 500, 502, 503, 504}


def _provider_candidates(model: str, ali_model: str | None) -> list[dict]:
    """DeepSeek first, Ali second; qwen-* explicitly selects Ali first."""
    from . import config
    ds_key = config.deepseek_key()
    ali_key = config.alibaba_key()
    ds_model = (model or "deepseek-v4-pro").strip()
    ali = (ali_model or "qwen-plus").strip()
    deep = {"provider": "deepseek", "key": ds_key, "url": DEEPSEEK_CHAT_URL, "model": ds_model}
    aliy = {"provider": "ali", "key": ali_key, "url": ALI_CHAT_URL, "model": ali}
    out = []
    if str(ds_model).lower().startswith("qwen"):
        out = [aliy, deep]
    else:
        out = [deep, aliy]
    out = [c for c in out if c["key"]]
    if not out:
        raise RuntimeError(
            "缺 research 模型 key：配置 DeepSeek（DEEPSEEK_API_KEY / DS_KEY / "
            "~/.taa）或阿里百炼（DASHSCOPE_API_KEY / ALIBABA_API_KEY）")
    return out


def _safe_error(exc: Exception) -> str:
    detail = str(exc).replace("\n", " ")[:180]
    return f"{type(exc).__name__}: {detail}"


def _post_chat(url: str, key: str, payload: dict, timeout: int) -> dict:
    import urllib.request as _url
    body = json.dumps(payload).encode("utf-8")
    req = _url.Request(url, data=body, method="POST",
                       headers={"Content-Type": "application/json",
                                "Authorization": f"Bearer {key}"})
    from .net_retry import urlopen_retry
    with urlopen_retry(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _chat(messages: list[dict], *, model: str, ali_model: str | None = None,
          temperature: float, max_tokens: int, timeout: int,
          json_mode: bool = False) -> tuple[str, dict]:
    """Run one chat call with DeepSeek → Ali fallback.

    Returns (answer, meta) where meta includes provider, actual model,
    usage, finish_reason, fallback_from and attempts.
    """
    import time as _time
    candidates = _provider_candidates(model, ali_model)
    errors: list[str] = []
    fallback_from = None
    for idx, cand in enumerate(candidates):
        payload = {"model": cand["model"], "messages": messages,
                   "temperature": temperature, "max_tokens": max_tokens, "stream": False}
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        last_exc: Exception | None = None
        attempts = 0
        for attempt in range(4):
            attempts = attempt + 1
            try:
                data = _post_chat(cand["url"], cand["key"], payload, timeout)
                ans = ((data.get("choices") or [{}])[0].get("message") or {}).get("content", "")
                finish = ((data.get("choices") or [{}])[0] or {}).get("finish_reason", "")
                return ans, {
                    "provider": cand["provider"], "model": cand["model"],
                    "usage": data.get("usage", {}), "finish_reason": finish,
                    "fallback_from": fallback_from if idx else None,
                    "attempts": attempts,
                }
            except Exception as exc:  # noqa: BLE001
                last_exc = exc
                code = getattr(exc, "code", 0)
                if code in RETRY_HTTP and attempt < 3:
                    _time.sleep((4, 12, 30)[attempt])
                    continue
                break
        errors.append(f"{cand['provider']}: {_safe_error(last_exc or RuntimeError('unknown'))}")
        if idx + 1 < len(candidates):
            fallback_from = cand["provider"]
    raise RuntimeError("research 模型调用失败：" + "；".join(errors))


def ask_deep(slug: str, question: str, *, rounds: int = 3, model: str = "deepseek-v4-pro",
             ali_model: str | None = None, system: str | None = None,
             temperature: float = 0.3, max_tokens: int = 16000,
             timeout: int = 900, tag: str = "", version: str | None = None,
             root: Path | None = None, progress=lambda *a: None) -> dict:
    """[深挖件] 多轮迭代调研：拆解 → 寻证/反例 → 综合。

    - 逐轮累积上下文（同一会话多轮），每轮落盘 `ask/<ts>_deep/roundN.md`；
    - 末轮产出 `SYNTHESIS.md`（含候选事实条目，便于并入 FACTS.md）。
    - DeepSeek 优先，失败或缺 key 时逐轮尝试 Ali。
    - 轮数可调（默认 3）；确定性门禁仍由 `check` 负责。
    """
    root = root or WORK
    resolved = resolve_ref(slug, version=version, root=root)
    d = resolved["path"]
    rounds = max(1, min(int(rounds), len(DEEP_PROMPTS)))
    import time as _time
    sys = system if system is not None else DEEP_SYSTEM
    messages: list[dict] = [{"role": "system", "content": sys}]
    tag_text = _safe_tag(tag)
    outdir = _unique_dir(
        d / "ask" / (_time.strftime("%Y%m%d_%H%M%S") + (f"_{tag_text}" if tag_text else "") + "_deep"))
    total_usage: dict = {}
    files = []
    providers: list[str] = []
    models: list[str] = []
    fallback_from = None
    attempts = 0
    last = ""
    for i in range(rounds):
        prompt = DEEP_PROMPTS[i].format(q=question)
        messages.append({"role": "user", "content": prompt})
        progress(f"  第 {i + 1}/{rounds} 轮 …（{len(prompt)} 字提示）")
        ans, meta = _chat(messages, model=model, ali_model=ali_model,
                          temperature=temperature, max_tokens=max_tokens, timeout=timeout)
        providers.append(meta["provider"])
        models.append(meta["model"])
        fallback_from = meta.get("fallback_from") or fallback_from
        attempts += int(meta.get("attempts") or 1)
        usage = meta.get("usage", {})
        messages.append({"role": "assistant", "content": ans})
        for k, v in usage.items():
            if isinstance(v, (int, float)):
                total_usage[k] = total_usage.get(k, 0) + v
        fp = outdir / f"round{i + 1}.md"
        fp.write_text(f"# deep · 第 {i + 1}/{rounds} 轮 · {meta['provider']}/{meta['model']}\n\n"
                      f"## 追问\n\n{prompt}\n\n## 回答\n\n{ans}\n", encoding="utf-8")
        files.append(str(fp))
        last = ans
    synth = outdir / "SYNTHESIS.md"
    synth.write_text(f"# deep 深挖综合 · {slug}\n\n- 时间：{_time.strftime('%Y-%m-%d %H:%M:%S')}\n"
                     f"- provider：{providers[-1] if providers else '-'}\n"
                     f"- models：{', '.join(dict.fromkeys(models)) or '-'}\n"
                     f"- 轮数：{rounds}\n- 累计用量：{total_usage}\n\n"
                     f"## 问题\n\n{question}\n\n## 综合结论（末轮）\n\n{last}\n\n"
                     f"## 各轮原文\n\n" + "\n".join(f"- {f}" for f in files) + "\n", encoding="utf-8")
    return {
        "dir": str(outdir), "file": str(synth), "rounds": rounds, "chars": len(last),
        "files": files, "usage": total_usage, "provider": providers[-1] if providers else None,
        "providers": providers, "model": models[-1] if models else None,
        "models": models, "fallback_from": fallback_from, "attempts": attempts,
        "kind": resolved["kind"], "code": resolved.get("code"),
        "version": resolved.get("version"),
        "ref": f"{resolved['code']}@{resolved['version']}" if resolved.get("code") else slug,
    }


def ask_prompt(prompt: str, *, title: str | None = None, reuse: bool = False,
               rounds: int = 1, model: str = "deepseek-v4-pro",
               ali_model: str | None = None, system: str | None = None,
               temperature: float = 0.3, max_tokens: int = 16000,
               timeout: int = 900, tag: str = "", root: Path | None = None,
               json_mode: bool = False, progress=lambda *a: None) -> dict:
    """Create/reuse the prompt workspace, then run ask or ask_deep.

    Default: a new version for every user-initiated prompt. reuse=True
    selects the latest existing version (for retries).
    """
    # Fail before creating an empty vN when no provider key is available.
    _provider_candidates(model, ali_model)
    slot = new_prompt(prompt, title=title, reuse=reuse, root=root)
    if int(rounds) > 1:
        result = ask_deep(slot["code"], prompt, rounds=rounds, model=model,
                          ali_model=ali_model, system=system, temperature=temperature,
                          max_tokens=max_tokens, timeout=timeout, tag=tag,
                          version=slot["version"], root=root, progress=progress)
    else:
        result = ask(slot["code"], prompt, model=model, ali_model=ali_model,
                     system=system, temperature=temperature, max_tokens=max_tokens,
                     timeout=timeout, tag=tag, version=slot["version"], root=root,
                     json_mode=json_mode)
    result.update({"code": slot["code"], "version": slot["version"],
                   "created": slot["created"], "ref": slot["ref"],
                   "title": slot["title"]})
    return result
