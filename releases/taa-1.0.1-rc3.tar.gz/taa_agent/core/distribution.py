"""公共程序目录、下载与 manifest 签名（docs/03）。"""
from __future__ import annotations

import base64
import hashlib
import json
import os
from datetime import datetime
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from . import protocol

ROOT = Path(__file__).resolve().parent.parent
DIST_DIR = ROOT / "dist"
VERSION_FILE = DIST_DIR / "VERSION"
SIGN_KEY_FILE = ROOT / "bootstrap" / "dist_signing.key"
SIGN_PUB_FILE = ROOT / "bootstrap" / "dist_signing.pub"
SERIAL_FILE = ROOT / "bootstrap" / "dist_serial"

PROTOCOL_VERSION = protocol.PROTOCOL_VERSION

# sources/ = 信源台「每站定制抽取器 + 源规格 + 黄金样本」（必须随包，否则 B 机信源台不可用）
CODE_DIRS = ["core", "dist", "cli", "static", "tools", "sources"]
# runtime 目录含本地数据（inbox/logs/locks），不能整目录下发；
# 只随发行版下发执行器代码，否则 B 机重启后仍跑旧 dispatcher。
RUNTIME_CODE_FILES = [
    "runtime/chatroom_agent.py",
    "runtime/dispatcher.py",
    "runtime/loop.py",
    "runtime/restart_agent.py",
    "runtime/supervisor.py",
    "runtime/workspace.py",
]
# 随发行版下发的非目录文件：依赖清单 + 可在每台机器本地跑的确定性自检（harvest）
CODE_FILES = ["requirements.txt",
              # 身份与方法论（跨 IDE 通用；**不含**任何人的私密取值）
              "AGENTS.md", "agents/_templates/AGENTS.md",
              "scripts/gen_agents_md.py", "scripts/redaction_scan.py",
              "scripts/test_privacy.py", "scripts/test_weather.py",
              "scripts/test_research.py",
              "scripts/test_llm_backends.py", "scripts/camera_capture.py", "scripts/test_lightbox.py",
              "scripts/test_camera.py",
              # 可在每台机器本地跑的确定性自检
              "scripts/test_harvest.py",
              "scripts/facts_check.py", "scripts/fact_audit.py",
              "scripts/test_chatwork.py", "scripts/test_ui.py",
              "scripts/test_share_exchange.py",
              "scripts/test_capture.py", "scripts/test_extractors.py", "scripts/test_style_select.py",
              "scripts/test_ingest_guard.py", "scripts/test_access_gate.py",
              # 手机 APP 分发（docs/331）：发布 + 自检
              "scripts/appdist_publish.py", "scripts/appdist_selftest.py",
              # 信源台：目录（RSS）拉取 / 加站 / 源同步 / 加工流水线 / 三自检
              "scripts/feed_pull.py", "scripts/add_source.py", "scripts/seed_sources.py",
              "scripts/open_article.py", "scripts/interpret.py",   # ★ 产品程序：带参数（URL）打开并采集（Owner 2026-10-14 设计）
              "scripts/process_capture.py", "scripts/selfcheck_article.py", "scripts/style_uniqueness.py",
              # 可用性（hub 守卫 / 切换演练 / 验收辅助）
              "scripts/health_watch.py", "scripts/failover_drill.py", "scripts/ac_check.py",
              "scripts/compute_check.py",
              *RUNTIME_CODE_FILES]


def _b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode()


def _unb64(s: str) -> bytes:
    return base64.urlsafe_b64decode(s)


def runtime_version() -> str:
    if VERSION_FILE.exists():
        return VERSION_FILE.read_text(encoding="utf-8").strip()
    return "0.0.0"


def _key() -> Ed25519PrivateKey:
    SIGN_KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
    if SIGN_KEY_FILE.exists():
        return Ed25519PrivateKey.from_private_bytes(_unb64(SIGN_KEY_FILE.read_text().strip()))
    sk = Ed25519PrivateKey.generate()
    seed = sk.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                            serialization.NoEncryption())
    SIGN_KEY_FILE.write_text(_b64(seed), encoding="utf-8")
    os.chmod(SIGN_KEY_FILE, 0o600)
    pub = sk.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    SIGN_PUB_FILE.write_text(_b64(pub), encoding="utf-8")
    return sk


def public_key_b64() -> str:
    return _b64(_key().public_key().public_bytes(serialization.Encoding.Raw,
                                                 serialization.PublicFormat.Raw))


def key_fingerprint() -> str:
    return hashlib.sha256(_unb64(public_key_b64())).hexdigest()[:16]


def serial() -> int:
    if SERIAL_FILE.exists():
        return int(SERIAL_FILE.read_text(encoding="utf-8").strip() or "1")
    SIGN_KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
    SERIAL_FILE.write_text("1", encoding="utf-8")
    return 1


def bump_serial() -> int:
    s = serial() + 1
    SERIAL_FILE.write_text(str(s), encoding="utf-8")
    return s


def _canonical(m: dict) -> bytes:
    return json.dumps({k: v for k, v in m.items() if k not in ("signature", "ok")},
                      sort_keys=True, ensure_ascii=False).encode("utf-8")


_EXCLUDE_PARTS = {"__pycache__", "uploads", ".git"}

# —— 脱敏红线（P1.4）：数据库 / 密钥 / 记忆库 / 本地配置一律不进包 ——
# 判据是「文件名/后缀/目录」三重，宁可多拦：误拦的代价是打不了包，漏放的代价是
# 把 Owner 的抓取库（实测 tools/litcrawl/data/*.sqlite = 137 MB / 97932 行）发给每个用户。
_SENSITIVE_SUFFIXES = (".db", ".db-wal", ".db-shm", ".sqlite", ".sqlite3",
                       ".key", ".pem", ".p12", ".pfx", ".keystore", ".jks",
                       ".pyc", ".pyo")
_SENSITIVE_NAMES = {"data.db", "memory.db", "config.yaml", "config.local.yaml",
                    "credentials.json", "id_rsa", "id_ed25519"}
_SENSITIVE_DIRS = {"uploads", "inbox", "logs", "locks", "certs", "backups",
                   "node_modules", ".venv", "venv", ".taa"}


def is_sensitive(path: Path) -> str:
    """返回敏感原因（空串=可入包）。path 可以是相对 ROOT 的路径。"""
    p = Path(path)
    name = p.name
    if name in _SENSITIVE_NAMES or name == ".env" or name.startswith(".env."):
        return f"敏感文件名 {name}"
    low = name.lower()
    for suf in _SENSITIVE_SUFFIXES:
        if low.endswith(suf):
            return f"敏感后缀 {suf}"
    hit = _SENSITIVE_DIRS & set(p.parts)
    if hit:
        return f"敏感目录 {sorted(hit)[0]}"
    return ""


# —— 开发过程产物：不是"敏感"，但绝不该发给用户（实测 static/alice_m0 = 80.9 MB / 424 张截图）——
# 只按"目录 + 后缀"拦，保留同目录的 report.json（core/app_ui.py:5524 的自检摘要仍可读）。
_DEV_ARTIFACT_DIRS = {"static/alice_m0"}
_DEV_ARTIFACT_SUFFIXES = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg")


def is_dev_artifact(rel: str) -> str:
    """返回"开发产物"原因（空串=可入包）。rel 为相对 ROOT 的 POSIX 路径。"""
    low = rel.lower()
    for d in _DEV_ARTIFACT_DIRS:
        if low.startswith(d + "/") and low.endswith(_DEV_ARTIFACT_SUFFIXES):
            return "开发过程截图"
    if low.startswith("dist/") and low.endswith(".tar.gz"):
        return "历史构建产物（包中包）"
    return ""


def _candidates() -> list[Path]:
    """入包候选（未过滤敏感文件），供 code_files() 与自检共用。"""
    out: list[Path] = []
    for d in CODE_DIRS:
        p = ROOT / d
        if p.exists():
            out += [f for f in p.rglob("*")
                    if f.is_file() and not (_EXCLUDE_PARTS & set(f.parts))
                    and f.name != ".DS_Store"]
    for name in CODE_FILES:
        p = ROOT / name
        if p.exists():
            out.append(p)
    return sorted(out)


def sensitive_files() -> list[tuple[Path, str]]:
    """候选集中被脱敏规则拦下的文件（用于发布自检取证，绝不入包）。"""
    out: list[tuple[Path, str]] = []
    for f in _candidates():
        why = is_sensitive(f.relative_to(ROOT))
        if why:
            out.append((f, why))
    return out


def code_files() -> list[Path]:
    """发行版包含的全部**代码**文件（排除运行时数据 / 敏感数据凭证 / 开发过程产物）。"""
    out: list[Path] = []
    for f in _candidates():
        rel = f.relative_to(ROOT).as_posix()
        if is_sensitive(rel) or is_dev_artifact(rel):
            continue
        out.append(f)
    return out


def assert_bundle_clean(data: bytes) -> None:
    """打包后二次断言（fail-closed）：包里只要有一条敏感成员/开发产物就拒绝发布。"""
    import io
    import tarfile
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tf:
        bad = [(n, why) for n in tf.getnames()
               if (why := (is_sensitive(n) or is_dev_artifact(n)))]
    if bad:
        raise RuntimeError(f"bundle 门禁失败（{len(bad)} 条）：{bad[:5]}")


_BUNDLE_CACHE: dict = {"key": None, "bytes": None}


def bundle() -> bytes:
    """确定性 tar.gz（排序、清零 mtime/uid），带缓存。"""
    import gzip
    import io
    import tarfile
    key = tuple((str(f), f.stat().st_mtime_ns, f.stat().st_size) for f in code_files())
    if _BUNDLE_CACHE["key"] == key and _BUNDLE_CACHE["bytes"] is not None:
        return _BUNDLE_CACHE["bytes"]
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode="w", format=tarfile.GNU_FORMAT) as tf:
        for f in code_files():
            ti = tf.gettarinfo(str(f), arcname=str(f.relative_to(ROOT)))
            ti.mtime = 0
            ti.uid = ti.gid = 0
            ti.uname = ti.gname = ""
            with open(f, "rb") as fh:
                tf.addfile(ti, fh)
    # gzip mtime=0 → 确定性压缩（否则每次 sha 不同）
    data = gzip.compress(raw.getvalue(), mtime=0)
    assert_bundle_clean(data)   # 脱敏红线：含 *.db/*.sqlite/*.key/.env 直接拒绝
    _BUNDLE_CACHE.update(key=key, bytes=data)
    return data


def bundle_sha256() -> str:
    return hashlib.sha256(bundle()).hexdigest()


def sign_bytes(data: bytes) -> str:
    return _b64(_key().sign(data))


def manifest() -> dict:
    v = runtime_version()
    programs = []
    for p in sorted(DIST_DIR.glob("*.py")):
        data = p.read_bytes()
        programs.append({"name": p.stem, "version": v,
                         "sha256": hashlib.sha256(data).hexdigest(),
                         "size": len(data), "url": f"/v1/dist/{p.stem}/{v}"})
    files = [{"path": str(f.relative_to(ROOT)),
              "sha256": hashlib.sha256(f.read_bytes()).hexdigest(),
              "size": f.stat().st_size} for f in code_files()]
    b = bundle()
    m = {"protocol": PROTOCOL_VERSION, "runtime_version": v, "serial": serial(),
         "algo": "ed25519", "key_fingerprint": key_fingerprint(),
         "pubkey": public_key_b64(),
         "capabilities": protocol.CAPABILITIES,
         "released_at": datetime.now().isoformat(timespec="seconds"),
         "programs": programs,
         "files": files,
         "bundle": {"sha256": hashlib.sha256(b).hexdigest(), "size": len(b),
                    "url": "/v1/dist/bundle"}}
    m["signature"] = _b64(_key().sign(_canonical(m)))
    return m


def verify_manifest(m: dict, pubkey_b64: str) -> bool:
    try:
        pub = Ed25519PublicKey.from_public_bytes(_unb64(pubkey_b64))
        pub.verify(_unb64(m["signature"]), _canonical(m))
        return True
    except Exception:
        return False


def program_path(name: str, version: str) -> Path | None:
    if version != runtime_version():
        return None
    if "/" in name or ".." in name:
        return None
    p = DIST_DIR / f"{name}.py"
    return p if p.exists() else None
