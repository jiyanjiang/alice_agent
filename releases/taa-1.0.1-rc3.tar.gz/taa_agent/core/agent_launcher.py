"""Launch local chatroom runtimes for TAA /app.

The installer starts the core Flask process. This module starts one
``runtime/chatroom_agent.py`` per local AI agent after core bootstrap / the
v0.5 bridge. It is intentionally local-only: keys stay under
``$TAA_HOME/agents/<id>/.key`` and are never printed or sent to the center.
"""
from __future__ import annotations

import os
import pathlib
import signal
import sqlite3
import subprocess
import sys
import time
from typing import Iterable

ROOT = pathlib.Path(__file__).resolve().parent.parent
HOME = pathlib.Path(os.environ.get("TAA_HOME") or (pathlib.Path.home() / ".taa"))
RUN = HOME / "run"
DB = pathlib.Path(os.environ.get("TEAMAI_DB") or (HOME / "data.db"))


def _agent_ids() -> list[str]:
    try:
        conn = sqlite3.connect(str(DB), timeout=10)
        try:
            rows = conn.execute("SELECT id FROM agents WHERE kind='ai' ORDER BY created_at").fetchall()
            return [str(r[0]) for r in rows if r and r[0]]
        finally:
            conn.close()
    except Exception:
        return []


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _read_pid(path: pathlib.Path) -> int:
    try:
        return int(path.read_text(encoding="utf-8").strip() or "0")
    except Exception:
        return 0


def _pid_file(agent: str) -> pathlib.Path:
    return RUN / f"agent-{agent}.pid"


def _start_one(agent: str) -> dict:
    key_file = HOME / "agents" / agent / ".key"
    if not key_file.exists():
        return {"agent": agent, "started": False, "reason": "missing_key"}

    pid_file = _pid_file(agent)
    old = _read_pid(pid_file)
    if old and _pid_alive(old):
        return {"agent": agent, "started": False, "reason": "already_running", "pid": old}

    RUN.mkdir(parents=True, exist_ok=True)
    log = (RUN / f"agent-{agent}.log").open("a", encoding="utf-8")
    port = os.environ.get("TAA_HTTP_PORT") or "6080"
    base = f"http://127.0.0.1:{port}"
    try:
        from core import host_mode
        if host_mode.is_client() and host_mode.host_url():
            base = host_mode.host_url()
    except Exception:  # noqa: BLE001
        pass
    env = dict(os.environ)
    env.update({
        "TAA_HOME": str(HOME),
        "TEAMAI_URL": base,
        "TEAMAI_HTTP_PORT": str(port),
        "TEAMAI_DB": str(DB),
        "PYTHONUNBUFFERED": "1",
    })
    try:
        proc = subprocess.Popen(
            [sys.executable, str(ROOT / "runtime" / "chatroom_agent.py"),
             "--as", agent, "--url", base,
             "--interval", "2", "--no-migrate", "--no-auto-update"],
            cwd=str(ROOT), env=env, stdout=log, stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    finally:
        log.close()
    pid_file.write_text(str(proc.pid), encoding="utf-8")
    return {"agent": agent, "started": True, "pid": proc.pid}


def ensure_agents(agent_ids: Iterable[str] | None = None) -> dict:
    """Start missing local agent runtimes; idempotent by pid file / DB identity."""
    RUN.mkdir(parents=True, exist_ok=True)
    ids = list(agent_ids) if agent_ids is not None else _agent_ids()
    started, skipped = [], []
    for agent in ids:
        result = _start_one(str(agent))
        (started if result.get("started") else skipped).append(result)
    return {"ok": True, "ids": ids, "started": started, "skipped": skipped}


def stop_agents() -> dict:
    """Stop only PIDs recorded by this launcher; never broad-pkill."""
    stopped = []
    for pid_file in RUN.glob("agent-*.pid"):
        pid = _read_pid(pid_file)
        if pid and _pid_alive(pid):
            try:
                os.kill(pid, signal.SIGTERM)
                time.sleep(0.2)
                if _pid_alive(pid):
                    os.kill(pid, signal.SIGKILL)
            except OSError:
                pass
            stopped.append({"agent": pid_file.stem.removeprefix("agent-"), "pid": pid})
        pid_file.unlink(missing_ok=True)
    return {"ok": True, "stopped": stopped}


def status() -> dict:
    rows = []
    for pid_file in sorted(RUN.glob("agent-*.pid")):
        agent = pid_file.stem.removeprefix("agent-")
        pid = _read_pid(pid_file)
        rows.append({"agent": agent, "pid": pid, "running": _pid_alive(pid)})
    return {"ok": True, "agents": rows}
