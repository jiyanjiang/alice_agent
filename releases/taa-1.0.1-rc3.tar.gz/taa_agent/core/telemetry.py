"""Phase 0 最小埋点：非阻塞写 ui_events。

设计约束：
- 不进入请求关键路径：queue + daemon 批量写 SQLite；
- 不记录消息正文、Key、附件内容；只记录 feature/action/target/延迟；
- 写入失败静默，不影响 `/app` 可用性。
"""
from __future__ import annotations

import os
import pathlib
import queue
import sqlite3
import threading
import time

from .db import DB_PATH as _CANON_DB

ROOT = pathlib.Path(__file__).resolve().parent.parent
# P1A/A1：统一 canonical 库
DB = pathlib.Path(os.environ.get("TEAMAI_UI_DB") or _CANON_DB)
DISABLED = os.environ.get("TEAMAI_TELEMETRY_DISABLED") == "1"
_Q: "queue.Queue[dict]" = queue.Queue(maxsize=50_000)
_started = False
_lock = threading.Lock()


def _worker() -> None:
    while True:
        batch = []
        try:
            batch.append(_Q.get(timeout=1.0))
            while len(batch) < 100:
                batch.append(_Q.get_nowait())
        except queue.Empty:
            pass
        if not batch:
            continue
        try:
            c = sqlite3.connect(DB, timeout=10)
            c.execute("PRAGMA busy_timeout=10000")
            c.executemany(
                "INSERT INTO ui_events(at,actor,feature,action,target,latency_ms,success,payload) "
                "VALUES(datetime('now','localtime'),?,?,?,?,?,?,?)",
                [(x.get("actor"), x.get("feature"), x.get("action"), x.get("target"),
                  x.get("latency_ms"), 1 if x.get("success", True) else 0, x.get("payload"))
                 for x in batch])
            c.commit()
            c.close()
        except Exception:
            # 遥测失败不能影响业务；丢掉这一批，下一批继续。
            pass


def _ensure_worker() -> None:
    global _started
    if DISABLED:
        return
    with _lock:
        if _started:
            return
        _started = True
        threading.Thread(target=_worker, name="taa-telemetry", daemon=True).start()


def record(feature: str, action: str, target: str = "", *, latency_ms: int | None = None,
           success: bool = True, actor: str = "", payload: str = "") -> None:
    if DISABLED:
        return
    _ensure_worker()
    try:
        _Q.put_nowait({
            "feature": str(feature or "unknown")[:60],
            "action": str(action or "?")[:20],
            "target": str(target or "")[:300],
            "latency_ms": int(latency_ms) if latency_ms is not None else None,
            "success": bool(success),
            "actor": str(actor or "")[:80],
            "payload": str(payload or "")[:1000],
        })
    except queue.Full:
        pass
