"""Durable per-agent executor queue."""
from __future__ import annotations

import sqlite3
import time
import uuid


def ensure(conn: sqlite3.Connection) -> None:
    conn.execute("""
      CREATE TABLE IF NOT EXISTS executor_jobs (
        id TEXT PRIMARY KEY,
        agent_id TEXT NOT NULL,
        room_id TEXT NOT NULL,
        body TEXT NOT NULL,
        sub_agent TEXT,
        dedupe_key TEXT UNIQUE,
        status TEXT NOT NULL DEFAULT 'queued',
        priority INTEGER NOT NULL DEFAULT 2,
        created_at TEXT DEFAULT (datetime('now','localtime')),
        started_at TEXT,
        finished_at TEXT,
        last_error TEXT
      )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS ix_executor_jobs_agent_status "
                 "ON executor_jobs(agent_id,status,created_at)")
    # 执行器后端（opencode / qoder / workbuddy …）：老库补列，空值=用默认后端
    cols = {r[1] for r in conn.execute("PRAGMA table_info(executor_jobs)")}
    if "backend" not in cols:
        conn.execute("ALTER TABLE executor_jobs ADD COLUMN backend TEXT")
    # 触发这条 job 的 room_messages.id：执行结束要拿它把 message_route 推进终态
    if "message_id" not in cols:
        conn.execute("ALTER TABLE executor_jobs ADD COLUMN message_id INTEGER")
    conn.commit()


def enqueue(conn: sqlite3.Connection, *, agent: str, room: str, body: str,
            sub: str = "", dedupe_key: str = "", backend: str = "",
            message_id: int = 0) -> tuple[str, str]:
    ensure(conn)
    key = str(dedupe_key or "")
    if key:
        row = conn.execute("SELECT id,status FROM executor_jobs WHERE dedupe_key=?", (key,)).fetchone()
        if row:
            return str(row["id"]), str(row["status"])
    jid = "ej-" + uuid.uuid4().hex[:12]
    try:
        cur = conn.execute(
            "INSERT OR IGNORE INTO executor_jobs(id,agent_id,room_id,body,sub_agent,dedupe_key,"
            "backend,message_id) VALUES(?,?,?,?,?,?,?,?)",
            (jid, str(agent), str(room), str(body), str(sub or ""), key or None,
             str(backend or "") or None, int(message_id or 0) or None))
        conn.commit()
        if cur.rowcount:
            return jid, "queued"
    except sqlite3.Error:
        pass
    row = conn.execute("SELECT id,status FROM executor_jobs WHERE dedupe_key=?", (key,)).fetchone()
    return (str(row["id"]), str(row["status"])) if row else ("", "failed")


def claim_next(conn: sqlite3.Connection, agent: str) -> dict | None:
    ensure(conn)
    row = conn.execute(
        "SELECT * FROM executor_jobs WHERE agent_id=? AND status='queued' "
        "ORDER BY priority,created_at,id LIMIT 1", (agent,)).fetchone()
    if not row:
        return None
    cur = conn.execute(
        "UPDATE executor_jobs SET status='running',started_at=datetime('now','localtime') "
        "WHERE id=? AND status='queued'", (row["id"],))
    conn.commit()
    if not cur.rowcount:
        return None
    out = dict(row)
    out["status"] = "running"
    return out


def finish(conn: sqlite3.Connection, job_id: str, ok: bool, error: str = "") -> None:
    ensure(conn)
    conn.execute(
        "UPDATE executor_jobs SET status=?,finished_at=datetime('now','localtime'),"
        "last_error=? WHERE id=?",
        ("done" if ok else "failed", error[:500] or None, job_id))
    conn.commit()


def queued_agents(conn: sqlite3.Connection) -> list[str]:
    ensure(conn)
    return [str(r["agent_id"]) for r in conn.execute(
        "SELECT DISTINCT agent_id FROM executor_jobs WHERE status='queued'").fetchall()]
