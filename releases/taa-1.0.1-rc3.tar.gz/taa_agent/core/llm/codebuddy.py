"""CodeBuddy CN 适配器 —— **启动器型**（interactive），不是同步执行器。

实测（2026-10-30，CodeBuddy CN **1.106.1**，本机）：
  · 真 CLI = `buddycn`（`~/.codebuddy/bin/buddycn` → `CodeBuddy CN.app/…/bin/code`）
  · `buddycn --version` → 1.106.1（可用）
  · `buddycn chat [-m agent|ask|edit] [-n|--new-window] <prompt>` → **打开 GUI 窗口**跑 agent
  · `buddycn chat --help` 的选项只有 mode / add-file / maximize / new-window / profile，
    **没有** `-p/--print`、`--output-format`：拿不到 stdout，也拿不到退出码语义

因此本适配器只承诺"**能启动**"，不承诺"能拿结果"：
  `INTERACTIVE = True`，`executor_bridge` 见到这个标记就不做"执行完成/核验"，
  只如实告诉群里"已在窗口启动，结果请在该窗口查看/由 agent 自己回帖"。

为什么不硬造一个 stdout：
  伪造"✅ 执行完成"会让人以为活干完了，而实际结果还在窗口里没提交——
  这正是 2026-10-30 "ACK + 结果帖"那类噪音的同一个病根。

配置（都不需要改代码）：
| 变量 | 作用 | 默认 |
|---|---|---|
| `TEAM_CODEBUDDY_BIN` | 可执行名/路径 | `buddycn`（再回落 `~/.codebuddy/bin/buddycn`） |
| `TEAM_CODEBUDDY_MODE` | chat 模式 | `agent` |
| `TEAM_CODEBUDDY_ARGS` | 追加参数（空格分隔） | 空 |
| `TEAM_CODEBUDDY_CMD` | 完整命令模板（`{prompt}/{cwd}/{model}/{title}`） | 空 |
"""
from __future__ import annotations

import os
import pathlib
import shlex
import shutil
import subprocess

from .base import LLMAdapter, LLMResult


class CodebuddyAdapter(LLMAdapter):
    name = "codebuddy"
    #: 只能启动 GUI，无法同步取回输出（executor_bridge 据此降级）
    INTERACTIVE = True

    def _bin(self) -> str:
        env = (os.environ.get("TEAM_CODEBUDDY_BIN") or "").strip()
        if env:
            return env
        hit = shutil.which("buddycn")
        if hit:
            return hit
        p = pathlib.Path.home() / ".codebuddy" / "bin" / "buddycn"
        return str(p) if p.exists() else "buddycn"

    def available(self) -> bool:
        if os.environ.get("TEAM_CODEBUDDY_CMD"):
            return True
        b = self._bin()
        if not (shutil.which(b) or pathlib.Path(b).exists()):
            return False
        try:
            r = subprocess.run([b, "--version"], capture_output=True, text=True, timeout=8)
            return r.returncode == 0
        except Exception:  # noqa: BLE001
            return False

    def build(self, prompt, *, model=None, cwd=".", files=None, title=None):
        tpl = os.environ.get("TEAM_CODEBUDDY_CMD") or ""
        if tpl:
            s = (tpl.replace("{prompt}", str(prompt)).replace("{cwd}", str(cwd))
                    .replace("{model}", str(model or "")).replace("{title}", str(title or "")))
            return [c for c in shlex.split(s) if c != ""]
        cmd = [self._bin(), "chat",
               "-m", os.environ.get("TEAM_CODEBUDDY_MODE", "agent"),
               "--new-window"]
        for f in (files or []):
            cmd += ["-a", str(f)]
        extra = os.environ.get("TEAM_CODEBUDDY_ARGS", "")
        if extra:
            cmd += shlex.split(extra)
        cmd.append(str(prompt))
        return cmd

    def run(self, prompt, *, model=None, cwd=".", files=None, title=None, timeout=180,
            env_extra=None, stdin_text=None):
        """detached 启动，立即返回（不等窗口里的 agent，也不假装拿到结果）。"""
        cmd = self.build(prompt, model=model, cwd=cwd, files=files, title=title)
        try:
            subprocess.Popen(cmd, cwd=str(cwd or "."), env=self.env(env_extra),
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True)
        except FileNotFoundError:
            return LLMResult(False, f"[codebuddy] 未找到命令：{cmd[0]}", None)
        except Exception as e:  # noqa: BLE001
            return LLMResult(False, f"[codebuddy] 启动失败：{type(e).__name__}: {e}", None)
        return LLMResult(True,
                         "已在 CodeBuddy 窗口启动（该执行器无终端输出）。\n"
                         "结果请在该窗口查看；需要入库时让 agent 用 `teamai submit` 回帖。",
                         0)
