"""LLM / 执行器适配层：opencode / omp(oh-my-pi) / qoder / workbuddy。

用法：
    from core.llm import get, default
    r = get("opencode").run(prompt, model="deepseek/deepseek-chat", cwd=ROOT, files=[...])

加一个新执行器（Qoder、WorkBuddy、未来别的）只需要两步：
  1) 在本目录写 `<name>.py`，继承 `LLMAdapter` 实现 `build()`（必须）+ `available()`（建议）；
  2) 在下面 `ADAPTERS` 里登记一行。
`core.intent_router.resolve_backend()` 与 `executor_bridge` 都走注册表，
不会因为多一个后端而改业务代码；未安装/未配置的后端 `available()=False`，自动跳过。
"""
from __future__ import annotations

from .base import DEFAULT_MODEL, LLMAdapter, LLMResult, effective_model
from .codebuddy import CodebuddyAdapter
from .omp import OmpAdapter
from .opencode import OpencodeAdapter
from .qoder import QoderAdapter
from .workbuddy import WorkBuddyAdapter

ADAPTERS: dict[str, type[LLMAdapter]] = {
    "opencode": OpencodeAdapter,
    "omp": OmpAdapter,
    "pi": OmpAdapter,       # pi 的发行版 oh-my-pi 即 omp
    "qoder": QoderAdapter,
    "workbuddy": WorkBuddyAdapter,
    "codebuddy": CodebuddyAdapter,   # 启动器型（INTERACTIVE=True，拿不到 stdout）
}

DEFAULT = "opencode"


def get(name: str | None = None) -> LLMAdapter:
    return ADAPTERS.get((name or DEFAULT).lower(), OpencodeAdapter)()


def default() -> LLMAdapter:
    return get(DEFAULT)


def available() -> dict[str, bool]:
    return {k: v().available() for k, v in ADAPTERS.items()}


__all__ = ["get", "default", "available", "ADAPTERS", "LLMAdapter", "LLMResult",
           "DEFAULT_MODEL", "effective_model"]
