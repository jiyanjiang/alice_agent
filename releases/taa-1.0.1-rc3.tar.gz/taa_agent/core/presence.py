"""Presence cache for owner / agent / node.

The center computes presence from node/agent heartbeats.  This module stores
the last snapshot locally so UI and routing do not need a network call for
every message.  Missing/unknown state is treated as not executable.
"""
from __future__ import annotations

from datetime import datetime, timezone

TTL_OWNER = 300
TTL_AGENT = 120
TTL_NODE = 120


def ensure(conn) -> None:
    conn.execute("""
      CREATE TABLE IF NOT EXISTS presence (
        principal_id TEXT NOT NULL,
        kind         TEXT NOT NULL CHECK(kind IN ('owner','agent','node')),
        online       TEXT NOT NULL DEFAULT 'unknown'
                     CHECK(online IN ('online','idle','offline','unknown')),
        last_seen    TEXT,
        source       TEXT,
        updated_at   TEXT DEFAULT (datetime('now','localtime')),
        PRIMARY KEY(principal_id, kind)
      )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS ux_presence_kind_online ON presence(kind, online)")
    conn.commit()


def _parse(value: str | None) -> datetime | None:
    raw = str(value or "").strip()
    if not raw:
        return None
    try:
        dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def classify(last_seen: str | None, ttl: int, now: datetime | None = None) -> str:
    dt = _parse(last_seen)
    if dt is None:
        return "unknown"
    now = now or datetime.now(timezone.utc)
    age = (now - dt).total_seconds()
    return "online" if age <= ttl else "offline"


def upsert(conn, principal_id: str, kind: str, online, last_seen: str = "",
           source: str = "") -> None:
    if not principal_id or kind not in ("owner", "agent", "node"):
        return
    if isinstance(online, bool):
        online = "online" if online else "offline"
    if online not in ("online", "idle", "offline", "unknown"):
        online = "unknown"
    ensure(conn)
    conn.execute(
        "INSERT INTO presence(principal_id,kind,online,last_seen,source,updated_at) "
        "VALUES(?,?,?,?,?,datetime('now','localtime')) "
        "ON CONFLICT(principal_id,kind) DO UPDATE SET "
        "online=excluded.online,last_seen=excluded.last_seen,source=excluded.source,"
        "updated_at=excluded.updated_at",
        (principal_id, kind, online, last_seen or None, source or None))


def get(conn, principal_id: str, kind: str) -> dict | None:
    ensure(conn)
    row = conn.execute(
        "SELECT principal_id,kind,online,last_seen,source,updated_at "
        "FROM presence WHERE principal_id=? AND kind=?", (principal_id, kind)).fetchone()
    return dict(row) if row else None


def is_online(conn, principal_id: str, kind: str) -> bool:
    row = get(conn, principal_id, kind)
    return bool(row and row["online"] == "online")


def label(conn, principal_id: str, kind: str) -> str:
    row = get(conn, principal_id, kind)
    if not row:
        return "未知"
    return {"online": "在线", "idle": "空闲", "offline": "离线"}.get(
        str(row["online"]), "未知")


def upsert_member(conn, member: dict) -> None:
    """Project one center group member presence snapshot."""
    owner_id = str(member.get("owner_id") or "").strip()
    if owner_id:
        upsert(conn, owner_id, "owner", member.get("owner_online", "unknown"),
               str(member.get("owner_last_seen") or member.get("node_last_seen") or ""),
               "center")
    agent_id = str(member.get("agent_id") or "").strip()
    if agent_id:
        upsert(conn, agent_id, "agent", member.get("agent_online", "unknown"),
               str(member.get("agent_last_seen") or ""), "center")
    node_id = str(member.get("transport_node_id") or member.get("node_id") or "").strip()
    if node_id:
        upsert(conn, node_id, "node", member.get("node_online", "unknown"),
               str(member.get("node_last_seen") or ""), "center")
