"""交付中心 · 交付物浏览与历史版本指引。

背景（t-0d087dcf）：交付帖正文里的 `deliverables/<task>/...` 是**仓库相对路径**，
Flask 只把 `static/` 挂到 `/static`，因此这些链接一律 404。本模块做三件事：

1. 把 `deliverables/` 只读挂到 `/deliverables/`，旧链接原样可用；
2. 提供任务目录页 / 文件页（Markdown 直接渲染），按修改时间倒序列出历史版本；
3. 自定义 404 页：给出「交付中心 → 任务 → 文件」与 PPT 历史的明确入口。

安全边界：只读；只允许访问 `deliverables/` 内文件；拒绝 `..` 越界；不列出隐藏目录。
"""
from __future__ import annotations

import datetime as _dt
import html
import os
import pathlib
import re
import sqlite3
import urllib.parse

from flask import Response, abort, jsonify, redirect, request, send_from_directory

from .db import DB_PATH as _CANON_DB

ROOT = pathlib.Path(__file__).resolve().parent.parent
DELIV = ROOT / "deliverables"
UPLOADS = ROOT / "static" / "uploads"
# P1A/A1：统一 canonical 库
DATA_DB = pathlib.Path(os.environ.get("TEAMAI_UI_DB") or os.environ.get("TEAMAI_DB") or _CANON_DB)

TASK_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,120}$")
HIDDEN = {"__pycache__", ".git", ".DS_Store"}
JUNK_PREFIX = ("~$",)  # Office 锁文件（~$xxx.pptx），不是交付物

CSS = """
.dlwrap{display:grid;gap:14px}
.dlcard{background:#fff;border:1px solid var(--pearl,#e8e5df);border-radius:16px;padding:18px 20px}
.dlcard h2{margin:4px 0 8px;font-size:20px}
.dlcard h3{margin:0 0 8px;font-size:15px}
.dlkicker{font-size:11px;letter-spacing:.12em;color:var(--muted,#7b7f86);text-transform:uppercase}
.dlguide{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-top:8px}
.dlstep{border:1px solid #dbe7f2;background:#f7fbff;border-radius:12px;padding:11px 12px}
.dlstep b{display:inline-flex;width:22px;height:22px;border-radius:50%;background:#2f6be4;color:#fff;
  align-items:center;justify-content:center;font-size:12px;margin-right:6px}
.dlstep p{margin:6px 0 0;font-size:13px;line-height:1.55;color:#3d4652}
.dlstep a{color:#2f6be4}
.dltable{width:100%;border-collapse:collapse;font-size:13px;table-layout:fixed}
.dltable td:last-child,.dltable th:last-child{width:136px}
.dltable td.dlmeta,.dltable th:nth-child(2){width:132px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dltable td .dlpath{display:block;white-space:normal;word-break:break-all}
.dlacts .dlbtn{white-space:nowrap}
.dltable th{text-align:left;font-weight:600;color:#6b7280;border-bottom:1px solid #ece9e3;padding:8px 6px}
.dltable td{border-bottom:1px solid #f2efea;padding:9px 6px;vertical-align:top}
.dltable tr:last-child td{border-bottom:0}
.dlname{font-weight:600;color:#1f2937;overflow-wrap:anywhere}
.dlmeta{color:#8a8f98;font-size:12px;white-space:nowrap}
.dlacts{display:flex;gap:8px;flex-wrap:wrap}
.dlbtn{display:inline-block;border:1px solid #cfd9e6;background:#fff;color:#2f5f86;border-radius:10px;
  padding:5px 10px;font-size:12px;text-decoration:none;line-height:1.6}
.dlbtn:hover{border-color:#7ea6c9;background:#f4f9ff}
.dlbtn.primary{background:#2f6be4;border-color:#2f6be4;color:#fff}
.dlbtn.primary:hover{background:#2559c4}
.dlbadge{display:inline-block;background:#eef4fb;color:#3c5f7a;border-radius:999px;padding:1px 8px;
  font-size:11px;margin-left:6px}
.dlempty{color:#8a8f98;font-size:13px;padding:10px 0}
.dlpath{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;background:#f5f3ef;border-radius:8px;
  padding:2px 6px;font-size:12px;word-break:break-all}
.dlmd{max-width:900px;line-height:1.7}
.dlmd pre{background:#f5f3ef;padding:10px 12px;border-radius:10px;overflow:auto}
.dlmd table{border-collapse:collapse;max-width:100%;display:block;overflow:auto}
.dlmd th,.dlmd td{border:1px solid #e6e2db;padding:6px 8px}
.dlmd code{background:#f5f3ef;padding:1px 5px;border-radius:5px}
.dlcopy{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:12px;padding-top:12px;
  border-top:1px dashed #e6e2db}
.dlcopy .dlkicker{margin-right:2px}
.dl404{max-width:820px}
.dl404 .code{font-size:44px;font-weight:700;letter-spacing:.04em;color:#c7d3e2;line-height:1}
@media(max-width:800px){.dlguide{grid-template-columns:1fr}}
"""


def esc(x) -> str:
    return html.escape(str(x if x is not None else ""))


def _junk(name: str) -> bool:
    return name in HIDDEN or name.startswith(JUNK_PREFIX) or name.startswith(".")


def _shell():
    from core.app_ui import shell
    return shell


def _fmt_time(ts: float) -> str:
    return _dt.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")


def _fmt_size(n: int) -> str:
    for unit, div in (("GB", 1 << 30), ("MB", 1 << 20), ("KB", 1 << 10)):
        if n >= div:
            return f"{n / div:.1f} {unit}"
    return f"{n} B"


def _url(task: str, rel: str = "") -> str:
    """规范地址一律带尾斜杠：避免每次点击都吃一次 308，代理/旧客户端下也更稳。"""
    base = "/deliverables/" + urllib.parse.quote(task) + "/"
    if rel:
        base += urllib.parse.quote(rel, safe="/")
    return base


def _task_of(path: str) -> str:
    """从请求路径里认出任务号，供 404 页直接给出该任务可用版本。"""
    m = re.search(r"/(t-[A-Za-z0-9][A-Za-z0-9._-]{2,120})(?:/|$)", path or "")
    return m.group(1) if m else ""


def _task_dirs() -> list[pathlib.Path]:
    if not DELIV.exists():
        return []
    out = []
    for p in DELIV.iterdir():
        if not p.is_dir() or p.name in HIDDEN or p.name.startswith("."):
            continue
        out.append(p)
    return out


def _latest_mtime(p: pathlib.Path) -> float:
    latest = p.stat().st_mtime
    try:
        for f in p.rglob("*"):
            if f.is_file() and not _junk(f.name):
                latest = max(latest, f.stat().st_mtime)
    except OSError:
        pass
    return latest


def _task_row(task: str) -> dict:
    """只读查任务表：判断「任务存在但没有产物目录」与「任务号根本不存在」。

    打不开库时返回空 dict（按未知任务处理），不抛异常、不写库。
    """
    if not DATA_DB.exists():
        return {}
    try:
        con = sqlite3.connect(f"file:{DATA_DB}?mode=ro", uri=True, timeout=2)
        con.row_factory = sqlite3.Row
        row = con.execute(
            "select id,title,status,assigned_to,created_at from tasks where id=?",
            (task,)).fetchone()
        con.close()
    except Exception:  # noqa: BLE001
        return {}
    return dict(row) if row else {}


def _family_dirs(task: str) -> list[pathlib.Path]:
    """同一任务的各轮目录：`t-x`、`t-x_v2`、`t-x_*`（按最近更新时间倒序）。"""
    base = (task or "").strip()
    if not base:
        return []
    out = []
    for p in _task_dirs():
        if p.name == base or p.name.startswith(base + "_"):
            out.append(p)
    out.sort(key=_latest_mtime, reverse=True)
    return out


def _version_rows(dirs: list[pathlib.Path]) -> list[dict]:
    """收集各轮目录里的 PPT / PDF，按修改时间倒序，作为「历史版本」清单。"""
    rows: list[dict] = []
    for d in dirs:
        for f in d.rglob("*"):
            if not f.is_file() or f.suffix.lower() not in (".pptx", ".pdf"):
                continue
            if any(_junk(part) for part in f.parts):
                continue
            try:
                st = f.stat()
            except OSError:
                continue
            rel = str(f.relative_to(d))
            rows.append({"dir": d.name, "rel": rel, "name": f.name,
                         "url": _url(d.name, rel), "mtime": st.st_mtime,
                         "size": st.st_size})
    rows.sort(key=lambda r: r["mtime"], reverse=True)
    return rows


def _task_summary(p: pathlib.Path) -> dict:
    files = [f for f in p.iterdir() if f.is_file() and not _junk(f.name)] if p.exists() else []
    all_files = list(p.rglob("*")) if p.exists() else []
    size = 0
    for f in all_files:
        try:
            if f.is_file():
                size += f.stat().st_size
        except OSError:
            pass
    newest = max(files, key=lambda f: f.stat().st_mtime) if files else None
    return {"name": p.name, "files": len(files), "size": size,
            "mtime": _latest_mtime(p), "newest": newest.name if newest else ""}


def _guide_html() -> str:
    return """
  <div class="dlcard" id="history-guide">
    <div class="dlkicker">历史版本查看指引</div>
    <h3>三步找到任何一版交付物</h3>
    <div class="dlguide">
      <div class="dlstep"><b>1</b><span>进交付中心</span>
        <p>打开 <a href="/deliverables/">/deliverables/</a>。任务按最近更新时间倒序，最新在最上面。</p></div>
      <div class="dlstep"><b>2</b><span>选任务</span>
        <p>点任务号（如 <span class="dlpath">t-a99397ed</span>）。任务页里 PPTX / PDF / HTML / Markdown 全部按修改时间倒序列出。</p></div>
      <div class="dlstep"><b>3</b><span>选版本 / 下载</span>
        <p>同一文件有多个版本时，任务页的「历史版本」区会同时列出旧版与新版；点「打开」直接看，点「下载」拿文件。</p></div>
    </div>
    <p style="margin:12px 0 0;font-size:13px;color:#3d4652">
      另一条路：<a href="/app/tools#ppt-history">工具 → AI 写 PPT → PPT 生成历史</a>（页面下方有列表），
      每次生成都落在独立的 <span class="dlpath">loomdoc-时间戳</span> 目录，可按时间逐个打开。
    </p>
    <p style="margin:8px 0 0;font-size:13px;color:#3d4652">
      <b>取回 / 恢复旧版：</b>历史版本按文件保留、不会自动覆盖。点「下载」把旧文件存到本地；
      需要换回旧版时，用该文件替换当前版本后刷新本页即可。页面只读、不自动回滚，避免误覆盖。
      若列表里看不到某个版本，说明该文件已不在本机
      <span class="dlpath">deliverables/&lt;task&gt;/</span> 或
      <span class="dlpath">static/uploads/loomdoc-&lt;时间戳&gt;/</span> 目录。
    </p>
  </div>"""


def _history_items(limit: int = 16) -> list[dict]:
    """扫描 PPT/PDF 产物，按修改时间倒序，供「历史版本」区使用。"""
    rows: list[dict] = []
    if not UPLOADS.exists():
        return rows
    for d in UPLOADS.iterdir():
        if not d.is_dir() or not d.name.startswith("loomdoc-"):
            continue
        for name in ("deck.pptx", "deck.pdf", "deck.html"):
            f = d / name
            if f.exists():
                try:
                    st = f.stat()
                except OSError:
                    continue
                rows.append({"kind": "AI 写 PPT", "task": "", "dir": d.name,
                             "name": name, "url": f"/static/uploads/{d.name}/{name}",
                             "mtime": st.st_mtime, "size": st.st_size})
    for p in DELIV.rglob("*.pptx"):
        if any(part in HIDDEN for part in p.parts):
            continue
        try:
            st = p.stat()
        except OSError:
            continue
        rel = p.relative_to(DELIV)
        task = rel.parts[0] if len(rel.parts) > 1 else ""
        rows.append({"kind": "任务交付", "task": task, "dir": task,
                     "name": str(rel), "url": _url(task, str(pathlib.Path(*rel.parts[1:]))),
                     "mtime": st.st_mtime, "size": st.st_size})
    rows.sort(key=lambda r: r["mtime"], reverse=True)
    return rows[:limit]


# 供 /app/tools 复用：页面上的「PPT 生成历史」必须是真列表，不能只写一句指路。
history_items = _history_items


def page_index(q: str = ""):
    tasks = [_task_summary(p) for p in _task_dirs()]
    tasks.sort(key=lambda t: t["mtime"], reverse=True)
    ql = (q or "").strip().lower()
    if ql:
        tasks = [t for t in tasks if ql in t["name"].lower()]
    rows = "".join(
        f'<tr><td><a class="dlname" href="{_url(t["name"])}">{esc(t["name"])}</a>'
        f'{"<span class=dlbadge>最新</span>" if i == 0 and not ql else ""}</td>'
        f'<td class="dlmeta">{_fmt_time(t["mtime"])}</td>'
        f'<td class="dlmeta">{t["files"]} 个文件 · {_fmt_size(t["size"])}</td>'
        f'<td class="dlmeta">{esc(t["newest"])}</td>'
        f'<td><a class="dlbtn" href="{_url(t["name"])}">打开任务 →</a></td></tr>'
        for i, t in enumerate(tasks))
    if not rows:
        rows = '<tr><td colspan="5" class="dlempty">没有匹配的交付任务。换个关键词，或直接看下方 PPT 生成历史。</td></tr>'

    hist = _history_items()
    hrows = "".join(
        f'<tr><td class="dlname">{esc(r["name"])}</td>'
        f'<td><span class="dlbadge">{esc(r["kind"])}</span></td>'
        f'<td class="dlmeta">{_fmt_time(r["mtime"])} · {_fmt_size(r["size"])}</td>'
        f'<td class="dlacts"><a class="dlbtn" href="{esc(r["url"])}" target="_blank" rel="noopener">打开</a>'
        f'<a class="dlbtn" href="{esc(r["url"])}?download=1">下载</a></td></tr>'
        for r in hist)
    if not hrows:
        hrows = '<tr><td colspan="4" class="dlempty">还没有可列出的 PPT 版本。</td></tr>'

    body = f"""
  <div class="dlwrap">
    <div class="dlcard">
      <div class="dlkicker">交付中心</div>
      <h2>交付物与历史版本</h2>
      <p style="margin:0;color:#4b5563;font-size:13.5px;line-height:1.65">
        这里直接读取本机 <span class="dlpath">deliverables/</span> 目录，只读、不复制、不改动产物。
        任务目录按最近更新时间倒序；点进去就是该任务的全部文件与历史版本。
      </p>
      <div class="dlacts" style="margin-top:12px">
        <a class="dlbtn primary" href="#ppt-history">↓ 直接看 PPT 生成历史</a>
        <a class="dlbtn" href="#history-guide">历史版本怎么找</a>
      </div>
      <form method="get" action="/deliverables/" style="margin-top:12px;display:flex;gap:8px;max-width:460px">
        <input name="q" value="{esc(q)}" placeholder="按任务号筛选，如 t-a99397ed"
               style="flex:1;padding:9px 12px;border:1px solid #d8d4cc;border-radius:10px;font:inherit">
        <button class="dlbtn primary" type="submit">筛选</button>
      </form>
    </div>

    {_guide_html()}

    <div class="dlcard">
      <div class="dlkicker">任务交付</div>
      <h3>全部任务（{len(tasks)}）</h3>
      <table class="dltable">
        <thead><tr><th>任务</th><th>最近更新</th><th>规模</th><th>最新文件</th><th></th></tr></thead>
        <tbody>{rows}</tbody>
      </table>
    </div>

    <div class="dlcard" id="ppt-history">
      <div class="dlkicker">PPT 生成历史</div>
      <h3>最近生成的演示（按时间倒序）</h3>
      <p style="margin:0 0 8px;color:#6b7280;font-size:12.5px">
        来源：<span class="dlpath">static/uploads/loomdoc-*</span> 与任务目录下的 <span class="dlpath">*.pptx</span>。
      </p>
      <table class="dltable">
        <thead><tr><th>文件</th><th>来源</th><th>时间 / 大小</th><th>操作</th></tr></thead>
        <tbody>{hrows}</tbody>
      </table>
    </div>
  </div>"""
    return _shell()("交付中心", body, "tools", "交付物浏览 · 历史版本", page_css=CSS)


def _file_rows(task_dir: pathlib.Path) -> list[dict]:
    rows = []
    for f in sorted(task_dir.rglob("*")):
        if not f.is_file() or _junk(f.name) or any(_junk(part) for part in f.parts):
            continue
        try:
            st = f.stat()
        except OSError:
            continue
        rel = str(f.relative_to(task_dir))
        rows.append({"rel": rel, "name": f.name, "size": st.st_size, "mtime": st.st_mtime})
    rows.sort(key=lambda r: r["mtime"], reverse=True)
    return rows


def _copy_bar(task: str) -> str:
    """可复制的任务入口路径 + 一键复制（无 JS 时也能手动选中复制）。"""
    path = f"/deliverables/{task}/"
    return f"""
    <div class="dlcopy">
      <span class="dlkicker">本任务固定入口</span>
      <code class="dlpath" id="dlpath-{esc(task)}">{esc(path)}</code>
      <button class="dlbtn" type="button"
        onclick="(function(){{var t='{esc(path)}';if(navigator.clipboard){{navigator.clipboard.writeText(t);}}var b=this;b.textContent='已复制';setTimeout(function(){{b.textContent='复制链接';}},1200);}}).call(this)">复制链接</button>
      <a class="dlbtn primary" href="#history">↓ 跳到历史版本</a>
    </div>"""


def _version_table(versions: list[dict]) -> str:
    if not versions:
        return '<tr><td colspan="4" class="dlempty">这一任务族还没有 PPT / PDF 版本。</td></tr>'
    return "".join(
        f'<tr><td><span class="dlname">{esc(r["name"])}</span>'
        f'{"<span class=dlbadge>" + esc(r["dir"]) + "</span>" if r["dir"] else ""}'
        f'<div class="dlmeta"><span class="dlpath">{esc(r["url"])}</span></div></td>'
        f'<td class="dlmeta">{_fmt_time(r["mtime"])}</td>'
        f'<td class="dlmeta">{_fmt_size(r["size"])}</td>'
        f'<td class="dlacts"><a class="dlbtn" href="{esc(r["url"])}" target="_blank" rel="noopener">打开</a>'
        f'<a class="dlbtn" href="{esc(r["url"])}?download=1">下载</a></td></tr>'
        for r in versions)


def page_task(task: str):
    if not TASK_RE.match(task or ""):
        return page_404(request.path)
    task_dir = DELIV / task
    if not task_dir.is_dir():
        row = _task_row(task)
        if not row:
            return page_404(request.path)
        return page_task_empty(task, row)
    files = _file_rows(task_dir)
    rows = "".join(
        f'<tr><td><span class="dlname">{esc(r["rel"])}</span>'
        f'<div class="dlmeta"><span class="dlpath">{esc(_url(task, r["rel"]))}</span></div></td>'
        f'<td class="dlmeta">{_fmt_time(r["mtime"])}</td>'
        f'<td class="dlmeta">{_fmt_size(r["size"])}</td>'
        f'<td class="dlacts"><a class="dlbtn" href="{_url(task, r["rel"])}" target="_blank" rel="noopener">打开</a>'
        f'<a class="dlbtn" href="{_url(task, r["rel"])}?download=1">下载</a></td></tr>'
        for r in files)
    if not rows:
        rows = '<tr><td colspan="4" class="dlempty">该任务目录为空。</td></tr>'
    latest = files[0] if files else None
    family = _family_dirs(task)
    versions = _version_rows(family)
    siblings = [p for p in family if p.name != task]
    sib_html = ""
    if siblings:
        links = "".join(
            f'<a class="dlbtn" href="{_url(p.name)}">{esc(p.name)} · {_fmt_time(_latest_mtime(p))}</a>'
            for p in siblings)
        sib_html = f"""
    <div class="dlcard">
      <div class="dlkicker">同一任务的历史目录</div>
      <h3>其它轮次</h3>
      <p style="margin:0 0 8px;color:#4b5563;font-size:13px">
        以下目录与 <span class="dlpath">{esc(task)}</span> 属于同一任务的不同轮次，按更新时间倒序；点进去同样能打开 / 下载历史 PPT。
      </p>
      <div class="dlacts">{links}</div>
    </div>"""
    body = f"""
  <div class="dlwrap">
    <div class="dlcard">
      <div class="dlkicker">任务交付 · {esc(task)}</div>
      <h2>{esc(task)}</h2>
      <p style="margin:0;color:#4b5563;font-size:13.5px;line-height:1.65">
        <a href="/deliverables/">← 返回交付中心</a> ·
        共 {len(files)} 个文件，按修改时间倒序（最新在最上面）。
        {f'当前最新：<span class="dlpath">{esc(latest["rel"])}</span>' if latest else ''}
      </p>
      {_copy_bar(task)}
    </div>

    {_guide_html()}

    {sib_html}

    <div class="dlcard" id="history">
      <div class="dlkicker">PPT / PDF 历史版本 · 不翻历史记录也能找</div>
      <h3>本任务各轮版本（{len(versions)}）</h3>
      <p style="margin:0 0 8px;color:#4b5563;font-size:13px">
        汇总 <span class="dlpath">deliverables/{esc(task)}*</span> 下所有轮次的
        <span class="dlpath">*.pptx</span> / <span class="dlpath">*.pdf</span>，按修改时间倒序；
        「打开」直接预览/下载，「下载」取回本地。下面的路径可直接复制给别人。
      </p>
      <table class="dltable">
        <thead><tr><th>文件 / 可复制路径</th><th>修改时间</th><th>大小</th><th>操作</th></tr></thead>
        <tbody>{_version_table(versions)}</tbody>
      </table>
    </div>

    <div class="dlcard">
      <div class="dlkicker">文件与历史版本</div>
      <h3>全部文件（{len(files)}）</h3>
      <table class="dltable">
        <thead><tr><th>文件 / 可复制路径</th><th>修改时间</th><th>大小</th><th>操作</th></tr></thead>
        <tbody>{rows}</tbody>
      </table>
    </div>
  </div>"""
    return _shell()("交付 · " + task, body, "tools", "任务交付物 · 历史版本", page_css=CSS)


def page_task_empty(task: str, row: dict):
    """任务存在、但还没有 deliverables/<task>/ 目录：返回 200 的说明页，而不是 404。

    帖子页的「打开本任务交付包」对所有绑定任务都会有链接；以前这类任务直接落在
    404 页，导师会以为产物丢了。这里明确告知「任务在、产物不在这个目录」，
    并直接给出同任务历史目录 / 最近产物 / PPT 生成历史入口。
    """
    family = [p for p in _family_dirs(task) if p.name != task]
    family_html = ""
    if family:
        links = "".join(
            f'<a class="dlbtn" href="{_url(p.name)}">{esc(p.name)} · {_fmt_time(_latest_mtime(p))}</a>'
            for p in family)
        family_html = f"""
    <div class="dlcard">
      <div class="dlkicker">同一任务的历史目录</div>
      <h3>产物可能在别的轮次目录里</h3>
      <div class="dlacts" style="margin-top:8px">{links}</div>
    </div>"""
    recent = sorted(_task_dirs(), key=_latest_mtime, reverse=True)[:8]
    recent_html = "".join(
        f'<tr><td><a class="dlname" href="{_url(p.name)}">{esc(p.name)}</a></td>'
        f'<td class="dlmeta">{_fmt_time(_latest_mtime(p))}</td>'
        f'<td class="dlmeta">{_task_summary(p)["files"]} 个文件</td>'
        f'<td><a class="dlbtn" href="{_url(p.name)}">打开 →</a></td></tr>'
        for p in recent)
    hist = _history_items(8)
    hrows = "".join(
        f'<tr><td class="dlname">{esc(r["name"])}</td>'
        f'<td><span class="dlbadge">{esc(r["kind"])}</span></td>'
        f'<td class="dlmeta">{_fmt_time(r["mtime"])}</td>'
        f'<td class="dlacts"><a class="dlbtn" href="{esc(r["url"])}" target="_blank" rel="noopener">打开</a>'
        f'<a class="dlbtn" href="{esc(r["url"])}?download=1">下载</a></td></tr>'
        for r in hist)
    if not hrows:
        hrows = '<tr><td colspan="4" class="dlempty">暂无 PPT 生成记录。</td></tr>'
    status = esc(row.get("status", ""))
    title = esc(row.get("title", ""))
    body = f"""
  <div class="dlwrap">
    <div class="dlcard">
      <div class="dlkicker">任务交付 · {esc(task)}</div>
      <h2>{title or esc(task)}</h2>
      <p style="margin:6px 0 0;color:#4b5563;font-size:13.5px;line-height:1.7">
        任务号 <span class="dlpath">{esc(task)}</span> 在当前看板里存在（状态：{status or "未知"}），
        但还没有 <span class="dlpath">deliverables/{esc(task)}/</span> 这个产物目录。
        <b>这不等于产物丢了</b>：本任务的产物可能登记在另一个轮次目录，或仍停留在
        <span class="dlpath">static/uploads/loomdoc-*</span> 的生成记录里。
      </p>
      {_copy_bar(task)}
    </div>

    {_guide_html()}

    {family_html}

    <div class="dlcard">
      <div class="dlkicker">最近有产物的任务</div>
      <h3>按更新时间倒序</h3>
      <table class="dltable">
        <thead><tr><th>任务</th><th>最近更新</th><th>规模</th><th></th></tr></thead>
        <tbody>{recent_html or '<tr><td colspan="4" class="dlempty">还没有任何任务产物。</td></tr>'}</tbody>
      </table>
    </div>

    <div class="dlcard">
      <div class="dlkicker">PPT 生成历史</div>
      <h3>最近生成的演示</h3>
      <table class="dltable">
        <thead><tr><th>文件</th><th>来源</th><th>时间</th><th>操作</th></tr></thead>
        <tbody>{hrows}</tbody>
      </table>
    </div>
  </div>"""
    return _shell()("交付 · " + task, body, "tools", "任务暂无产物 · 历史版本指引", page_css=CSS)


def _render_md(path: pathlib.Path) -> str:
    text = path.read_text(encoding="utf-8", errors="replace")
    try:
        import markdown as _md
        return _md.markdown(text, extensions=["tables", "fenced_code", "sane_lists", "nl2br"])
    except Exception:  # noqa: BLE001
        return "<pre>" + esc(text) + "</pre>"


def serve_file(task: str, rel: str):
    if not TASK_RE.match(task or ""):
        abort(404)
    base = (DELIV / task).resolve()
    try:
        target = (base / rel).resolve()
        target.relative_to(base)
    except (ValueError, OSError):
        abort(404)
    if not target.is_file():
        # 文件被改名/移动时，不甩一个空白 404：就在 404 页列出该任务现存文件与历史版本。
        return page_404(request.path, task=task, missing=rel)
    download = request.args.get("download") in ("1", "true", "yes")
    suffix = target.suffix.lower()
    if suffix in (".md", ".markdown") and not download:
        decoded = urllib.parse.unquote(rel)
        html_body = _render_md(target)
        body = f"""
  <div class="dlwrap">
    <div class="dlcard">
      <div class="dlkicker">交付文件 · {esc(task)}</div>
      <h2>{esc(pathlib.Path(decoded).name)}</h2>
      <div class="dlacts" style="margin:8px 0 4px">
        <a class="dlbtn" href="/deliverables/{urllib.parse.quote(task)}/">← 返回任务</a>
        <a class="dlbtn" href="{_url(task, rel)}?download=1">下载原文</a>
        <a class="dlbtn" href="/deliverables/">交付中心</a>
      </div>
      <div class="dlmd">{html_body}</div>
    </div>
  </div>"""
        return Response(_shell()("交付 · " + pathlib.Path(decoded).name, body, "tools",
                                 "Markdown 交付物", page_css=CSS), mimetype="text/html")
    return send_from_directory(str(base), rel, as_attachment=download,
                               download_name=pathlib.Path(rel).name if download else None)


def _recovery_html(task: str, missing: str = "") -> str:
    """404 时直接给出「这个任务现在到底有什么」，而不是让用户回首页猜。"""
    if not task:
        return ""
    versions = _version_rows(_family_dirs(task))
    task_dir = DELIV / task
    files = _file_rows(task_dir)[:40] if task_dir.is_dir() else []
    rows = "".join(
        f'<tr><td><span class="dlname">{esc(r["rel"])}</span>'
        f'<div class="dlmeta"><span class="dlpath">{esc(_url(task, r["rel"]))}</span></div></td>'
        f'<td class="dlmeta">{_fmt_time(r["mtime"])}</td>'
        f'<td class="dlacts"><a class="dlbtn" href="{_url(task, r["rel"])}" target="_blank" rel="noopener">打开</a>'
        f'<a class="dlbtn" href="{_url(task, r["rel"])}?download=1">下载</a></td></tr>'
        for r in files)
    files_card = f"""
    <div class="dlcard">
      <div class="dlkicker">该任务现存文件 · {esc(task)}</div>
      <h3>{'要打开的文件不在目录里' if missing else '按修改时间倒序'}</h3>
      {f'<p style="margin:0 0 8px;font-size:13px;color:#4b5563">找不到 <span class="dlpath">{esc(missing)}</span>，下面是同一任务目录里实际存在的文件。</p>' if missing else ''}
      <table class="dltable">
        <thead><tr><th>文件 / 可复制路径</th><th>修改时间</th><th>操作</th></tr></thead>
        <tbody>{rows or '<tr><td colspan="3" class="dlempty">该任务目录为空。</td></tr>'}</tbody>
      </table>
    </div>"""
    versions_card = f"""
    <div class="dlcard" id="history">
      <div class="dlkicker">PPT / PDF 历史版本</div>
      <h3>本任务各轮版本（{len(versions)}）</h3>
      <table class="dltable">
        <thead><tr><th>文件 / 可复制路径</th><th>修改时间</th><th>大小</th><th>操作</th></tr></thead>
        <tbody>{_version_table(versions)}</tbody>
      </table>
    </div>"""
    if not versions and not files:
        return ""
    parts = []
    if files:
        parts.append(files_card)
    if versions:
        parts.append(versions_card)
    return "".join(parts)


def page_404(path: str, task: str = "", missing: str = ""):
    task = task or _task_of(path)
    recovery = _recovery_html(task, missing)
    task_link = (f'<a class="dlbtn primary" href="{_url(task)}">打开 {esc(task)} 的交付页 →</a>'
                 if task else "")
    hint = (f'文件 <span class="dlpath">{esc(missing)}</span> 可能已改名或移到别的轮次目录；'
            if missing else
            '链接可能写成了仓库相对路径（如 <span class="dlpath">deliverables/t-xxxx/文件.pptx</span>），'
            '或产物已被移到新的任务目录。')
    body = f"""
  <div class="dlwrap dl404">
    <div class="dlcard">
      <div class="code">404</div>
      <h2>这个地址没有对应的交付物</h2>
      <p style="margin:6px 0 0;color:#4b5563;font-size:13.5px;line-height:1.7">
        请求的地址：<span class="dlpath">{esc(path)}</span><br>
        常见原因：{hint}产物通常没有丢，按下面入口就能找到。
      </p>
      <div class="dlacts" style="margin-top:14px">
        {task_link}
        <a class="dlbtn primary" href="/deliverables/">去交付中心找历史版本 →</a>
        <a class="dlbtn" href="/app/tools#ppt-history">AI 写 PPT / 生成历史</a>
        <a class="dlbtn" href="/app/feed">返回频道</a>
        <a class="dlbtn" href="/app">返回首页</a>
      </div>
    </div>
    {recovery}
    {_guide_html()}
  </div>"""
    return Response(_shell()("页面未找到", body, "tools", "交付物入口指引", page_css=CSS),
                    status=404, mimetype="text/html")


def _wants_json() -> bool:
    p = request.path or ""
    if p.startswith("/v1/") or p.startswith("/app/api/"):
        return True
    if request.args.get("format") == "json":
        return True
    return "application/json" in (request.headers.get("Accept") or "")


def register(app):
    def _redirect(dest: str, code: int = 302):
        qs = request.query_string.decode("utf-8", "ignore")
        if qs:
            dest += ("&" if "?" in dest else "?") + qs
        return redirect(dest, code=code)

    @app.get("/deliverables/")
    def deliverables_index():
        task = (request.args.get("task") or "").strip()
        if task:
            return redirect("/deliverables/" + urllib.parse.quote(task) + "/", code=302)
        return redirect("/app/feed", code=302)  # 交付中心与频道重复：入口统一回频道

    @app.get("/deliverables")
    def deliverables_no_slash():
        return _redirect("/deliverables/", 302)

    # 旧入口：带不带尾斜杠都要能进（t-6118ab9e 复现的 404 就是 /app/deliverables/）
    @app.get("/app/deliverables")
    @app.get("/app/deliverables/")
    def deliverables_alias():
        return _redirect("/deliverables/", 302)

    # 旧入口的深层链接（/app/deliverables/<task>/<file>）同样回落到只读挂载
    @app.get("/app/deliverables/<path:rel>")
    def deliverables_alias_deep(rel: str):
        return _redirect("/deliverables/" + urllib.parse.quote(rel, safe="/"), 302)

    @app.get("/deliverables/<task>/")
    def deliverables_task(task: str):
        return page_task(task)

    @app.get("/deliverables/<task>/<path:rel>")
    def deliverables_file(task: str, rel: str):
        return serve_file(task, rel)

    @app.errorhandler(404)
    def not_found(_e):
        if _wants_json():
            return jsonify({"ok": False, "error": "not found", "path": request.path}), 404
        return page_404(request.path)
