"""Local agent-name allocation helpers.

The center owns global uniqueness.  The local database keeps the same
case-insensitive invariant so an offline node cannot create two ``Alice``
agents while the center is unreachable.  If the center later has to rename an
agent, the durable ``agent_id`` is unchanged and the display name is updated.
"""
from __future__ import annotations

import json
import re
import secrets
from pathlib import Path
from typing import Iterable

_POOL_PATH = Path(__file__).resolve().parent / "data" / "agent_names.json"


def _load_pool() -> tuple[str, ...]:
    try:
        data = json.loads(_POOL_PATH.read_text(encoding="utf-8"))
        names = data.get("names") if isinstance(data, dict) else data
        out = tuple(str(n).strip() for n in (names or []) if str(n).strip())
        if out:
            return out
    except Exception:  # noqa: BLE001
        pass
    return ("Alice", "Alicia", "Amanda", "Amy", "Andrea", "Angela", "Anna")


AGENT_NAMES = _load_pool()
_NAME_KEYS = tuple(n.lower() for n in AGENT_NAMES)


def clean_name(value: object) -> str:
    """Strip controls and collapse whitespace; display names stay short."""
    text = re.sub(r"[\x00-\x1f\x7f]", "", str(value or ""))
    return re.sub(r"\s+", " ", text).strip()[:40]


def name_key(value: object) -> str:
    return clean_name(value).lower()


def random_name() -> str:
    return secrets.choice(AGENT_NAMES)


def _taken(conn, exclude_agent_id: str = "") -> set[str]:
    """Every human handle, Owner handle and agent name shares one namespace."""
    try:
        rows = conn.execute(
            "select id, name, owner_name from agents"
        ).fetchall()
    except Exception:  # noqa: BLE001
        return set()
    out: set[str] = set()
    for row in rows:
        try:
            aid = str(row["id"] if hasattr(row, "keys") else row[0])
            name = row["name"] if hasattr(row, "keys") else row[1]
            owner = row["owner_name"] if hasattr(row, "keys") else ""
        except Exception:  # noqa: BLE001
            continue
        if exclude_agent_id and aid == exclude_agent_id:
            # Do not block a rename to the same name, but still reserve the
            # Owner handle that belongs to this row.
            pass
        else:
            key = name_key(name)
            if key:
                out.add(key)
        okey = name_key(owner)
        if okey:
            out.add(okey)
    return out


def next_available_name(
    conn,
    preferred: str = "",
    *,
    exclude_agent_id: str = "",
    taken: Iterable[str] | None = None,
) -> tuple[str, bool]:
    """Return ``(name, renamed)``.

    A free preferred name is preserved.  On collision, walk the curated pool
    from the preferred name's position, then wrap.  A suffix is used only if
    every curated name is occupied.
    """
    preferred = clean_name(preferred)
    used = set(taken) if taken is not None else _taken(conn, exclude_agent_id)
    key = preferred.lower()
    if preferred and key not in used:
        return preferred, False

    start = -1
    try:
        start = _NAME_KEYS.index(key)
    except ValueError:
        pass
    for step in range(1, len(AGENT_NAMES) + 1):
        i = (start + step) % len(AGENT_NAMES) if start >= 0 else step - 1
        candidate = AGENT_NAMES[i]
        if candidate.lower() not in used:
            return candidate, True

    base = preferred or "Agent"
    for n in range(10_000):
        candidate = f"{base}-{n:04d}"[:40]
        if candidate.lower() not in used:
            return candidate, True
    raise RuntimeError("agent name pool exhausted")


def ensure_unique_name(conn, preferred: str, *, exclude_agent_id: str = "") -> tuple[str, bool]:
    """Convenience wrapper used by local write paths."""
    return next_available_name(conn, preferred, exclude_agent_id=exclude_agent_id)
