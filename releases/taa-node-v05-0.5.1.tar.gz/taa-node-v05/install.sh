#!/bin/sh
# TAA Node v0.5 installer.
#
# One-command path:
#   ./install.sh --home "$HOME/.taa-v05" --center "http://<center>:8788"
#
# It installs dependencies, creates a local identity if missing, then starts
# claim-ui. The browser claim is still a human action; the script prints the
# claim URL before waiting.
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"

HOME_DIR=${TAA_V05_HOME:-$HOME/.taa-v05}
CENTER=""
ALIAS=""
LANG_CODE="zh-CN"
TIMEOUT="1200"
NO_BROWSER=""
SKIP_DEPS=""
INIT_ONLY=""

usage() {
  cat <<'EOF'
TAA Node v0.5 installer

Usage:
  ./install.sh [options]

Options:
  --home DIR       local identity directory (default: $HOME/.taa-v05)
  --center URL     center base URL; enables claim-ui after init
  --alias NAME     node alias (default: hostname)
  --lang CODE      zh-CN | en (default: zh-CN)
  --timeout SEC    claim wait timeout (default: 1200)
  --no-browser     print CLAIM_URL instead of opening a browser
  --init-only      install/init only; do not claim
  --skip-deps      skip venv/pip installation (for tests)
  -h, --help       show this help
EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    --home) HOME_DIR=$2; shift 2 ;;
    --center) CENTER=$2; shift 2 ;;
    --alias) ALIAS=$2; shift 2 ;;
    --lang) LANG_CODE=$2; shift 2 ;;
    --timeout) TIMEOUT=$2; shift 2 ;;
    --no-browser) NO_BROWSER="--no-browser"; shift ;;
    --init-only) INIT_ONLY="1"; shift ;;
    --skip-deps) SKIP_DEPS="1"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [ -z "$SKIP_DEPS" ]; then
  sh "$ROOT/scripts/install_dev.sh"
fi

if [ -x "$ROOT/.venv/bin/python" ]; then
  PY="$ROOT/.venv/bin/python"
else
  PY="${TAA_BASE_PYTHON:-python3}"
fi

if [ -f "$HOME_DIR/identity.json" ]; then
  echo "AUTO_INIT=NO (identity exists: $HOME_DIR/identity.json)"
else
  echo "AUTO_INIT=YES"
  if [ -n "$ALIAS" ]; then
    "$PY" -m taa_node_v05 init --home "$HOME_DIR" --alias "$ALIAS"
  else
    "$PY" -m taa_node_v05 init --home "$HOME_DIR"
  fi
fi

if [ -n "$INIT_ONLY" ] || [ -z "$CENTER" ]; then
  if [ -z "$CENTER" ]; then
    echo "NEXT_CLAIM=python3 -m taa_node_v05 claim-ui --home $HOME_DIR --base <CENTER_URL>"
  fi
  exit 0
fi

echo "AUTO_CLAIM=YES"
echo "CENTER=$CENTER"
export PYTHONUNBUFFERED=1
"$PY" -m taa_node_v05 claim-ui \
  --home "$HOME_DIR" \
  --base "$CENTER" \
  --lang "$LANG_CODE" \
  --timeout "$TIMEOUT" \
  $NO_BROWSER
CLAIM_RC=$?

if [ "$CLAIM_RC" -eq 0 ] && [ -x "$ROOT/taa" ]; then
  if [ -n "$NO_BROWSER" ]; then
    TAA_V05_HOME="$HOME_DIR" "$ROOT/taa" start --no-open || true
  else
    TAA_V05_HOME="$HOME_DIR" "$ROOT/taa" start || true
  fi
fi

exit "$CLAIM_RC"
