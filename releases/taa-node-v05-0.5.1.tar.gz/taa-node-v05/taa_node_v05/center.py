"""Minimal HTTP client for the v0.5 center API."""
from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from typing import Any


class CenterError(RuntimeError):
    def __init__(self, status: int, body: dict[str, Any] | str):
        self.status = status
        self.body = body
        super().__init__(f"center HTTP {status}: {body}")


class CenterClient:
    def __init__(self, base: str, timeout: int = 15):
        self.base = base.rstrip("/")
        self.timeout = timeout

    def _request(self, method: str, path: str, body: dict[str, Any] | None = None,
                 token: str = "") -> dict[str, Any]:
        headers = {
            "content-type": "application/json",
            "accept": "application/json",
            "user-agent": "TAA-Node/0.5.1",
        }
        if token:
            headers["authorization"] = "Bearer " + token
        data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        req = urllib.request.Request(self.base + path, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read()
                return json.loads(raw.decode("utf-8")) if raw else {}
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode("utf-8", "ignore")
            try:
                parsed: dict[str, Any] | str = json.loads(raw)
            except json.JSONDecodeError:
                parsed = raw[:500]
            raise CenterError(exc.code, parsed) from exc
        except urllib.error.URLError as exc:
            raise CenterError(0, str(exc)) from exc

    def register_node(self, *, node_id: str, node_key: str, alias: str,
                      fingerprint_hash: str, version: str = "0.5.1",
                      enc_pubkey: str = "") -> dict[str, Any]:
        return self._request("POST", "/v05/node/register", {
            "node_id": node_id,
            "node_key": node_key,
            "alias": alias,
            "fingerprint_hash": fingerprint_hash,
            "version": version,
            "enc_pubkey": enc_pubkey,
        })

    def owner_register(self, *, username: str, password: str, email: str = "") -> dict[str, Any]:
        return self._request("POST", "/v05/owner/register", {
            "username": username, "password": password, "email": email,
        })

    def owner_login(self, *, username: str, password: str) -> dict[str, Any]:
        return self._request("POST", "/v05/owner/login", {
            "username": username, "password": password,
        })

    def claim_node(self, *, owner_token: str, claim_token: str) -> dict[str, Any]:
        return self._request("POST", "/v05/node/claim", {"claim_token": claim_token}, owner_token)

    def node_me(self, *, node_key: str) -> dict[str, Any]:
        return self._request("GET", "/v05/node/me", None, node_key)

    def refresh_claim(self, *, node_key: str) -> dict[str, Any]:
        return self._request("POST", "/v05/node/claim-token", {}, node_key)

    def heartbeat(self, *, node_key: str, endpoint: str = "", version: str = "0.5.1") -> dict[str, Any]:
        return self._request("POST", "/v05/node/heartbeat", {"endpoint": endpoint, "version": version}, node_key)

    def register_agent(self, *, node_key: str, agent_id: str, agent_key: str,
                       display_name: str) -> dict[str, Any]:
        return self._request("POST", "/v05/agent/register", {
            "agent_id": agent_id, "agent_key": agent_key, "display_name": display_name,
        }, node_key)

    def agent_me(self, *, agent_key: str) -> dict[str, Any]:
        return self._request("GET", "/v05/agent/me", None, agent_key)

    def reset_owner_password(self, *, node_id: str, node_key: str, password: str) -> dict[str, Any]:
        return self._request("POST", "/v05/owner/reset-password", {
            "node_id": node_id, "node_key": node_key, "password": password,
        })

    def lookup_agent(self, *, agent_key: str, agent_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v05/agent/lookup?agent_id={urllib.parse.quote(agent_id)}",
                             None, agent_key)

    def send_encrypted(self, *, agent_key: str, to_agent_id: str,
                       ciphertext: dict[str, Any] | str) -> dict[str, Any]:
        return self._request("POST", "/v05/agent/send", {
            "to_agent_id": to_agent_id, "ciphertext": ciphertext,
        }, agent_key)

    def inbox(self, *, agent_key: str) -> dict[str, Any]:
        return self._request("GET", "/v05/agent/inbox", None, agent_key)

    def presence(self, *, owner_token: str) -> dict[str, Any]:
        return self._request("GET", "/v05/owner/presence", None, owner_token)

    def friend_request(self, *, owner_token: str, to_owner_id: str) -> dict[str, Any]:
        return self._request("POST", "/v05/owner/friends/request",
                             {"to_owner_id": to_owner_id}, owner_token)

    def friend_approve(self, *, owner_token: str, from_owner_id: str) -> dict[str, Any]:
        return self._request("POST", "/v05/owner/friends/approve",
                             {"from_owner_id": from_owner_id}, owner_token)

    def friends(self, *, owner_token: str) -> dict[str, Any]:
        return self._request("GET", "/v05/owner/friends", None, owner_token)

    def friend_nodes(self, *, owner_token: str, owner_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v05/owner/friends/{owner_id}/nodes", None, owner_token)

    def grant_node(self, *, owner_token: str, node_id: str, grantee_owner_id: str,
                   scopes: list[str]) -> dict[str, Any]:
        return self._request("POST", "/v05/node/grant", {
            "node_id": node_id, "grantee_owner_id": grantee_owner_id, "scopes": scopes,
        }, owner_token)

    def catalog(self, *, owner_token: str, node_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v05/node/{node_id}/catalog", None, owner_token)

    def create_group(self, *, owner_token: str, name: str,
                     member_owner_ids: list[str] | None = None) -> dict[str, Any]:
        return self._request("POST", "/v05/collab/groups", {
            "name": name, "member_owner_ids": member_owner_ids or [],
        }, owner_token)

    def groups(self, *, owner_token: str) -> dict[str, Any]:
        return self._request("GET", "/v05/collab/groups", None, owner_token)

    def add_group_member(self, *, owner_token: str, group_id: str,
                         owner_id: str = "", agent_id: str = "") -> dict[str, Any]:
        body: dict[str, Any] = {"owner_id": owner_id, "agent_id": agent_id}
        return self._request("POST", f"/v05/collab/groups/{group_id}/members", body, owner_token)

    def group(self, *, owner_token: str, group_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v05/collab/groups/{group_id}", None, owner_token)
