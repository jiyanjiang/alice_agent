"""TAA direct peer transport foundation.

The peer listener is deliberately separate from the local UI port (6080).
It advertises only reachability candidates; the center remains the directory
and relay fallback. Chat payloads will be added behind a group capability
check in the next step. This module currently exposes only a harmless
reachability probe so a direct path can be tested without sending data.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import ipaddress
import json
import mimetypes
import os
import socket
import threading
import time
import urllib.parse
import urllib.request
import uuid
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from core.peer_network import candidate_endpoints, rank_endpoints

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_PORT = int(os.environ.get("TAA_PEER_PORT", "6090") or 6090)
DEFAULT_BIND = os.environ.get("TAA_PEER_BIND", "0.0.0.0") or "0.0.0.0"
_SERVER: ThreadingHTTPServer | None = None
_THREAD: threading.Thread | None = None


def _lan_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return ""
    finally:
        s.close()


def _global_ipv6() -> list[str]:
    out: list[str] = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET6):
            addr = str(info[4][0]).split("%", 1)[0]
            try:
                ip = ipaddress.ip_address(addr)
            except ValueError:
                continue
            if ip.is_global and addr not in out:
                out.append(addr)
    except OSError:
        pass
    return out


def _normalise_public(value: str) -> str:
    value = (value or "").strip().rstrip("/")
    if not value:
        return ""
    if not value.startswith(("http://", "https://")):
        value = "http://" + value
    return value


def peer_endpoints(port: int | None = None) -> list[dict[str, Any]]:
    """All reachable candidates for the dedicated peer listener, not port 6080."""
    return candidate_endpoints(port)


def _node_id() -> str:
    try:
        from taa_node_v05.identity import load_state
        home = Path(os.environ.get("TAA_V05_HOME") or os.environ.get("TAA_HOME") or "~/.taa").expanduser()
        return str(load_state(home).node.node_id or "")
    except Exception:  # noqa: BLE001
        return ""


def _version() -> str:
    for p in (ROOT / "VERSION", ROOT / "dist" / "VERSION"):
        try:
            v = p.read_text(encoding="utf-8").strip()
            if v:
                return v
        except OSError:
            pass
    return ""


def _sha256_hex(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _signature(secret: str, group_id: str, timestamp: str, raw: bytes) -> str:
    message = f"{group_id}\n{timestamp}\n{_sha256_hex(raw)}".encode("utf-8")
    return hmac.new(secret.encode("utf-8"), message, hashlib.sha256).hexdigest()


def _verify_signature(secret: str, group_id: str, timestamp: str, raw: bytes, sig: str) -> bool:
    try:
        if abs(int(time.time()) - int(timestamp)) > 300:
            return False
    except (TypeError, ValueError):
        return False
    return hmac.compare_digest(_signature(secret, group_id, timestamp, raw), sig or "")


def _ensure_peer_columns(c) -> None:
    cols = {str(r["name"]) for r in c.execute("pragma table_info(rooms)").fetchall()}
    for name, ddl in (
        ("center_group_id", "text"),
        ("center_transport_secret", "text"),
        ("center_peer_endpoints", "text"),
    ):
        if name not in cols:
            c.execute(f"alter table rooms add column {name} {ddl}")
    mcols = {str(r["name"]) for r in c.execute("pragma table_info(room_messages)").fetchall()}
    for name, ddl in (
        ("peer_message_id", "text"),
        ("client_message_id", "text"),
        ("direct_delivered", "integer default 0"),
    ):
        if name not in mcols:
            c.execute(f"alter table room_messages add column {name} {ddl}")
    c.execute("create unique index if not exists ux_room_messages_peer on room_messages(room_id, peer_message_id) where peer_message_id is not null")
    c.execute("create unique index if not exists ux_room_messages_client on room_messages(room_id, client_message_id) where client_message_id is not null")
    c.commit()


def _room_for_group(c, gid: str):
    return c.execute("select * from rooms where center_group_id=? limit 1", (gid,)).fetchone()


def _ensure_remote_agent(c, *, owner_id: str, agent_id: str, agent_name: str, node_id: str) -> str:
    if agent_id and c.execute("select 1 from agents where id=?", (agent_id,)).fetchone():
        return agent_id
    if agent_id:
        full = f"{agent_name or agent_id}@center"
        c.execute("insert or ignore into agents(id,name,kind,node_id,full_name,role,persona_json,status) "
                  "values(?,?, 'ai', NULL, ?, 'executor', '{}', 'idle')",
                  (agent_id, (agent_name or agent_id)[:80], full))
        c.execute("update agents set name=?, status='idle' where id=?", ((agent_name or agent_id)[:80], agent_id))
        return agent_id
    local = "remote-human-" + owner_id
    if not c.execute("select 1 from agents where id=?", (local,)).fetchone():
        c.execute("insert or ignore into agents(id,name,kind,node_id,full_name,role,persona_json,status) "
                  "values(?,?, 'human', NULL, NULL, 'executor', '{}', 'active')",
                  (local, (owner_id or "remote")[:80]))
    return local


def _decode_attachments(raw: Any) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    if not isinstance(raw, list):
        return out
    base = ROOT / "static" / "uploads"
    base.mkdir(parents=True, exist_ok=True)
    for item in raw[:9]:
        if not isinstance(item, dict):
            continue
        try:
            data = base64.b64decode(str(item.get("data") or ""), validate=True)
        except Exception:
            continue
        if not data or len(data) > 6 * 1024 * 1024:
            continue
        ext = mimetypes.guess_extension(str(item.get("mime") or "")) or Path(str(item.get("name") or "")).suffix or ".bin"
        if ext.lower() not in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bin"}:
            ext = ".bin"
        name = f"peer-{uuid.uuid4().hex}{ext}"
        (base / name).write_bytes(data)
        out.append({"url": "/static/uploads/" + name, "name": str(item.get("name") or name)[:120]})
    return out


def _read_json(handler: BaseHTTPRequestHandler, limit: int = 10 * 1024 * 1024) -> tuple[bytes, dict[str, Any]]:
    try:
        size = int(handler.headers.get("content-length") or "0")
    except ValueError:
        size = 0
    if size <= 0 or size > limit:
        raise ValueError("bad_content_length")
    raw = handler.rfile.read(size)
    data = json.loads(raw.decode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError("bad_json")
    return raw, data


def post_direct_group_message(*, group_id: str, secret: str, endpoints: list[dict[str, str]],
                              payload: dict[str, Any], timeout: float = 2.0) -> dict[str, Any]:
    """Push one already-created local message to peer endpoints.

    Returns attempted/ok counts; callers must fall back to the center when any
    remote endpoint fails, so a partially delivered message is not silently lost.
    """
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    ts = str(int(time.time()))
    sig = _signature(secret, group_id, ts, raw)
    attempted = 0
    ok = 0
    errors: list[str] = []
    seen: set[str] = set()
    for ep in rank_endpoints(endpoints or []):
        if isinstance(ep, str):
            ep = {"kind": "peer", "url": ep}
        if not isinstance(ep, dict):
            continue
        url = str(ep.get("url") or "").rstrip("/")
        if not url or url in seen:
            continue
        seen.add(url)
        if ep.get("kind") == "peer-loopback":
            continue
        attempted += 1
        target = url + "/peer/v1/groups/" + urllib.parse.quote(group_id, safe="") + "/messages"
        req = urllib.request.Request(target, data=raw, method="POST", headers={
            "content-type": "application/json",
            "x-taa-group": group_id,
            "x-taa-timestamp": ts,
            "x-taa-signature": sig,
            "user-agent": "TAA-Peer/1",
        })
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                if 200 <= resp.status < 300:
                    ok += 1
                else:
                    errors.append(f"{url}: HTTP {resp.status}")
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{url}: {type(exc).__name__}")
    return {"attempted": attempted, "ok": ok, "errors": errors, "ok_all": attempted > 0 and ok == attempted}


class _Handler(BaseHTTPRequestHandler):
    server_version = "TAA-Peer/1"

    def _json(self, status: int, obj: dict[str, Any]) -> None:
        raw = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("content-length", str(len(raw)))
        self.send_header("cache-control", "no-store")
        self.send_header("x-taa-peer", "1")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(raw)

    def do_HEAD(self) -> None:  # noqa: N802
        self.do_GET()

    def do_GET(self) -> None:  # noqa: N802
        if self.path.split("?", 1)[0] in ("/peer/v1/ping", "/peer/v1/health"):
            self._json(200, {
                "ok": True, "service": "taa-peer", "proto": 1,
                "node_id": _node_id(), "version": _version(),
                "time": int(time.time()),
            })
            return
        self._json(404, {"ok": False, "error": "not_found"})

    def do_POST(self) -> None:  # noqa: N802
        path = self.path.split("?", 1)[0]
        if not path.startswith("/peer/v1/groups/") or not path.endswith("/messages"):
            self._json(404, {"ok": False, "error": "not_found"})
            return
        gid = urllib.parse.unquote(path[len("/peer/v1/groups/"):-len("/messages")].strip("/"))
        if not gid or len(gid) > 80:
            self._json(400, {"ok": False, "error": "bad_group"})
            return
        try:
            raw, data = _read_json(self)
        except Exception as exc:
            self._json(400, {"ok": False, "error": str(exc)})
            return
        from core import db as db_mod
        c = db_mod.connect()
        try:
            _ensure_peer_columns(c)
            room = _room_for_group(c, gid)
            if not room:
                self._json(404, {"ok": False, "error": "group_not_local"})
                return
            secret = str(room["center_transport_secret"] or "")
            ts = str(self.headers.get("x-taa-timestamp") or "")
            sig = str(self.headers.get("x-taa-signature") or "")
            if not secret or not _verify_signature(secret, gid, ts, raw, sig):
                self._json(403, {"ok": False, "error": "bad_signature"})
                return
            body = str(data.get("body") or "").strip()
            if not body:
                self._json(400, {"ok": False, "error": "body_required"})
                return
            if len(body) > 4000:
                self._json(413, {"ok": False, "error": "body_too_long"})
                return
            owner_id = str(data.get("owner_id") or "")[:80]
            node_id = str(data.get("node_id") or "")[:80]
            agent_id = str(data.get("agent_id") or "")[:80]
            agent_name = str(data.get("agent_name") or "")[:80]
            client_id = str(data.get("client_message_id") or "")[:120]
            if not owner_id or not node_id:
                self._json(400, {"ok": False, "error": "identity_required"})
                return
            local_agent = _ensure_remote_agent(c, owner_id=owner_id, agent_id=agent_id,
                                               agent_name=agent_name, node_id=node_id)
            created = str(data.get("created_at") or "").replace("T", " ")[:19]
            if not created:
                created = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            rnd = int(room["current_round"] or 1)
            attachments = _decode_attachments(data.get("attachments"))
            att_json = json.dumps(attachments, ensure_ascii=False) if attachments else None
            cur = c.execute(
                "insert or ignore into room_messages(room_id,round,agent_id,body,kind,source,created_at,"
                "attachment,peer_message_id,client_message_id) values(?,?,?,?, 'assertion','peer',?,?,?,?)",
                (room["id"], rnd, local_agent, body[:4000], created, att_json,
                 client_id or ("peer-" + uuid.uuid4().hex), client_id or None),
            )
            c.commit()
            self._json(200, {"ok": True, "room_id": room["id"], "inserted": bool(cur.rowcount),
                             "message_id": cur.lastrowid})
        except Exception as exc:  # noqa: BLE001
            try:
                c.rollback()
            except Exception:
                pass
            self._json(500, {"ok": False, "error": f"{type(exc).__name__}: {exc}"})
        finally:
            c.close()

    def log_message(self, fmt: str, *args: Any) -> None:
        # Keep the local log quiet unless probing fails.
        return


def start_peer_server(*, port: int | None = None, bind: str | None = None) -> dict[str, Any]:
    global _SERVER, _THREAD
    if os.environ.get("TAA_PEER_DISABLE") == "1":
        return {"ok": False, "disabled": True}
    if _SERVER is not None:
        return {"ok": True, "host": _SERVER.server_address[0], "port": _SERVER.server_address[1]}
    p = int(port or DEFAULT_PORT)
    host = (bind or DEFAULT_BIND).strip() or "0.0.0.0"
    try:
        srv = ThreadingHTTPServer((host, p), _Handler)
    except OSError as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}", "host": host, "port": p}
    srv.daemon_threads = True
    _SERVER = srv
    _THREAD = threading.Thread(target=srv.serve_forever, name="taa-peer-server", daemon=True)
    _THREAD.start()
    return {"ok": True, "host": host, "port": p, "endpoints": peer_endpoints(p)}


def stop_peer_server() -> None:
    global _SERVER, _THREAD
    if _SERVER is None:
        return
    try:
        _SERVER.shutdown()
    except Exception:  # noqa: BLE001
        pass
    try:
        _SERVER.server_close()
    except Exception:  # noqa: BLE001
        pass
    _SERVER = None
    _THREAD = None
